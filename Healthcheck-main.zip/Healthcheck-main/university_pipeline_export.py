"""Excel export for the University Pipeline page - exactly what the page is
showing for the year / Intake tab / Application Manager / Intake Month it is
filtered to. Two worksheets:

- "Summary": a few lines saying which filters were applied, then one row per
  University in the page chart's order with the chart's own figures (Pending
  Assessment / Offer / Enrolment, Enrolled This Intake, Lost, Total, Forecast,
  Conversion, average Offer Days) plus "All Stages Total", the University's
  share of the page's Overall Apps card (the chart leaves out 02-PendingQA and
  03-PendingSubmission; this column does not).
- "Applications": every application behind those numbers - one row each,
  in pipeline stage (Status) order, then University, then Student Name - with
  the Status cell coloured like the other exports.

No filtering happens in here; the caller passes the already-filtered rows."""

import io
import math

import openpyxl
from openpyxl.styles import Font
from openpyxl.utils import get_column_letter

from excel_export_helpers import apply_column_widths, safe_append_row
from just_jon_export import _STATUS_FILLS, _STATUS_FONT
from pipeline import STAGES

SUMMARY_SHEET = "Summary"
APPLICATIONS_SHEET = "Applications"

# (header, key of the figure on a summary row)
SUMMARY_COLUMNS = [
    ("University", "university"),
    ("Pending Assessment", "pending_assessment"),
    ("Pending Offer", "pending_offer"),
    ("Pending Enrolment", "pending_enrolment"),
    ("Enrolled This Intake", "enrolled_this_intake"),
    ("Lost", "lost"),
    ("Total", "total"),
    ("Forecast", "forecast"),
    ("Conversion %", "conversion"),
    ("Avg Days Pending Assessment", "avg_pending_assessment"),
    ("Avg Days Pending Offer", "avg_pending_offer"),
    ("All Stages Total", "all_stages_total"),
]
SUMMARY_HEADER_ROW = 5

APPLICATION_COLUMNS = [
    "Student Code",
    "Student Name",
    "University Name",
    "Course Name",
    "Intake",
    "Consultant",
    "Application Manager",
    "Status",
]

_STAGE_ORDER = {stage: index for index, stage in enumerate(STAGES)}


def _university(row):
    return (row.get("University Name") or "").strip() or "Unassigned"


def build_summary_rows(chart_groups, report, average_offer_days):
    """One dict per University, in the page chart's order. `chart_groups` is
    pipeline.build_stage_group_chart_groups() for the filtered rows, `report`
    the University build_pipeline_report() and `average_offer_days` the
    offer_days.build_university_average_age_by_group() result - the very
    objects the page renders, so the sheet can't drift from the page."""
    all_stages_total = {m["name"]: m["total"] for group in report["office_groups"] for m in group["managers"]}
    summary = []
    for group in chart_groups:
        for row in group["rows"]:
            counts = {segment["key"]: segment["count"] for segment in row["segments"]}
            average = average_offer_days.get(row["name"]) or {}

            def days(key):
                value = average.get(key)
                return None if value is None else math.ceil(value)

            summary.append(
                {
                    "university": row["name"],
                    "pending_assessment": counts.get("pending_assessment", 0),
                    "pending_offer": counts.get("pending_offer", 0),
                    "pending_enrolment": counts.get("pending_enrolment", 0),
                    "enrolled_this_intake": counts.get("enrolled_this_intake", 0),
                    "lost": counts.get("lost", 0),
                    "total": row["total"],
                    "forecast": row["forecast"],
                    "conversion": row["conversion"],
                    "avg_pending_assessment": days("pending_assessment"),
                    "avg_pending_offer": days("pending_offer"),
                    "all_stages_total": all_stages_total.get(row["name"], 0),
                }
            )
    return summary


def _sort_applications(rows):
    """Pipeline stage order first (02-PendingQA ... 10-Lost), then University,
    then Student Name."""
    return sorted(
        rows,
        key=lambda row: (
            _STAGE_ORDER.get((row.get("Status") or "").strip(), len(_STAGE_ORDER)),
            _university(row).lower(),
            (row.get("Student Name") or "").strip().lower(),
        ),
    )


def application_rows(rows):
    """The applications behind the page's numbers: every row whose Status is a
    pipeline stage (the same rule the Overall Apps card counts by)."""
    return [row for row in rows if (row.get("Status") or "").strip() in _STAGE_ORDER]


def _write_summary(ws, title, filter_lines, overall_line, summary_rows):
    bold = Font(bold=True)
    ws["A1"] = title
    ws["A1"].font = Font(bold=True, size=14)
    ws["A2"] = filter_lines
    ws["A3"] = overall_line
    for column, (header, _) in enumerate(SUMMARY_COLUMNS, start=1):
        cell = ws.cell(row=SUMMARY_HEADER_ROW, column=column, value=header)
        cell.font = bold
    for row in summary_rows:
        safe_append_row(ws, [row[key] if row[key] is not None else "" for _, key in SUMMARY_COLUMNS])
    ws.freeze_panes = f"B{SUMMARY_HEADER_ROW + 1}"
    ws.auto_filter.ref = f"A{SUMMARY_HEADER_ROW}:{get_column_letter(len(SUMMARY_COLUMNS))}{SUMMARY_HEADER_ROW}"
    apply_column_widths(ws, [header for header, _ in SUMMARY_COLUMNS])
    ws.column_dimensions["A"].width = 32


def _write_applications(ws, rows):
    ws.append(APPLICATION_COLUMNS)
    for cell in ws[1]:
        cell.font = Font(bold=True)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(APPLICATION_COLUMNS))}1"
    status_col = APPLICATION_COLUMNS.index("Status") + 1
    for row in _sort_applications(rows):
        status = (row.get("Status") or "").strip()
        safe_append_row(
            ws,
            [
                row.get("Student Code") or "",
                row.get("Student Name") or "",
                _university(row),
                row.get("Course Name") or "",
                row.get("Intake") or "",
                row.get("Consultant") or "",
                (row.get("Application") or "").strip() or "Unassigned",
                status,
            ],
        )
        fill = _STATUS_FILLS.get(status)
        if fill is not None:
            cell = ws.cell(row=ws.max_row, column=status_col)
            cell.fill = fill
            cell.font = _STATUS_FONT
    apply_column_widths(ws, APPLICATION_COLUMNS)


def build_university_pipeline_export(rows, summary_rows, title, filter_lines, overall_line):
    """The export workbook as an in-memory buffer. `rows` are the filtered
    application rows (see application_rows()), `summary_rows` come from
    build_summary_rows(), and the three strings are the Summary sheet's
    heading lines."""
    workbook = openpyxl.Workbook()
    summary_ws = workbook.active
    summary_ws.title = SUMMARY_SHEET
    _write_summary(summary_ws, title, filter_lines, overall_line, summary_rows)
    _write_applications(workbook.create_sheet(APPLICATIONS_SHEET), application_rows(rows))

    buffer = io.BytesIO()
    workbook.save(buffer)
    buffer.seek(0)
    return buffer


def _clean(text):
    return "".join(ch if ch.isalnum() else "-" for ch in text.strip()).strip("-")


def export_filename(today, year, intake_bucket_label=None, manager=None, statuses=(), month_labels=(), consultant=None, office=None):
    """University_Pipeline_2026[_Intake03][_<office>][_<manager>][_<consultant>][_<status>][_Sep-Oct]_dd-mm-yyyy.xlsx
    - the filters applied are in the name so downloads don't overwrite each
    other. Office, Manager and Consultant are reduced to letters, digits and hyphens; one Status
    appears in full ("05-Assessment"), several as their numbers
    ("Status05-06-09"); months are their 3-letter names."""
    parts = ["University_Pipeline", str(year)]
    if intake_bucket_label:
        parts.append(intake_bucket_label.replace(" ", ""))
    if office:
        parts.append(_clean(office) or "Office")
    if manager:
        parts.append(_clean(manager) or "Manager")
    if consultant:
        parts.append(_clean(consultant) or "Consultant")
    statuses = list(statuses or ())
    if len(statuses) == 1:
        parts.append(_clean(statuses[0]) or "Status")
    elif statuses:
        parts.append("Status" + "-".join(_clean(status).split("-")[0] or "x" for status in statuses))
    if month_labels:
        parts.append("-".join(label.split()[0][:3] for label in month_labels))
    return "_".join(parts) + f"_{today.strftime('%d-%m-%Y')}.xlsx"
