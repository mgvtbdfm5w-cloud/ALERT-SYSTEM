"""Interviews page logic: the operational business days (Today, Tomorrow and the
three after) and grouping.

Interviews are read live from whatever the current active dataset is - no
separate interviews data is stored, so a new upload/reprocess is reflected
automatically the next time this page is loaded.
"""

from datetime import timedelta

from dateutils import safe_date, today_uk

# Weekday indices per date.weekday(): Monday=0 ... Sunday=6
_SATURDAY, _SUNDAY = 5, 6
_FRIDAY = 4


def get_operational_days(reference_date=None, count=5):
    """The next `count` business days as date objects, starting with
    "today" per the operational calendar - the days the Interviews page lists.

    Interviews are treated as a Monday-Friday operation: a weekend rolls
    forward to Monday (so on a Saturday or Sunday "today" is Monday), and the
    day after a Friday is the following Monday. So there are always `count`
    business days: from a Monday, Mon-Fri; from a Friday, that Friday then the
    next Mon-Thu.
    """
    if reference_date is None:
        reference_date = today_uk()

    day = reference_date
    while day.weekday() in (_SATURDAY, _SUNDAY):
        day += timedelta(days=1)

    days = [day]
    while len(days) < count:
        day += timedelta(days=1)
        if day.weekday() not in (_SATURDAY, _SUNDAY):
            days.append(day)
    return days


def get_operational_dates(reference_date=None):
    """Return (today, tomorrow) as date objects, per the operational calendar -
    the first two of get_operational_days()."""
    days = get_operational_days(reference_date, count=2)
    return days[0], days[1]


def day_label(index, day):
    """What the Interviews page calls the `index`-th business day (0 = first):
    "Today", "Tomorrow", then the weekday name ("Wednesday")."""
    if index == 0:
        return "Today"
    if index == 1:
        return "Tomorrow"
    return day.strftime("%A")


# Students who are QA Rejected, or past the interview stage - Pre-Enrolled,
# Enrolled and Lost - are never listed on the Interviews page, even when an
# Interview Date is still recorded against them. These are Status values as
# produced by the status lookup (see pipeline.STAGES and
# pipeline.QA_REJECTED_STATUS).
EXCLUDED_INTERVIEW_STATUSES = frozenset({"00-QARejected", "08-Pre-Enrolled", "09-Enrolled", "10-Lost"})


def _application_label(value):
    if value and str(value).strip():
        return str(value).strip()
    return "Unassigned"


def build_interview_groups(rows, target_date):
    """Return rows with Interview Date == target_date, grouped and sorted.

    Each result item is {"application": label, "students": [row, ...]}.
    Groups are sorted alphabetically by application label; students within
    a group are sorted alphabetically by Student Name. Rows with a blank,
    invalid, or malformed Interview Date are simply excluded, never raised,
    and so are rows whose Status is in EXCLUDED_INTERVIEW_STATUSES.
    """
    matches = []
    for row in rows:
        if (row.get("Status") or "").strip() in EXCLUDED_INTERVIEW_STATUSES:
            continue
        interview_date = safe_date(row.get("Interview Date"))
        if interview_date == target_date:
            matches.append(row)

    groups = {}
    for row in matches:
        label = _application_label(row.get("Application"))
        groups.setdefault(label, []).append(row)

    result = []
    for label in sorted(groups.keys(), key=lambda s: s.lower()):
        students = sorted(groups[label], key=lambda r: (r.get("Student Name") or "").lower())
        result.append({"application": label, "students": students})
    return result


def interview_window_rows(rows, days):
    """The rows with an Interview Date on one of `days` that are not in
    EXCLUDED_INTERVIEW_STATUSES - everything the page could list, before any
    filter. The filters' options are drawn from these."""
    wanted = set(days)
    return [
        row
        for row in rows
        if (row.get("Status") or "").strip() not in EXCLUDED_INTERVIEW_STATUSES and safe_date(row.get("Interview Date")) in wanted
    ]
