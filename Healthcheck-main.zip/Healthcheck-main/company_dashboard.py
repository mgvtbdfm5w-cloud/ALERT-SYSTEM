"""Company Dashboard calculation logic: nine top-level number tiles for an
at-a-glance company health snapshot.

Four tiles are month-scoped (Leads Generated, Docs Approved, QA Passed,
Submitted to University) and follow this page's own month filter. The
other five (Pending Assessment, Pending Offer, Pending Enrolment,
Enrolled This Intake, Enrolled This Year) are live/point-in-time
figures, unaffected by that filter - the same convention KPI's Pipeline
Backlog boxes already use for a live snapshot independent of that page's
selected month.

Every figure here reuses that same number's own page's existing
calculation rather than recomputing anything fresh, so a Company
Dashboard tile can never disagree with what that page shows for the same
period:
  - Leads Generated: leads_dashboard.filter_by_creation_month/build_month_summary
  - Docs Approved / Submitted to University: submissions.build_daily_matrix
  - QA Passed: kpi.build_kpi_report
  - Pending Assessment/Offer/Enrolment: pipeline.count_by_stage, scoped to
    Intake 03 2026 only (see PENDING_TILES_INTAKE_YEAR/
    PENDING_TILES_INTAKE_BUCKET) and deduplicated to one row per Student
    Code (pipeline.resolve_pipeline_rows_by_student) - a live application
    always wins over a 10-Lost one for the same student, and a student
    applying to several courses only counts once
  - Enrolled This Intake (and its Enrolled by Office breakdown):
    pipeline.filter_by_intake_year

An Offer Days average-age tile used to live here too (see
offer_days.average_age_days, still defined and tested there in case it's
wanted again) - removed as its own Company Dashboard section for now.
"""

from calendar import monthrange

from dateutils import safe_date
from kpi import build_kpi_report, classify_status
from leads_dashboard import build_month_summary, filter_by_creation_month
from pipeline import (
    PIPELINE_INTAKE_YEAR,
    count_by_stage,
    filter_by_intake_bucket,
    filter_by_intake_year,
    resolve_pipeline_rows_by_student,
    round_half_up,
)
from processing import parse_stage_length_days
from submissions import build_daily_matrix
from submissions import list_available_months as _list_date_field_months

# The live pipeline, split into 3 tiles by Status - together with the
# Doc Check/QA/Submitting boxes on the KPI page's own Pipeline Backlog
# section (Statuses 01-NewApp/02-PendingQA/03-PendingSubmission), these
# cover every stage between submission and a final outcome
# (09-Enrolled/10-Lost/00-QARejected/11-Deferred aren't counted in any
# of the 3 - they're already resolved, not still pending).
PENDING_ASSESSMENT_STAGES = ("04-Onboarding", "05-Assessment")
PENDING_OFFER_STAGES = ("06-Decision",)
PENDING_ENROLMENT_STAGES = ("07-Ready", "08-Pre-Enrolled")

# The 3 Pending tiles are scoped to Intake 03 2026 (July-December 2026)
# only, not every Intake year/month - the CRM migration means Jan-Jun
# 2026 has no reliable live pipeline data in this app at all (see the
# Enrolled page's manual Intake 01/02 backfill for that half of the
# year instead), so this app's own live pipeline data effectively starts
# at Intake 03 2026. Deliberately a fixed year/bucket, not tied to
# PIPELINE_INTAKE_YEAR or "the current month" - unlike that migration
# quirk, 2027 onwards has no such gap, so these tiles are not expected to
# need to move forward every year.
PENDING_TILES_INTAKE_YEAR = 2026
PENDING_TILES_INTAKE_BUCKET = "intake_03"

# Fixed monthly targets for the 4 month-scoped tiles - colour-coded with
# kpi.classify_status()'s same 3-tier ratio rule every Sales Office/
# Company KPI card already uses (below 80% of target red, 80-99% yellow,
# 100%+ green), so this can never disagree with how the KPI page itself
# colours the exact same kind of Actual-vs-Target figure.
MONTH_TILE_TARGETS = {
    "leads_generated": 6000,
    "docs_approved": 400,
    "qa_passed": 400,
    "submitted_to_uni": 400,
}


def list_available_months(rows, leads_rows):
    """Union of every distinct (year, month) with at least one row on any
    of the four month-scoped tiles' own date fields (Current Data's Docs
    Approved/QA Passed/Submitted To Uni, or the Leads dataset's own
    Creation Date) - the Company Dashboard's month filter only offers a
    month if at least one tile actually has something to show for it."""
    months = set()
    for date_field in ("Docs Approved", "QA Passed", "Submitted To Uni"):
        months.update(_list_date_field_months(rows, date_field=date_field))
    months.update(_list_date_field_months(leads_rows, date_field="Creation Date"))
    return sorted(months, key=lambda ym: (-ym[0], -ym[1]))


def month_progress(year, month, today):
    """Return {"day", "days_in_month", "pct"} - how far through the
    selected (year, month) `today` is, shown next to the Month filter so
    the 4 month-scoped tiles' figures can be read in context (e.g. "Day
    21 of 30 (70%)" makes clear there's more to come, not a final
    total). A month other than `today`'s own is either fully in the past
    (day = days_in_month, 100% - every day-scoped tile for it is already
    complete) or hasn't started yet (day = 0, 0%); only the current
    month lands strictly between the two."""
    days_in_month = monthrange(year, month)[1]
    if (year, month) < (today.year, today.month):
        day = days_in_month
    elif (year, month) > (today.year, today.month):
        day = 0
    else:
        day = today.day
    pct = round(day / days_in_month * 100, 1)
    return {"day": day, "days_in_month": days_in_month, "pct": pct}


def build_month_scoped_tiles(rows, leads_rows, year, month, company_target=None):
    """The four month-scoped tiles' values for (year, month) - see the
    module docstring for which existing page/calculation backs each one.

    company_target (int or None, same "not set" semantics as the KPI
    page's own Company Target - see kpi.build_kpi_report) is the
    Admin-editable KPI target for (year, month), passed in by the
    caller rather than looked up here (this module has no DB access of
    its own). Applications Approved also gets "qa_passed_target"/
    "qa_passed_achievement_pct"/"qa_passed_status" alongside its plain
    "qa_passed" actual count - the exact same Company entry the KPI
    page's own Overall card shows for this month, reused rather than
    recomputed, so the two can never disagree (including which of
    red/yellow/green it's classified as - "qa_passed_status" replaces
    classify_month_tile()'s fixed-400-target classification for this one
    tile, so the tile's own colour always matches the ratio it's
    displaying). None when no Company Target is set for the month, same
    as the KPI page's own "Target Not Set" state."""
    leads_generated = build_month_summary(filter_by_creation_month(leads_rows, year, month))["total"]
    docs_approved = build_daily_matrix(rows, year, month, date_field="Docs Approved", person_field="QA")[
        "grand_total"
    ]
    qa_passed_company_entry = build_kpi_report(rows, year, month, {}, company_target)["company"]
    submitted_to_uni = build_daily_matrix(
        rows, year, month, date_field="Submitted To Uni", person_field="Support"
    )["grand_total"]
    return {
        "leads_generated": leads_generated,
        "docs_approved": docs_approved,
        "qa_passed": qa_passed_company_entry["actual"],
        "qa_passed_target": qa_passed_company_entry["target"],
        "qa_passed_achievement_pct": qa_passed_company_entry["achievement_pct"],
        "qa_passed_status": qa_passed_company_entry["status"],
        "submitted_to_uni": submitted_to_uni,
    }


def classify_month_tile(tile_key, actual):
    """Red/yellow/green for one of the 4 month-scoped tiles against its
    fixed monthly target (see MONTH_TILE_TARGETS) - None if `tile_key`
    has no target (nothing to classify), same "not set" convention as
    kpi.classify_status()."""
    return classify_status(actual, MONTH_TILE_TARGETS.get(tile_key))


def _average_stage_length_days(rows_for_stage):
    """Average Stage Length (calendar days, rounded to 1 decimal place)
    across whichever of `rows_for_stage` have a parseable Stage Length -
    None if none do. Same convention as kpi.py's Pipeline Backlog boxes
    (_backlog_box_result), reused here for Pending Assessment/Offer."""
    day_total = 0
    day_sample_count = 0
    for row in rows_for_stage:
        days = parse_stage_length_days(row.get("Stage Length"))
        if days is not None:
            day_total += days
            day_sample_count += 1
    return round_half_up(day_total / day_sample_count, decimals=1) if day_sample_count else None


def build_pipeline_stage_tiles(rows):
    """Live counts for the 3 pipeline-progress tiles - Pending
    Assessment/Offer/Enrolment - each summing pipeline.count_by_stage()'s
    per-Status counts over a fixed group of Statuses (see
    PENDING_ASSESSMENT_STAGES/PENDING_OFFER_STAGES/
    PENDING_ENROLMENT_STAGES), so every application currently at one of
    these stages is counted in exactly one tile and this can never
    disagree with a Status count shown elsewhere in the app.

    Scoped to Intake 03 2026 only (see PENDING_TILES_INTAKE_YEAR/
    PENDING_TILES_INTAKE_BUCKET), then deduplicated to one row per
    Student Code via pipeline.resolve_pipeline_rows_by_student() - the
    same "a student applying to several courses is one prospect, not one
    per course" rule the Dashboard's own Application Manager/Consultant
    Pipeline reports already use. A student with an open application in
    one course and a 10-Lost one in another isn't double-counted or
    mistakenly dropped: resolve_pipeline_rows_by_student() always keeps
    the open one over the Lost one for the same student.

    Pending Assessment and Pending Offer also get an average_days figure
    (see _average_stage_length_days) - how long, on average, an
    application in that group has been sitting there. Pending Enrolment
    doesn't get one (not asked for)."""
    scoped_rows = filter_by_intake_bucket(
        filter_by_intake_year(rows, PENDING_TILES_INTAKE_YEAR), PENDING_TILES_INTAKE_BUCKET
    )
    deduped_rows = resolve_pipeline_rows_by_student(scoped_rows)

    stage_counts, _ = count_by_stage(deduped_rows)
    pending_assessment_rows = [
        row for row in deduped_rows if (row.get("Status") or "").strip() in PENDING_ASSESSMENT_STAGES
    ]
    pending_offer_rows = [row for row in deduped_rows if (row.get("Status") or "").strip() in PENDING_OFFER_STAGES]
    return {
        "pending_assessment": sum(stage_counts[s] for s in PENDING_ASSESSMENT_STAGES),
        "pending_assessment_average_days": _average_stage_length_days(pending_assessment_rows),
        "pending_offer": sum(stage_counts[s] for s in PENDING_OFFER_STAGES),
        "pending_offer_average_days": _average_stage_length_days(pending_offer_rows),
        "pending_enrolment": sum(stage_counts[s] for s in PENDING_ENROLMENT_STAGES),
    }


def count_enrolled_this_intake(rows, intake_year=PIPELINE_INTAKE_YEAR):
    """Total 09-Enrolled rows for `intake_year` - the Intake field's own
    label (e.g. "September 2026"), matching the population the Enrolled
    page's year tab for that year shows. Defaults to the app's current
    default Intake Year (pipeline.PIPELINE_INTAKE_YEAR).

    Deliberately a different cut from count_enrolled_this_calendar_year()
    below - a student's Intake Year and the real calendar date they
    enrolled on don't have to be the same year (e.g. an Intake 2027
    student enrolling early, in December 2026)."""
    year_rows = filter_by_intake_year(rows, intake_year)
    return sum(1 for row in year_rows if (row.get("Status") or "").strip() == "09-Enrolled")


def build_enrolled_by_office(rows, intake_year=PIPELINE_INTAKE_YEAR):
    """Enrolled This Intake's own total (see count_enrolled_this_intake),
    broken down by Sales Office - [{"office", "count"}, ...] sorted
    alphabetically (case-insensitive), same convention as the Sales
    Office ordering on the KPI/Dashboard pages. A row with no Sales
    Office is excluded from the breakdown (nowhere sensible to attribute
    it - no fake "Unassigned" office is fabricated), so the office totals
    can add up to less than count_enrolled_this_intake()'s own total, but
    never more."""
    year_rows = filter_by_intake_year(rows, intake_year)
    counts = {}
    for row in year_rows:
        if (row.get("Status") or "").strip() != "09-Enrolled":
            continue
        office = (row.get("Sales Office") or "").strip()
        if not office:
            continue
        counts[office] = counts.get(office, 0) + 1
    return [{"office": office, "count": counts[office]} for office in sorted(counts, key=str.lower)]


def count_enrolled_this_calendar_year(rows, calendar_year, manual_backfill_total=0):
    """Total 09-Enrolled rows whose real Enrolled Date falls in
    `calendar_year` - see count_enrolled_this_intake()'s docstring for how
    this differs from the Intake-Year cut.

    `manual_backfill_total` adds on the CRM-migration-era manual Intake
    01/02 backfill total from the Consultant Lookup table (Admin page) -
    the same figure the Enrolled page's own "Total" card for 2026 uses
    (see app.py's enrolled() route). Those enrolments genuinely happened
    in the first half of calendar 2026, but predate this app's own
    Enrolled Date data entirely, so they can never be found by scanning
    `rows` here - the caller is responsible for only passing a nonzero
    total when `calendar_year` is 2026, since that backfill has no
    meaning for any other year."""
    count = 0
    for row in rows:
        if (row.get("Status") or "").strip() != "09-Enrolled":
            continue
        d = safe_date(row.get("Enrolled Date"))
        if d and d.year == calendar_year:
            count += 1
    return count + manual_backfill_total
