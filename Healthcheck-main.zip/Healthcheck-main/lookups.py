import sqlite3

from db import fits_sqlite_integer


class DuplicateLookupError(Exception):
    pass


class LookupValidationError(Exception):
    pass


def list_lookup_rows(conn, table_name):
    return conn.execute(
        "SELECT * FROM lookup_tables WHERE table_name = ? ORDER BY source_value COLLATE NOCASE",
        (table_name,),
    ).fetchall()


def _has_duplicate(conn, table_name, source_value, exclude_id=None):
    key = source_value.strip().lower()
    query = "SELECT id FROM lookup_tables WHERE table_name = ? AND lower(source_value) = ?"
    params = [table_name, key]
    if exclude_id is not None:
        query += " AND id != ?"
        params.append(exclude_id)
    return conn.execute(query, params).fetchone() is not None


def _violates_unique_index(conn, table_name, source_value, exclude_id=None):
    """True if another row collides with `source_value` under EXACTLY the
    expression the database's unique index uses (table_name +
    lower(source_value), SQLite's own lower() on both sides). It is not a
    second duplicate rule: it only exists so a constraint failure can be
    recognised as the duplicate it is even where _has_duplicate() (unchanged)
    would not see it - SQLite's lower() leaves a non-ASCII capital such as
    the "E" in "Ecole" with an accent untouched, so _has_duplicate() cannot
    match an exact repeat of such a value, while the index rightly refuses it."""
    query = "SELECT 1 FROM lookup_tables WHERE table_name = ? AND lower(source_value) = lower(?)"
    params = [table_name, source_value]
    if exclude_id is not None:
        query += " AND id != ?"
        params.append(exclude_id)
    return conn.execute(query, params).fetchone() is not None


def _conflict_is_a_duplicate(conn, table_name, source_value, exclude_id=None):
    """After the database refused a write with an IntegrityError: was it
    really a duplicate? Re-check with the existing application rule first,
    then with the index's own rule. If neither finds a colliding row the
    failure is something else and must NOT be reported as a duplicate."""
    return _has_duplicate(conn, table_name, source_value, exclude_id=exclude_id) or _violates_unique_index(
        conn, table_name, source_value, exclude_id=exclude_id
    )


def _parse_count(value, field_label):
    """Parse one of the Consultant Lookup table's manual Intake 01/02
    Enrolled backfill counts - blank/None means "not entered" (0), never
    an error. Raises LookupValidationError for anything else that isn't a
    non-negative whole number."""
    if value is None:
        return 0
    value = str(value).strip()
    if not value:
        return 0
    try:
        parsed = int(value)
    except ValueError:
        raise LookupValidationError(f"{field_label} must be a whole number.")
    if parsed < 0:
        raise LookupValidationError(f"{field_label} cannot be negative.")
    if not fits_sqlite_integer(parsed):
        raise LookupValidationError(f"{field_label} is too large.")
    return parsed


def add_lookup(
    conn,
    table_name,
    source_value,
    mapped_value,
    now_iso,
    intake_01_count=None,
    intake_02_count=None,
    group_as_other=False,
):
    source_value = (source_value or "").strip()
    mapped_value = (mapped_value or "").strip()

    if not source_value:
        raise LookupValidationError("Source / Lookup Value is required.")

    if _has_duplicate(conn, table_name, source_value):
        raise DuplicateLookupError(
            f"'{source_value}' already exists in this lookup table. Edit the existing mapping instead."
        )

    intake_01 = _parse_count(intake_01_count, "Intake 01")
    intake_02 = _parse_count(intake_02_count, "Intake 02")

    try:
        conn.execute(
            "INSERT INTO lookup_tables "
            "(table_name, source_value, mapped_value, created_at, intake_01_count, intake_02_count, group_as_other) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (table_name, source_value, mapped_value, now_iso, intake_01, intake_02, int(bool(group_as_other))),
        )
    except sqlite3.IntegrityError:
        # Another request inserted the same mapping between our duplicate
        # check above and this INSERT, and the database's unique index
        # refused ours. Report it exactly like an ordinary duplicate - never
        # SQLite's own wording. (Anything that is NOT a duplicate is re-raised.)
        conn.rollback()
        if _conflict_is_a_duplicate(conn, table_name, source_value):
            raise DuplicateLookupError(
                f"'{source_value}' already exists in this lookup table. Edit the existing mapping instead."
            ) from None
        raise
    conn.commit()


def update_lookup(
    conn,
    lookup_id,
    table_name,
    source_value,
    mapped_value,
    intake_01_count=None,
    intake_02_count=None,
    group_as_other=False,
):
    source_value = (source_value or "").strip()
    mapped_value = (mapped_value or "").strip()

    if not source_value:
        raise LookupValidationError("Source / Lookup Value is required.")

    # An id outside SQLite's integer range (the URL can carry any number of
    # digits) cannot be bound as a query parameter. No row has such an id, so
    # treat it like any id that matches nothing: exclude no row from the
    # duplicate check.
    exclude_id = lookup_id if fits_sqlite_integer(lookup_id) else None
    if _has_duplicate(conn, table_name, source_value, exclude_id=exclude_id):
        raise DuplicateLookupError(
            f"'{source_value}' already exists in this lookup table. Choose a different value."
        )

    intake_01 = _parse_count(intake_01_count, "Intake 01")
    intake_02 = _parse_count(intake_02_count, "Intake 02")

    if fits_sqlite_integer(lookup_id):
        try:
            conn.execute(
                "UPDATE lookup_tables "
                "SET source_value = ?, mapped_value = ?, intake_01_count = ?, intake_02_count = ?, group_as_other = ? "
                "WHERE id = ? AND table_name = ?",
                (source_value, mapped_value, intake_01, intake_02, int(bool(group_as_other)), lookup_id, table_name),
            )
        except sqlite3.IntegrityError:
            # Lost a race to another request that just wrote the same value
            # (see add_lookup) - same friendly message as an ordinary duplicate.
            conn.rollback()
            if _conflict_is_a_duplicate(conn, table_name, source_value, exclude_id=lookup_id):
                raise DuplicateLookupError(
                    f"'{source_value}' already exists in this lookup table. Choose a different value."
                ) from None
            raise
    # else: no row can have that id, so there is nothing to update - exactly
    # what the UPDATE above does for any other id that matches no row.
    conn.commit()


def delete_lookup(conn, lookup_id, table_name):
    if fits_sqlite_integer(lookup_id):          # an out-of-range id matches no row, and cannot be bound
        conn.execute(
            "DELETE FROM lookup_tables WHERE id = ? AND table_name = ?", (lookup_id, table_name)
        )
    conn.commit()


def list_unresolved_unmapped(conn):
    return conn.execute(
        "SELECT * FROM unmapped_lookup_values WHERE resolved = 0 ORDER BY first_seen_at DESC"
    ).fetchall()


def resolve_unmapped(conn, unmapped_id):
    conn.execute(
        "UPDATE unmapped_lookup_values SET resolved = 1 WHERE id = ?", (unmapped_id,)
    )
    conn.commit()
