function showCopied(btn) {
    var original = btn.textContent.trim();
    btn.textContent = 'Copied';
    btn.classList.add('copied');
    setTimeout(function () {
        btn.textContent = original;
        btn.classList.remove('copied');
    }, 1200);
}

function fallbackCopy(code, btn) {
    var textarea = document.createElement('textarea');
    textarea.value = code;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.focus();
    textarea.select();
    try {
        if (document.execCommand('copy')) {
            showCopied(btn);
        }
    } catch (err) {
        /* copy not supported in this browser; nothing to show */
    }
    document.body.removeChild(textarea);
}

document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.copy-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var code = btn.getAttribute('data-code');
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(code).then(
                    function () { showCopied(btn); },
                    function () { fallbackCopy(code, btn); }
                );
            } else {
                fallbackCopy(code, btn);
            }
        });
    });
});
