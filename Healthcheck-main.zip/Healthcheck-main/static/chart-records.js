/* Click a piece of a pipeline chart (University Pipeline, Just Jon) and a window
   opens listing the applications in it (PES Code, Student, University, Intake,
   Consultant, Application Manager). It stays open until it is closed (the cross,
   the Close button or Esc). Each PES Code is a button that copies the code,
   ready to paste into the CRM.

   A clickable piece carries data-records-title (the window's title),
   data-records-params (what to ask the page's records endpoint for, as a query
   string) and data-count. The endpoint is sent those plus the page's own query
   string (its filters), so the list always matches the number on the piece
   clicked. Optional on a piece: data-records-url (an endpoint other than the
   window's own, e.g. for leads rather than applications), data-records-noun
   ("lead"; the default is "application") and data-records-wide (open the wide
   window for this piece, for a list with more or longer columns). A response may name its own columns
   ([[label, key], ...]); the default is the application columns below.
   Everything from the server is added with textContent - never as HTML. */
(function () {
    var dialog = document.getElementById('chart-records');
    if (!dialog) { return; }
    var title = document.getElementById('chart-records-title');
    var sub = document.getElementById('chart-records-sub');
    var body = document.getElementById('chart-records-body');
    var opener = null;
    var wideByDefault = dialog.classList.contains('chart-records-wide');
    var requestNumber = 0;

    var COLUMNS = [
        ['PES Code', 'code'],
        ['Student', 'student'],
        ['University', 'university'],
        ['Intake', 'intake'],
        ['Consultant', 'consultant'],
        ['Application Manager', 'manager']
    ];

    function element(tag, className, text) {
        var node = document.createElement(tag);
        if (className) { node.className = className; }
        if (text !== undefined) { node.textContent = text; }
        return node;
    }

    function copyCode(button, code) {
        function done() {
            if (typeof showCopied === 'function') { showCopied(button); }
        }
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(code).then(done, function () {
                if (typeof fallbackCopy === 'function') { fallbackCopy(code, button); }
            });
        } else if (typeof fallbackCopy === 'function') {
            fallbackCopy(code, button);
        }
    }

    function message(text, className) {
        body.textContent = '';
        body.appendChild(element('p', className || 'chart-records-note', text));
    }

    function render(data, noun) {
        var columns = data.columns || COLUMNS;
        body.textContent = '';
        sub.textContent = data.count + ' ' + noun + (data.count === 1 ? '' : 's') +
            (data.count ? ' — click a PES Code to copy it' : '');
        if (!data.records.length) {
            message('No ' + noun + 's.');
            return;
        }
        var table = element('table', 'chart-records-table');
        var headRow = element('tr');
        columns.forEach(function (column) { headRow.appendChild(element('th', '', column[0])); });
        table.appendChild(element('thead')).appendChild(headRow);
        var tbody = element('tbody');
        data.records.forEach(function (record) {
            var tr = element('tr');
            columns.forEach(function (column) {
                var td = element('td');
                if (column[1] === 'code') {
                    var button = element('button', 'copy-btn', record.code);
                    button.type = 'button';
                    button.setAttribute('data-code', record.code);
                    button.title = 'Copy ' + record.code;
                    button.addEventListener('click', function () { copyCode(button, record.code); });
                    td.appendChild(button);
                } else {
                    td.textContent = record[column[1]];
                }
                tr.appendChild(td);
            });
            tbody.appendChild(tr);
        });
        table.appendChild(tbody);
        body.appendChild(table);
    }

    function open() {
        if (typeof dialog.showModal === 'function') {
            if (!dialog.open) { dialog.showModal(); }
        } else {
            dialog.setAttribute('open', '');
        }
    }

    function close() {
        if (typeof dialog.close === 'function') {
            dialog.close();
        } else {
            dialog.removeAttribute('open');
        }
    }

    function show(segment) {
        opener = segment;
        var number = ++requestNumber;
        title.textContent = segment.getAttribute('data-records-title');
        dialog.classList.toggle('chart-records-wide', wideByDefault || segment.hasAttribute('data-records-wide'));
        var noun = segment.getAttribute('data-records-noun') || 'application';
        sub.textContent = segment.getAttribute('data-count') + ' ' + noun + 's';
        message('Loading…');
        open();
        var params = new URLSearchParams(window.location.search);
        new URLSearchParams(segment.getAttribute('data-records-params')).forEach(function (value, key) {
            params.set(key, value);
        });
        fetch((segment.getAttribute('data-records-url') || dialog.getAttribute('data-url')) + '?' + params.toString(), {
            credentials: 'same-origin',
            headers: { 'Accept': 'application/json' }
        }).then(function (response) {
            if (!response.ok) { throw new Error('HTTP ' + response.status); }
            return response.json();
        }).then(function (data) {
            if (number === requestNumber) { render(data, noun); }
        }).catch(function () {
            if (number === requestNumber) { message('The ' + noun + 's could not be loaded. Close this window and try again.', 'chart-records-note chart-records-error'); }
        });
    }

    document.querySelectorAll('.chart-segment-clickable').forEach(function (segment) {
        segment.addEventListener('click', function () { show(segment); });
        segment.addEventListener('keydown', function (event) {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                show(segment);
            }
        });
    });
    dialog.querySelectorAll('[data-close]').forEach(function (button) {
        button.addEventListener('click', close);
    });
    dialog.addEventListener('close', function () {
        requestNumber++;
        if (opener) { opener.focus(); }
    });
})();
