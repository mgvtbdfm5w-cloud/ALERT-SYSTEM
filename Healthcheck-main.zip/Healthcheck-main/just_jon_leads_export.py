"""Excel export for the Just Jon "Lead Allocates" chart: the very leads the chart
is drawn from (the Just Jon leads, for the month chosen above it), one worksheet
per Consultant, with the click-through window's columns.

Each worksheet is set up to print: landscape A4, one page wide however many
pages long it runs, the column headings repeated at the top of every page, and
"Page x of y" in the footer.

No filtering happens in here; the caller passes the already-scoped leads."""

import io

import openpyxl
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.properties import PageSetupProperties

from dateutils import safe_date
from excel_export_helpers import safe_append_row, unique_sheet_title
from leads import LEAD_STAGE_ORDER
from leads_dashboard import LEAD_RECORD_COLUMNS, UNASSIGNED_LABEL, lead_record

TITLE = "Just Jon Lead Allocates"
HEADERS = [label for label, _ in LEAD_RECORD_COLUMNS]
# Wide enough that fitting the sheet to one page wide barely has to shrink it.
COLUMN_WIDTHS = {"code": 14, "name": 32, "lead_source": 18, "sub_source": 18, "lead_status": 22, "consultant": 14, "created": 12}
HEADER_ROW = 4

_STAGE_INDEX = {stage: index for index, stage in enumerate(LEAD_STAGE_ORDER)}
_THIN = Side(style="thin", color="FFC7CCD4")
_BORDER = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)
_HEADER_FILL = PatternFill(start_color="FF1F2430", end_color="FF1F2430", fill_type="solid")


def _consultant(row):
    return (row.get("Consultant") or "").strip() or UNASSIGNED_LABEL


def _sort_key(row):
    """Lead stage order (01 - New Lead ... 10 - Disqualified, anything unrecognised
    last), then Name, then PES Code."""
    return (_STAGE_INDEX.get((row.get("Stage") or "").strip(), len(_STAGE_INDEX)), (row.get("Name") or "").strip().lower(), (row.get("PES Code") or "").strip())


def group_by_consultant(rows):
    """[(consultant, [rows])], one entry per Consultant (names that differ only
    in capitals are one person; the first spelling seen wins), A-Z, with
    "Unassigned" - leads nobody has been allocated - last."""
    groups = {}
    for row in rows:
        name = _consultant(row)
        entry = groups.setdefault(name.lower(), (name, []))
        entry[1].append(row)
    ordered = sorted(groups.values(), key=lambda g: (g[0] == UNASSIGNED_LABEL, g[0].lower(), g[0]))
    return [(name, sorted(group_rows, key=_sort_key)) for name, group_rows in ordered]


def _set_up_printing(ws):
    ws.page_setup.orientation = "landscape"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0          # as many pages long as it needs
    ws.sheet_properties.pageSetUpPr = PageSetupProperties(fitToPage=True)
    ws.print_title_rows = f"{HEADER_ROW}:{HEADER_ROW}"
    ws.print_options.horizontalCentered = True
    ws.page_margins.left = ws.page_margins.right = 0.4
    ws.page_margins.top = 0.6
    ws.page_margins.bottom = 0.7
    ws.oddFooter.left.text = "&A"
    ws.oddFooter.right.text = "Page &P of &N"


def _write_consultant_sheet(ws, consultant, rows, scope_label, today):
    ws["A1"] = f"{TITLE} - {consultant}"
    ws["A1"].font = Font(bold=True, size=14)
    ws["A2"] = f"Leads created: {scope_label}  |  {len(rows):,} lead{'' if len(rows) == 1 else 's'}  |  Downloaded {today.strftime('%d/%m/%Y')}"
    for column, header in enumerate(HEADERS, start=1):
        cell = ws.cell(row=HEADER_ROW, column=column, value=header)
        cell.font = Font(bold=True, color="FFFFFFFF")
        cell.fill = _HEADER_FILL
        cell.border = _BORDER
        cell.alignment = Alignment(vertical="center")
    created_column = [key for _, key in LEAD_RECORD_COLUMNS].index("created") + 1
    for row in rows:
        record = lead_record(row)
        values = [record[key] for _, key in LEAD_RECORD_COLUMNS]
        created = safe_date(row.get("Creation Date"))
        values[created_column - 1] = created if created else ""
        safe_append_row(ws, values)
        for column in range(1, len(HEADERS) + 1):
            cell = ws.cell(row=ws.max_row, column=column)
            cell.border = _BORDER
            cell.alignment = Alignment(vertical="top", horizontal="left")
        if created:
            ws.cell(row=ws.max_row, column=created_column).number_format = "DD/MM/YYYY"
    for column, (_, key) in enumerate(LEAD_RECORD_COLUMNS, start=1):
        ws.column_dimensions[get_column_letter(column)].width = COLUMN_WIDTHS[key]
    ws.freeze_panes = f"A{HEADER_ROW + 1}"
    ws.auto_filter.ref = f"A{HEADER_ROW}:{get_column_letter(len(HEADERS))}{max(ws.max_row, HEADER_ROW)}"
    _set_up_printing(ws)


def build_just_jon_leads_export(rows, scope_label, today):
    """The export workbook as an in-memory buffer: one worksheet per Consultant
    in `rows`, or a single note if there are no leads. `scope_label` is what the
    month dropdown said ("All months", "September 2026")."""
    workbook = openpyxl.Workbook()
    workbook.remove(workbook.active)
    used_titles = set()
    for consultant, consultant_rows in group_by_consultant(rows):
        title = unique_sheet_title(consultant, used_titles)
        used_titles.add(title)
        _write_consultant_sheet(workbook.create_sheet(title), consultant, consultant_rows, scope_label, today)
    if not workbook.sheetnames:
        ws = workbook.create_sheet("No leads")
        ws["A1"] = f"{TITLE}: no Just Jon leads for {scope_label}."
        _set_up_printing(ws)

    buffer = io.BytesIO()
    workbook.save(buffer)
    buffer.seek(0)
    return buffer


def export_filename(today, month_label=None):
    """Just_Jon_Lead_Allocates[_Sep-2026]_dd-mm-yyyy.xlsx"""
    month_part = "_" + month_label.replace(" ", "-")[:3] + "-" + month_label.split()[-1] if month_label else ""
    return f"Just_Jon_Lead_Allocates{month_part}_{today.strftime('%d-%m-%Y')}.xlsx"
