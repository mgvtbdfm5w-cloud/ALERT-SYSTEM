"""Excel export for every Enrolled (09-Enrolled) record in the current
Intake - July to December 2026 ("Intake 03", this app's own live-CRM
starting point - see pipeline.py's module docstring on why Jan-Jun 2026
predates the CRM migration and has no reliable live data here).

A single flat sheet (no per-University/per-Manager tabs - just one list),
with a wider column set than the Enrolled page's own Intake 03 download
(enrolled_export.py) - built for a different audience/purpose, so kept as
its own module rather than bolted onto that one's fixed column set.
"""

import io

import openpyxl
from openpyxl.styles import Font
from openpyxl.utils import get_column_letter

from dateutils import safe_date as _safe_date
from excel_export_helpers import apply_column_widths, apply_date_format, safe_append_row

EXPORT_COLUMNS = [
    "Student Code",
    "Student Name",
    "Student Number",
    "Phone Number",
    "Email",
    "Intake",
    "University Name",
    "Course Name",
    "Location",
    "Status",
    "Source",
    "Sub-Source",
    "Consultant",
    "Application",
    "Enrolled Date",
]

SHEET_TITLE = "Enrolled - Current Intake"


def _sort_rows(rows):
    """University Name, then Student Name - alphabetically (case-
    insensitive), a simple, predictable default since no particular
    grouping was asked for."""
    return sorted(
        rows,
        key=lambda row: (
            (row.get("University Name") or "").strip().lower(),
            (row.get("Student Name") or "").strip().lower(),
        ),
    )


def build_enrolled_current_intake_export(rows):
    """Build the export workbook (an in-memory buffer) - one row per
    record in `rows`, which the caller has already filtered down to the
    population it wants exported (Status 09-Enrolled, Intake within
    July-December 2026 - see app.py's enrolled_export_current_intake()
    route). No filtering happens in here."""
    ordered = _sort_rows(rows)

    workbook = openpyxl.Workbook()
    ws = workbook.active
    ws.title = SHEET_TITLE

    ws.append(EXPORT_COLUMNS)
    header_font = Font(bold=True)
    for cell in ws[1]:
        cell.font = header_font
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(EXPORT_COLUMNS))}1"

    for row in ordered:
        safe_append_row(
            ws,
            [
                row.get("Student Code") or "",
                row.get("Student Name") or "",
                row.get("Student Number") or "",
                row.get("Phone Number") or "",
                row.get("Email") or "",
                row.get("Intake") or "",
                row.get("University Name") or "",
                row.get("Course Name") or "",
                row.get("Location") or "",
                row.get("Status") or "",
                row.get("Source") or "",
                row.get("Sub-Source") or "",
                row.get("Consultant") or "",
                row.get("Application") or "",
                _safe_date(row.get("Enrolled Date")),
            ],
        )

    apply_date_format(ws, EXPORT_COLUMNS, {"Enrolled Date"})
    apply_column_widths(ws, EXPORT_COLUMNS)

    buffer = io.BytesIO()
    workbook.save(buffer)
    buffer.seek(0)
    return buffer


def export_filename(today, intake_year=None):
    year_part = f"_{intake_year}" if intake_year is not None else ""
    return f"Enrolled_Current_Intake{year_part}_{today.strftime('%d-%m-%Y')}.xlsx"
