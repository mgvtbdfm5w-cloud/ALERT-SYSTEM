"""KPI dashboard calculation logic: monthly QA Passed performance.

Kept out of the route and template on purpose, mirroring pipeline.py's
approach - build_kpi_report() takes the current active dataset rows, a
target year/month, and the stored targets, and returns a plain data
structure the template renders with minimal logic of its own. Nothing here
is persisted except the targets themselves; the report is recalculated from
Current Data on every page load.

Reuses dateutils.safe_date() for all date handling (no separate date parsing
logic) and pipeline.round_half_up() for the same whole-percentage rounding
convention already used by the Pipeline dashboards.
"""

import math
from calendar import month_name, monthrange

from colors import assign_categorical_colors
from dateutils import safe_date
from db import fits_sqlite_integer
from pipeline import PIPELINE_INTAKE_YEARS, filter_by_intake_year, round_half_up
from processing import parse_stage_length_days

# Reserved target_type values (in kpi_targets) for the Company Total and
# Consultant targets, kept distinct from any real Sales Office code.
COMPANY_TARGET_TYPE = "__COMPANY__"
CONSULTANT_TARGET_TYPE = "__CONSULTANT__"

# Every Consultant has the same target for a given month, editable via
# Admin (like Sales Office/Company targets) rather than fixed in code. This
# is the fallback used only when no value has been saved yet for a month -
# it also happens to be the value this scale always used before it became
# editable, so behaviour is unchanged until someone sets a different one.
DEFAULT_CONSULTANT_TARGET = 40

# A Consultant who shouldn't get their own bar on the Consultant KPI
# Health chart - their Actual still counts fully toward their Sales
# Office's and the Company's own totals (see build_kpi_report - this set
# is only consulted when building each office's consultant_rows list,
# never office_actual/company_actual), same "hidden but still counted"
# convention as pipeline.HIDDEN_CONSULTANTS, just scoped to this page's
# own Consultant chart rather than shared with it.
HIDDEN_CONSULTANTS = {"tanaka"}


class KpiTargetValidationError(Exception):
    pass


def _qa_passed_date(row):
    return safe_date(row.get("QA Passed"))


def list_available_months(rows):
    """Return [(year, month), ...] for every distinct year/month with at
    least one valid QA Passed date, sorted newest first."""
    months = set()
    for row in rows:
        d = _qa_passed_date(row)
        if d:
            months.add((d.year, d.month))
    return sorted(months, key=lambda ym: (-ym[0], -ym[1]))


def format_month_label(year, month):
    return f"{month_name[month]} {year}"


def month_key(year, month):
    return f"{year:04d}-{month:02d}"


def build_month_options(available_months):
    """Return [{"key": ..., "label": ...}, ...] for a month picker <select>,
    from a list of (year, month) pairs (as returned by list_available_months()
    here or in submissions.py, which share this same (year, month) shape).
    Used by the KPI, Submissions, and Admin KPI-targets month dropdowns, so
    a future change to how a month option is presented only needs to happen
    once."""
    return [{"key": month_key(y, m), "label": format_month_label(y, m)} for y, m in available_months]


def parse_month_key(key):
    """Parse a 'YYYY-MM' key back into (year, month) ints, or None if it
    isn't a valid month key - never raises on bad input."""
    if not key:
        return None
    try:
        year_str, month_str = key.split("-")
        year, month = int(year_str), int(month_str)
    except (ValueError, AttributeError):
        return None
    if 1 <= month <= 12:
        return year, month
    return None


def classify_status(actual, target):
    """Return 'red' | 'yellow' | 'green' for actual vs target, or None when
    target is not configured (None) or not a usable positive value - in
    which case there is nothing meaningful to classify.

    Used for Sales Office and Company cards, whose targets vary month to
    month - a ratio is the only thing that stays meaningful across
    different target values. Consultants use classify_consultant_status()
    instead (see below), which is also ratio-based but against a 5-tier
    scale rather than this 3-tier one."""
    if target is None or target <= 0:
        return None
    ratio = actual / target
    if ratio >= 1.0:
        return "green"
    if ratio >= 0.8:
        return "yellow"
    return "red"


# Single source of truth for the Consultant 5-tier colour scale, as ratios
# of the (Admin-editable, per-month) Consultant Target - "Bare Min" (the
# dark-red/orange boundary) up to "Ghung Ho" (the green tier, i.e. hitting
# target). These exact ratios (0.55, 0.675, 0.8, 0.975) are chosen so that
# at the original fixed target of 40 they reproduce the scale's original
# whole-number cutoffs (22, 27, 32, 39) precisely - if the monthly target
# changes, every cutoff scales with it via build_consultant_status_tiers()
# below, so the scale and the legend can never disagree with each other or
# with whatever this month's target actually is.
CONSULTANT_STATUS_TIER_RATIOS = [
    {"status": "dark-red", "color": "#7f1d1d", "ratio": 0.55},
    {"status": "orange", "color": "#ea580c", "ratio": 0.675},
    {"status": "yellow", "color": "#eab308", "ratio": 0.8},
    {"status": "olive", "color": "#6b8e23", "ratio": 0.975},
    {"status": "green", "color": "#16a34a", "ratio": None},
]

# The KPI Consultant chart's "Remaining to target" legend swatch - not a
# status tier (no Actual count maps to it), just the bar-track's empty-space
# colour, so it's listed separately from the tier ratios above.
CONSULTANT_STATUS_REMAINING_COLOR = "#d1d5db"


def build_consultant_status_tiers(target):
    """Return the 5-tier boundary table (status/color/upper/label) for this
    month's Consultant Target, scaling CONSULTANT_STATUS_TIER_RATIOS' fixed
    ratios to whole-number cutoffs (via round_half_up). Computed once per
    report/request and reused for both classification (_classify_from_tiers)
    and the legend, rather than being rebuilt per consultant or hand-typed
    separately in the template."""
    tiers = []
    lower = 0
    for i, tier in enumerate(CONSULTANT_STATUS_TIER_RATIOS):
        if tier["ratio"] is None:
            upper = None
            label = f"{lower} and above"
        else:
            upper = round_half_up(tier["ratio"] * target)
            label = f"Below {upper + 1}" if i == 0 else f"{lower} to {upper}"
        tiers.append({"status": tier["status"], "color": tier["color"], "upper": upper, "label": label})
        lower = upper + 1 if upper is not None else None
    return tiers


def _classify_from_tiers(actual, tiers):
    for tier in tiers:
        if tier["upper"] is None or actual <= tier["upper"]:
            return tier["status"]
    raise AssertionError("the last tier must have upper=None")


def classify_consultant_status(actual, target):
    """Classify a single Consultant's raw Actual count against `target`
    (this month's editable Consultant Target) using the 5-tier scale. A
    convenience single-value wrapper around build_consultant_status_tiers();
    build_kpi_report() builds the tier table once per report instead of
    once per consultant."""
    if not target or target <= 0:
        return None
    return _classify_from_tiers(actual, build_consultant_status_tiers(target))


def _marker_pct(tiers, target):
    """Horizontal position (0-100) of the "Bare Min" guide line (the
    dark-red/orange tier boundary) within a bar-track sized to `target` -
    computed here rather than in the template, matching how every other
    positional value on this dashboard (bar_pct, achievement_pct) is
    prepared in Python."""
    if not target:
        return 0
    threshold = tiers[0]["upper"] + 1
    return round(threshold / target * 100, 1)


def _achievement_pct(actual, target):
    if target is None or target <= 0:
        return None
    return round_half_up(actual / target * 100)


def _bar_pct(actual, target):
    """Visual bar fill percentage, capped at 100 even when actual exceeds
    target - the displayed achievement percentage (above) is what's allowed
    to exceed 100, not the bar itself."""
    if target is None or target <= 0:
        return 0
    return min(100.0, actual / target * 100)


def _build_kpi_entry(label, actual, target):
    return {
        "label": label,
        "actual": actual,
        "target": target,
        "achievement_pct": _achievement_pct(actual, target),
        "bar_pct": _bar_pct(actual, target),
        "status": classify_status(actual, target),
    }


def _group_rows_by_qa_passed_student_code(rows, year, month):
    """Group rows with a QA Passed date in (year, month) by Student Code,
    so a student with more than one qualifying row this month can be
    resolved to a single entry by _resolve_qualifying_group() below. Rows
    with a blank Student Code each get their own unique key via the row
    index, so they are never wrongly collapsed together."""
    grouped = {}
    for index, row in enumerate(rows):
        d = _qa_passed_date(row)
        if not d or d.year != year or d.month != month:
            continue
        code = (row.get("Student Code") or "").strip()
        key = code if code else f"__unidentified_{index}__"
        grouped.setdefault(key, []).append(row)
    return grouped


def _resolve_qualifying_group(group):
    """Return (any_consultant, consultant, office, chosen_row) for one
    Student-Code group of qualifying rows - the Consultant/Sales-Office
    attribution rule shared by _group_qualifying_rows() (build_kpi_report/
    list_sales_offices_for_month) and build_oxford_kpi_matrix(), so all
    three always agree on which single row (if any) represents this
    student this month.

    Looks for a row with both a non-blank Consultant and a non-blank Sales
    Office, rather than stopping at whichever row has a Consultant first -
    a student can have multiple qualifying rows this month (e.g.
    reassigned mid-month), and an earlier row with an unmapped/blank-office
    Consultant must not shadow a later row that does qualify.

    any_consultant is False when no row in the group has any Consultant at
    all (nothing to attribute). When any_consultant is True but office is
    "", a Consultant was found but never with a Sales Office alongside it
    (counts toward blank_sales_office_count, never a fake group). chosen_row
    is the specific row that supplied consultant/office, or None if office
    was never resolved."""
    consultant = ""
    office = ""
    chosen_row = None
    any_consultant = False
    for row in group:
        candidate = (row.get("Consultant") or "").strip()
        if not candidate:
            continue
        any_consultant = True
        candidate_office = (row.get("Sales Office") or "").strip()
        if candidate_office:
            consultant, office, chosen_row = candidate, candidate_office, row
            break

    return any_consultant, consultant, office, chosen_row


def _group_qualifying_rows(rows, year, month):
    """Return (company_actual, blank_sales_office_count, consultants) for
    the given month - the Student-Code dedup and Consultant/Sales-Office
    attribution logic shared by build_kpi_report() and
    list_sales_offices_for_month(), so both always agree on which records
    qualify and how they're attributed, without list_sales_offices_for_month()
    having to pay for build_kpi_report()'s achievement%/bar%/status
    decoration work it doesn't need.

    consultants: {consultant_name: {"office": str, "actual": int}}. See
    build_kpi_report()'s docstring for the full qualification rules.
    """
    grouped = _group_rows_by_qa_passed_student_code(rows, year, month)

    company_actual = len(grouped)
    blank_sales_office_count = 0

    # consultant -> {"office": str, "actual": int}
    consultants = {}

    for group in grouped.values():
        any_consultant, consultant, office, _ = _resolve_qualifying_group(group)

        if not any_consultant:
            continue

        if not office:
            blank_sales_office_count += 1
            continue

        entry = consultants.setdefault(consultant, {"office": office, "actual": 0})
        entry["actual"] += 1

    return company_actual, blank_sales_office_count, consultants


def build_kpi_report(rows, year, month, sales_office_targets, company_target, consultant_target=None):
    """Return the full KPI report as a plain dict for the given month.

    sales_office_targets: {office_name: target_int_or_None}. A missing key
    (or a None value) means "Target Not Set" - never treated as zero.
    company_target: int or None, same "not set" semantics.
    consultant_target: the single Target every Consultant is measured
    against this month (Admin-editable, like Sales Office/Company targets).
    None falls back to DEFAULT_CONSULTANT_TARGET - unlike Sales
    Office/Company, Consultants always need a usable target for their chart
    to render at all, so this can never end up "Target Not Set".

    A Student Code counts once for the month even if it has multiple
    qualifying rows (e.g. two applications for the same student both QA
    Passed in the same month) - a row with a blank Student Code is never
    collapsed with any other row, since there is no reliable way to tell
    whether two blank-coded rows are the same student.

    A record counts when its QA Passed date falls in (year, month). Company
    Actual counts every such distinct Student Code regardless of
    Consultant/Sales Office data quality (it's a total-company metric, not
    office-attributed). Sales Office and Consultant Actuals only count
    Student Codes that have at least one qualifying row with both a
    non-blank Consultant and a non-blank Sales Office - there's nowhere
    sensible to attribute the rest, so they're excluded from those
    breakdowns and counted in blank_sales_office_count instead (never
    silently dropped without a trace, and never given a fake "Unassigned"
    group).
    """
    consultant_target = consultant_target if consultant_target else DEFAULT_CONSULTANT_TARGET
    consultant_tiers = build_consultant_status_tiers(consultant_target)
    consultant_marker_pct = _marker_pct(consultant_tiers, consultant_target)

    company_actual, blank_sales_office_count, consultants = _group_qualifying_rows(rows, year, month)

    offices = {}
    for name, data in consultants.items():
        offices.setdefault(data["office"], []).append(name)

    sales_office_reports = []
    for office_name in sorted(offices.keys(), key=str.lower):
        names = offices[office_name]
        ordered = sorted(names, key=lambda n: (-consultants[n]["actual"], n.lower()))

        consultant_rows = [
            _build_kpi_entry(name, consultants[name]["actual"], consultant_target)
            for name in ordered
            if name.lower() not in HIDDEN_CONSULTANTS
        ]
        # Consultants use the 5-tier colour scale (built once above from
        # this month's consultant_target), not the ratio-based one
        # _build_kpi_entry() applied by default - overridden here rather
        # than threaded through as a parameter, so Sales Office/Company
        # entries built the same way are unaffected. marker_pct is
        # likewise Consultant-only (the guide line only appears on the
        # Consultant chart) and identical for every consultant this month,
        # since they all share the same target.
        for entry in consultant_rows:
            entry["status"] = _classify_from_tiers(entry["actual"], consultant_tiers)
            entry["marker_pct"] = consultant_marker_pct
        office_actual = sum(consultants[name]["actual"] for name in names)
        office_target = sales_office_targets.get(office_name)

        office_entry = _build_kpi_entry(office_name, office_actual, office_target)
        office_entry["consultants"] = consultant_rows
        sales_office_reports.append(office_entry)

    company_entry = _build_kpi_entry("Overall", company_actual, company_target)

    return {
        "sales_offices": sales_office_reports,
        "company": company_entry,
        "blank_sales_office_count": blank_sales_office_count,
        "consultant_target": consultant_target,
        "consultant_status_tiers": consultant_tiers,
    }


def list_sales_offices_for_month(rows, year, month):
    """Sales Offices with at least one qualifying record in (year, month) -
    reuses the same row-grouping/attribution logic build_kpi_report() uses
    (via _group_qualifying_rows), so this can never disagree with what the
    KPI page itself shows, without paying for build_kpi_report()'s
    achievement%/bar%/status decoration work that isn't needed here."""
    _, _, consultants = _group_qualifying_rows(rows, year, month)
    offices = {data["office"] for data in consultants.values()}
    return sorted(offices, key=str.lower)


def _svg_point(day, pct, num_days, max_pct):
    """Map (day-of-month, % of target) to an (x, y) pair in a 0-100 x
    0-100 SVG viewBox - x is the day's position across the month, y is
    inverted (0% at the bottom, max_pct% at the top, since SVG y grows
    downward). Shared by every line on the chart so they all plot against
    the same axes."""
    x = (day - 1) / (num_days - 1) * 100 if num_days > 1 else 0.0
    y = 100 - (pct / max_pct * 100 if max_pct > 0 else 0.0)
    return round(x, 2), round(y, 2)


def build_kpi_progress_chart(rows, year, month, sales_office_targets, today=None):
    """One cumulative-QA-Passed-vs-target line per Sales Office across the
    selected month, all sharing a single "% of target" y-axis - offices
    have very different target volumes (e.g. OXF's 240 vs CAR/LON/MAN's
    60), so plotting raw counts would squash the smaller ones; % of target
    puts every office on the same 0-100(+)% scale and means every line
    would reach the same point (day num_days, 100%) if it hit target
    exactly on time.

    Reuses the exact same Student-Code dedup/attribution rule as
    build_kpi_report (via _group_rows_by_qa_passed_student_code/
    _resolve_qualifying_group), so each line's value on its last "actual"
    day always matches that office's summary card Actual figure exactly.
    An office with no target set this month (sales_office_targets.get(name)
    missing, None, or <= 0) has no "% of target" to plot and is left out
    entirely.

    `today`, when given and falling within the selected (year, month),
    splits each line into two segments: "actual" (day 1 to today, real
    QA Passed data) and "pace" (today to the last day of the month) - a
    straight line from today's actual % to 100%, i.e. the pace needed
    from here to close the gap and hit target exactly by month end. Any
    other month (in particular, a past month whose data is already
    complete) gets no pace segment - `on_target_month` is False and every
    line simply runs the real data for the whole month.

    Every point/line already carries ready-to-render SVG coordinates
    (0-100 x 0-100 viewBox, see _svg_point) so the template only has to
    print them, matching how every other chart on this dashboard has its
    positions computed in Python rather than in Jinja.
    """
    num_days = monthrange(year, month)[1]
    grouped = _group_rows_by_qa_passed_student_code(rows, year, month)

    # office -> {day_of_month: count}
    daily_counts = {}
    for group in grouped.values():
        any_consultant, consultant, office, chosen_row = _resolve_qualifying_group(group)
        if not any_consultant or not office:
            continue
        day = _qa_passed_date(chosen_row).day
        counts = daily_counts.setdefault(office, {})
        counts[day] = counts.get(day, 0) + 1

    on_target_month = today is not None and (today.year, today.month) == (year, month)
    last_actual_day = min(today.day, num_days) if on_target_month else num_days

    office_names = sorted(
        (name for name, target in sales_office_targets.items() if target and target > 0),
        key=str.lower,
    )
    office_colors = dict(zip(office_names, assign_categorical_colors(office_names)))

    lines = []
    for office_name in office_names:
        target = sales_office_targets[office_name]
        counts = daily_counts.get(office_name, {})

        actual_points = []
        cumulative = 0
        for day in range(1, last_actual_day + 1):
            cumulative += counts.get(day, 0)
            actual_points.append({"day": day, "actual": cumulative, "pct": round(cumulative / target * 100, 1)})

        final_pct = actual_points[-1]["pct"] if actual_points else 0.0

        pace_points = []
        if on_target_month and last_actual_day < num_days:
            pace_points = [
                {"day": last_actual_day, "pct": final_pct},
                {"day": num_days, "pct": 100.0},
            ]

        lines.append(
            {
                "office": office_name,
                "color": office_colors[office_name],
                "target": target,
                "final_actual": cumulative,
                "final_pct": final_pct,
                "actual_points": actual_points,
                "pace_points": pace_points,
            }
        )

    max_pct = max(
        [100.0]
        + [p["pct"] for line in lines for p in line["actual_points"]]
        + [p["pct"] for line in lines for p in line["pace_points"]]
    )

    for line in lines:
        line["actual_svg_points"] = " ".join(
            f"{x},{y}" for x, y in (_svg_point(p["day"], p["pct"], num_days, max_pct) for p in line["actual_points"])
        )
        line["pace_svg_points"] = " ".join(
            f"{x},{y}" for x, y in (_svg_point(p["day"], p["pct"], num_days, max_pct) for p in line["pace_points"])
        )

    target_line_y = _svg_point(1, 100.0, num_days, max_pct)[1]
    today_line_x = _svg_point(last_actual_day, 0, num_days, max_pct)[0] if on_target_month else None

    y_axis_top = max(100, math.ceil(max_pct / 25) * 25)
    y_ticks = [
        {"pct": pct, "y": _svg_point(1, pct, num_days, max_pct)[1]}
        for pct in range(0, y_axis_top + 1, 25)
    ]
    x_tick_days = sorted({1, 7, 14, 21, num_days})
    x_ticks = [{"day": d, "x": _svg_point(d, 0, num_days, max_pct)[0]} for d in x_tick_days]

    return {
        "num_days": num_days,
        "on_target_month": on_target_month,
        "today_day": last_actual_day if on_target_month else None,
        "lines": lines,
        "max_pct": max_pct,
        "target_line_y": target_line_y,
        "today_line_x": today_line_x,
        "y_ticks": y_ticks,
        "x_ticks": x_ticks,
    }


# The 2 earliest pipeline stages, tracked here as a live "pending action"
# backlog snapshot rather than a monthly metric - each box counts every
# record currently at that Status in the whole active dataset, regardless
# of Intake year or QA Passed month (a record stuck at Doc Check needs
# action no matter when it entered), with its own fixed green/amber/red
# volume thresholds. "01-NewApp" isn't part of pipeline.STAGES (which
# starts at 02-PendingQA), since the Pipeline dashboards don't track it,
# but it's a real Status value in Current Data.
PIPELINE_BACKLOG_BOXES = [
    {"key": "doc_check", "label": "Doc Check", "status": "01-NewApp", "green_max": 10, "amber_max": 15},
    {"key": "qa", "label": "QA", "status": "02-PendingQA", "green_max": 8, "amber_max": 12},
]

# Submitting is the one backlog box split by Intake year (one box per year
# in pipeline.PIPELINE_INTAKE_YEARS) instead of a single combined count
# like Doc Check/QA above - Sales want the Submitting backlog visible per
# intake separately. Same green/amber/red thresholds as before the split;
# each year's box is classified independently against them.
SUBMITTING_STATUS = "03-PendingSubmission"
SUBMITTING_GREEN_MAX = 20
SUBMITTING_AMBER_MAX = 30


def _classify_backlog(count, green_max, amber_max):
    if count <= green_max:
        return "green"
    if count <= amber_max:
        return "yellow"
    return "red"


def _backlog_box_result(label, rows_for_box, green_max, amber_max):
    count = len(rows_for_box)
    day_total = 0
    day_sample_count = 0
    for row in rows_for_box:
        days = parse_stage_length_days(row.get("Stage Length"))
        if days is not None:
            day_total += days
            day_sample_count += 1
    average_days = round_half_up(day_total / day_sample_count, decimals=1) if day_sample_count else None
    return {
        "label": label,
        "count": count,
        "status": _classify_backlog(count, green_max, amber_max),
        "average_days": average_days,
    }


def build_backlog_box(rows, key):
    """One named box from PIPELINE_BACKLOG_BOXES (e.g. "doc_check", "qa")
    - a live count of every record currently at that box's Status, with
    average Stage Length days and green/amber/red classification (see
    _backlog_box_result). This is the shared computation behind both
    build_pipeline_backlog_summary()'s own boxes below and the Company
    Dashboard's single-box "Pending" breakdowns next to that same
    figure's own month-scoped tile (e.g. Docs Approved -> Doc Check)."""
    box_config = next(box for box in PIPELINE_BACKLOG_BOXES if box["key"] == key)
    rows_for_box = [row for row in rows if (row.get("Status") or "").strip() == box_config["status"]]
    return _backlog_box_result(box_config["label"], rows_for_box, box_config["green_max"], box_config["amber_max"])


def build_submission_pending_by_year(rows):
    """Return [{"year", "label", "count", "status", "average_days"}, ...],
    one per pipeline.PIPELINE_INTAKE_YEARS entry - a live count of every
    record currently at Status 03-PendingSubmission (SUBMITTING_STATUS)
    for that Intake year, with the same average Stage Length days/green-
    amber-red classification as every other backlog box (see
    _backlog_box_result). This is the shared computation behind both
    build_pipeline_backlog_summary()'s own per-year Submitting boxes
    below and the Company Dashboard's Pending (year) tiles next to its
    Submitted tile (company_dashboard module) - the "label" field is
    just a plain year string here; each page names these differently
    ("Submitting (2026)" vs "Pending (2026)"), so display text is left to
    the caller rather than baked in here."""
    result = []
    for year in PIPELINE_INTAKE_YEARS:
        year_rows = [
            row
            for row in filter_by_intake_year(rows, year)
            if (row.get("Status") or "").strip() == SUBMITTING_STATUS
        ]
        box = _backlog_box_result(str(year), year_rows, SUBMITTING_GREEN_MAX, SUBMITTING_AMBER_MAX)
        box["year"] = year
        result.append(box)
    return result


def build_pipeline_backlog_summary(rows):
    """Return [{"label", "count", "status", "average_days"}, ...] - one box
    per PIPELINE_BACKLOG_BOXES entry (a live count of every record
    currently at that box's Status, ignoring Intake year and QA Passed
    month entirely - see PIPELINE_BACKLOG_BOXES above), plus one Submitting
    box per Intake year (see build_submission_pending_by_year() above,
    which is scoped by Intake year unlike the other boxes). Every box's
    average_days is the average Stage Length (calendar days, rounded to 1
    decimal place) across whichever of its records have a parseable Stage
    Length - None if none do."""
    result = [build_backlog_box(rows, box["key"]) for box in PIPELINE_BACKLOG_BOXES]

    for box in build_submission_pending_by_year(rows):
        result.append({**box, "label": f"Submitting ({box['year']})"})

    return result


# The Oxford KPI section's own Sales Office - matches the "OXF" label used
# everywhere else on this page (report["sales_offices"]).
OXFORD_SALES_OFFICE = "OXF"


def _classify_oxford_cell(count):
    """0 = red (nobody QA Passed that day), 1 = yellow, 2 = green, 3+ =
    dark-green (even better than green) - a fixed volume rule for the
    Oxford KPI matrix, the opposite direction to _classify_backlog() above
    (there, a low count is good; here, a low count is the thing to
    flag)."""
    if count <= 0:
        return "red"
    if count == 1:
        return "yellow"
    if count == 2:
        return "green"
    return "dark-green"


def build_oxford_kpi_matrix(rows, year, month):
    """Daily QA Passed matrix for OXFORD_SALES_OFFICE only, Consultant
    across the top and QA Passed date down the side.

    Deliberately reuses the exact same Student-Code dedup and Consultant/
    Sales-Office attribution rule as _group_qualifying_rows() (see
    _resolve_qualifying_group()) rather than counting every qualifying row
    - a student with two qualifying applications this month (e.g. two
    courses, both QA Passed) is still only one Actual for that Consultant
    up in the OXF summary card, so this section's Month Total must count
    them the same way or the two totals would silently disagree. The one
    row chosen for each student's group also supplies which single day
    they're bucketed under."""
    grouped = _group_rows_by_qa_passed_student_code(rows, year, month)

    day_counts = {}  # date -> {consultant: count}
    consultants_seen = set()

    for group in grouped.values():
        any_consultant, consultant, office, chosen_row = _resolve_qualifying_group(group)
        if not any_consultant or office != OXFORD_SALES_OFFICE:
            continue

        consultants_seen.add(consultant)
        day = _qa_passed_date(chosen_row)
        day_counts.setdefault(day, {})
        day_counts[day][consultant] = day_counts[day].get(consultant, 0) + 1

    ordered_consultants = sorted(consultants_seen, key=str.lower)
    ordered_days = sorted(day_counts.keys())

    day_rows = []
    for day in ordered_days:
        counts_for_day = day_counts[day]
        counts = [counts_for_day.get(consultant, 0) for consultant in ordered_consultants]
        day_rows.append(
            {
                "day": day,
                "label": day.strftime("%d %b"),
                "counts": counts,
                "cell_status": [_classify_oxford_cell(count) for count in counts],
                "total": sum(counts),
            }
        )

    support_totals = [
        sum(day_counts[day].get(consultant, 0) for day in ordered_days) for consultant in ordered_consultants
    ]
    grand_total = sum(support_totals)

    return {
        "support_people": ordered_consultants,
        "day_rows": day_rows,
        "support_totals": support_totals,
        "grand_total": grand_total,
    }


def get_kpi_targets(conn, year, month):
    """Return {target_type: target_value} for the given year/month (only
    the target types that have actually been saved - missing means not
    configured, never defaulted to zero)."""
    rows = conn.execute(
        "SELECT target_type, target_value FROM kpi_targets WHERE year = ? AND month = ?",
        (year, month),
    ).fetchall()
    return {row["target_type"]: row["target_value"] for row in rows}


def set_kpi_target(conn, year, month, target_type, raw_value):
    try:
        value = int(str(raw_value).strip())
    except (TypeError, ValueError):
        raise KpiTargetValidationError("Target must be a whole number.")

    if value < 0:
        raise KpiTargetValidationError("Target must be zero or greater.")
    if not fits_sqlite_integer(value):
        raise KpiTargetValidationError("Target is too large.")

    conn.execute(
        """
        INSERT INTO kpi_targets (year, month, target_type, target_value)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(year, month, target_type) DO UPDATE SET target_value = excluded.target_value
        """,
        (year, month, target_type, value),
    )
    conn.commit()
