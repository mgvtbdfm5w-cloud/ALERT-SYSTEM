"""Central authorization policy: which login roles may reach which Flask
endpoints.

This is the ONE place that decides access - app.py's single
before_request hook (_enforce_authorization) calls authorize() below for
every request, and nothing else in the app should hard-code a role list.
Endpoints are keyed by Flask endpoint name (the route function's name),
not URL, so parameterised routes (lookup edit/delete, offer-days export)
need no special handling.

CURRENT POLICY (decided by the business owner, enforced here and nowhere
else):

- full:        everything.
- admissions:  every page, report and export (including the full
               Applications/Leads downloads), plus uploading Applications
               and Leads and running Reprocess. NOT lookup mappings,
               Forecast settings, or KPI targets.
- consultants: view every page and report and use the page-level exports.
  and         NOT uploads, Reprocess, the full
  marketing:  Applications/Leads downloads, lookup mappings, Forecast
              settings, or KPI targets. (Same rights for both roles
              today; they are separate roles so that can diverge later.)

Navigation is deliberately NOT yet role-aware: every role still sees every
link and form, and a disallowed action simply returns 403. Hiding links
by role is a later step; this table is what actually enforces access.

Narrowing or widening an endpoint is a one-line edit to ENDPOINT_ROLES
below (plus the matching row in tests/test_authorization.py's expected
matrix, which exists precisely so a policy change can never be silent).

Fails closed:
- A logged-in session whose role is not one of KNOWN_ROLES (missing,
  unknown, or tampered) is denied everywhere except public endpoints.
- A non-public endpoint with no ENDPOINT_ROLES entry is denied rather
  than defaulting to open, so a newly added route that forgets a policy
  entry is never silently reachable (tests/test_authorization.py also
  fails the build if one is added without an entry).
"""

ROLE_FULL = "full"
ROLE_ADMISSIONS = "admissions"
ROLE_CONSULTANTS = "consultants"
ROLE_MARKETING = "marketing"

KNOWN_ROLES = (ROLE_FULL, ROLE_ADMISSIONS, ROLE_CONSULTANTS, ROLE_MARKETING)

# Every role, for endpoints that currently allow everyone. A named
# constant rather than a repeated literal so "everyone" reads as such.
ALL_ROLES = frozenset(KNOWN_ROLES)

# Roles allowed to upload/replace data, reprocess it, and take the full
# student-level downloads.
FULL_AND_ADMISSIONS = frozenset({ROLE_FULL, ROLE_ADMISSIONS})

# Roles allowed to change shared configuration (lookup mappings, Forecast
# settings, KPI targets).
FULL_ONLY = frozenset({ROLE_FULL})

# Reachable with no login at all. "static" is Flask's built-in handler for
# CSS/JS; the other three are the entry/exit points of the login flow.
# "logout" is POST-only and CSRF-protected (see app.py) and is DELIBERATELY
# outside role authorization: a session with an unknown or tampered role is
# denied everywhere else, so logout must stay reachable or it could never
# clear itself. It is never added to ENDPOINT_ROLES.
PUBLIC_ENDPOINTS = frozenset({"index", "login", "logout", "static"})

# endpoint name -> the set of roles allowed to reach it. Every
# authenticated route in app.py must appear here. See the module
# docstring for the policy; every entry below is one of ALL_ROLES,
# FULL_AND_ADMISSIONS, or FULL_ONLY.
ENDPOINT_ROLES = {
    # Dashboards and reporting pages
    "company_dashboard": ALL_ROLES,
    "todo": ALL_ROLES,
    "interviews": ALL_ROLES,
    "dashboard": ALL_ROLES,
    "university_pipeline": ALL_ROLES,
    "just_jon": ALL_ROLES,
    "faheem": ALL_ROLES,
    "consultants": ALL_ROLES,
    "consultants_records": ALL_ROLES,
    "enrolled": ALL_ROLES,
    "university_report": ALL_ROLES,
    "kpi": ALL_ROLES,
    "offer_days": ALL_ROLES,
    "lost_reasons": ALL_ROLES,
    "submissions": ALL_ROLES,
    "doc_check": ALL_ROLES,
    "leads_dashboard": ALL_ROLES,
    "allocation": ALL_ROLES,
    "split": ALL_ROLES,
    "ninety_days": ALL_ROLES,
    "thirty_days": ALL_ROLES,
    # Paid Ad spend and the cost/revenue figures built from it: financial, so
    # not for the view-only Consultants/Marketing roles.
    "paid_ads": FULL_AND_ADMISSIONS,
    "admin": ALL_ROLES,
    # Downloads
    "dashboard_export": ALL_ROLES,
    "just_jon_export": ALL_ROLES,
    "university_pipeline_export": ALL_ROLES,
    "university_pipeline_records": ALL_ROLES,
    "incentives": ALL_ROLES,
    "incentives_records": ALL_ROLES,
    "just_jon_records": ALL_ROLES,
    "dashboard_records": ALL_ROLES,
    "dashboard_loss_records": ALL_ROLES,
    "thirty_days_records": ALL_ROLES,
    "thirty_days_export": ALL_ROLES,
    "just_jon_lead_records": ALL_ROLES,
    "just_jon_leads_export": ALL_ROLES,
    "enrolled_export_intake_03": ALL_ROLES,
    "enrolled_export_current_intake": ALL_ROLES,
    "offer_days_export": ALL_ROLES,
    "download": FULL_AND_ADMISSIONS,
    "leads_download": FULL_AND_ADMISSIONS,
    # Uploads and data processing
    "upload": FULL_AND_ADMISSIONS,
    "leads_upload": FULL_AND_ADMISSIONS,
    "reprocess": FULL_AND_ADMISSIONS,
    # Configuration changes
    "add_lookup_route": FULL_ONLY,
    "edit_lookup_route": FULL_ONLY,
    "delete_lookup_route": FULL_ONLY,
    "update_forecast_setting_route": FULL_ONLY,
    "update_kpi_target_route": FULL_ONLY,
    "save_paid_ad_spend_route": FULL_ONLY,
    "delete_paid_ad_spend_route": FULL_ONLY,
    "save_paid_ad_settings_route": FULL_ONLY,
    # One-time data restore (off unless ENABLE_DATA_RESTORE=1): Full only.
    "admin_restore": FULL_ONLY,
    # The Admin page's access grid (see role_access.py): Full only.
    "save_role_access_route": FULL_ONLY,
    "reset_role_access_route": FULL_ONLY,
}

# Endpoints the Admin page's access grid (role_access.py) decides per role:
# endpoint -> permission key. For these (and only these) the GRID is the
# authority for every role except Full Access - ticking a box grants the
# page/download, unticking removes it - and the ENDPOINT_ROLES entry above is
# only the starting point the grid is seeded from. Everything not listed here
# (uploads, lookups, KPI targets, Paid Ads, ...) stays exactly as the fixed
# table says. Full Access always has everything, so it can never be locked
# out of Admin or of the grid itself.
ENDPOINT_PERMISSION = {
    "company_dashboard": "company_dashboard",
    "consultants": "consultants",
    "consultants_records": "consultants",  # the pop-up behind the Consultants page's charts follows the page's switch
    "faheem": "consultants",              # the old Faheem bookmark leads to the Consultants page
    "admin": "admin",
    "todo": "todo",
    "dashboard_export": "download_exports",
    "thirty_days_export": "download_exports",
    "just_jon_export": "download_exports",
    "university_pipeline_export": "download_exports",
    "just_jon_leads_export": "download_exports",
    "enrolled_export_intake_03": "download_exports",
    "enrolled_export_current_intake": "download_exports",
    "offer_days_export": "download_exports",
    "download": "download_full",
    "leads_download": "download_full",
}

ALLOW = "allow"
REQUIRE_LOGIN = "require_login"
DENY = "deny"


def authorize(endpoint, logged_in, role, access=None):
    """Return ALLOW, REQUIRE_LOGIN, or DENY for a request to `endpoint`
    from a session with the given logged_in/role values.

    - No matched endpoint (endpoint is None) is a 404/405 Flask handles
      itself - nothing to authorize.
    - Public endpoints are always allowed.
    - Not logged in -> REQUIRE_LOGIN (the existing redirect to /login).
    - Logged in with an unrecognised role -> DENY (fails closed).
    - Endpoint missing from ENDPOINT_ROLES -> DENY (fails closed).
    - Endpoint missing from ENDPOINT_ROLES -> DENY (fails closed).
    - For an endpoint in ENDPOINT_PERMISSION, when `access` ({role: set of
      permission keys}, from role_access.py) is given, the access grid
      decides for every role except Full Access: allowed exactly when that
      role's set holds the endpoint's permission (a role missing from
      `access` has none - fails closed).
    - Otherwise allowed only if the role is in that endpoint's fixed set
      (and always, for those grid endpoints, when `access` is None)."""
    if endpoint is None:
        return ALLOW
    if endpoint in PUBLIC_ENDPOINTS:
        return ALLOW
    if not logged_in:
        return REQUIRE_LOGIN
    if role not in KNOWN_ROLES:
        return DENY
    allowed = ENDPOINT_ROLES.get(endpoint)
    if allowed is None:
        return DENY
    permission = ENDPOINT_PERMISSION.get(endpoint)
    if access is not None and permission is not None and role != ROLE_FULL:
        return ALLOW if permission in access.get(role, ()) else DENY
    if role not in allowed:
        return DENY
    return ALLOW
