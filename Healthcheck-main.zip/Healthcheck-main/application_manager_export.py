"""Excel export for the Apps (Application Manager Pipeline) page - one
worksheet per Application Manager, listing only that manager's Offer
Days records (Pending Assessment/Pending Offer - see
AGE_HIGHLIGHT_STATUSES, the same 04-Onboarding/05-Assessment/
06-Decision statuses offer_days.QUALIFYING_STATUSES tracks) that are
more than AGE_HIGHLIGHT_THRESHOLD_DAYS old, for whichever year/Intake
bucket the Apps page itself is currently showing. Same one-tab-per-group
convention as offer_days.py's Total download and enrolled_export.py,
just grouped by Application Manager. A manager with nothing over that
age gets no tab at all.

Since every row is already over AGE_HIGHLIGHT_THRESHOLD_DAYS old, its
Age (Days) cell always gets a light red highlight, mirroring Offer
Days' own 30+ day ageing. A blank Submitted To Uni date (common for
anything that predates the CRM migration) is treated as
MIGRATION_FALLBACK_SUBMITTED_DATE rather than "just submitted" or
"unknown" - both the displayed Date Submitted to University cell and
the Age (Days) figure use this same fallback, so they can never
disagree with each other.

Every worksheet starts with a merged title row (see _write_title_row)
naming the sheet and today's date, then a header row in black with
white text (see HEADER_FILL/HEADER_FONT_ON_DARK), then the data -
frozen just below the header so both stay visible while scrolling. Every
worksheet is also set up to print 1 page wide, landscape (see
_apply_print_setup), however many pages tall it needs.

An extra "Top 20 Aged" tab, first in the workbook, collects the top
OVERDUE_TOP_N oldest rows across every manager that get the Age (Days)
highlight - so reviewing what's overdue doesn't mean opening every
manager's own tab in turn. That tab alone also colours its Application
Manager column with a colour unique to that manager (see
_build_manager_color_map) so a reader can spot which rows belong to the
same person at a glance without reading every name.
"""

import io
import itertools
from datetime import date

import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from dateutils import safe_date as _safe_date
from excel_export_helpers import apply_column_widths, apply_date_format, safe_append_row, unique_sheet_title
from pipeline import EXCLUDED_MANAGERS, STAGES

EXPORT_COLUMNS = [
    "Student Code",
    "Student Name",
    "University",
    "Course",
    "Application Manager",
    "Consultant",
    "Application Status",
    "Date Submitted to University",
    "Age (Days)",
]

# The only 2 stages included anywhere in this export (both the
# per-manager tabs and the Top 20 Aged summary) - the same "still
# climbing toward an offer" Offer Days tracks. See
# pipeline.PIPELINE_HEALTH_STAGE_GROUPS ("pending_assessment"/
# "pending_offer" entries) and offer_days.QUALIFYING_STATUSES.
AGE_HIGHLIGHT_STATUSES = {"04-Onboarding", "05-Assessment", "06-Decision"}
AGE_HIGHLIGHT_THRESHOLD_DAYS = 30

# The CRM migration date - a blank Submitted To Uni (no reliable data
# from the old system) is treated as if it were submitted on this date
# rather than left blank, so Age (Days) still reflects "at least this
# old" instead of looking brand new or being dropped from the ageing
# calculation entirely. Matches pipeline.py's own note that this app's
# live data effectively starts here.
MIGRATION_FALLBACK_SUBMITTED_DATE = date(2026, 7, 15)

OVERDUE_SHEET_TITLE = "Top 20 Aged"
OVERDUE_TITLE_TEXT = "Top 20 Aged Applications"
MANAGER_TITLE_TEXT = "Application Manager Aged Applications"

# Only the N oldest rows (by Age (Days)) go on the Top 20 Aged tab - a
# focused "deal with these first" list rather than every overdue row.
OVERDUE_TOP_N = 20

# A light red cell fill - this marks a cell as "worth a second look".
AGE_HIGHLIGHT_FILL = PatternFill(start_color="FFF8D7DA", end_color="FFF8D7DA", fill_type="solid")

# Every sheet's header styling - black fill, white bold text.
HEADER_FILL = PatternFill(start_color="FF000000", end_color="FF000000", fill_type="solid")
HEADER_FONT_ON_DARK = Font(bold=True, color="FFFFFFFF")

# A fixed, cyclic palette for Top 20 Aged's per-manager Application
# Manager cell colouring (see _build_manager_color_map) - light enough
# that the default black text stays readable, and deliberately avoiding
# AGE_HIGHLIGHT_FILL's own pink-red tone so a manager's colour is never
# mistaken for the "over 30 days" cell highlight.
MANAGER_COLOR_PALETTE = [
    "FFD6E4FF",  # light blue
    "FFD9F2D9",  # light green
    "FFFFF3CD",  # light yellow
    "FFE6D9F2",  # light purple
    "FFFFE0CC",  # light orange
    "FFD6F2F0",  # light teal
    "FFF2E0D6",  # light tan
    "FFE0E0E0",  # light grey
    "FFD6EAF2",  # light cyan
    "FFEAF2D6",  # light lime
]

_STAGE_ORDER = {stage: index for index, stage in enumerate(STAGES)}


def _build_manager_color_map(manager_names):
    """{manager_name: PatternFill}, one fixed colour per manager (see
    MANAGER_COLOR_PALETTE), assigned in the same alphabetical order as
    the workbook's own manager tabs - cycles through the palette if
    there are more managers than colours."""
    return {
        name: PatternFill(
            start_color=color,
            end_color=color,
            fill_type="solid",
        )
        for name, color in zip(manager_names, itertools.cycle(MANAGER_COLOR_PALETTE))
    }


def _effective_submitted_date(row):
    """The Submitted To Uni date to use for this row - the real one if
    present, otherwise MIGRATION_FALLBACK_SUBMITTED_DATE. A blank date
    on an Offer Days record doesn't mean "just submitted"; it usually
    means the real date didn't carry over from the old system, so
    treating it as "at least since the migration" is a safer floor than
    leaving it blank/unknown."""
    return _safe_date(row.get("Submitted To Uni")) or MIGRATION_FALLBACK_SUBMITTED_DATE


def _age_days(row, today):
    """Whole-number age in days (today - _effective_submitted_date) -
    always a real number now (see _effective_submitted_date), never
    None."""
    return (today - _effective_submitted_date(row)).days


def _sort_rows(rows, today):
    """Pipeline stage order (see pipeline.STAGES) first, then oldest
    Submitted To Uni date first within that stage, then Student Name."""

    def sort_key(row):
        status = (row.get("Status") or "").strip()
        stage_index = _STAGE_ORDER.get(status, len(_STAGE_ORDER))
        return (stage_index, -_age_days(row, today), (row.get("Student Name") or "").strip().lower())

    return sorted(rows, key=sort_key)


def _write_title_row(ws, title, today):
    """Row 1 on every sheet - `title` merged across every export column,
    with today's date appended, sitting above the header row."""
    ws.append([f"{title} - {today.strftime('%d/%m/%Y')}"])
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(EXPORT_COLUMNS))
    title_cell = ws.cell(row=1, column=1)
    title_cell.font = Font(bold=True, size=13)
    title_cell.alignment = Alignment(horizontal="left", vertical="center")


def _write_header(ws):
    """Appends the header row (always black/white - see HEADER_FILL/
    HEADER_FONT_ON_DARK) as whichever row comes next - row 2, below
    _write_title_row's row 1 - and returns that row's index so callers
    can finalize/freeze relative to it without hard-coding row numbers."""
    ws.append(EXPORT_COLUMNS)
    header_row_index = ws.max_row
    for cell in ws[header_row_index]:
        cell.font = HEADER_FONT_ON_DARK
        cell.fill = HEADER_FILL
    # A plain string, not ws.cell(...).coordinate - calling ws.cell() here
    # would materialize an empty cell one row below the header *before*
    # any data has been appended there, which openpyxl then treats as
    # that row already existing - every subsequent ws.append() call would
    # skip past it, leaving a blank row between the header and the data.
    ws.freeze_panes = f"A{header_row_index + 1}"
    ws.auto_filter.ref = f"A{header_row_index}:{get_column_letter(len(EXPORT_COLUMNS))}{header_row_index}"
    return header_row_index


def _finalize_columns(ws, header_row_index):
    apply_date_format(ws, EXPORT_COLUMNS, {"Date Submitted to University"}, header_row=header_row_index)
    apply_column_widths(ws, EXPORT_COLUMNS)


def _apply_print_setup(ws):
    """Landscape, fit to 1 page wide (however many pages tall it needs) -
    applied to every sheet in the workbook."""
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True


def _append_row(ws, row, today):
    """Append one export row and apply the Age (Days) highlight - shared
    by every worksheet (per-manager and the Top 20 Aged summary), so the
    rule can never drift between them."""
    status = (row.get("Status") or "").strip()
    submitted = _effective_submitted_date(row)
    age = _age_days(row, today)

    safe_append_row(
        ws,
        [
            row.get("Student Code") or "",
            row.get("Student Name") or "",
            row.get("University Name") or "",
            row.get("Course Name") or "",
            row.get("Application") or "",
            row.get("Consultant") or "",
            status,
            submitted,
            age,
        ],
    )

    if age > AGE_HIGHLIGHT_THRESHOLD_DAYS:
        ws.cell(row=ws.max_row, column=EXPORT_COLUMNS.index("Age (Days)") + 1).fill = AGE_HIGHLIGHT_FILL


def _write_manager_worksheet(ws, rows, today):
    ordered = _sort_rows(rows, today)
    _write_title_row(ws, MANAGER_TITLE_TEXT, today)
    header_row_index = _write_header(ws)
    for row in ordered:
        _append_row(ws, row, today)
    _finalize_columns(ws, header_row_index)
    _apply_print_setup(ws)


def _write_overdue_worksheet(ws, rows, today, manager_color_map):
    """Most overdue first (oldest Age (Days)), then Application Manager,
    then Student Name - unlike a manager's own tab, this one spans every
    manager, so surfacing the worst cases first is more useful than
    grouping by stage. Trimmed to the OVERDUE_TOP_N oldest after
    sorting, and each row's Application Manager cell gets that manager's
    own fixed colour (see _build_manager_color_map)."""
    ordered = sorted(
        rows,
        key=lambda row: (
            -_age_days(row, today),
            (row.get("Application") or "").strip().lower(),
            (row.get("Student Name") or "").strip().lower(),
        ),
    )[:OVERDUE_TOP_N]

    _write_title_row(ws, OVERDUE_TITLE_TEXT, today)
    header_row_index = _write_header(ws)
    manager_col_index = EXPORT_COLUMNS.index("Application Manager") + 1
    for row in ordered:
        _append_row(ws, row, today)
        manager = (row.get("Application") or "").strip()
        manager_fill = manager_color_map.get(manager)
        if manager_fill is not None:
            ws.cell(row=ws.max_row, column=manager_col_index).fill = manager_fill
    _finalize_columns(ws, header_row_index)
    _apply_print_setup(ws)


def build_application_manager_pipeline_export(rows, today):
    """Build the Apps page export workbook (an in-memory buffer) - one
    worksheet per Application Manager, each listing only that manager's
    Offer Days records (see AGE_HIGHLIGHT_STATUSES) more than
    AGE_HIGHLIGHT_THRESHOLD_DAYS old, for whichever year/Intake bucket
    `rows` has already been filtered and deduplicated to (see app.py's
    dashboard_export() route: filter_by_intake_year/
    filter_by_intake_bucket then resolve_pipeline_rows_by_student/
    drop_carried_forward_losses - the exact same steps
    _build_pipeline_dashboard_context() uses to build that report). A
    blank or EXCLUDED_MANAGERS Application is dropped entirely rather
    than exported, matching build_pipeline_report()'s own exclusion rule
    for the Application Manager Pipeline report. A manager with no rows
    left after the 30+ day filter gets no tab at all, rather than an
    empty one.

    The first tab is always "Top 20 Aged" (see OVERDUE_TOP_N), listing
    the top OVERDUE_TOP_N oldest of those same 30+ day rows across every
    manager - then one tab per Application Manager, ordered
    alphabetically (case-insensitive). There's no "Unassigned" manager
    tab, since a blank Application is dropped rather than folded into
    one (same as the chart itself)."""
    aged_rows = [
        row
        for row in rows
        if (row.get("Status") or "").strip() in AGE_HIGHLIGHT_STATUSES
        and _age_days(row, today) > AGE_HIGHLIGHT_THRESHOLD_DAYS
    ]

    by_manager = {}
    for row in aged_rows:
        manager = (row.get("Application") or "").strip()
        if not manager or manager.lower() in EXCLUDED_MANAGERS:
            continue
        by_manager.setdefault(manager, []).append(row)

    manager_names = sorted(by_manager.keys(), key=str.lower)
    included_rows = [row for manager_rows in by_manager.values() for row in manager_rows]
    manager_color_map = _build_manager_color_map(manager_names)

    workbook = openpyxl.Workbook()
    workbook.remove(workbook.active)

    used_titles = set()

    overdue_title = unique_sheet_title(OVERDUE_SHEET_TITLE, used_titles)
    used_titles.add(overdue_title)
    overdue_ws = workbook.create_sheet(title=overdue_title)
    _write_overdue_worksheet(overdue_ws, included_rows, today, manager_color_map)

    if not manager_names:
        # No rows at all - still produce a valid, openable workbook (a
        # blank workbook with zero sheets is invalid) rather than erroring.
        ws = workbook.create_sheet(title="Application Manager Pipeline")
        _write_manager_worksheet(ws, [], today)
    else:
        for name in manager_names:
            title = unique_sheet_title(name, used_titles)
            used_titles.add(title)
            ws = workbook.create_sheet(title=title)
            _write_manager_worksheet(ws, by_manager[name], today)

    buffer = io.BytesIO()
    workbook.save(buffer)
    buffer.seek(0)
    return buffer


def export_filename(today, intake_year=None, intake_bucket_label=None, intake_month_label=None):
    year_part = f"_{intake_year}" if intake_year is not None else ""
    bucket_part = f"_{intake_bucket_label.replace(' ', '')}" if intake_bucket_label else ""
    month_part = f"_{intake_month_label.replace(' ', '')}" if intake_month_label else ""
    return f"Application_Manager_Pipeline{year_part}{bucket_part}{month_part}_{today.strftime('%d-%m-%Y')}.xlsx"
