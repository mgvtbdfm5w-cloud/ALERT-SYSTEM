"""Submissions dashboard calculation logic.

Mirrors kpi.py/offer_days.py's architecture: this module does all the
filtering, grouping and date maths; the route/template only render
already-prepared data. Nothing here is persisted - everything is
recalculated from the current active dataset on every page load.

Two different time concepts are deliberately kept separate here:
  - Pending Submission / Hold are CURRENT-STATE pipeline counts, based on
    Status/Sub Status only - they never depend on Submitted To Uni or the
    selected month.
  - Submitted This Month / the daily matrix / Support monthly totals are
    all SELECTED-MONTH figures, based on Submitted To Uni, and change when
    the month dropdown changes.

Reuses dateutils.safe_date() for all date handling. The month-label/key
helpers (format_month_label, month_key, parse_month_key) are pure
calendar-formatting utilities with no KPI-specific logic that already live
in kpi.py - the route reuses those directly for this page too rather than
duplicating them here.

list_available_months() and build_daily_matrix() are generic over which
date field and which person field they group by (date_field/person_field
below), defaulting to Submitted To Uni/Support for this page's own use -
the Doc Check page reuses these same two functions with Docs
Approved/QA instead, rather than duplicating the matrix-building logic.
The returned dict keys stay named "support_*" for historical reasons (this
was Submissions-only originally) but hold whichever person_field was
requested - Doc Check's route/template just read them under that same
name for a different person.
"""

from colors import assign_categorical_colors as _assign_support_colors
from dateutils import safe_date as _safe_date

_PENDING_SUBMISSION_STATUS = "03-pendingsubmission"


def list_available_months(rows, date_field="Submitted To Uni"):
    """Return [(year, month), ...] for every distinct year/month with at
    least one valid `date_field` date, sorted newest first."""
    months = set()
    for row in rows:
        d = _safe_date(row.get(date_field))
        if d:
            months.add((d.year, d.month))
    return sorted(months, key=lambda ym: (-ym[0], -ym[1]))


def _is_pending_submission(status):
    return (status or "").strip().lower() == _PENDING_SUBMISSION_STATUS


def count_pending_submission(rows):
    """Current pipeline count of records at 03-PendingSubmission - a
    current-state measure, independent of any selected month."""
    return sum(1 for row in rows if _is_pending_submission(row.get("Status")))


def count_hold(rows):
    """Current pipeline count of 03-PendingSubmission records with a
    non-blank Sub Status - also independent of any selected month.

    The business definition is deliberately just "Pending Submission +
    non-blank Sub Status" - no specific wording is required."""
    count = 0
    for row in rows:
        if not _is_pending_submission(row.get("Status")):
            continue
        if (row.get("Sub Status") or "").strip():
            count += 1
    return count


def build_daily_matrix(rows, year, month, date_field="Submitted To Uni", person_field="Support"):
    """Return the daily person-by-date matrix for (year, month), grouped by
    `date_field` and `person_field`.

    Only rows with a valid `date_field` date falling in that month are
    included - the same filter "Submitted This Month" uses for the default
    Submitted To Uni field, so the two can never disagree. Every qualifying
    row is counted into exactly one (day, person) cell, so summing every
    cell always equals the month's total count.
    """
    day_support_counts = {}  # date -> {person: count}
    support_people = set()

    for row in rows:
        submitted = _safe_date(row.get(date_field))
        if not submitted or submitted.year != year or submitted.month != month:
            continue

        support = (row.get(person_field) or "").strip() or "Unassigned"
        support_people.add(support)

        day_counts = day_support_counts.setdefault(submitted, {})
        day_counts[support] = day_counts.get(support, 0) + 1

    ordered_support = sorted(support_people, key=str.lower)
    ordered_days = sorted(day_support_counts.keys())

    day_rows = []
    for day in ordered_days:
        counts = day_support_counts[day]
        row_counts = [counts.get(support, 0) for support in ordered_support]
        day_rows.append(
            {
                "day": day,
                "label": day.strftime("%d %b"),
                "counts": row_counts,
                "total": sum(row_counts),
            }
        )

    support_totals = [
        sum(day_support_counts[day].get(support, 0) for day in ordered_days)
        for support in ordered_support
    ]
    grand_total = sum(support_totals)

    # Largest single cell value in the whole matrix - used only for the
    # optional subtle intensity styling on non-zero cells (higher counts
    # shade slightly darker, relative to this one shared scale).
    max_cell = max((max(dr["counts"], default=0) for dr in day_rows), default=0)

    support_colors = _assign_support_colors(ordered_support)

    # Chart: one row per Support person (matching the table's alphabetical
    # order), each bar split into one segment per day they submitted,
    # chronologically - the same "scale relative to the largest value"
    # convention the Pipeline/Offer Days charts already use, so the busiest
    # person's bar is full-length and everyone else scales proportionally
    # against that same reference. Segment widths are computed here (not in
    # the template) so the chart can never disagree with the table's own
    # per-day, per-Support counts it's built from.
    max_person_total = max(support_totals, default=0)
    person_rows = []
    for idx, support in enumerate(ordered_support):
        total = support_totals[idx]
        segments = []
        for day in ordered_days:
            count = day_support_counts[day].get(support, 0)
            if count <= 0:
                continue
            width_pct = (count / max_person_total * 100) if max_person_total > 0 else 0
            segments.append(
                {"day": day, "label": day.strftime("%d %b"), "count": count, "width_pct": width_pct}
            )
        person_rows.append(
            {
                "name": support,
                "color": support_colors[idx],
                "total": total,
                "segments": segments,
            }
        )

    return {
        "support_people": ordered_support,
        "support_colors": support_colors,
        "day_rows": day_rows,
        "support_totals": support_totals,
        "grand_total": grand_total,
        "max_cell": max_cell,
        "person_rows": person_rows,
    }
