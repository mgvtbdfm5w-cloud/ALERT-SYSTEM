"""Leads Generated dashboard calculation logic.

Mirrors lost_reasons.py's architecture: this module does all the grouping;
the route/template only render already-prepared data. Nothing here is
persisted - everything is recalculated from the current active Leads
dataset on every page load.

Scope: every row in the month the caller has already filtered to (via
filter_by_creation_month below) - unlike Lost Reasons, there's no Status
to restrict to here, every Lead counts.

Chart shape: Lead Source is a group header (like Lost Reason in
lost_reasons.py), and each Sub Source under it is its own chart row - but
unlike Lost Reasons' single-colour bars, every row here is a SEGMENTED bar
broken down by Stage (leads.LEAD_STAGE_COLORS), the same "one coloured
segment per category, own colour per category" convention as
pipeline.build_chart_groups()'s per-Stage Pipeline segments. Every row's
segments (and build_lead_source_summary()'s Lead-Source-level segments)
are scaled against the single busiest row's own total across the WHOLE
report, so overall bar length stays comparable across every row on the
page, exactly like the old flat-colour bars did - only the colouring
changed, not the length convention.
"""

from dateutils import safe_date
from colors import UNASSIGNED_COLOR
from leads import LEAD_STAGE_COLORS, LEAD_STAGE_ORDER
from pipeline import JUST_JON_SUB_SOURCES, round_half_up


def filter_by_creation_month(rows, year, month):
    """Return only the rows whose Creation Date falls in (year, month) -
    the Leads Dashboard's month filter, mirroring how kpi.py/submissions.py
    scope their own reports to one month at a time."""
    result = []
    for row in rows:
        d = safe_date(row.get("Creation Date"))
        if d and d.year == year and d.month == month:
            result.append(row)
    return result


# The two Stage groupings for the Leads Dashboard's top summary cards -
# Prospecting is a lead still being worked before an Application exists;
# Applications is one that's gone in (successfully or not). A Stage in
# neither set (07-10, or blank/unrecognised) still counts in "total" but
# not either bucket - the two buckets are not meant to sum back to total.
PROSPECTING_STAGES = {"01 - New Lead", "02 - Qualified", "03 - Documents"}
APPLICATIONS_STAGES = {"04 - Applied", "05 - Enrolled", "06 - Applied Lost"}


def _applications_pct(applications, total):
    """Applications as a % of Total, rounded to the nearest whole number
    (round_half_up, the same "0.5 always rounds up" rule every other
    percentage in this app uses) - None when total is 0, rather than
    dividing by zero or showing a misleading 0%."""
    return round_half_up(applications / total * 100) if total > 0 else None


ENROLLED_STAGE = "05 - Enrolled"


def is_enrolled_lead(row, enrolled_student_codes=frozenset()):
    """A lead counts as ENROLLED when its Stage is "05 - Enrolled" OR its PES
    Code is one of `enrolled_student_codes` (see build_month_summary)."""
    code = (row.get("PES Code") or "").strip()
    return (row.get("Stage") or "").strip() == ENROLLED_STAGE or (bool(code) and code in enrolled_student_codes)


def is_application_lead(row):
    """A lead that has gone in as an application (Stage in APPLICATIONS_STAGES)."""
    return (row.get("Stage") or "").strip() in APPLICATIONS_STAGES


def build_month_summary(rows, enrolled_student_codes=frozenset()):
    """Return {"total", "prospecting", "applications", "applications_pct",
    "enrolled", "enrolled_pct"} for `rows` (the caller filters to one month
    first, via filter_by_creation_month, before calling this) - the Leads
    Dashboard's top summary cards.

    A lead counts as ENROLLED when its Stage is "05 - Enrolled" OR its PES
    Code is one of `enrolled_student_codes` (the Student Codes of 09-Enrolled
    applications), so a student the Applications data shows as enrolled is
    counted even if the CRM lead record was never moved on."""
    total = len(rows)
    prospecting = sum(1 for row in rows if (row.get("Stage") or "").strip() in PROSPECTING_STAGES)
    applications = sum(1 for row in rows if is_application_lead(row))

    enrolled_rows = [row for row in rows if is_enrolled_lead(row, enrolled_student_codes)]
    return {
        "total": total,
        "prospecting": prospecting,
        "applications": applications,
        "applications_pct": _applications_pct(applications, total),
        "enrolled": len(enrolled_rows),
        "enrolled_pct": round_half_up(len(enrolled_rows) / total * 100, 1) if total > 0 else None,
    }


def _applications_count(segments):
    """Sum of a row's own Applied/Enrolled/Applied Lost segments (see
    APPLICATIONS_STAGES) - the "Applications" figure shown next to Total
    on both Leads Dashboard charts. Derived from the row's own
    already-built segments rather than recounted from raw rows, so it
    can never disagree with what the bar itself shows."""
    return sum(seg["count"] for seg in segments if seg["stage"] in APPLICATIONS_STAGES)


def _stage_segments(stage_counts, max_count):
    """One segment per Stage present in `stage_counts`, in
    LEAD_STAGE_ORDER order, each coloured via LEAD_STAGE_COLORS - width is
    a percentage of `max_count` (the shared denominator every row on the
    page uses), so a row's total segmented length is directly comparable
    to every other row's. A Stage with zero leads is omitted, same
    convention as pipeline.build_chart_groups(). Any Stage not in
    LEAD_STAGE_ORDER (a blank/unrecognised Lead Status - see
    leads.lookup_stage) is folded into one grey "Unassigned" segment
    rather than silently vanishing from the bar."""
    segments = []
    for stage in LEAD_STAGE_ORDER:
        count = stage_counts.get(stage, 0)
        if count <= 0:
            continue
        width_pct = (count / max_count * 100) if max_count > 0 else 0
        segments.append({"stage": stage, "count": count, "width_pct": width_pct, "color": LEAD_STAGE_COLORS[stage]})

    other_count = sum(count for stage, count in stage_counts.items() if stage not in LEAD_STAGE_COLORS)
    if other_count > 0:
        width_pct = (other_count / max_count * 100) if max_count > 0 else 0
        segments.append(
            {"stage": "Unassigned", "count": other_count, "width_pct": width_pct, "color": UNASSIGNED_COLOR}
        )

    return segments


def build_lead_source_report(rows):
    """Return a plain dict report for every row in `rows` (the caller
    filters to one month first, via filter_by_creation_month, before
    calling this).

    source_groups: one entry per Lead Source (rank_by_total order - the
    source with the most leads first, name ascending as the tie-break,
    matching lost_reasons.py's own convention), each containing "rows":
    one per that source's distinct Sub Sources (also rank_by_total
    order), each with its own Stage-coloured "segments" (see
    _stage_segments above). Blank Lead Source/Sub Source both fold into
    "Unassigned", same convention used everywhere else in this app.
    """
    # sources[source][sub_source] = {"total": int, "stage_counts": {stage: count}}
    sources = {}
    total = 0
    for row in rows:
        source = (row.get("Lead Source") or "").strip() or "Unassigned"
        sub_source = (row.get("Sub Source") or "").strip() or "Unassigned"
        stage = (row.get("Stage") or "").strip()

        sub_entries = sources.setdefault(source, {})
        entry = sub_entries.setdefault(sub_source, {"total": 0, "stage_counts": {}})
        entry["total"] += 1
        entry["stage_counts"][stage] = entry["stage_counts"].get(stage, 0) + 1
        total += 1

    ordered_sources = sorted(
        sources.keys(),
        key=lambda name: (-sum(e["total"] for e in sources[name].values()), name.lower()),
    )

    # The single busiest Sub Source total across the WHOLE report (every
    # Lead Source group combined) - the shared denominator for every
    # row's segmented bar width, so a row's length is comparable to any
    # other row on the page, not just the other rows in its own Lead
    # Source group.
    max_sub_source_total = max(
        (entry["total"] for sub_entries in sources.values() for entry in sub_entries.values()),
        default=0,
    )

    source_groups = []
    for source in ordered_sources:
        sub_entries = sources[source]
        source_total = sum(e["total"] for e in sub_entries.values())

        sub_source_rows = []
        for sub_source in sorted(sub_entries.keys(), key=lambda name: (-sub_entries[name]["total"], name.lower())):
            entry = sub_entries[sub_source]
            segments = _stage_segments(entry["stage_counts"], max_sub_source_total)
            applications = _applications_count(segments)
            sub_source_rows.append(
                {
                    "name": sub_source,
                    "count": entry["total"],
                    "applications": applications,
                    "applications_pct": _applications_pct(applications, entry["total"]),
                    "segments": segments,
                }
            )

        source_groups.append({"source": source, "total": source_total, "rows": sub_source_rows})

    return {"source_groups": source_groups, "total": total}


UNASSIGNED_LABEL = "Unassigned"
OTHER_CONSULTANTS_LABEL = "Other"
PAID_AD_SOURCE = "Paid Ad"
INBOUND_CALL_SOURCE = "Inbound Call"


MIN_AGE_DAYS = 90


def filter_by_min_age_days(rows, today, days=MIN_AGE_DAYS):
    """Only the leads created at least `days` days before `today` (a lead
    created exactly `days` days ago counts); a lead with no usable Creation
    Date is left out rather than guessed at."""
    result = []
    for row in rows:
        created = safe_date(row.get("Creation Date"))
        if created and (today - created).days >= days:
            result.append(row)
    return result


def _filter_by_lead_source(rows, source):
    return [row for row in rows if (row.get("Lead Source") or "").strip().lower() == source.lower()]


def filter_paid_ad_leads(rows):
    """Only the Paid Ad leads (Lead Source "Paid Ad", any case/spacing)."""
    return _filter_by_lead_source(rows, PAID_AD_SOURCE)


def filter_just_jon_leads(rows):
    """Only the Just Jon leads: Sub Source "Jon Daniels", "Jon Daniels TT" or
    "Just Jon" (pipeline.JUST_JON_SUB_SOURCES, the same names the Just Jon
    pipeline uses), whatever the Lead Source, matched whole and ignoring
    case/spacing - so "Riley Jonathan" is not a match."""
    wanted = {name.strip().lower() for name in JUST_JON_SUB_SOURCES}
    return [row for row in rows if (row.get("Sub Source") or "").strip().lower() in wanted]


def filter_inbound_call_leads(rows):
    """Only the Inbound Call leads (Lead Source "Inbound Call", any
    case/spacing) - shown as "Inbound" on the Allocation page."""
    return _filter_by_lead_source(rows, INBOUND_CALL_SOURCE)


def _allocation_slot(row, office_by_consultant, other_consultants):
    """(Office, row name) a lead sits under on the Allocation and Split pages:
    no Consultant -> Unassigned/Unassigned; a Consultant with no Office on the
    lookup -> "Other" office; a "Group as Other" Consultant -> the "Other" row
    in their Office."""
    consultant = (row.get("Consultant") or "").strip()
    if not consultant:
        return UNASSIGNED_LABEL, UNASSIGNED_LABEL
    office = (office_by_consultant.get(consultant.lower()) or "").strip() or "Other"
    name = OTHER_CONSULTANTS_LABEL if consultant.lower() in other_consultants else consultant
    return office, name


def allocation_office(row, office_by_consultant=None, other_consultants=None):
    """The Sales Office a lead sits under on the Allocation / Split pages and the
    Paid Ads by-office table: its Consultant's office on the Consultant lookup;
    "Other" for a Consultant that is not on the lookup (or has no office there);
    "Unassigned" for a lead with no Consultant."""
    return _allocation_slot(row, office_by_consultant or {}, other_consultants or set())[0]


def build_allocation_report(rows, office_by_consultant=None, other_consultants=None):
    """The Allocation page's chart: the same Stage-coloured bars as the Lead
    Source chart, grouped by OFFICE with one row per CONSULTANT.

    `rows` are Leads rows (the caller filters to one month, and for the Paid
    Ads chart to Paid Ad leads, first). A lead's Consultant is its own
    "Consultant" field; its Office is looked up from `office_by_consultant`
    ({consultant name, lower case: Sales Office} - the Consultant lookup
    table). A Consultant with no Office there goes under "Other"; a lead with
    no Consultant at all is shown as "Unassigned" (a lead nobody has been
    allocated to). Consultants in `other_consultants` (lower-case names set
    to "Group as Other" on the Admin page) get no row of their own: their
    leads are added together into one "Other" row in their Office, so every
    Office total still equals the sum of its rows.

    Returns {"groups": [{"label", "office", "total", "rows": [...]}], "total"}
    in the shapes the Lead Source chart template uses (each row has name,
    count, applications, applications_pct, segments). Offices and rows are
    ranked by total, name ascending as the tie-break; every bar is scaled to
    the single busiest row so they can all be compared."""
    office_by_consultant = office_by_consultant or {}
    other_consultants = other_consultants or set()

    # offices[office][row name (lower)] = {"name", "total", "stage_counts"}
    offices = {}
    total = 0
    for row in rows:
        stage = (row.get("Stage") or "").strip()
        office, name = _allocation_slot(row, office_by_consultant, other_consultants)
        entries = offices.setdefault(office, {})
        entry = entries.setdefault(name.lower(), {"name": name, "total": 0, "stage_counts": {}})
        entry["total"] += 1
        entry["stage_counts"][stage] = entry["stage_counts"].get(stage, 0) + 1
        total += 1

    max_row_total = max((e["total"] for entries in offices.values() for e in entries.values()), default=0)
    ordered_offices = sorted(offices, key=lambda o: (-sum(e["total"] for e in offices[o].values()), o.lower()))

    groups = []
    for office in ordered_offices:
        entries = offices[office]
        rows_out = []
        for entry in sorted(entries.values(), key=lambda e: (-e["total"], e["name"].lower())):
            segments = _stage_segments(entry["stage_counts"], max_row_total)
            applications = _applications_count(segments)
            rows_out.append(
                {
                    "name": entry["name"],
                    "count": entry["total"],
                    "applications": applications,
                    "applications_pct": _applications_pct(applications, entry["total"]),
                    "segments": segments,
                }
            )
        office_total = sum(e["total"] for e in entries.values())
        groups.append({"label": f"{office} ({office_total})", "office": office, "total": office_total, "rows": rows_out})

    return {"groups": groups, "total": total}


def is_paid_ad_lead(row):
    """True for a Paid Ad lead (Lead Source "Paid Ad", any case/spacing)."""
    return (row.get("Lead Source") or "").strip().lower() == PAID_AD_SOURCE.lower()


def _split_counts():
    return {"paid": 0, "non_paid": 0, "total": 0}


def _split_figures():
    return {"leads": _split_counts(), "applications": _split_counts(), "enrolled": _split_counts()}


def _add_paid_pct(figures):
    """Set "paid_pct" on each measure: Paid as a whole-number % of Total
    (round_half_up, like every other percentage here), None when Total is 0."""
    for counts in figures.values():
        counts["paid_pct"] = round_half_up(counts["paid"] / counts["total"] * 100) if counts["total"] > 0 else None


def _add_to_split(figures, row, enrolled_student_codes):
    kind = "paid" if is_paid_ad_lead(row) else "non_paid"
    measures = ["leads"]
    if is_application_lead(row):
        measures.append("applications")
    if is_enrolled_lead(row, enrolled_student_codes):
        measures.append("enrolled")
    for measure in measures:
        figures[measure][kind] += 1
        figures[measure]["total"] += 1


def build_split_report(rows, office_by_consultant=None, other_consultants=None, enrolled_student_codes=frozenset()):
    """The Split page's table: for each Consultant (grouped by Office, exactly
    as on the Allocation page - see _allocation_slot) how many of the month's
    leads were Paid Ad vs Non Paid (any other Lead Source), and how many of
    those leads are now Applications and Enrolled, each with a Total.

    `rows` are Leads rows (the caller filters to one month first). Leads
    allocated = every lead; Applications = leads in APPLICATIONS_STAGES;
    Enrolled = leads that are enrolled (is_enrolled_lead) - the same
    definitions as the Leads Dashboard's summary cards, so the totals agree.

    Returns {"groups": [{"office", "figures", "rows": [{"name", "figures"}]}],
    "figures"} where every "figures" is {"leads"|"applications"|"enrolled":
    {"paid", "non_paid", "total", "paid_pct"}} (paid_pct = Paid as a whole-number
    % of Total, None when Total is 0). Offices and Consultants are ranked by
    leads allocated, name ascending as the tie-break; every Office's figures
    are the sum of its rows and the grand figures the sum of the Offices."""
    office_by_consultant = office_by_consultant or {}
    other_consultants = other_consultants or set()

    offices = {}
    grand = _split_figures()
    for row in rows:
        office, name = _allocation_slot(row, office_by_consultant, other_consultants)
        entries = offices.setdefault(office, {})
        entry = entries.setdefault(name.lower(), {"name": name, "figures": _split_figures()})
        _add_to_split(entry["figures"], row, enrolled_student_codes)
        _add_to_split(grand, row, enrolled_student_codes)

    def office_figures(entries):
        figures = _split_figures()
        for entry in entries.values():
            for measure in figures:
                for kind in ("paid", "non_paid", "total"):
                    figures[measure][kind] += entry["figures"][measure][kind]
        return figures

    groups = []
    for office, entries in offices.items():
        groups.append(
            {
                "office": office,
                "figures": office_figures(entries),
                "rows": sorted(entries.values(), key=lambda e: (-e["figures"]["leads"]["total"], e["name"].lower())),
            }
        )
    groups.sort(key=lambda g: (-g["figures"]["leads"]["total"], g["office"].lower()))
    _add_paid_pct(grand)
    for group in groups:
        _add_paid_pct(group["figures"])
        for entry in group["rows"]:
            _add_paid_pct(entry["figures"])
    return {"groups": groups, "figures": grand}


def allocation_segment_rows(rows, office, name, stage, office_by_consultant=None, other_consultants=None):
    """The leads behind one piece of an Allocation-style chart (build_allocation_report):
    the leads sitting under `office` / `name` (see _allocation_slot) at `stage`.
    "Unassigned" is the grey piece: any lead whose Stage is not one of the
    recognised stages (see _stage_segments)."""
    office_by_consultant = office_by_consultant or {}
    other_consultants = other_consultants or set()
    result = []
    for row in rows:
        if _allocation_slot(row, office_by_consultant, other_consultants) != (office, name):
            continue
        row_stage = (row.get("Stage") or "").strip()
        in_piece = row_stage not in LEAD_STAGE_COLORS if stage == UNASSIGNED_LABEL else row_stage == stage
        if in_piece:
            result.append(row)
    return result


# The click-through window's columns for a lead (label, key in lead_records()).
LEAD_RECORD_COLUMNS = [
    ["PES Code", "code"],
    ["Name", "name"],
    ["Lead Source", "lead_source"],
    ["Sub Source", "sub_source"],
    ["Lead Status", "lead_status"],
    ["Consultant", "consultant"],
    ["Created", "created"],
]


def lead_record(row):
    """One lead as a plain dict for the click-through window and the Just Jon
    export (see LEAD_RECORD_COLUMNS). A blank Consultant reads "Unassigned";
    Created is DD/MM/YYYY (blank if there is no usable date)."""
    created = safe_date(row.get("Creation Date"))
    return {
        "code": (row.get("PES Code") or "").strip(),
        "name": (row.get("Name") or "").strip(),
        "lead_source": (row.get("Lead Source") or "").strip(),
        "sub_source": (row.get("Sub Source") or "").strip(),
        "lead_status": (row.get("Lead Status") or "").strip(),
        "consultant": (row.get("Consultant") or "").strip() or UNASSIGNED_LABEL,
        "created": created.strftime("%d/%m/%Y") if created else "",
    }


def lead_records(rows):
    """lead_record() for each lead, sorted by Name then PES Code."""
    return sorted((lead_record(row) for row in rows), key=lambda r: (r["name"].lower(), r["code"]))


def build_lead_source_summary(report):
    """One row per Lead Source, no Sub Source breakdown - a high-level
    view shown above the detailed Lead Source/Sub Source chart. Reshaped
    directly from an already-built build_lead_source_report()'s
    source_groups (summing each group's Sub Source rows' own segment
    counts back up by Stage), so its totals can never disagree with the
    detailed chart below it - no new counting happens here, only
    re-aggregation.

    Segments are scaled against the single busiest Lead Source's own
    total (not any Sub Source's) - this chart's bars are only ever
    comparable to each other, not to the detailed chart's bars."""
    max_total = max((group["total"] for group in report["source_groups"]), default=0)
    rows = []
    for group in report["source_groups"]:
        stage_counts = {}
        for sub_row in group["rows"]:
            for segment in sub_row["segments"]:
                stage_counts[segment["stage"]] = stage_counts.get(segment["stage"], 0) + segment["count"]
        segments = _stage_segments(stage_counts, max_total)
        applications = _applications_count(segments)
        rows.append(
            {
                "name": group["source"],
                "count": group["total"],
                "applications": applications,
                "applications_pct": _applications_pct(applications, group["total"]),
                "segments": segments,
            }
        )
    return rows
