"""Shared date-safety helpers used anywhere Current Data date fields are read."""

from datetime import date, datetime, timezone
from zoneinfo import ZoneInfo

# Single source of truth for "what timezone is this business in" - the app
# is deployed on a server that runs in UTC (gunicorn), but every date-based
# decision (today/tomorrow, age-bucketing, "today's" date shown on screen)
# needs to reflect UK local time (GMT/BST-aware), not the server's clock.
UK_TIMEZONE = ZoneInfo("Europe/London")


def today_uk():
    """Return today's date in UK local time (GMT/BST-aware) - use this
    instead of date.today() for any business-logic "today", since the
    server's own clock is UTC and the two disagree for up to an hour a day
    during British Summer Time."""
    return datetime.now(timezone.utc).astimezone(UK_TIMEZONE).date()


def safe_date(value):
    """Coerce a processed-row date value to a date object, or None.

    Accepts date/datetime objects or ISO 'YYYY-MM-DD' strings (how dates are
    stored in Current Data). Anything blank, malformed, or unrecognised is
    treated as "no date" rather than raising.
    """
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, str):
        stripped = value.strip()
        if not stripped:
            return None
        try:
            return date.fromisoformat(stripped)
        except ValueError:
            return None
    return None
