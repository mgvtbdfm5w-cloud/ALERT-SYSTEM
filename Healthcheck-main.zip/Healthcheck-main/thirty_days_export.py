"""Excel export for the 30 Day Offers Accepted page: one worksheet listing the
Eligible applications (offer accepted within 30 days of the Submitted To Uni
date - see bonus.py) behind the page's chart, sorted by Application Manager.
It is used for checking commission, so only Eligible applications are in it.

No filtering happens in here; the caller passes the chart the page itself shows
(bonus.build_bonus_chart), so the sheet holds exactly the applications counted
as Eligible - for the "Submitted to uni in" month chosen, or every month."""

import io

import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from bonus import ELIGIBLE, UNASSIGNED, submitted_date
from dateutils import safe_date
from excel_export_helpers import apply_column_widths, apply_date_format, safe_append_row

SHEET_TITLE = "30 Day Offers Accepted"
EXPORT_COLUMNS = [
    "Application Manager",
    "Office",
    "PES Code",
    "Student Name",
    "University",
    "Course",
    "Intake",
    "Consultant",
    "Application Status",
    "Date Submitted to University",
    "Offer Accepted Date",
    "Days to Offer",
]
DATE_COLUMNS = {"Date Submitted to University", "Offer Accepted Date"}
HEADER_ROW = 2

HEADER_FILL = PatternFill(start_color="FF000000", end_color="FF000000", fill_type="solid")
HEADER_FONT = Font(bold=True, color="FFFFFFFF")


def eligible_rows(chart):
    """The (manager, row) pairs the chart counts as Eligible, sorted by Application
    Manager (A to Z, "Unassigned" last), then the Submitted To Uni date, then Student
    Name and PES Code."""
    pairs = [(manager, row) for manager, per in chart["managers"].items() for row in per[ELIGIBLE]]
    return sorted(
        pairs,
        key=lambda p: (
            p[0] == UNASSIGNED,
            p[0].lower(),
            p[0],
            submitted_date(p[1]),
            (p[1].get("Student Name") or "").strip().lower(),
            (p[1].get("Student Code") or "").strip(),
        ),
    )


def build_thirty_days_export(chart, today, month_label=None):
    """The workbook (an in-memory buffer). `month_label` ("October 2026") names the
    "Submitted to uni in" month the chart was narrowed to, or None for every month."""
    workbook = openpyxl.Workbook()
    ws = workbook.active
    ws.title = SHEET_TITLE

    title = f"{SHEET_TITLE} - Eligible applications"
    if month_label:
        title += f" - submitted in {month_label}"
    ws.append([f"{title} - {today.strftime('%d/%m/%Y')}"])
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(EXPORT_COLUMNS))
    ws.cell(row=1, column=1).font = Font(bold=True, size=13)
    ws.cell(row=1, column=1).alignment = Alignment(horizontal="left", vertical="center")

    ws.append(EXPORT_COLUMNS)
    for cell in ws[HEADER_ROW]:
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
    ws.freeze_panes = f"A{HEADER_ROW + 1}"
    ws.auto_filter.ref = f"A{HEADER_ROW}:{get_column_letter(len(EXPORT_COLUMNS))}{HEADER_ROW}"

    for manager, row in eligible_rows(chart):
        submitted = submitted_date(row)
        accepted = safe_date(row.get("Offer Accepted Date"))
        safe_append_row(
            ws,
            [
                manager,
                (row.get("Office") or "").strip(),
                (row.get("Student Code") or "").strip(),
                (row.get("Student Name") or "").strip(),
                (row.get("University Name") or "").strip(),
                (row.get("Course Name") or "").strip(),
                (row.get("Intake") or "").strip(),
                (row.get("Consultant") or "").strip(),
                (row.get("Status") or "").strip(),
                submitted,
                accepted,
                (accepted - submitted).days,
            ],
        )

    apply_date_format(ws, EXPORT_COLUMNS, DATE_COLUMNS, header_row=HEADER_ROW)
    apply_column_widths(ws, EXPORT_COLUMNS)
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True

    buffer = io.BytesIO()
    workbook.save(buffer)
    buffer.seek(0)
    return buffer


def export_filename(today, month_label=None):
    month_part = f"_{month_label.replace(' ', '')}" if month_label else ""
    return f"30_Day_Offers_Accepted{month_part}_{today.strftime('%d-%m-%Y')}.xlsx"
