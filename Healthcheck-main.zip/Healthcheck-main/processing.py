import io
import json
import logging
import re
from datetime import date, datetime

import openpyxl

from db import cleanup_orphaned_uploads, prune_active_dataset_table
from excel_export_helpers import apply_column_widths, apply_date_format, safe_append_row
from pipeline import STAGES

logger = logging.getLogger(__name__)

COLUMNS = [
    "Student Code", "Student Name", "Intake", "University Name", "Course Name",
    "Status", "Source", "Sub-Source", "Consultant", "Sales Office",
    "Application", "Office", "QA", "Support", "Created", "Docs Approved",
    "QA Passed", "Submitted To Uni", "Sub Status", "Student Number", "Interview Date",
    "Lost Reason", "Lost Sub Reason", "Enrolled Date", "Offer Accepted Date",
    "Location", "Email",
]

DATE_COLUMNS = {
    "Created", "Docs Approved", "QA Passed", "Submitted To Uni", "Interview Date",
    "Enrolled Date", "Offer Accepted Date",
}

_STAGE_LENGTH_PATTERN = re.compile(r"^(\d+)\s+days?\s+ago$", re.IGNORECASE)


def parse_stage_length_days(value):
    """Parse a Stage Length value like "4 Days ago" / "0 Day ago" (the
    optional column read below) into an int, or None if blank/unrecognised
    - never raises on bad input. Shared by healthcheck.py's New App/QA
    "stuck" rules and kpi.py's Pipeline Backlog average-days figures, so
    both read this single definition of what Stage Length means."""
    if not value:
        return None
    match = _STAGE_LENGTH_PATTERN.match(str(value).strip())
    if not match:
        return None
    return int(match.group(1))

REQUIRED_IMPORT_COLUMNS = [
    "Student Code", "Student Name", "Intake", "University Name", "Course Name",
    "Application Status", "Lead Source", "Counsellor", "Admission Officer",
    "QA Officer", "Other Contact", "Applied On", "Document Approved Date",
    "QA Signed Off", "Uni Submission Done", "Submission Complete",
    "Application ID", "Interview Booked Date/Time",
]

# (lookup table_name, Lookups-sheet key column, Lookups-sheet value column)
LOOKUP_SHEET_RANGES = [
    ("status", "A", "B"),
    ("office", "D", "E"),
    ("sales_office", "G", "H"),
]

LOOKUP_TABLE_INFO = {
    "status": {
        "label": "Application Status",
        "source_label": "Application Status",
        "value_label": "Health Check Status",
    },
    "office": {
        "label": "Admission Officer",
        "source_label": "Admission Officer",
        "value_label": "Office",
    },
    "sales_office": {
        "label": "Consultant",
        "source_label": "Consultant",
        "value_label": "Sales Office",
    },
}


class ProcessingError(Exception):
    """A problem with the uploaded workbook that the USER can understand and
    fix. Its message is shown verbatim on the Admin page ("Upload failed:
    <message>"), so it must only ever be built from literals and values the
    user supplied themselves (sheet names, the required column list) -
    NEVER from a caught exception's text (which can contain server paths,
    SQL, library internals or source filenames). Unexpected technical
    failures are not ProcessingErrors: they propagate to the route's
    generic handler, which logs the traceback and shows a safe message."""


def is_filesystem_error(exc):
    """True for a genuine operating-system failure (missing file, permission
    denied, disk I/O error, ...) as opposed to an invalid workbook.

    Real OS errors always carry an errno. openpyxl, however, signals "this
    zip has no workbook part" with a hand-built IOError("File contains no
    valid workbook part") - an OSError subclass with NO errno - which is a bad
    FILE, not a server problem. Telling them apart by errno (not by message
    text) keeps both classified correctly."""
    return isinstance(exc, OSError) and exc.errno is not None


# Shown when a workbook cannot be opened because the FILE is bad (not a zip,
# corrupt, missing workbook parts, ...). Deliberately free of any detail from
# the library error, which is logged instead.
WORKBOOK_UNREADABLE_MESSAGE = (
    "The file could not be opened as an Excel workbook. "
    "Please check that it is a valid .xlsx file and try again."
)


def first_token(value):
    if not value:
        return ""
    stripped = str(value).strip()
    if not stripped:
        return ""
    return stripped.split()[0]


def _collapse_whitespace(value):
    return " ".join(value.split())


# The source workbook isn't consistent about capitalising/abbreviating
# this one Sub-Source (also seen as plain "Jon Daniels", with no "TT" at
# all) - every variant is normalised to this one canonical spelling so
# every Sub-Source-based feature (the "Just Jon" Dashboard filter, Lost
# Reasons' filters, etc.) can match it with a single exact value instead
# of every caller having to know about the variants.
_JON_DANIELS_SUB_SOURCE_VARIANTS = {"jon daniels", "jon daniels tt"}
_JON_DANIELS_SUB_SOURCE = "Jon Daniels TT"

# A Lead Source of "Inbound Call" paired with a staff/Consultant name as
# its Sub-Source is a data-entry quirk in the source workbook (the caller
# just phoned in - there's no real Sub-Source, but whichever staff member
# logged the call got attached as one instead). Only rewritten when the
# Lead Source is specifically "Inbound Call" - the same names are genuine,
# meaningful Sub-Sources for other Lead Sources (e.g. "Staff Referral /
# Mel Imonhimi") and must stay untouched there.
_INBOUND_CALL_SOURCE = "inbound call"
_INBOUND_CALL_STAFF_SUB_SOURCES = {
    "adam haddadene",
    "amjed abdel",
    "claudio rodrigues",
    "faheem ahmed",
    "hannah west",
    "jack knight",
    "jalloh mohamed",
    "jay syed",
    "kian fogh",
    "mel imonhimi",
    "mo omer",
    "monika morgans",
    "mustapha falola",
    "nahidul kamalee",
    "nicoleta dumitrache",
    "oliver hravodsky",
    "raneen ali",
    "raymond odetah",
    "solyman meer",
    "tanaka chitsenga",
    "tyrone roberts",
    "yuliia bashkirova",
}
_INBOUND_CALL_STAFF_SUB_SOURCE_REPLACEMENT = "Telephone"


def split_lead_source(value):
    if not value or not str(value).strip():
        return "", ""
    raw = _collapse_whitespace(str(value))
    if "/" not in raw:
        return raw, ""
    idx = raw.find("/")
    source = raw[:idx].strip()
    sub_source = raw[idx + 1:].strip().title()
    if sub_source.lower() in _JON_DANIELS_SUB_SOURCE_VARIANTS:
        sub_source = _JON_DANIELS_SUB_SOURCE
    if source.lower() == _INBOUND_CALL_SOURCE and sub_source.lower() in _INBOUND_CALL_STAFF_SUB_SOURCES:
        sub_source = _INBOUND_CALL_STAFF_SUB_SOURCE_REPLACEMENT
    return source, sub_source


def parse_date(value):
    if value is None:
        return None
    # A cell Excel actually formats as a date (rather than plain text) comes
    # back from openpyxl as a real datetime/date object, not a string - the
    # DD/MM/YYYY text-slicing logic below would silently mangle
    # str(datetime(...)) (which is "YYYY-MM-DD HH:MM:SS") into garbage and
    # return None, dropping a perfectly valid date. datetime must be checked
    # before date since datetime is a subclass of date.
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    if not str(value).strip():
        return None
    s = str(value).strip()
    if len(s) < 10:
        return None
    try:
        day = int(s[0:2])
        month = int(s[3:5])
        year = int(s[6:10])
    except ValueError:
        return None
    if year <= 1899:
        # Mirrors Excel's DATE() behaviour: a year of 0-1899 is treated as 1900+year.
        year += 1900
    try:
        return date(year, month, day).isoformat()
    except ValueError:
        return None


def _phone_text(value):
    """A phone number as text: a blank cell is "", a number Excel stored as a
    numeric cell is written without a trailing ".0", anything else is trimmed."""
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        value = int(value)
    return str(value).strip()


def read_lookup_groups(workbook):
    if "Lookups" not in workbook.sheetnames:
        return {}
    ws = workbook["Lookups"]
    groups = {}
    for table_name, key_col, val_col in LOOKUP_SHEET_RANGES:
        pairs = []
        for row in range(2, ws.max_row + 1):
            key = ws[f"{key_col}{row}"].value
            val = ws[f"{val_col}{row}"].value
            if key is None or str(key).strip() == "":
                continue
            pairs.append((str(key).strip(), "" if val is None else str(val).strip()))
        groups[table_name] = pairs
    return groups


def seed_lookup_tables_if_empty(conn, workbook, now_iso):
    count = conn.execute("SELECT COUNT(*) AS c FROM lookup_tables").fetchone()["c"]
    if count > 0:
        return False

    groups = read_lookup_groups(workbook)
    for table_name, pairs in groups.items():
        # add_lookup()/update_lookup() both reject a source_value that
        # already exists (case-insensitively) for a table - seeding must
        # enforce the same rule, or two rows in the source workbook's own
        # Lookups sheet that differ only by case/whitespace would both get
        # inserted, leaving _load_lookup_dict() to silently pick whichever
        # one SQLite happens to return last.
        seen = set()
        for source_value, mapped_value in pairs:
            key = source_value.strip().lower()
            if key in seen:
                continue
            seen.add(key)
            conn.execute(
                "INSERT INTO lookup_tables (table_name, source_value, mapped_value, created_at) "
                "VALUES (?, ?, ?, ?)",
                (table_name, source_value, mapped_value, now_iso),
            )
    return True


def _load_lookup_dict(conn, table_name):
    # Ordered by id (insertion/edit order) rather than left to SQLite's
    # unspecified default order, so that if a case/whitespace-duplicate key
    # ever exists, which row "wins" below is at least deterministic and
    # reproducible rather than arbitrary.
    rows = conn.execute(
        "SELECT source_value, mapped_value FROM lookup_tables WHERE table_name = ? ORDER BY id",
        (table_name,),
    ).fetchall()
    return {row["source_value"].strip().lower(): row["mapped_value"] for row in rows}


def _lookup(lookup_dict, raw_key):
    if not raw_key or not str(raw_key).strip():
        return "", None
    key = str(raw_key).strip()
    match = lookup_dict.get(key.lower())
    if match is not None:
        return match, None
    return "", key


def _record_unmapped(conn, table_name, value, now_iso):
    clean_value = value.strip()
    existing = conn.execute(
        "SELECT id FROM unmapped_lookup_values WHERE table_name = ? AND lower(value) = ? AND resolved = 0",
        (table_name, clean_value.lower()),
    ).fetchone()
    if existing:
        conn.execute(
            "UPDATE unmapped_lookup_values SET occurrence_count = occurrence_count + 1 WHERE id = ?",
            (existing["id"],),
        )
        return

    conn.execute(
        "INSERT INTO unmapped_lookup_values (table_name, value, first_seen_at, resolved, occurrence_count) "
        "VALUES (?, ?, ?, 0, 1)",
        (table_name, clean_value, now_iso),
    )


def _json_safe(value):
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    return str(value)


def _read_headers(ws):
    header_to_col = {}
    for col in range(1, ws.max_column + 1):
        header = ws.cell(row=1, column=col).value
        if header:
            header_to_col[str(header).strip()] = col
    return header_to_col


def _find_source_sheet(workbook):
    """Locate the sheet holding the raw source data.

    Real-world exports arrive as a single sheet with an arbitrary name (e.g.
    'Sheet1'), while the original reference workbook used a sheet literally
    named 'Import'. Rather than depending on a fixed sheet name, find whichever
    sheet actually has the required columns.
    """
    if "Import" in workbook.sheetnames:
        ws = workbook["Import"]
        return ws, _read_headers(ws)

    if len(workbook.sheetnames) == 1:
        ws = workbook[workbook.sheetnames[0]]
        return ws, _read_headers(ws)

    for name in workbook.sheetnames:
        ws = workbook[name]
        header_to_col = _read_headers(ws)
        if all(c in header_to_col for c in REQUIRED_IMPORT_COLUMNS):
            return ws, header_to_col

    raise ProcessingError(
        "Could not find a sheet containing the required source columns. "
        "Sheets found in the workbook: " + ", ".join(workbook.sheetnames)
    )


def process_workbook(file_path, conn, now_iso):
    """Read the uploaded workbook and return (processed_rows, unmapped_count).

    TRANSACTION CONTRACT - read this before calling it:
    this function may WRITE, through the caller's connection: the first-ever
    seeding of `lookup_tables` from the workbook's Lookups sheet, and one
    `unmapped_lookup_values` record/increment per unmapped value. Those
    writes are left PENDING in the caller's open transaction - this function
    never commits. They are committed (together with the new dataset snapshot
    and the retention pruning) by the ONE commit in save_active_dataset(), so
    that either everything the upload changed is saved or none of it is.
    The caller MUST therefore call save_active_dataset() with the same
    connection straight afterwards (upload and reprocess both do); if
    anything fails first, the caller's connection is rolled back / closed and
    every pending write disappears. On any processing error this function
    rolls the pending writes back itself before raising."""
    try:
        workbook = openpyxl.load_workbook(file_path, data_only=True)
    except Exception as exc:
        if is_filesystem_error(exc):
            # A filesystem problem (missing file, permissions, disk error),
            # not a bad workbook. Its text can contain full server paths, so
            # it is NOT turned into a user message: re-raised unchanged for
            # the route's generic handler, which logs it at ERROR with the
            # traceback and shows a safe message.
            raise
        # The file itself is invalid (corrupt, not a zip, parts missing, ...).
        # The library's wording is for the log, never for the user.
        logger.warning("Uploaded file could not be opened as an .xlsx workbook.", exc_info=True)
        raise ProcessingError(WORKBOOK_UNREADABLE_MESSAGE)

    ws, header_to_col = _find_source_sheet(workbook)

    missing = [c for c in REQUIRED_IMPORT_COLUMNS if c not in header_to_col]
    if missing:
        raise ProcessingError(
            f"The '{ws.title}' sheet is missing required column(s): " + ", ".join(missing)
        )

    def cell(row, header_name):
        return ws.cell(row=row, column=header_to_col[header_name]).value

    def optional_cell(row, header_name):
        """Like cell(), but for a column that isn't in REQUIRED_IMPORT_COLUMNS
        - returns None (rather than raising) if the workbook doesn't have
        this column at all, so older/other workbook layouts that lack it
        still upload successfully."""
        col = header_to_col.get(header_name)
        if col is None:
            return None
        return ws.cell(row=row, column=col).value

    try:
        seed_lookup_tables_if_empty(conn, workbook, now_iso)

        status_lookup = _load_lookup_dict(conn, "status")
        office_lookup = _load_lookup_dict(conn, "office")
        sales_office_lookup = _load_lookup_dict(conn, "sales_office")

        seen_unmapped = set()
        processed_rows = []

        for row in range(2, ws.max_row + 1):
            student_code = cell(row, "Student Code")
            student_name = cell(row, "Student Name")
            if (not student_code or not str(student_code).strip()) and (
                not student_name or not str(student_name).strip()
            ):
                continue

            application_status = cell(row, "Application Status")
            status_value, unmapped_status = _lookup(status_lookup, application_status)
            if unmapped_status:
                seen_unmapped.add(("status", unmapped_status.lower()))
                _record_unmapped(conn, "status", unmapped_status, now_iso)

            source, sub_source = split_lead_source(cell(row, "Lead Source"))

            consultant = first_token(cell(row, "Counsellor"))
            sales_office_value, unmapped_sales_office = _lookup(sales_office_lookup, consultant)
            if unmapped_sales_office:
                seen_unmapped.add(("sales_office", unmapped_sales_office.lower()))
                _record_unmapped(conn, "sales_office", unmapped_sales_office, now_iso)
                # A named Consultant with no mapping yet (e.g. a departed
                # employee never added to the lookup table) still counts
                # toward the Consultant Pipeline, under a generic "Other"
                # Sales Office, rather than being silently excluded from
                # it entirely (build_pipeline_report() drops any row whose
                # group is blank). Still flagged above for admin review, in
                # case it's actually a new Consultant who needs a real
                # mapping.
                sales_office_value = "Other"

            admission_officer = cell(row, "Admission Officer")
            application = first_token(admission_officer)
            office_value, unmapped_office = _lookup(office_lookup, admission_officer)
            if unmapped_office:
                seen_unmapped.add(("office", unmapped_office.lower()))
                _record_unmapped(conn, "office", unmapped_office, now_iso)

            qa = first_token(cell(row, "QA Officer"))
            support = first_token(cell(row, "Other Contact"))

            raw_fields = {col: _json_safe(cell(row, col)) for col in REQUIRED_IMPORT_COLUMNS}

            processed_rows.append(
                {
                    "Student Code": student_code or "",
                    "Student Name": student_name or "",
                    "Intake": cell(row, "Intake") or "",
                    "University Name": cell(row, "University Name") or "",
                    "Course Name": cell(row, "Course Name") or "",
                    "Status": status_value,
                    "Source": source,
                    "Sub-Source": sub_source,
                    "Consultant": consultant,
                    "Sales Office": sales_office_value,
                    "Application": application,
                    "Office": office_value,
                    "QA": qa,
                    "Support": support,
                    "Created": parse_date(cell(row, "Applied On")),
                    "Docs Approved": parse_date(cell(row, "Document Approved Date")),
                    "QA Passed": parse_date(cell(row, "QA Signed Off")),
                    "Submitted To Uni": parse_date(cell(row, "Uni Submission Done")),
                    "Sub Status": cell(row, "Submission Complete") or "",
                    "Student Number": cell(row, "Application ID") or "",
                    "Interview Date": parse_date(cell(row, "Interview Booked Date/Time")),
                    # Optional: not in REQUIRED_IMPORT_COLUMNS, so a
                    # workbook missing this column still uploads
                    # successfully (blank here instead) - read only for the
                    # New App/QA "stuck for N business days" Healthcheck
                    # rules (see healthcheck.py). Deliberately NOT in
                    # COLUMNS either, unlike the fields below - Stage
                    # Length is an internal-use-only figure, not meant to
                    # be shown in Current Data/exports.
                    "Stage Length": optional_cell(row, "Stage Length") or "",
                    # Optional (same "missing column is fine" reasoning as
                    # Stage Length above), but these four ARE in COLUMNS -
                    # shown in Current Data and the Download Spreadsheet
                    # export, and used by the Lost Reasons page.
                    "Lost Reason": optional_cell(row, "Lost Reason") or "",
                    "Lost Sub Reason": optional_cell(row, "Lost Sub Reason") or "",
                    "Enrolled Date": parse_date(optional_cell(row, "Enrolment Confirmed Date")),
                    "Offer Accepted Date": parse_date(optional_cell(row, "Offer Accepted Date")),
                    "Location": optional_cell(row, "Location") or "",
                    "Email": optional_cell(row, "Email ID") or "",
                    # Not in COLUMNS (so not shown in Current Data or the full
                    # Applications download) - read only by the Enrolled
                    # downloads. Kept as text so a leading 0 / + survives.
                    "Phone Number": _phone_text(optional_cell(row, "Mobile No")),
                    "_raw": raw_fields,
                }
            )
    except Exception:
        # Roll back, then let the ORIGINAL exception through. A user-facing
        # ProcessingError reaches the user as-is; anything else is an
        # unexpected technical failure (database, code bug, ...) that the
        # route's generic handler logs with its traceback and reports with a
        # safe message - its text must never be shown to the user.
        conn.rollback()
        raise

    if not processed_rows:
        conn.rollback()
        raise ProcessingError(f"No data rows were found in the '{ws.title}' sheet.")

    # Deliberately NO commit here - see the transaction contract above.
    return processed_rows, len(seen_unmapped)


def save_active_dataset(conn, original_filename, stored_filename, uploaded_at, rows, uploads_dir):
    """Insert a new active_dataset snapshot and prune older ones down to
    db.ACTIVE_DATASET_RETENTION_LIMIT, as a single transaction - if pruning
    fails for any reason, the insert is rolled back too rather than left
    committed with the table unpruned.

    This is the ONE commit of the whole upload/reprocess. The same open
    transaction also holds whatever process_workbook() left pending on this
    connection (first-time lookup seeding, unmapped-value bookkeeping), so
    the single commit below saves all of it together - and a failure at any
    point before it (including here) rolls ALL of it back, not just the
    snapshot.

    Once that transaction has committed successfully, also runs the
    filesystem half of the same retention policy
    (db.cleanup_orphaned_uploads()) against `uploads_dir`, deleting any
    managed upload file no longer referenced by either active_dataset or
    active_leads_dataset - deliberately a separate step, outside the
    database transaction, since a filesystem cleanup failure must never
    roll back (or be allowed to fail) an already-successful upload."""
    try:
        conn.execute(
            "INSERT INTO active_dataset (original_filename, stored_filename, uploaded_at, row_count, data_json) "
            "VALUES (?, ?, ?, ?, ?)",
            (original_filename, stored_filename, uploaded_at, len(rows), json.dumps(rows)),
        )
        prune_active_dataset_table(conn, "active_dataset")
    except Exception:
        conn.rollback()
        raise
    conn.commit()
    try:
        cleanup_orphaned_uploads(conn, uploads_dir)
    except Exception:
        # Belt and suspenders: cleanup_orphaned_uploads() already catches
        # its own errors internally and should never raise, but the save
        # above has already committed successfully by this point - nothing
        # a cleanup problem does here may ever reach the caller as a
        # failed upload.
        logger.exception("Post-save orphaned upload cleanup failed.")


_STAGE_ORDER = {stage: index for index, stage in enumerate(STAGES)}


def build_export_workbook(rows):
    workbook = openpyxl.Workbook()
    ws = workbook.active
    ws.title = "Current Data"

    ws.append(COLUMNS)

    rows = sorted(rows, key=lambda row: _STAGE_ORDER.get((row.get("Status") or "").strip(), len(_STAGE_ORDER)))

    for row in rows:
        values = []
        for column in COLUMNS:
            value = row.get(column) or ""
            if column in DATE_COLUMNS and value:
                value = date.fromisoformat(value)
            values.append(value)
        safe_append_row(ws, values)

    apply_date_format(ws, COLUMNS, DATE_COLUMNS)
    apply_column_widths(ws, COLUMNS)

    buffer = io.BytesIO()
    workbook.save(buffer)
    buffer.seek(0)
    return buffer
