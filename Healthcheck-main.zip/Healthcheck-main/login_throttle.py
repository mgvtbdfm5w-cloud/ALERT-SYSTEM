"""In-memory throttle for failed login attempts.

POLICY (see the constants below): a client address that makes
MAX_FAILED_ATTEMPTS failed attempts within FAILURE_WINDOW_SECONDS is locked
out for LOCKOUT_SECONDS. While locked, the login route must not even look at
the submitted password, so a correct guess made during a lockout gains
nothing and the lockout genuinely bounds how fast anything can be guessed.

WHAT IT KEYS ON: whatever string the caller passes - app.py passes
request.remote_addr and nothing else (X-Forwarded-For is deliberately NOT
used: without a real proxy in front it is client-controlled, so trusting it
would let an attacker pick their own identity). With the app bound to
127.0.0.1 every client has the same address, so in practice this behaves as
one global limiter; if the app is ever put behind a proxy, the proxy's
address becomes the key until ProxyFix is configured for the exact number
of trusted hops.

STATE LIVES IN THIS PROCESS ONLY. A restart clears every counter and every
lockout (an attacker able to restart the server already controls the
machine), and several Gunicorn workers or instances would each keep their
own counts, multiplying the effective limit. The app currently runs a
single worker; if that changes, this class is the thing to replace with a
shared store. Nothing here touches the database.

MEMORY IS BOUNDED: stale entries (failures older than the window, expired
lockouts) are dropped whenever a new address is added, and there is a hard
cap of MAX_TRACKED_CLIENTS entries - when it is reached the least recently
used unlocked entry is evicted first (a locked entry only if every entry is
locked), so the table can never grow past the cap.

The clock is injectable (default time.monotonic) so tests never sleep, and
every public method takes a lock, so concurrent requests cannot corrupt the
counts.
"""

import math
import threading
import time
from collections import OrderedDict, deque
from dataclasses import dataclass

MAX_FAILED_ATTEMPTS = 5
FAILURE_WINDOW_SECONDS = 10 * 60
LOCKOUT_SECONDS = 15 * 60
MAX_TRACKED_CLIENTS = 1024


@dataclass(frozen=True)
class FailureResult:
    """What record_failure() tells the caller."""

    count: int          # failures currently counted for this client (the lock-triggering one included)
    locked: bool        # True if this client is now (or was already) locked out
    retry_after: int    # whole seconds until the lockout ends (0 when not locked)


class _Entry:
    __slots__ = ("failures", "locked_until", "rejections")

    def __init__(self):
        self.failures = deque()      # timestamps of counted failures, oldest first
        self.locked_until = None     # clock reading at which the lockout ends, or None
        self.rejections = 0          # attempts turned away during the CURRENT lockout


class LoginThrottle:
    def __init__(
        self,
        *,
        max_failures=MAX_FAILED_ATTEMPTS,
        window_seconds=FAILURE_WINDOW_SECONDS,
        lockout_seconds=LOCKOUT_SECONDS,
        max_clients=MAX_TRACKED_CLIENTS,
        clock=time.monotonic,
    ):
        if max_failures < 1 or max_clients < 1:
            raise ValueError("max_failures and max_clients must be at least 1")
        self.max_failures = max_failures
        self.window_seconds = window_seconds
        self.lockout_seconds = lockout_seconds
        self.max_clients = max_clients
        self._clock = clock
        self._lock = threading.Lock()
        self._entries = OrderedDict()   # key -> _Entry, least recently used first

    # --- public API ------------------------------------------------------
    def is_locked(self, key):
        """True while `key` is locked out. An expired lockout is cleared here
        (the client's whole state is reset), so the first call after it ends
        returns False and the client starts again from zero."""
        with self._lock:
            return self._locked_state(key, self._clock()) is not None

    def retry_after(self, key):
        """Whole seconds (rounded up, at least 1) until `key`'s lockout ends;
        0 if it is not locked."""
        with self._lock:
            now = self._clock()
            entry = self._locked_state(key, now)
            return 0 if entry is None else max(1, math.ceil(entry.locked_until - now))

    def record_failure(self, key):
        """Count one failed attempt for `key` and lock it out if that was the
        MAX_FAILED_ATTEMPTS-th within the window. A failure reported for a key
        that is already locked is not counted and does not extend the lockout."""
        with self._lock:
            now = self._clock()
            entry = self._locked_state(key, now)
            if entry is not None:
                return FailureResult(self.max_failures, True, max(1, math.ceil(entry.locked_until - now)))

            entry = self._entries.get(key)
            if entry is None:
                self._make_room(now)
                entry = self._entries[key] = _Entry()
            else:
                self._entries.move_to_end(key)

            self._drop_old_failures(entry, now)
            entry.failures.append(now)
            count = len(entry.failures)
            if count >= self.max_failures:
                entry.failures.clear()
                entry.locked_until = now + self.lockout_seconds
                entry.rejections = 0
                return FailureResult(count, True, max(1, math.ceil(self.lockout_seconds)))
            return FailureResult(count, False, 0)

    def record_rejection(self, key):
        """Note that an attempt was turned away because `key` is locked;
        returns how many have been turned away during this lockout (so the
        caller can log just the first one). 0 if the key is not locked."""
        with self._lock:
            entry = self._locked_state(key, self._clock())
            if entry is None:
                return 0
            entry.rejections += 1
            return entry.rejections

    def clear(self, key):
        """Forget everything about `key` (called after a successful login)."""
        with self._lock:
            self._entries.pop(key, None)

    def prune(self):
        """Drop every stale entry now (failures outside the window and
        expired lockouts)."""
        with self._lock:
            self._prune_stale(self._clock())

    def reset_all(self):
        """Forget every client - what a process restart does."""
        with self._lock:
            self._entries.clear()

    def tracked_clients(self):
        with self._lock:
            return len(self._entries)

    # --- internals (caller holds the lock) -------------------------------
    def _locked_state(self, key, now):
        """The entry for `key` if it is currently locked; otherwise None.
        Clears the entry if its lockout has just expired."""
        entry = self._entries.get(key)
        if entry is None or entry.locked_until is None:
            return None
        if now >= entry.locked_until:
            del self._entries[key]
            return None
        return entry

    def _drop_old_failures(self, entry, now):
        cutoff = now - self.window_seconds
        while entry.failures and entry.failures[0] <= cutoff:
            entry.failures.popleft()

    def _prune_stale(self, now):
        for key in list(self._entries):
            entry = self._entries[key]
            if entry.locked_until is not None:
                if now >= entry.locked_until:
                    del self._entries[key]
                continue
            self._drop_old_failures(entry, now)
            if not entry.failures:
                del self._entries[key]

    def _make_room(self, now):
        """Called before adding a NEW key: drop every stale entry, then, if
        the table is still at its cap, evict until there is space."""
        self._prune_stale(now)
        while len(self._entries) >= self.max_clients:
            victim = next((k for k, e in self._entries.items() if e.locked_until is None), None)
            if victim is None:                       # everything is locked: drop the oldest
                victim = next(iter(self._entries))
            del self._entries[victim]
