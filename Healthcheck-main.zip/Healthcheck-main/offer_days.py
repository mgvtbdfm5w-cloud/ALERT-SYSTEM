"""Offer Days ageing dashboard calculation logic, and the matching export.

Mirrors kpi.py's architecture: this module does all the filtering, date
maths and bucketing; the route/template only render already-prepared data.
Nothing here is persisted - age is always recalculated from Submitted To
Uni and the caller-supplied "today" on every page load, so a record moves
from one bucket to the next automatically as real time passes, even if
Current Data hasn't been re-uploaded.

list_qualifying_records() is the single source of truth for "which rows are
in the Offer Days dashboard right now" - build_offer_days_report() (the
chart/summary cards) and build_offer_days_export() (the spreadsheet
download) both build on this exact same list, so the two can never disagree
about which records are included or how many there are.
"""

import io
from datetime import date

import openpyxl
from openpyxl.styles import Font
from openpyxl.utils import get_column_letter

from dateutils import safe_date as _safe_date
from excel_export_helpers import (
    apply_column_widths,
    apply_date_format,
    safe_append_row,
    safe_sheet_title,
    unique_sheet_title,
)

# Only these three stages are "pre-offer" for this dashboard - once a record
# reaches 07-Ready (or 08-Pre-Enrolled/09-Enrolled/10-Lost) it has already
# reached or passed offer and should no longer be tracked here.
QUALIFYING_STATUSES = {"04-Onboarding", "05-Assessment", "06-Decision"}

BUCKETS = ["0-10 Days", "11-20 Days", "21-30 Days", "31+ Days"]

# Cold-to-hot gradient built entirely from colours already established
# elsewhere in this app, so Offer Days reads as part of the same dashboard
# family rather than introducing an unrelated palette:
#   - 0-10 Days reuses Pipeline's 02-PendingQA blue (pipeline.STAGE_COLORS) -
#     the same "just started" colour used at the top of that gradient.
#   - 11-20 Days reuses Pipeline's 06-Decision teal/blue-green - the same
#     gradient, a few stages further along.
#   - 21-30 Days reuses the KPI page's amber/warning yellow (kpi-bar-yellow).
#   - 31+ Days reuses the softened red already used for Pipeline's 10-Lost
#     (and KPI's red) - the one colour in this app that already means
#     "needs attention".
BUCKET_COLORS = {
    "0-10 Days": "#2563eb",
    "11-20 Days": "#1c888f",
    "21-30 Days": "#eab308",
    "31+ Days": "#c0605a",
}

# URL-safe slugs for the export routes/links - avoids putting spaces or "+"
# directly in a URL path. "total" (below) is the special all-buckets case.
BUCKET_EXPORT_SLUGS = {
    "0-10 Days": "0-10",
    "11-20 Days": "11-20",
    "21-30 Days": "21-30",
    "31+ Days": "31-plus",
}
SLUG_TO_BUCKET = {slug: bucket for bucket, slug in BUCKET_EXPORT_SLUGS.items()}
TOTAL_EXPORT_SLUG = "total"

# Human-readable pieces used to build each download's filename, e.g.
# "Offer_Days_31_Plus_13-08-2026.xlsx".
_FILENAME_LABELS = {
    TOTAL_EXPORT_SLUG: "Total",
    "0-10": "0-10",
    "11-20": "11-20",
    "21-30": "21-30",
    "31-plus": "31_Plus",
}

EXPORT_COLUMNS = [
    "Student Code",
    "Student Name",
    "University",
    "Course",
    "Application Manager",
    "Consultant",
    "Application Status",
    "Date Submitted to University",
    "Offer Days",
]


def classify_bucket(age_days):
    """Return the bucket label for a non-negative age in days, or None for
    a negative age (a Submitted To Uni date that is somehow in the future)."""
    if age_days < 0:
        return None
    if age_days <= 10:
        return "0-10 Days"
    if age_days <= 20:
        return "11-20 Days"
    if age_days <= 30:
        return "21-30 Days"
    return "31+ Days"


def list_qualifying_records(rows, today):
    """Return one dict per row that currently belongs on the Offer Days
    dashboard, as of the given "today" date: {"bucket", "age_days",
    "manager", "submitted", "row"}. Excludes anything not in
    QUALIFYING_STATUSES, with no/invalid Submitted To Uni date, or with a
    future Submitted To Uni date - exactly the same three checks
    build_offer_days_report() counts as excluded, just returning the
    row-level detail instead of a tally.

    age_days is the exact whole-number age in calendar days (Today minus
    Submitted To Uni) that bucket was classified from - exposed here so the
    export can reuse this precise value directly rather than recomputing
    age separately, which is what guarantees a record classified as (say)
    21-30 Days can never show a different, disagreeing exact age in the
    spreadsheet.
    """
    records = []
    for row in rows:
        status = row.get("Status") or ""
        if status not in QUALIFYING_STATUSES:
            continue

        submitted = _safe_date(row.get("Submitted To Uni"))
        if not submitted:
            continue

        age_days = (today - submitted).days
        bucket = classify_bucket(age_days)
        if bucket is None:
            continue

        manager = (row.get("Application") or "").strip() or "Unassigned"
        records.append(
            {
                "bucket": bucket,
                "age_days": age_days,
                "manager": manager,
                "submitted": submitted,
                "row": row,
            }
        )
    return records


def _build_bucket_chart_rows(qualifying, group_key_fn, rank_by_total=False):
    """Shared grouping/bucketing logic behind every Offer Days chart
    breakdown (Application Manager, University, ...) - group_key_fn picks
    which group each qualifying record belongs to (blank/missing values
    fold into "Unassigned", same as Application Manager already did).
    Segment width is expressed as a percentage of the busiest group's
    total (the same convention pipeline.build_chart_groups uses for the
    Pipeline dashboards' charts), so bar length reflects relative volume
    across groups while each bar's internal segments stay proportional to
    that group's own age mix.

    rank_by_total: when False (the default), groups are sorted
    alphabetically. When True, they're sorted by their own total
    descending, name ascending as the tie-break - the same convention
    pipeline.build_pipeline_report() uses for University Pipeline."""
    groups = {}  # name -> {bucket: count}
    for rec in qualifying:
        key = (group_key_fn(rec) or "").strip() or "Unassigned"
        entry = groups.setdefault(key, {b: 0 for b in BUCKETS})
        entry[rec["bucket"]] += 1

    max_total = max((sum(b.values()) for b in groups.values()), default=0)

    if rank_by_total:
        ordered_names = sorted(groups.keys(), key=lambda n: (-sum(groups[n].values()), n.lower()))
    else:
        ordered_names = sorted(groups.keys(), key=str.lower)

    rows = []
    for name in ordered_names:
        buckets = groups[name]
        group_total = sum(buckets.values())

        segments = []
        for bucket in BUCKETS:
            count = buckets[bucket]
            if count <= 0:
                continue
            width_pct = (count / max_total * 100) if max_total > 0 else 0
            segments.append({"bucket": bucket, "count": count, "width_pct": width_pct})

        rows.append({"name": name, "buckets": buckets, "total": group_total, "segments": segments})

    return rows


def build_offer_days_report(rows, today):
    """Return a plain dict report built from the current active dataset
    rows, as of the given "today" date.

    today is passed in by the caller (date.today()) rather than computed
    here, so this function stays trivially testable with a fixed date.
    """
    qualifying = list_qualifying_records(rows, today)

    overall = {bucket: 0 for bucket in BUCKETS}
    total = 0
    for rec in qualifying:
        overall[rec["bucket"]] += 1
        total += 1

    # Counted separately (not from list_qualifying_records, which only
    # returns records that ARE included) purely for the "data quality"
    # figures reported elsewhere - these two counts have no bearing on the
    # chart, summary cards or export.
    invalid_date_count = 0
    future_date_count = 0
    for row in rows:
        status = row.get("Status") or ""
        if status not in QUALIFYING_STATUSES:
            continue
        submitted = _safe_date(row.get("Submitted To Uni"))
        if not submitted:
            invalid_date_count += 1
            continue
        if classify_bucket((today - submitted).days) is None:
            future_date_count += 1

    manager_rows = _build_bucket_chart_rows(qualifying, lambda rec: rec["manager"], rank_by_total=True)
    university_rows = _build_bucket_chart_rows(
        qualifying, lambda rec: rec["row"].get("University Name"), rank_by_total=True
    )

    return {
        "manager_rows": manager_rows,
        "university_rows": university_rows,
        "overall": overall,
        "total": total,
        "invalid_date_count": invalid_date_count,
        "future_date_count": future_date_count,
    }


def average_age_days(qualifying):
    """Average age (in whole days, rounded to 1 decimal place) across
    `qualifying` (as returned by list_qualifying_records()) - the
    Company Dashboard's Offer Days tile uses this across every
    currently-qualifying record (the same population as this page's own
    "Total" card), not broken down by bucket. None if there are no
    qualifying records, rather than dividing by zero or fabricating a 0."""
    if not qualifying:
        return None
    return round(sum(rec["age_days"] for rec in qualifying) / len(qualifying), 1)


def _build_average_age_by_group(qualifying, stage_groups, group_key_fn):
    """Shared grouping behind build_manager_average_age_by_group() and
    build_university_average_age_by_group() below - split `qualifying`
    (as returned by list_qualifying_records()) by whatever `group_key_fn`
    returns for each record (e.g. Application Manager, University Name),
    then further by which of `stage_groups` each record's own Status
    falls into (e.g. Pipeline's own Pending Assessment/Pending Offer
    groups - see pipeline.PIPELINE_HEALTH_STAGE_GROUPS), and
    average_age_days() each (group_key, stage_group) bucket.

    Returns {group_key: {stage_group_key: avg_days}}, only for
    combinations that actually have at least one qualifying record - a
    group with none in a given stage group has no key for it at all, so
    callers should look it up with .get() and treat a miss the same as
    average_age_days()'s own None (nothing to average).

    `stage_groups` is a plain list of {"key", "stages", ...} dicts, same
    shape as pipeline.PIPELINE_HEALTH_STAGE_GROUPS - passed in rather than imported
    from pipeline.py, since this module has no dependency on pipeline.py
    otherwise and QUALIFYING_STATUSES already covers a fixed, narrower
    set of Statuses than pipeline.STAGES."""
    by_group = {}
    for rec in qualifying:
        status = (rec["row"].get("Status") or "").strip()
        for stage_group in stage_groups:
            if status in stage_group["stages"]:
                by_group.setdefault(group_key_fn(rec), {}).setdefault(stage_group["key"], []).append(rec)
                break

    return {
        group_key: {key: average_age_days(recs) for key, recs in groups.items()}
        for group_key, groups in by_group.items()
    }


def build_manager_average_age_by_group(qualifying, stage_groups):
    """Split by Application Manager - see _build_average_age_by_group()."""
    return _build_average_age_by_group(qualifying, stage_groups, lambda rec: rec["manager"])


def build_university_average_age_by_group(qualifying, stage_groups):
    """Split by University Name - see _build_average_age_by_group(). A
    blank University Name is folded into "Unassigned", same convention
    as pipeline.build_pipeline_report's own blank_person_label."""
    return _build_average_age_by_group(
        qualifying, stage_groups, lambda rec: (rec["row"].get("University Name") or "").strip() or "Unassigned"
    )


def resolve_export_bucket(bucket_slug):
    """Translate a URL slug to (bucket_label_or_None, display_label).

    bucket_label is None for the "total" slug (meaning "every qualifying
    record, all four buckets"); display_label is used for the filename and
    worksheet title. Returns None entirely for an unrecognised slug.
    """
    if bucket_slug == TOTAL_EXPORT_SLUG:
        return None, "Total"
    bucket_label = SLUG_TO_BUCKET.get(bucket_slug)
    if not bucket_label:
        return "__invalid__", None
    return bucket_label, bucket_label


def export_filename(bucket_slug, today, intake_year=None, intake_bucket_label=None):
    label = _FILENAME_LABELS.get(bucket_slug, "Total")
    year_part = f"_{intake_year}" if intake_year is not None else ""
    bucket_part = f"_{intake_bucket_label.replace(' ', '')}" if intake_bucket_label else ""
    return f"Offer_Days_{label}{year_part}{bucket_part}_{today.strftime('%d-%m-%Y')}.xlsx"


def _sort_records(records):
    """Ordering used by the single-sheet bucket downloads (0-10/11-20/21-30/
    31+): Consultant (alphabetically, case-insensitive; blank sorts first),
    then Submitted To Uni date ascending (oldest first), then Student Name
    (alphabetically) as a tie-breaker. Which records are included at all is
    entirely decided upstream by list_qualifying_records()."""
    return sorted(
        records,
        key=lambda rec: (
            (rec["row"].get("Consultant") or "").strip().lower(),
            rec["submitted"],
            (rec["row"].get("Student Name") or "").strip().lower(),
        ),
    )


def _sort_records_by_date_first(records):
    """Ordering used within each Application Manager tab of the Total
    download: Submitted To Uni date ascending (oldest first - sorted on the
    actual parsed date object already produced by list_qualifying_records(),
    never on the DD/MM/YYYY display string written to Excel afterward),
    then Consultant alphabetically, then Student Name alphabetically as a
    final tie-breaker. This is deliberately a different priority order from
    _sort_records() above (which the bucket downloads keep using
    unchanged) - here, date takes priority over Consultant."""
    return sorted(
        records,
        key=lambda rec: (
            rec["submitted"],
            (rec["row"].get("Consultant") or "").strip().lower(),
            (rec["row"].get("Student Name") or "").strip().lower(),
        ),
    )


def _write_records_worksheet(ws, records, sort_fn=_sort_records):
    """Write the standard Offer Days export columns into an existing
    worksheet: header row, sorted data rows, and every shared formatting
    rule (bold header, frozen header, autofilter, DD/MM/YYYY date column,
    column widths). Used by both build_offer_days_export() (one sheet,
    Consultant-first order) and build_offer_days_total_export() (one sheet
    per Application Manager, date-first order via sort_fn), so the shared
    formatting can never drift between the two while each keeps its own
    required ordering."""
    ordered = sort_fn(records)

    ws.append(EXPORT_COLUMNS)
    header_font = Font(bold=True)
    for cell in ws[1]:
        cell.font = header_font
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(EXPORT_COLUMNS))}1"

    for rec in ordered:
        row = rec["row"]
        safe_append_row(
            ws,
            [
                row.get("Student Code") or "",
                row.get("Student Name") or "",
                row.get("University Name") or "",
                row.get("Course Name") or "",
                rec["manager"],
                row.get("Consultant") or "",
                row.get("Status") or "",
                rec["submitted"],
                rec["age_days"],
            ],
        )

    apply_date_format(ws, EXPORT_COLUMNS, {"Date Submitted to University"})
    apply_column_widths(ws, EXPORT_COLUMNS)


def build_offer_days_export(records, sheet_title="Offer Days"):
    """Build a single-sheet .xlsx workbook (as an in-memory buffer) from a
    list of records as returned by list_qualifying_records() (optionally
    already filtered down to one bucket). Used by the four age-bucket
    downloads. The Total download uses build_offer_days_total_export()
    instead - see that function for why it needs multiple sheets.
    """
    workbook = openpyxl.Workbook()
    ws = workbook.active
    ws.title = safe_sheet_title(sheet_title, fallback="Offer Days")
    _write_records_worksheet(ws, records)

    buffer = io.BytesIO()
    workbook.save(buffer)
    buffer.seek(0)
    return buffer


def build_offer_days_total_export(records):
    """Build the TOTAL Offer Days download: one worksheet per Application
    Manager, each containing only that manager's records - grouped using
    the "manager" field every record already carries from
    list_qualifying_records() (which already folds a blank Application
    into "Unassigned"), so no separate filtering/grouping logic is
    introduced here. Every record in `records` ends up on exactly one
    sheet, so summing every sheet's row count always equals len(records)
    (the same count the Total dashboard card shows).

    Tabs are ordered alphabetically (case-insensitive) with Unassigned - if
    present - placed last. Within each tab, rows are sorted oldest
    Submitted To Uni date first (see _sort_records_by_date_first()) - a
    different priority order from the single-sheet bucket downloads, which
    intentionally still sort Consultant-first via _sort_records().
    """
    by_manager = {}
    for rec in records:
        by_manager.setdefault(rec["manager"], []).append(rec)

    manager_names = sorted(by_manager.keys(), key=lambda n: (n == "Unassigned", n.lower()))

    workbook = openpyxl.Workbook()
    workbook.remove(workbook.active)

    used_titles = set()
    if not manager_names:
        # No qualifying records at all - still produce a valid, openable
        # workbook (a blank workbook with zero sheets is invalid) rather
        # than erroring.
        ws = workbook.create_sheet(title="Offer Days")
        _write_records_worksheet(ws, [], sort_fn=_sort_records_by_date_first)
    else:
        for name in manager_names:
            title = unique_sheet_title(name, used_titles, fallback="Offer Days")
            used_titles.add(title)
            ws = workbook.create_sheet(title=title)
            _write_records_worksheet(ws, by_manager[name], sort_fn=_sort_records_by_date_first)

    buffer = io.BytesIO()
    workbook.save(buffer)
    buffer.seek(0)
    return buffer
