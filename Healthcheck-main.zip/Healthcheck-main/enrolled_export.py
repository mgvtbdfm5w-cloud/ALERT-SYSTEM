"""Excel export for the Enrolled page's Intake 03 (live CRM) summary card -
one worksheet per University Name, since that's how this list gets
reviewed/shared. Follows the same one-tab-per-group convention as
offer_days.py's Total download, just grouped by University Name instead of
Application Manager.
"""

import io

import openpyxl
from openpyxl.styles import Font
from openpyxl.utils import get_column_letter

from dateutils import safe_date as _safe_date
from excel_export_helpers import apply_column_widths, apply_date_format, safe_append_row, unique_sheet_title

EXPORT_COLUMNS = [
    "Consultant Name",
    "PES Code",
    "Student Name",
    "Student Number",
    "Location",
    "Sub Source",
    "Phone Number",
    "Email",
    "Course",
    "Enrolled Date",
]


def _sort_rows(rows):
    """Consultant (alphabetically, case-insensitive; blank sorts first),
    then Student Name - same Consultant-first convention as Offer Days'
    single-sheet downloads."""
    return sorted(
        rows,
        key=lambda row: (
            (row.get("Consultant") or "").strip().lower(),
            (row.get("Student Name") or "").strip().lower(),
        ),
    )


def _write_rows_worksheet(ws, rows):
    ordered = _sort_rows(rows)

    ws.append(EXPORT_COLUMNS)
    header_font = Font(bold=True)
    for cell in ws[1]:
        cell.font = header_font
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(EXPORT_COLUMNS))}1"

    for row in ordered:
        safe_append_row(
            ws,
            [
                row.get("Consultant") or "",
                row.get("Student Code") or "",
                row.get("Student Name") or "",
                row.get("Student Number") or "",
                row.get("Location") or "",
                row.get("Sub-Source") or "",
                row.get("Phone Number") or "",
                row.get("Email") or "",
                row.get("Course Name") or "",
                _safe_date(row.get("Enrolled Date")),
            ]
        )

    apply_date_format(ws, EXPORT_COLUMNS, {"Enrolled Date"})
    apply_column_widths(ws, EXPORT_COLUMNS)


def build_enrolled_export(rows):
    """Build the Enrolled export workbook (an in-memory buffer) - one
    worksheet per University Name, each listing only that university's
    rows. A blank University Name is grouped under "Unassigned" rather
    than dropped, so every row in `rows` ends up on exactly one sheet -
    summing every sheet's row count always equals len(rows) (the same
    count the summary card shows).

    Tabs are ordered alphabetically (case-insensitive) with Unassigned -
    if present - placed last. `rows` is expected to already be filtered
    down to the population the caller wants exported (e.g. one Intake
    year's 09-Enrolled rows) - no filtering happens in here.
    """
    by_university = {}
    for row in rows:
        university = (row.get("University Name") or "").strip() or "Unassigned"
        by_university.setdefault(university, []).append(row)

    university_names = sorted(by_university.keys(), key=lambda n: (n == "Unassigned", n.lower()))

    workbook = openpyxl.Workbook()
    workbook.remove(workbook.active)

    used_titles = set()
    if not university_names:
        # No rows at all - still produce a valid, openable workbook (a
        # blank workbook with zero sheets is invalid) rather than erroring.
        ws = workbook.create_sheet(title="Enrolled")
        _write_rows_worksheet(ws, [])
    else:
        for name in university_names:
            title = unique_sheet_title(name, used_titles)
            used_titles.add(title)
            ws = workbook.create_sheet(title=title)
            _write_rows_worksheet(ws, by_university[name])

    buffer = io.BytesIO()
    workbook.save(buffer)
    buffer.seek(0)
    return buffer


def export_filename(today, intake_year=None, intake_bucket_label=None):
    year_part = f"_{intake_year}" if intake_year is not None else ""
    bucket_part = f"_{intake_bucket_label.replace(' ', '')}" if intake_bucket_label else ""
    return f"Enrolled{year_part}{bucket_part}_{today.strftime('%d-%m-%Y')}.xlsx"
