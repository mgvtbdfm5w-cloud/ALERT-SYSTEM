"""Admin-editable access switches: which logins can open which of the main
pages, and whether downloads are available.

Everything else about who can do what stays in authorization.py's fixed table
(uploads, lookups, KPI targets, Paid Ads, ...). For the switches below the grid
IS the authority (see authorization.ENDPOINT_PERMISSION): ticking a box grants
that page or download to the login, unticking removes it. Full Access is not
configurable: it always has every switch on, so it can never be locked out of
Admin or of this very settings grid.

Storage is the role_access table (one row per role + permission). The shipped
defaults reproduce exactly what each role could do before this feature, so
nothing changes until someone edits the grid.
"""

from authorization import ROLE_ADMISSIONS, ROLE_CONSULTANTS, ROLE_FULL, ROLE_MARKETING

# (key, label shown in the grid) - the grid's rows, in order.
PERMISSIONS = (
    ("company_dashboard", "Company Dashboard"),
    ("consultants", "Consultants"),
    ("admin", "Admin"),
    ("todo", "To Do List"),
    ("download_exports", "Download page exports (Excel files from the dashboards)"),
    ("download_full", "Download the full Applications and Leads spreadsheets"),
)
PERMISSION_KEYS = tuple(key for key, _ in PERMISSIONS)

# Roles whose switches can be edited (Full Access is always everything).
CONFIGURABLE_ROLES = (ROLE_ADMISSIONS, ROLE_CONSULTANTS, ROLE_MARKETING)
ROLE_COLUMN_LABELS = {
    ROLE_FULL: "Full Access",
    ROLE_ADMISSIONS: "Admissions",
    ROLE_CONSULTANTS: "Consultants",
    ROLE_MARKETING: "Marketing",
}

# The defaults = what every role could do before these switches existed.
_FULL_DOWNLOADS = {ROLE_ADMISSIONS}          # the full spreadsheets were Full + Admissions only


def default_allowed(role, permission):
    if permission == "download_full":
        return role in _FULL_DOWNLOADS
    return True


def default_rows():
    """[(role, permission, 1/0), ...] for every configurable role + permission."""
    return [(role, key, 1 if default_allowed(role, key) else 0) for role in CONFIGURABLE_ROLES for key in PERMISSION_KEYS]


def field_name(role, permission):
    return f"{role}__{permission}"


def load_access(conn):
    """{role: set(permission keys that role may use)} for EVERY role. Full
    Access always has them all; a configurable role's switch that has no row
    yet falls back to its default."""
    stored = {(r["role"], r["permission"]): bool(r["allowed"]) for r in conn.execute("SELECT role, permission, allowed FROM role_access")}
    access = {ROLE_FULL: set(PERMISSION_KEYS)}
    for role in CONFIGURABLE_ROLES:
        access[role] = {key for key in PERMISSION_KEYS if stored.get((role, key), default_allowed(role, key))}
    return access


def save_access(conn, form_fields, now_iso):
    """Store the grid from a submitted form: a switch is ON exactly when its
    field name (see field_name) is present. Fields for anything that is not a
    configurable role / known permission (e.g. a tampered request) are
    ignored, and Full Access cannot be changed."""
    for role in CONFIGURABLE_ROLES:
        for key in PERMISSION_KEYS:
            conn.execute(
                "INSERT INTO role_access (role, permission, allowed, updated_at) VALUES (?, ?, ?, ?) "
                "ON CONFLICT(role, permission) DO UPDATE SET allowed = excluded.allowed, updated_at = excluded.updated_at",
                (role, key, 1 if field_name(role, key) in form_fields else 0, now_iso),
            )
    conn.commit()


def reset_access(conn, now_iso):
    """Put every switch back to its default."""
    for role, key, allowed in default_rows():
        conn.execute(
            "INSERT INTO role_access (role, permission, allowed, updated_at) VALUES (?, ?, ?, ?) "
            "ON CONFLICT(role, permission) DO UPDATE SET allowed = excluded.allowed, updated_at = excluded.updated_at",
            (role, key, allowed, now_iso),
        )
    conn.commit()


def build_grid(access):
    """Rows for the Admin grid: [{"key", "label", "cells": [{"role", "field", "checked", "locked"}, ...]}, ...]
    with Full Access first (always ticked, locked)."""
    columns = (ROLE_FULL,) + CONFIGURABLE_ROLES
    return [
        {
            "key": key,
            "label": label,
            "cells": [
                {"role": role, "field": field_name(role, key), "checked": key in access[role], "locked": role == ROLE_FULL}
                for role in columns
            ],
        }
        for key, label in PERMISSIONS
    ]
