"""One-time data restore: load a database + uploaded workbooks bundle into a
fresh deployment (e.g. moving from a local Mac to Railway).

Deliberately narrow and OFF by default:
- The /admin/restore route only exists in practice when the environment
  variable ENABLE_DATA_RESTORE is "1"; otherwise it is a 404. Turn it on,
  restore once, then remove the variable.
- Only Full Access may reach it (authorization.ENDPOINT_ROLES).
- The bundle is a .tar.gz containing exactly `app.db` and, optionally,
  `uploads/<managed workbook name>.xlsx` files. Anything else (other names,
  directories, links, path traversal) rejects the whole bundle before
  anything is written.
- The database is integrity-checked in a temporary file next to the live
  one and only then atomically swapped in.
"""

import os
import re
import sqlite3
import tarfile
import tempfile
from pathlib import Path

RESTORE_ENV_VAR = "ENABLE_DATA_RESTORE"

# Bundles are compressed; this bounds what may be uploaded and also the
# total size we are willing to extract.
MAX_BUNDLE_BYTES = 200 * 1024 * 1024
MAX_EXTRACTED_BYTES = 1024 * 1024 * 1024

_UPLOAD_MEMBER = re.compile(r"uploads/((?:leads_)?\d{14}_[^/\\]+\.xlsx)")


class RestoreError(ValueError):
    """The bundle was rejected; the message is safe to show the user."""


def restore_enabled():
    return os.environ.get(RESTORE_ENV_VAR) == "1"


def _plan(archive):
    """Validate every member and return (db_member, [(member, filename)])."""
    db_member = None
    uploads = []
    total = 0
    for member in archive.getmembers():
        name = member.name
        if name.startswith("./"):
            name = name[2:]
        if member.isdir() and name in ("", ".", "uploads"):
            continue
        if not member.isfile():
            raise RestoreError("The bundle contains an unexpected entry and was not used.")
        total += member.size
        if total > MAX_EXTRACTED_BYTES:
            raise RestoreError("The bundle is too large to restore.")
        if name == "app.db":
            if db_member is not None:
                raise RestoreError("The bundle contains more than one database.")
            db_member = member
            continue
        match = _UPLOAD_MEMBER.fullmatch(name)
        if not match:
            raise RestoreError("The bundle contains an unexpected file and was not used.")
        uploads.append((member, match.group(1)))
    if db_member is None:
        raise RestoreError("The bundle does not contain app.db.")
    return db_member, uploads


def _copy_member(archive, member, destination_dir, prefix):
    """Extract one member into a temp file in destination_dir; return its path."""
    fd, tmp_name = tempfile.mkstemp(dir=destination_dir, prefix=prefix, suffix=".tmp")
    tmp_path = Path(tmp_name)
    try:
        with os.fdopen(fd, "wb") as out:
            source = archive.extractfile(member)
            while True:
                chunk = source.read(1024 * 1024)
                if not chunk:
                    break
                out.write(chunk)
            out.flush()
            os.fsync(out.fileno())
    except BaseException:
        tmp_path.unlink(missing_ok=True)
        raise
    return tmp_path


def _check_database(path):
    try:
        conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        try:
            result = conn.execute("PRAGMA integrity_check").fetchone()
        finally:
            conn.close()
    except sqlite3.Error:
        raise RestoreError("The database in the bundle could not be opened.")
    if not result or result[0] != "ok":
        raise RestoreError("The database in the bundle failed its integrity check.")


def restore_bundle(fileobj, db_path, upload_dir):
    """Restore from an open .tar.gz file object. Returns the number of
    workbooks restored. Raises RestoreError (nothing changed) on a bad
    bundle."""
    db_path = Path(db_path)
    upload_dir = Path(upload_dir)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    upload_dir.mkdir(parents=True, exist_ok=True)
    try:
        archive = tarfile.open(fileobj=fileobj, mode="r:gz")
    except (tarfile.TarError, OSError, EOFError):
        raise RestoreError("The file is not a valid .tar.gz bundle.")
    staged = []
    try:
        with archive:
            db_member, uploads = _plan(archive)
            db_tmp = _copy_member(archive, db_member, db_path.parent, ".app.db.restore.")
            staged.append(db_tmp)
            _check_database(db_tmp)
            upload_tmps = []
            for member, filename in uploads:
                tmp = _copy_member(archive, member, upload_dir, f".{filename}.")
                staged.append(tmp)
                upload_tmps.append((tmp, filename))
    except RestoreError:
        for tmp in staged:
            tmp.unlink(missing_ok=True)
        raise
    except (tarfile.TarError, OSError, EOFError):
        for tmp in staged:
            tmp.unlink(missing_ok=True)
        raise RestoreError("The bundle could not be read.")

    # Everything validated: swap in. Stale WAL/SHM files from the old
    # database must not be applied to the restored one.
    for suffix in ("-wal", "-shm"):
        Path(str(db_path) + suffix).unlink(missing_ok=True)
    os.replace(db_tmp, db_path)
    for tmp, filename in upload_tmps:
        os.replace(tmp, upload_dir / filename)
    return len(upload_tmps)
