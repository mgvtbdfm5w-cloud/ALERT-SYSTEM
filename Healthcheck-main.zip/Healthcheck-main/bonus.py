"""Bonus eligibility for the Application Manager Pipeline page's second chart.

Day one is an application's Submitted To Uni date. Within BONUS_DAYS (30) days
of day one it can still earn the bonus:

- ELIGIBLE: the Offer Accepted Date is 30 days or less after day one.
- OPEN: no offer accepted yet and 30 days or less have passed since day one -
  it can still become Eligible.
- MISSED: everything else - an offer accepted more than 30 days after day one, or
  no offer by day 31. A Lost application with no accepted offer can never earn
  the bonus, so it is Missed straight away rather than staying Open.
- NOT ELIGIBLE: the Offer Accepted Date is before day one (negative days) - a
  deferral, which does not count. It is shown on the chart and in its pop-up but
  kept out of each manager's Total and %, and out of the download.

Only applications for the 2027 Intake, submitted to a university on or after
1 October 2026, with a pipeline Status (pipeline.STAGES - so not QA-rejected or
Deferred) are included. Everything is read live from the active Applications
data, nothing is stored.
"""

from datetime import date

from dateutils import safe_date
from pipeline import (
    EXCLUDED_MANAGERS,
    STAGES,
    _fold_unassigned,
    _group_sort_key,
    filter_by_intake_year,
    round_half_up,
)

BONUS_DAYS = 30
BONUS_INTAKE_YEAR = 2027
BONUS_SUBMITTED_FROM = date(2026, 10, 1)

ELIGIBLE, OPEN, MISSED, NOT_ELIGIBLE = "Eligible", "Open", "Missed", "Not Eligible"
STATUSES = (ELIGIBLE, OPEN, MISSED, NOT_ELIGIBLE)
STATUS_COLORS = {ELIGIBLE: "#16a34a", OPEN: "#e0a526", MISSED: "#c0605a", NOT_ELIGIBLE: "#9aa4b2"}
# The statuses that count towards a manager's Total and the Eligible % (all but Not Eligible).
COUNTED_STATUSES = (ELIGIBLE, OPEN, MISSED)
LOST_STATUS = "10-Lost"
UNASSIGNED = "Unassigned"

# The click-through window's columns for a bonus piece (label, key in bonus_records()).
BONUS_RECORD_COLUMNS = [
    ["PES Code", "code"],
    ["Student", "student"],
    ["University", "university"],
    ["Intake", "intake"],
    ["Consultant", "consultant"],
    ["Submitted To Uni", "submitted"],
    ["Offer Accepted", "accepted"],
    ["Days to Offer", "days_to_offer"],
    ["Days Waiting", "days_waiting"],
]


def status_slug(status):
    """The status as used in the chart's pieces and the pop-up's query string
    ("Not Eligible" -> "not_eligible")."""
    return status.lower().replace(" ", "_")


def submitted_date(row):
    return safe_date(row.get("Submitted To Uni"))


def classify(row, today):
    """ELIGIBLE / OPEN / MISSED / NOT_ELIGIBLE for an application with a Submitted To Uni date
    (see the module docstring), or None if it has no usable one."""
    submitted = submitted_date(row)
    if submitted is None:
        return None
    accepted = safe_date(row.get("Offer Accepted Date"))
    if accepted is not None:
        days = (accepted - submitted).days
        if days < 0:
            return NOT_ELIGIBLE
        return ELIGIBLE if days <= BONUS_DAYS else MISSED
    if (row.get("Status") or "").strip() == LOST_STATUS:
        return MISSED
    return OPEN if (today - submitted).days <= BONUS_DAYS else MISSED


def in_scope(rows):
    """The applications the chart is about: the 2027 Intake, a Submitted To Uni date
    on or after BONUS_SUBMITTED_FROM, and a pipeline Status."""
    return [
        row
        for row in filter_by_intake_year(rows, BONUS_INTAKE_YEAR)
        if (submitted_date(row) or date.min) >= BONUS_SUBMITTED_FROM and (row.get("Status") or "").strip() in STAGES
    ]


def submitted_months(rows, today):
    """The (year, month) pairs for the "Submitted to uni in" filter, oldest first: every
    month from BONUS_SUBMITTED_FROM's through the current one (or the latest one an
    in-scope application was submitted in, if that is later)."""
    last = max([(today.year, today.month)] + [(d.year, d.month) for d in (submitted_date(r) for r in in_scope(rows))])
    months = []
    year, month = BONUS_SUBMITTED_FROM.year, BONUS_SUBMITTED_FROM.month
    while (year, month) <= last:
        months.append((year, month))
        year, month = (year + 1, 1) if month == 12 else (year, month + 1)
    return months


def _person(row, field):
    return (row.get(field) or "").strip()


def build_bonus_chart(rows, today, group_priority=("EG", "UK"), person_field="Application"):
    """The chart: one row per Application Manager (a blank one is "Unassigned"; the
    placeholder managers in pipeline.EXCLUDED_MANAGERS are left out), grouped by
    Office (EG before UK) and alphabetical within it, each with how many of their
    applications are Eligible, Open, Missed and Not Eligible. A manager's "total"
    and "eligible_pct" leave the Not Eligible ones out (they do not count).

    Returns {"groups": [{"office", "rows": [{"name", "total", "eligible", "open",
    "missed", "not_eligible", "eligible_pct", "segments"}]}], "totals": {...},
    "managers": {name: {status: [rows]}}} - "managers" being the very rows counted
    in each piece, so the click-through list is exactly what was counted. Bars
    (which do show the Not Eligible piece) are scaled to the biggest manager.

    `person_field` picks who the rows are: "Application" (the Application Manager,
    grouped by Office as above) or "QA" (the QA Officer: a QA Officer has no Office
    of their own, so there is a single group with no label, A to Z, with
    "Unassigned" last). The same applications are counted either way - including leaving
    out the placeholder managers' (see EXCLUDED_MANAGERS), so both charts total the same."""
    by_office = person_field == "Application"
    people = {}
    for row in in_scope(rows):
        name = _person(row, person_field) or UNASSIGNED
        if _person(row, "Application").lower() in EXCLUDED_MANAGERS:
            continue
        status = classify(row, today)
        person = people.setdefault(name, {"office": None, "rows": {s: [] for s in STATUSES}})
        office = (row.get("Office") or "").strip() if by_office else ""
        if person["office"] is None and office:
            person["office"] = office
        person["rows"][status].append(row)

    max_total = max((sum(len(v) for v in p["rows"].values()) for p in people.values()), default=0)
    groups = {}
    grand = {s: 0 for s in STATUSES}
    for name, person in people.items():
        counts = {s: len(person["rows"][s]) for s in STATUSES}
        total = sum(counts[s] for s in COUNTED_STATUSES)
        for s in STATUSES:
            grand[s] += counts[s]
        segments = [
            {"key": status_slug(s), "label": s, "count": counts[s], "color": STATUS_COLORS[s], "width_pct": (counts[s] / max_total * 100) if max_total else 0}
            for s in STATUSES
            if counts[s] > 0
        ]
        groups.setdefault((person["office"] or UNASSIGNED) if by_office else "", []).append(
            {
                "name": name,
                "total": total,
                "eligible": counts[ELIGIBLE],
                "open": counts[OPEN],
                "missed": counts[MISSED],
                "not_eligible": counts[NOT_ELIGIBLE],
                "eligible_pct": round_half_up(counts[ELIGIBLE] / total * 100) if total else 0,
                "segments": segments,
            }
        )
    ordered = []
    for office in sorted(groups, key=lambda o: _group_sort_key(o, group_priority)):
        ordered.append({"office": office, "rows": sorted(groups[office], key=lambda r: (r["name"] == UNASSIGNED and not by_office, r["name"].lower(), r["name"]))})
    total = sum(grand[s] for s in COUNTED_STATUSES)
    return {
        "groups": ordered,
        "totals": {"total": total, "eligible": grand[ELIGIBLE], "open": grand[OPEN], "missed": grand[MISSED], "not_eligible": grand[NOT_ELIGIBLE]},
        "managers": {name: person["rows"] for name, person in people.items()},
    }


def _date_text(value):
    return value.strftime("%d/%m/%Y") if value else ""


def bonus_records(chart, manager, status_key, today):
    """The applications behind one piece of the chart - `manager`'s (or, on the QA
    Officer chart, the QA Officer's) applications whose
    bonus status is `status_key` ("eligible", "open", "missed" or "not_eligible") - as plain dicts for
    the click-through window (see BONUS_RECORD_COLUMNS), sorted by Student then PES
    Code. None if the status is unknown. Days to Offer is how long the offer took;
    Days Waiting is how long an application with no offer yet has waited."""
    status = next((s for s in STATUSES if status_slug(s) == status_key), None)
    if status is None:
        return None
    records = []
    for row in chart["managers"].get(manager, {}).get(status, []):
        submitted = submitted_date(row)
        accepted = safe_date(row.get("Offer Accepted Date"))
        records.append(
            {
                "code": (row.get("Student Code") or "").strip(),
                "student": (row.get("Student Name") or "").strip(),
                "university": _fold_unassigned(row.get("University Name")),
                "intake": (row.get("Intake") or "").strip(),
                "consultant": _fold_unassigned(row.get("Consultant")),
                "submitted": _date_text(submitted),
                "accepted": _date_text(accepted),
                "days_to_offer": str((accepted - submitted).days) if accepted else "",
                "days_waiting": "" if accepted else str((today - submitted).days),
            }
        )
    return sorted(records, key=lambda r: (r["student"].lower(), r["code"]))
