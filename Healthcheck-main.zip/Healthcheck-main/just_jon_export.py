"""Excel export for the Just Jon page - one worksheet per Application
Manager, every record for whichever year/Intake tab the page is
currently on, sorted by pipeline stage (pipeline.STAGES order).

Each row's Status cell is filled using the exact same Stage colour
gradient the rest of the app already uses (pipeline.STAGE_COLORS - blue
for the earliest stage, progressing through teal/green up to
09-Enrolled's green, with 10-Lost kept as its own distinct red rather
than part of that gradient), so a reader can see how far along - or
whether lost - a record is at a glance without reading the Status
column's text.
"""

import io

import openpyxl
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

from excel_export_helpers import apply_column_widths, safe_append_row, unique_sheet_title
from pipeline import EXCLUDED_MANAGERS, STAGES, STAGE_COLORS

EXPORT_COLUMNS = [
    "Student Code",
    "Student Name",
    "University Name",
    "Course Name",
    "Intake",
    "Consultant",
    "Application Manager",
    "Status",
]

_STAGE_ORDER = {stage: index for index, stage in enumerate(STAGES)}

# White text reads cleanly against every one of STAGE_COLORS' fills - the
# same blue-to-green gradient used everywhere else in the app, plus
# Lost's own distinct red.
_STATUS_FONT = Font(color="FFFFFFFF", bold=True)
_STATUS_FILLS = {
    stage: PatternFill(
        start_color=f"FF{color.lstrip('#').upper()}",
        end_color=f"FF{color.lstrip('#').upper()}",
        fill_type="solid",
    )
    for stage, color in STAGE_COLORS.items()
}


def _sort_rows(rows):
    """Pipeline stage order (see pipeline.STAGES), then Student Name - a
    Status not in STAGES (blank/unrecognised) sorts last."""
    return sorted(
        rows,
        key=lambda row: (
            _STAGE_ORDER.get((row.get("Status") or "").strip(), len(_STAGE_ORDER)),
            (row.get("Student Name") or "").strip().lower(),
        ),
    )


def _write_manager_worksheet(ws, rows):
    ordered = _sort_rows(rows)

    ws.append(EXPORT_COLUMNS)
    header_font = Font(bold=True)
    for cell in ws[1]:
        cell.font = header_font
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(EXPORT_COLUMNS))}1"

    status_col_index = EXPORT_COLUMNS.index("Status") + 1

    for row in ordered:
        status = (row.get("Status") or "").strip()
        safe_append_row(
            ws,
            [
                row.get("Student Code") or "",
                row.get("Student Name") or "",
                row.get("University Name") or "",
                row.get("Course Name") or "",
                row.get("Intake") or "",
                row.get("Consultant") or "",
                row.get("Application") or "",
                status,
            ],
        )

        fill = _STATUS_FILLS.get(status)
        if fill is not None:
            cell = ws.cell(row=ws.max_row, column=status_col_index)
            cell.fill = fill
            cell.font = _STATUS_FONT

    apply_column_widths(ws, EXPORT_COLUMNS)


def build_just_jon_export(rows):
    """Build the export workbook (an in-memory buffer) - one worksheet
    per Application Manager, each listing every one of that manager's
    rows sorted by pipeline stage. `rows` is expected to already be
    filtered to the population the caller wants exported (Just Jon's own
    Sub-Source match, year/Intake bucket, deduplicated by student - see
    app.py's just_jon_export() route) - no filtering happens in here. A
    blank or EXCLUDED_MANAGERS Application is dropped entirely rather
    than exported, matching build_pipeline_report()'s own exclusion rule
    for the Application Manager Pipeline report (so this export's tabs
    always match the managers shown on the page's own chart)."""
    by_manager = {}
    for row in rows:
        manager = (row.get("Application") or "").strip()
        if not manager or manager.lower() in EXCLUDED_MANAGERS:
            continue
        by_manager.setdefault(manager, []).append(row)

    manager_names = sorted(by_manager.keys(), key=str.lower)

    workbook = openpyxl.Workbook()
    workbook.remove(workbook.active)

    used_titles = set()
    if not manager_names:
        # No rows at all - still produce a valid, openable workbook (a
        # blank workbook with zero sheets is invalid) rather than erroring.
        ws = workbook.create_sheet(title="Just Jon Pipeline")
        _write_manager_worksheet(ws, [])
    else:
        for name in manager_names:
            title = unique_sheet_title(name, used_titles)
            used_titles.add(title)
            ws = workbook.create_sheet(title=title)
            _write_manager_worksheet(ws, by_manager[name])

    buffer = io.BytesIO()
    workbook.save(buffer)
    buffer.seek(0)
    return buffer


def export_filename(today, intake_year=None, intake_bucket_label=None):
    year_part = f"_{intake_year}" if intake_year is not None else ""
    bucket_part = f"_{intake_bucket_label.replace(' ', '')}" if intake_bucket_label else ""
    return f"Just_Jon_Pipeline{year_part}{bucket_part}_{today.strftime('%d-%m-%Y')}.xlsx"
