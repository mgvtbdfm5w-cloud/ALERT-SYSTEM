"""Shared categorical colour-assignment helper.

Used anywhere a chart needs to give a stable colour to each distinct value
in a dynamic, page-specific list (Support people, QA Officers, Lost Sub
Reasons, ...) - "Unassigned" always gets the same neutral grey (matching
KPI's kpi-bar-unset) since it's an administrative gap, not a real
category, so it shouldn't compete with the palette used for real values.
"""

# Built entirely from hex values already established elsewhere in this app
# (Pipeline's stage gradient, KPI/Offer Days' amber and red) so every chart
# using this palette reads as part of the same dashboard family rather than
# introducing a new colour scheme. Cycles if there are more distinct values
# than palette entries.
CATEGORICAL_PALETTE = [
    "#2563eb",  # Pipeline 02-PendingQA blue
    "#eab308",  # KPI/Offer Days amber
    "#1c888f",  # Pipeline 06-Decision teal
    "#c0605a",  # Pipeline 10-Lost / KPI red
    "#16a34a",  # Pipeline 09-Enrolled green
    "#236cd4",  # Pipeline 03-PendingSubmission blue
    "#1a9178",  # Pipeline 07-Ready teal-green
    "#2175bd",  # Pipeline 04-Onboarding blue
]

UNASSIGNED_COLOR = "#9aa4b2"


def assign_categorical_colors(names, palette=CATEGORICAL_PALETTE):
    """Return one hex colour per entry in `names`, in the same order -
    "Unassigned" (if present) always gets UNASSIGNED_COLOR; everyone else
    gets the next colour from `palette`, so the same value always gets the
    same colour across every row/segment in the same report."""
    colors = []
    palette_index = 0
    for name in names:
        if name == "Unassigned":
            colors.append(UNASSIGNED_COLOR)
        else:
            colors.append(palette[palette_index % len(palette)])
            palette_index += 1
    return colors
