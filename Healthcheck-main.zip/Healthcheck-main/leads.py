"""Leads Generated dataset ingestion.

Mirrors processing.py's upload pipeline (workbook -> validated rows -> an
active_*_dataset row). The source workbook's raw columns (Student Id, Name,
Mobile No, Phone Number, Location, Lead Status, Lead Source, Call Attempt,
Campaign Name, Counsellor, Agency Name, Creation Date, Stage Length, Last
Updated, Status) are mapped onto LEADS_COLUMNS below, the fixed presentation
shape Current Data/the leads page actually shows - not a raw passthrough of
whatever the workbook happens to contain, the same way processing.py maps
Applications' raw columns onto its own COLUMNS.
"""

import io
import json
import logging
from datetime import date, datetime

import openpyxl

from db import cleanup_orphaned_uploads, prune_active_dataset_table
from excel_export_helpers import apply_column_widths, apply_date_format, safe_append_row
from processing import WORKBOOK_UNREADABLE_MESSAGE, first_token, is_filesystem_error, parse_date, split_lead_source

logger = logging.getLogger(__name__)

# The Current Data column order for Leads Generated - PES Code first (per
# the Applications page's own convention of leading with the student
# identifier), then everything else in the source workbook's own column
# order, with Lead Source split into two adjacent columns in place and
# Stage inserted directly before the Lead Status it's derived from.
LEADS_COLUMNS = [
    "PES Code",
    "Name",
    "Location",
    "Stage",
    "Lead Status",
    "Lead Source",
    "Sub Source",
    "Call Attempt",
    "Consultant",
    "Agency Name",
    "Creation Date",
    "Stage Length",
    "Last Updated",
]

# Creation Date is stored as an ISO 'YYYY-MM-DD' string (see parse_date()
# below), same convention as every other date field in this app (Current
# Data's `ukdate` template filter expects this) - unlike Stage Length and
# Last Updated, which stay as whatever text the workbook has (Last Updated
# carries a time component this app has no use for beyond display).
LEADS_DATE_COLUMNS = {"Creation Date"}

# Lead Status -> Stage, a fixed VLOOKUP-style mapping (not admin-editable
# like Applications' Status lookup table, since this list was given as a
# complete, fixed set) - several raw Lead Status values collapse onto the
# same Stage (e.g. every disqualification reason maps to "10 -
# Disqualified"), same convention as Applications' own Status lookup.
# Matched case-insensitively, trimmed - a Lead Status with no match here
# gets a blank Stage rather than raising, so an unexpected value never
# breaks the upload.
LEAD_STAGE_LOOKUP = {
    "new lead": "01 - New Lead",
    "uploaded": "01 - New Lead",
    "qualified": "02 - Qualified",
    "awaiting documents": "03 - Documents",
    "applied": "04 - Applied",
    "enrolled student": "05 - Enrolled",
    "applied lost": "06 - Applied Lost",
    "future intake": "07 - Future Intake",
    "not interested": "08 - Not Interested",
    "non-responsive": "09 - Non-Responsive",
    "marketing campaign": "09 - Non-Responsive",
    "location issue": "10 - Disqualified",
    "residency issue": "10 - Disqualified",
    "sfe issue": "10 - Disqualified",
    "international": "10 - Disqualified",
    "disqualified": "10 - Disqualified",
    "english classes": "10 - Disqualified",
    "number invalid": "10 - Disqualified",
    "unsubscribe": "10 - Disqualified",
    "health or family issue": "10 - Disqualified",
    "extenuating circumstances": "10 - Disqualified",
}


def lookup_stage(lead_status):
    """VLOOKUP Lead Status -> Stage via LEAD_STAGE_LOOKUP - "" if blank or
    not a recognised Lead Status (never raises)."""
    if not lead_status or not str(lead_status).strip():
        return ""
    return LEAD_STAGE_LOOKUP.get(str(lead_status).strip().lower(), "")


# Every distinct Stage LEAD_STAGE_LOOKUP can produce, in display order -
# the Leads Dashboard's Stage chart shows one row per entry here (even a
# Stage with zero leads right now), rather than only whichever Stages
# happen to appear in the current data.
LEAD_STAGE_ORDER = [
    "01 - New Lead",
    "02 - Qualified",
    "03 - Documents",
    "04 - Applied",
    "05 - Enrolled",
    "06 - Applied Lost",
    "07 - Future Intake",
    "08 - Not Interested",
    "09 - Non-Responsive",
    "10 - Disqualified",
]

# Stage -> colour for the Leads Dashboard's Stage chart. 05 - Enrolled
# wasn't given a colour in the original scheme - it's treated as another
# positive outcome alongside 04 - Applied and given the same green.
LEAD_STAGE_COLORS = {
    "01 - New Lead": "#c0605a",
    "02 - Qualified": "#2563eb",
    "03 - Documents": "#7c3aed",
    "04 - Applied": "#16a34a",
    "05 - Enrolled": "#16a34a",
    "06 - Applied Lost": "#1f2430",
    "07 - Future Intake": "#1f2430",
    "08 - Not Interested": "#1f2430",
    "09 - Non-Responsive": "#1f2430",
    "10 - Disqualified": "#1f2430",
}

# Raw source columns actually used to build LEADS_COLUMNS above. Mobile No,
# Phone Number, Campaign Name and Status are read from the source workbook
# but deliberately dropped from Current Data, so they're not required here.
REQUIRED_LEADS_SOURCE_COLUMNS = [
    "Student Id",
    "Name",
    "Location",
    "Lead Status",
    "Lead Source",
    "Call Attempt",
    "Counsellor",
    "Agency Name",
    "Creation Date",
    "Stage Length",
    "Last Updated",
]


class LeadsProcessingError(Exception):
    """User-fixable problem with the uploaded Leads workbook; shown verbatim
    ("Upload failed: <message>"), so - exactly like processing.ProcessingError
    - never built from a caught exception's text."""


def _display_value(value):
    """A cell Excel actually formats as a date comes back from openpyxl as
    a real datetime/date object, not a string - store it as an ISO date
    string (matching every other date value in this app) rather than
    Python's str(datetime(...)) representation. Everything else passes
    through unchanged. datetime must be checked before date since datetime
    is a subclass of date."""
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    if value is None:
        return ""
    return value


def _read_headers(ws):
    header_to_col = {}
    for col in range(1, ws.max_column + 1):
        header = ws.cell(row=1, column=col).value
        if header:
            header_to_col[str(header).strip()] = col
    return header_to_col


def process_leads_workbook(file_path):
    """Read the first sheet of the uploaded Leads workbook and return the
    processed rows, one dict per non-blank data row, keyed by
    LEADS_COLUMNS. Raises LeadsProcessingError on an unreadable file, a
    sheet missing a required source column, or no data rows - never raises
    on a single bad cell."""
    try:
        workbook = openpyxl.load_workbook(file_path, data_only=True)
    except Exception as exc:
        if is_filesystem_error(exc):
            raise  # filesystem problem: the route's generic handler logs it (ERROR + traceback) and shows a safe message
        logger.warning("Uploaded Leads file could not be opened as an .xlsx workbook.", exc_info=True)
        raise LeadsProcessingError(WORKBOOK_UNREADABLE_MESSAGE)

    ws = workbook[workbook.sheetnames[0]]
    header_to_col = _read_headers(ws)

    missing = [c for c in REQUIRED_LEADS_SOURCE_COLUMNS if c not in header_to_col]
    if missing:
        raise LeadsProcessingError(
            f"The '{ws.title}' sheet is missing required column(s): " + ", ".join(missing)
        )

    def cell(row, header_name):
        return ws.cell(row=row, column=header_to_col[header_name]).value

    rows = []
    for row_num in range(2, ws.max_row + 1):
        pes_code = cell(row_num, "Student Id")
        name = cell(row_num, "Name")
        if (not pes_code or not str(pes_code).strip()) and (not name or not str(name).strip()):
            continue

        lead_source, sub_source = split_lead_source(cell(row_num, "Lead Source"))
        lead_status = _display_value(cell(row_num, "Lead Status"))

        rows.append(
            {
                "PES Code": _display_value(pes_code),
                "Name": _display_value(name),
                "Location": _display_value(cell(row_num, "Location")),
                "Stage": lookup_stage(lead_status),
                "Lead Status": lead_status,
                "Lead Source": lead_source,
                "Sub Source": sub_source,
                "Call Attempt": _display_value(cell(row_num, "Call Attempt")),
                "Consultant": first_token(cell(row_num, "Counsellor")),
                "Agency Name": _display_value(cell(row_num, "Agency Name")),
                "Creation Date": parse_date(cell(row_num, "Creation Date")),
                "Stage Length": _display_value(cell(row_num, "Stage Length")),
                "Last Updated": _display_value(cell(row_num, "Last Updated")),
            }
        )

    if not rows:
        raise LeadsProcessingError(f"No data rows were found in the '{ws.title}' sheet.")

    return LEADS_COLUMNS, rows


def save_active_leads_dataset(conn, original_filename, stored_filename, uploaded_at, columns, rows, uploads_dir):
    """Insert a new active_leads_dataset snapshot and prune older ones down
    to db.ACTIVE_DATASET_RETENTION_LIMIT, as a single transaction, then run
    the filesystem half of the same retention policy against `uploads_dir`
    once that transaction has committed - same convention as
    processing.save_active_dataset()."""
    try:
        conn.execute(
            "INSERT INTO active_leads_dataset "
            "(original_filename, stored_filename, uploaded_at, row_count, columns_json, data_json) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (original_filename, stored_filename, uploaded_at, len(rows), json.dumps(columns), json.dumps(rows)),
        )
        prune_active_dataset_table(conn, "active_leads_dataset")
    except Exception:
        conn.rollback()
        raise
    conn.commit()
    try:
        cleanup_orphaned_uploads(conn, uploads_dir)
    except Exception:
        logger.exception("Post-save orphaned upload cleanup failed.")


_STAGE_ORDER = {stage: index for index, stage in enumerate(LEAD_STAGE_ORDER)}


def build_leads_export_workbook(rows):
    """Build a downloadable .xlsx of the current Leads Generated Current
    Data - same columns/order as LEADS_COLUMNS, mirroring
    processing.build_export_workbook()'s approach for Applications."""
    workbook = openpyxl.Workbook()
    ws = workbook.active
    ws.title = "Leads Current Data"

    ws.append(LEADS_COLUMNS)

    rows = sorted(rows, key=lambda row: _STAGE_ORDER.get((row.get("Stage") or "").strip(), len(_STAGE_ORDER)))

    for row in rows:
        values = []
        for column in LEADS_COLUMNS:
            value = row.get(column) or ""
            if column in LEADS_DATE_COLUMNS and value:
                value = date.fromisoformat(value)
            values.append(value)
        safe_append_row(ws, values)

    apply_date_format(ws, LEADS_COLUMNS, LEADS_DATE_COLUMNS)
    apply_column_widths(ws, LEADS_COLUMNS)

    buffer = io.BytesIO()
    workbook.save(buffer)
    buffer.seek(0)
    return buffer
