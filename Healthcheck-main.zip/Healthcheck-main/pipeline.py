"""Pipeline dashboard calculation logic, shared by every pipeline report.

Kept out of the route and template on purpose - build_pipeline_report() takes
the current active dataset rows plus the current forecast percentages and
returns a plain data structure the template renders with minimal logic of
its own. Nothing here is persisted; it's recalculated from Current Data and
the live forecast_settings table on every page load.

build_pipeline_report() is deliberately generic: the Application Manager
Pipeline and Consultant Pipeline are the same report shape grouped by
different fields (Application/Office vs Consultant/Sales Office), so they
share this one implementation via the person_field/group_field/
excluded_persons/group_priority parameters rather than being two copies of
the same maths.
"""

import math

from dateutils import safe_date

# Live Current Data (and the existing Status lookup table) uses the value
# "08-Pre-Enrolled" for this stage. There is no "09-PreEnrolled" anywhere in
# the system, and every other stage below matches Current Data verbatim, so
# this is treated as referring to the same real stage rather than a new one.
STAGES = [
    "02-PendingQA",
    "03-PendingSubmission",
    "04-Onboarding",
    "05-Assessment",
    "06-Decision",
    "07-Ready",
    "08-Pre-Enrolled",
    "09-Enrolled",
    "10-Lost",
]

# Two of the statuses outside STAGES entirely (see EXCLUDED_PIPELINE_STATUSES
# further down) that build_pipeline_report() tracks separately per person,
# purely so the University Pipeline - which doesn't pre-filter
# EXCLUDED_PIPELINE_STATUSES the way the Application Manager/Consultant
# Pipeline does - can surface their existence without folding them into
# Total. 01-NewApp (the third excluded status) is deliberately NOT tracked
# this way: it already has its own dedicated home on the KPI page's Doc
# Check backlog box, and its University Pipeline treatment is unchanged.
QA_REJECTED_STATUS = "00-QARejected"
DEFERRED_STATUS = "11-Deferred"

# "Admission" (from an Admission Officer literally named "Admission Manager")
# is a holding/placeholder account rather than a real Application Manager, so
# it is excluded from the pipeline report entirely.
EXCLUDED_MANAGERS = {"admission"}

# Consultants who have left the company. Their historical records still
# count toward their Sales Office and Grand Totals (the pipeline volume was
# real), but they no longer get their own row/bar on the report.
HIDDEN_CONSULTANTS = {"daniel", "ahmed", "anum", "jay", "jon"}

# The Application Manager / Consultant / University Pipeline reports show
# one Intake year at a time, picked via a tab on the Dashboard page - every
# other page (KPI, Offer Days, Submissions, To Do List, Interviews, Health
# Check/Current Data) is unaffected and continues to show every Intake
# year. PIPELINE_INTAKE_YEAR is the default/fallback tab; add a year to
# PIPELINE_INTAKE_YEARS to give it its own tab.
PIPELINE_INTAKE_YEAR = 2026
PIPELINE_INTAKE_YEARS = (2026, 2027)


def _intake_year(value):
    """Return the year from an Intake value like "September 2026" as an
    int, or None if it's blank or doesn't end in a recognisable year -
    never raises on bad input."""
    if not value:
        return None
    parts = str(value).strip().split()
    if not parts:
        return None
    try:
        return int(parts[-1])
    except ValueError:
        return None


def filter_by_intake_year(rows, year):
    """Return only the rows whose Intake is for the given year. A blank or
    unparseable Intake is excluded rather than assumed to match, so it can
    never silently sneak into a report scoped to a specific year."""
    return [row for row in rows if _intake_year(row.get("Intake")) == year]


# From 2027 onwards, every Intake-year-scoped report also offers an
# optional Intake 01/02/03 sub-tab that narrows the selected year down to
# a 3-month window, based on the Intake value's own month: Jan-Mar is
# Intake 01, Apr-Jun is Intake 02, and the rest of the year (Jul-Dec) is
# Intake 03. 2026 is excluded because the CRM migration means only its
# back half is this app's own live data - see the Enrolled page's
# separate manual Intake 01/02 backfill for that year instead.
INTAKE_MONTH_GROUPING_FROM_YEAR = 2027

INTAKE_BUCKET_MONTHS = {
    "intake_01": ("january", "february", "march"),
    "intake_02": ("april", "may", "june"),
    "intake_03": ("july", "august", "september", "october", "november", "december"),
}

INTAKE_BUCKET_KEYS = tuple(INTAKE_BUCKET_MONTHS.keys())

INTAKE_BUCKET_LABELS = {
    "intake_01": "Intake 01",
    "intake_02": "Intake 02",
    "intake_03": "Intake 03",
}

# Matches both the full month name and its 3-letter abbreviation (e.g.
# "September 2026" and "Sep 2026"), since the source workbook isn't
# strict about which one gets used.
_INTAKE_BUCKET_BY_MONTH_NAME = {}
for _bucket, _months in INTAKE_BUCKET_MONTHS.items():
    for _month in _months:
        _INTAKE_BUCKET_BY_MONTH_NAME[_month] = _bucket
        _INTAKE_BUCKET_BY_MONTH_NAME[_month[:3]] = _bucket


def intake_buckets_available_for_year(year):
    """Whether the Intake 01/02/03 month sub-tabs apply to this Intake
    year (see INTAKE_MONTH_GROUPING_FROM_YEAR) - False for 2026 and
    anything blank/unrecognised."""
    return isinstance(year, int) and year >= INTAKE_MONTH_GROUPING_FROM_YEAR


def _intake_month_bucket(value):
    """Return which Intake bucket ("intake_01"/"intake_02"/"intake_03") an
    Intake value like "September 2026" falls into, based on its month name
    - or None if it's blank or the month isn't recognised. Never raises on
    bad input, same convention as _intake_year."""
    if not value:
        return None
    parts = str(value).strip().split()
    if not parts:
        return None
    return _INTAKE_BUCKET_BY_MONTH_NAME.get(parts[0].strip().lower())


_MONTH_NAMES = (
    "january", "february", "march", "april", "may", "june",
    "july", "august", "september", "october", "november", "december",
)
_MONTH_NUMBER_BY_NAME = {}
for _number, _name in enumerate(_MONTH_NAMES, start=1):
    _MONTH_NUMBER_BY_NAME[_name] = _number
    _MONTH_NUMBER_BY_NAME[_name[:3]] = _number


def intake_month_number(value):
    """The month number (1-12) of an Intake value like "September 2026" (full
    month name or its 3-letter form, any case), or None if it's blank or the
    month isn't recognised. Never raises on bad input."""
    if not value:
        return None
    parts = str(value).strip().split()
    if not parts:
        return None
    return _MONTH_NUMBER_BY_NAME.get(parts[0].strip().lower())


def list_intake_months(rows):
    """The Intake month numbers (1-12) present in `rows`, in calendar order -
    the Intake Month filter's options for whichever year/Intake tab the rows
    were already narrowed to."""
    return sorted({intake_month_number(row.get("Intake")) for row in rows} - {None})


def filter_by_intake_months(rows, months):
    """Only the rows whose Intake month is one of `months` (numbers 1-12); a
    blank or unrecognised Intake is excluded, same convention as
    filter_by_intake_year."""
    wanted = set(months)
    return [row for row in rows if intake_month_number(row.get("Intake")) in wanted]


def list_statuses(rows):
    """The pipeline Statuses (members of STAGES) present in `rows`, in
    pipeline order - the Status filter's options. A Status outside STAGES
    (blank, 00-QARejected, ...) is never offered: those rows aren't part of
    the pipeline numbers."""
    present = {(row.get("Status") or "").strip() for row in rows}
    return [stage for stage in STAGES if stage in present]


def _list_people(rows, person_field):
    """The names in `person_field` present in `rows`, alphabetical (case-
    insensitive, then as typed so the order never depends on set ordering), a
    blank one folded into "Unassigned" exactly as the pipeline reports fold it
    (see _fold_unassigned)."""
    return sorted({_fold_unassigned(row.get(person_field)) for row in rows}, key=lambda name: (name.lower(), name))


def list_application_managers(rows):
    """The Application Manager filter's options (see _list_people)."""
    return _list_people(rows, "Application")


# The Offices in the order the Office filter lists them; anything else a row
# carries (e.g. "Other" for a consultant not on the lookup yet) follows A-Z, and
# a blank one ("Unassigned") comes last.
OFFICE_FILTER_ORDER = ("LON", "CAR", "MAN", "OXF")


def list_sales_offices(rows):
    """The Office filter's options: the Sales Offices present in `rows` - LON,
    CAR, MAN, OXF first (in that order), then any others A-Z, then
    "Unassigned" for a row with no Sales Office."""
    present = _list_people(rows, "Sales Office")
    known = [office for office in OFFICE_FILTER_ORDER if office in present]
    others = [office for office in present if office not in OFFICE_FILTER_ORDER and office != "Unassigned"]
    return known + others + (["Unassigned"] if "Unassigned" in present else [])


def list_qa_officers(rows):
    """The QA Officer filter's options (see _list_people)."""
    return _list_people(rows, "QA")


def list_consultants(rows):
    """The Consultant filter's options (see _list_people)."""
    return _list_people(rows, "Consultant")


def filter_by_intake_bucket(rows, bucket):
    """Return only the rows whose Intake month falls into the given
    Intake bucket (see _intake_month_bucket) - a blank or unparseable
    Intake is excluded, same convention as filter_by_intake_year."""
    return [row for row in rows if _intake_month_bucket(row.get("Intake")) == bucket]


# The "Just Jon" Dashboard tab shows records from any of these
# Sub-Source values - all the same person/source, just recorded under
# different spellings over time. "Just Jon" is the current spelling
# going forward; "Jon Daniels TT"/"Jon Daniels" are kept so older
# records recorded before the rename still show up. Compared
# case-insensitively since the source workbook isn't consistent about
# capitalisation either (e.g. "Jon Daniels Tt" vs "JON DANIELS TT").
JUST_JON_SUB_SOURCES = ("Jon Daniels TT", "Jon Daniels", "Just Jon")


def filter_by_sub_source(rows, sub_sources):
    """Return only the rows whose Sub-Source matches (case-insensitively,
    trimmed) any value in `sub_sources`."""
    targets = {s.strip().lower() for s in sub_sources}
    return [row for row in rows if (row.get("Sub-Source") or "").strip().lower() in targets]


# The "Faheem" Dashboard tab shows only records where Faheem is the
# Consultant - regardless of Sub-Source/how the lead came in, unlike
# "Just Jon" above which filters by Sub-Source instead.
FAHEEM_CONSULTANT = "Faheem"


def filter_by_consultant(rows, consultant):
    """Return only the rows whose Consultant matches (case-insensitively,
    trimmed) `consultant` - same convention as filter_by_sub_source."""
    target = consultant.strip().lower()
    return [row for row in rows if (row.get("Consultant") or "").strip().lower() == target]

def list_consultant_names(rows, exclude=None):
    """Every distinct Consultant named in `rows`, A-Z (case-insensitive),
    one entry per name however its case varies (the first spelling seen
    wins). Blank Consultants are skipped. Feeds the Consultants page's
    picker, so a name offered there always matches at least one row.

    `exclude`: names (any case, any surrounding spaces) to leave out - the
    Consultants page passes the ones flagged "Group as Other" on the Admin
    page's Consultant lookup table, so they are not offered for analysis."""
    excluded = {name.strip().lower() for name in (exclude or []) if name and name.strip()}
    names = {}
    for row in rows:
        name = (row.get("Consultant") or "").strip()
        if name and name.lower() not in excluded:
            names.setdefault(name.lower(), name)
    return sorted(names.values(), key=str.lower)


def resolve_consultant_name(names, requested):
    """`requested` (from the query string) matched case-insensitively,
    trimmed, against `names`; returns the canonical spelling, or None for
    a blank, missing or unknown value - never raises."""
    target = (requested or "").strip().lower()
    if not target:
        return None
    for name in names:
        if name.lower() == target:
            return name
    return None


def build_consultant_enrolled_by_year(rows, consultant, years, manual_adjustments_by_year=None):
    """One consultant's Enrolled figures for each Intake year, shaped like the
    Enrolled page's own totals: [{"year", "intake_01", "intake_02",
    "intake_03", "total"}, ...] in `years` order.

    Uses exactly build_consultant_enrolled_chart() for each year - the same
    counting the Enrolled page does (live 09-Enrolled rows; a year with
    month buckets splits them by Intake month, otherwise they are all
    Intake 03 and Intake 01/02 come from the manual pre-migration backfill)
    - so the figures here always agree with that page. `rows` is every
    year's rows; `manual_adjustments_by_year` maps year -> the Enrolled
    page's manual_adjustments list ({"consultant", "intake_01",
    "intake_02", ...}). A consultant spelled with different case in
    different rows is still one person."""
    manual_adjustments_by_year = manual_adjustments_by_year or {}
    target = (consultant or "").strip().lower()
    result = []
    for year in years:
        year_rows = filter_by_consultant(filter_by_intake_year(rows, year), consultant) if target else []
        manual = [
            a for a in manual_adjustments_by_year.get(year, [])
            if (a.get("consultant") or "").strip().lower() == target
        ]
        chart = build_consultant_enrolled_chart(
            year_rows, manual, None, use_month_buckets=intake_buckets_available_for_year(year)
        )
        counts = {kind: sum(entry[kind] for entry in chart) for kind in ("intake_01", "intake_02", "intake_03")}
        result.append({"year": year, **counts, "total": sum(counts.values())})
    return result


DEFAULT_FORECAST_PERCENTAGES = {
    "02-PendingQA": 0,
    "03-PendingSubmission": 20,
    "04-Onboarding": 30,
    "05-Assessment": 40,
    "06-Decision": 60,
    "07-Ready": 80,
    "08-Pre-Enrolled": 90,
    "09-Enrolled": 100,
    "10-Lost": 0,
}

# One consistent colour per stage, used by both the pipeline health chart and
# its legend. The 8 "still progressing" stages form a single blue-to-green
# gradient (02-PendingQA starts blue, 09-Enrolled ends on the same green used
# for a positive outcome elsewhere in this app), reflecting that every record
# is moving toward one of exactly two end states. 10-Lost is deliberately left
# out of that gradient and stays a clearly distinct red - it's not "further
# along" the same journey, it's the other outcome entirely.
STAGE_COLORS = {
    "02-PendingQA": "#2563eb",
    "03-PendingSubmission": "#236cd4",
    "04-Onboarding": "#2175bd",
    "05-Assessment": "#1f7ea6",
    "06-Decision": "#1c888f",
    "07-Ready": "#1a9178",
    "08-Pre-Enrolled": "#189a61",
    "09-Enrolled": "#16a34a",
    "10-Lost": "#c0605a",
}


class ForecastValidationError(Exception):
    pass


def round_half_up(value, decimals=0):
    """Standard "0.5 always rounds up" rounding, used consistently for every
    Forecast and Conversion figure on this dashboard (Python's built-in
    round() uses round-half-to-even instead, which would occasionally look
    wrong to a reader checking the maths by hand). decimals=0 (the
    default) returns a plain int, matching every existing caller; pass a
    positive decimals for a rounded float (e.g. kpi.py's average Stage
    Length days)."""
    factor = 10**decimals
    result = math.floor(value * factor + 0.5) / factor
    return int(result) if decimals == 0 else result


def seed_forecast_settings_if_empty(conn):
    count = conn.execute("SELECT COUNT(*) AS c FROM forecast_settings").fetchone()["c"]
    if count > 0:
        return False
    for stage in STAGES:
        conn.execute(
            "INSERT INTO forecast_settings (stage, forecast_percent) VALUES (?, ?)",
            (stage, DEFAULT_FORECAST_PERCENTAGES[stage]),
        )
    conn.commit()
    return True


def get_forecast_percentages(conn):
    rows = conn.execute("SELECT stage, forecast_percent FROM forecast_settings").fetchall()
    stored = {row["stage"]: row["forecast_percent"] for row in rows}
    return {stage: stored.get(stage, DEFAULT_FORECAST_PERCENTAGES[stage]) for stage in STAGES}


def list_forecast_settings(conn):
    percentages = get_forecast_percentages(conn)
    return [{"stage": stage, "forecast_percent": percentages[stage]} for stage in STAGES]


def update_forecast_setting(conn, stage, raw_value):
    if stage not in STAGES:
        raise ForecastValidationError("Unknown pipeline stage.")

    try:
        percent = float(raw_value)
    except (TypeError, ValueError):
        raise ForecastValidationError("Forecast % must be a number.")

    if math.isnan(percent) or percent < 0 or percent > 100:
        raise ForecastValidationError("Forecast % must be between 0 and 100.")

    conn.execute(
        "UPDATE forecast_settings SET forecast_percent = ? WHERE stage = ?",
        (percent, stage),
    )
    conn.commit()


def _group_sort_key(name, group_priority):
    """Sort by an explicit priority list first (e.g. EG, then UK), falling
    back to plain alphabetical - for everything not in the priority list, and
    for every group when no priority list is given at all. A group_name of
    None (the single implicit group used when group_field is None) always
    sorts first, though it's meaningless in practice since it's always the
    only group in that case."""
    if name is None:
        return (-1, "")
    if group_priority:
        for index, priority_name in enumerate(group_priority):
            if name == priority_name:
                return (index, "")
        return (len(group_priority), name.lower())
    return (0, name.lower())


def build_pipeline_report(
    rows,
    forecast_percentages,
    person_field="Application",
    group_field="Office",
    excluded_persons=None,
    hidden_persons=None,
    group_priority=("EG", "UK"),
    blank_person_label=None,
    rank_by_total=False,
    keep_rows=False,
):
    """Return a full pipeline report as a plain dict.

    Generic over which field identifies the person (Application, Consultant,
    University Name, ...) and which field groups them (Office, Sales Office,
    or no grouping at all) - every pipeline report on this dashboard is this
    same shape, just parameterised differently, so they share this one
    implementation rather than duplicating the maths:

    - person_field / group_field: which Current Data columns to read.
    - group_field=None means "no grouping" (e.g. University Pipeline) - every
      person is placed in a single implicit, unlabelled group.
    - excluded_persons: a person in this set is dropped entirely, from every
      total (e.g. a holding/placeholder account).
    - hidden_persons: a person in this set still counts fully toward their
      group's and the Grand Total's totals, but doesn't get their own
      row/bar (e.g. someone who has left, whose past volume still counts).
    - blank_person_label: when a row's person field is blank, normally the
      row is excluded entirely (nowhere sensible to attribute it). Passing a
      label here (e.g. "Unassigned") instead folds all such rows into one
      pseudo-person under that name, so they're still visible and ranked
      rather than silently dropped.
    - rank_by_total: when False (the default), people within a group are
      sorted alphabetically. When True, they're sorted by their own Grand
      Total descending, with name ascending as the tie-break (for University
      Pipeline, which ranks by volume rather than alphabetically).
    - group_priority: an explicit group ordering (e.g. EG before UK); falls
      back to alphabetical for anything not listed, or entirely when None.
    - keep_rows: when True, every person row also carries "rows_by_stage" -
      {stage: [the very rows counted in that stage]} - so a caller can list the
      applications behind any number in the report (the click-through window)
      and be sure the list is exactly what was counted, exclusions and all.

    A blank group (when group_field is set) is always treated as a data
    error and excluded, the same as a blank person with no blank_person_label
    - there's nowhere sensible to attribute it, and no report currently asks
    for an "Unassigned" grouping bucket.

    A person's group is fixed the first time that person is seen. If a
    later row has the same person but a different group (e.g. two real
    people collapse to the same person_field value - Application/Consultant
    are first-tokened, but Office/Sales Office are looked up from the full
    raw name), that row is excluded rather than silently merged into the
    first-seen group.

    Every excluded row (blank/excluded person, blank group, or a
    person/group conflict) is counted in excluded_record_count in case that
    count is ever useful.

    A row whose Status is QA_REJECTED_STATUS or DEFERRED_STATUS is never
    counted in counts/total/forecast (neither is in STAGES) - same as any
    other unrecognised Status - but is tallied separately per person, per
    group, and overall (qa_rejected_count/deferred_count on each person row
    and office_group, grand_total_qa_rejected/grand_total_deferred overall),
    purely so a caller that doesn't pre-filter EXCLUDED_PIPELINE_STATUSES
    (the University Pipeline) can surface their existence without folding
    them into Total. 01-NewApp (the third EXCLUDED_PIPELINE_STATUSES value)
    is deliberately not tracked this way - see QA_REJECTED_STATUS's own
    comment for why.
    """
    excluded_persons = excluded_persons or set()
    hidden_persons = hidden_persons or set()
    excluded_record_count = 0

    # person -> {"group": str, "counts": {stage: int}, "qa_rejected_count": int,
    # "deferred_count": int}
    people = {}

    for row in rows:
        person = (row.get(person_field) or "").strip()
        if not person:
            if blank_person_label:
                person = blank_person_label
            else:
                excluded_record_count += 1
                continue

        if person.lower() in excluded_persons:
            excluded_record_count += 1
            continue

        if group_field is None:
            group = None
        else:
            group = (row.get(group_field) or "").strip()
            if not group:
                excluded_record_count += 1
                continue

        status = row.get("Status") or ""

        entry = people.get(person)
        if entry is None:
            entry = {
                "group": group,
                "counts": {s: 0 for s in STAGES},
                "qa_rejected_count": 0,
                "deferred_count": 0,
                "rows": {s: [] for s in STAGES} if keep_rows else None,
            }
            people[person] = entry
        elif entry["group"] != group:
            # person_field is often a first-token of a longer raw name (see
            # processing.first_token), while group_field can be looked up
            # from the full raw name - so two different real people can
            # collapse to the same person string here while genuinely
            # belonging to different groups (e.g. two Admission Officers
            # who share a first name). Never silently fold one into the
            # other's totals - exclude the conflicting row instead of
            # guessing which group is "right".
            excluded_record_count += 1
            continue

        if status in entry["counts"]:
            entry["counts"][status] += 1
            if keep_rows:
                entry["rows"][status].append(row)
        elif status == QA_REJECTED_STATUS:
            entry["qa_rejected_count"] += 1
        elif status == DEFERRED_STATUS:
            entry["deferred_count"] += 1

    def stage_forecast_raw(counts):
        return sum(counts[s] * (forecast_percentages.get(s, 0) / 100.0) for s in STAGES)

    def stage_total(counts):
        return sum(counts[s] for s in STAGES)

    groups = {}
    for person, data in people.items():
        groups.setdefault(data["group"], []).append(person)

    office_groups = []
    grand_total_counts = {s: 0 for s in STAGES}
    grand_total_forecast_raw = 0.0
    grand_total_records = 0
    grand_total_qa_rejected = 0
    grand_total_deferred = 0

    for group_name in sorted(groups.keys(), key=lambda name: _group_sort_key(name, group_priority)):
        person_names = groups[group_name]

        # Compute every person's figures first; display order (alphabetical,
        # or ranked by total) is decided afterwards and doesn't affect the
        # aggregated group/grand totals below, which include everyone
        # regardless of hidden status or final display order.
        computed = {}
        group_counts = {s: 0 for s in STAGES}
        group_forecast_raw = 0.0
        group_records = 0
        group_qa_rejected = 0
        group_deferred = 0

        for name in person_names:
            counts = people[name]["counts"]
            total = stage_total(counts)
            forecast_raw = stage_forecast_raw(counts)
            forecast_rounded = round_half_up(forecast_raw)
            conversion = round_half_up(forecast_rounded / total * 100) if total > 0 else 0
            qa_rejected_count = people[name]["qa_rejected_count"]
            deferred_count = people[name]["deferred_count"]

            computed[name] = {
                "counts": counts,
                "total": total,
                "forecast": forecast_rounded,
                "conversion": conversion,
                "qa_rejected_count": qa_rejected_count,
                "deferred_count": deferred_count,
            }
            if keep_rows:
                computed[name]["rows_by_stage"] = people[name]["rows"]

            for s in STAGES:
                group_counts[s] += counts[s]
            group_forecast_raw += forecast_raw
            group_records += total
            group_qa_rejected += qa_rejected_count
            group_deferred += deferred_count

        if rank_by_total:
            ordered_names = sorted(person_names, key=lambda n: (-computed[n]["total"], n.lower()))
        else:
            ordered_names = sorted(person_names, key=str.lower)

        person_rows = [
            {"name": name, **computed[name]}
            for name in ordered_names
            if name.lower() not in hidden_persons
        ]

        group_forecast_rounded = round_half_up(group_forecast_raw)
        group_conversion = (
            round_half_up(group_forecast_rounded / group_records * 100) if group_records > 0 else 0
        )

        office_groups.append(
            {
                "office": group_name,
                "managers": person_rows,
                "counts": group_counts,
                "total": group_records,
                "forecast": group_forecast_rounded,
                "conversion": group_conversion,
                "qa_rejected_count": group_qa_rejected,
                "deferred_count": group_deferred,
            }
        )

        for s in STAGES:
            grand_total_counts[s] += group_counts[s]
        grand_total_forecast_raw += group_forecast_raw
        grand_total_records += group_records
        grand_total_qa_rejected += group_qa_rejected
        grand_total_deferred += group_deferred

    grand_total_forecast = round_half_up(grand_total_forecast_raw)
    grand_total_conversion = (
        round_half_up(grand_total_forecast / grand_total_records * 100) if grand_total_records > 0 else 0
    )

    return {
        "office_groups": office_groups,
        "grand_total_counts": grand_total_counts,
        "grand_total_records": grand_total_records,
        "grand_total_forecast": grand_total_forecast,
        "grand_total_conversion": grand_total_conversion,
        "excluded_record_count": excluded_record_count,
        "grand_total_qa_rejected": grand_total_qa_rejected,
        "grand_total_deferred": grand_total_deferred,
    }


def build_summary_cards(report):
    """One card per office (in the same order as the table/chart) plus a
    final Overall card. Pure reshaping of an already-built report - no new
    counting or maths, so cards can never disagree with the table."""
    cards = [
        {
            "label": group["office"],
            "total": group["total"],
            "forecast": group["forecast"],
            "conversion": group["conversion"],
        }
        for group in report["office_groups"]
    ]
    cards.append(
        {
            "label": "Overall",
            "total": report["grand_total_records"],
            "forecast": report["grand_total_forecast"],
            "conversion": report["grand_total_conversion"],
        }
    )
    return cards


# The Consultants page's Source Pipeline treats these lead Sources as one:
# raw Source (any case/spacing) -> the name shown on the page's cards/chart.
CONSULTANT_PAGE_SOURCE_GROUPS = {
    "inbound call": "Inbound",
    "website": "Inbound",
    "social media": "Inbound",
    "employee": "Inbound",
}


def regroup_sources(rows, groups=CONSULTANT_PAGE_SOURCE_GROUPS):
    """Copies of `rows` whose Source is replaced by its group name from
    `groups` (matched case-insensitively, trimmed); any other Source - and a
    blank one - is left as it was. The input rows are never modified, so the
    other reports built from them are unaffected."""
    regrouped = []
    for row in rows:
        group = groups.get((row.get("Source") or "").strip().lower())
        regrouped.append({**row, "Source": group} if group else row)
    return regrouped


# The Consultants page's Source Pipeline summary cards are just Paid vs
# everything else, then the total.
PAID_SOURCE = "Paid Ad"
PAID_CARD_LABEL = "Paid Ads"
NON_PAID_CARD_LABEL = "Non Paid"


def build_paid_split_cards(rows, forecast_percentages):
    """Summary cards for `rows`: "Paid Ads" (Source "Paid Ad", matched
    case-insensitively, trimmed), "Non Paid" (every other Source, a blank one
    included) and "Overall" (everyone) - always all three, in that order, even
    when one is zero. Each card is the same {"label", "total", "forecast",
    "conversion"} the other pipelines' cards use, worked out by the very same
    build_pipeline_report() maths (never by adding percentages up), so Paid
    Ads + Non Paid always add up to Overall."""
    paid_key = PAID_SOURCE.lower()
    labelled = [
        {**row, "Source": PAID_CARD_LABEL if (row.get("Source") or "").strip().lower() == paid_key else NON_PAID_CARD_LABEL}
        for row in rows
    ]
    report = build_pipeline_report(
        labelled, forecast_percentages, person_field="Source", group_field=None, rank_by_total=False
    )
    found = {person["name"]: person for group in report["office_groups"] for person in group["managers"]}

    def card(label):
        person = found.get(label)
        if person is None:
            return {"label": label, "total": 0, "forecast": 0, "conversion": 0}
        return {"label": label, "total": person["total"], "forecast": person["forecast"], "conversion": person["conversion"]}

    return [
        card(PAID_CARD_LABEL),
        card(NON_PAID_CARD_LABEL),
        {
            "label": "Overall",
            "total": report["grand_total_records"],
            "forecast": report["grand_total_forecast"],
            "conversion": report["grand_total_conversion"],
        },
    ]


def build_chart_groups(report):
    """Office-grouped chart rows, one row per individual Application Manager
    only (never Office/Grand Totals) - same Office-then-alphabetical order
    as the table, since it's read directly off report["office_groups"].

    Each stage segment's width is expressed as a percentage of the largest
    manager's Grand Total, so bar length reflects relative pipeline size and
    every manager's stage segments are directly comparable to one another.
    """
    all_managers = [m for group in report["office_groups"] for m in group["managers"]]
    max_total = max((m["total"] for m in all_managers), default=0)

    chart_groups = []
    for group in report["office_groups"]:
        rows = []
        for manager in group["managers"]:
            segments = []
            for stage in STAGES:
                count = manager["counts"][stage]
                if count <= 0:
                    continue
                width_pct = (count / max_total * 100) if max_total > 0 else 0
                segments.append({"stage": stage, "count": count, "width_pct": width_pct})

            rows.append(
                {
                    "name": manager["name"],
                    "total": manager["total"],
                    "forecast": manager["forecast"],
                    "conversion": manager["conversion"],
                    "segments": segments,
                }
            )
        chart_groups.append({"office": group["office"], "rows": rows})
    return chart_groups


# The Enrolled Dashboard's own subset of STAGES - a student who has made
# it this far is a successful outcome, not still "in progress" the way
# the rest of the Pipeline dashboards track it. Used for the page's
# summary cards (both stages); the bar chart itself only shows Enrolled
# (see ENROLLED_CHART_STAGES below) - Pre-Enrolled stays a card-only
# figure there.
ENROLLED_STAGES = ["08-Pre-Enrolled", "09-Enrolled"]

# The Enrolled Dashboard chart's own stage subset - just Enrolled itself,
# so the bar chart isn't broken out by Pre-Enrolled/Enrolled per
# Application Manager (the page's top summary cards are Enrolled-only too
# - see app.py's enrolled() route).
ENROLLED_CHART_STAGES = ["09-Enrolled"]

# The Enrolled Dashboard's own chart colours - a copy of STAGE_COLORS with
# Pre-Enrolled overridden to a neutral grey (same tone as
# colors.UNASSIGNED_COLOR), since on this page specifically Enrolled is
# the "arrived" outcome and Pre-Enrolled is still a waiting state, not
# another shade of success - left as STAGE_COLORS' green everywhere else
# (Dashboard/University Report/Just Jon), which is unaffected by this.
ENROLLED_STAGE_COLORS = {**STAGE_COLORS, "08-Pre-Enrolled": "#9aa4b2"}

# build_consultant_enrolled_chart()'s three Intake segments - a single
# green ramp (dark to light, Intake 01 to 03) rather than distinct colors
# per source, since all three are the same "Enrolled" outcome.
ENROLLED_INTAKE_COLORS = {
    "intake_01": "#14532d",
    "intake_02": "#22c55e",
    "intake_03": "#86efac",
}

ENROLLED_INTAKE_LABELS = {
    "intake_01": "Intake 01",
    "intake_02": "Intake 02",
    "intake_03": "Intake 03",
}


def build_stage_subset_chart_groups(report, stages):
    """Like build_chart_groups(), but each row is only segmented by the
    given `stages` (e.g. ENROLLED_STAGES), and a manager's bar length
    (and the shared scaling denominator) is based on their combined count
    across just those stages - not their full Grand Total - so a manager
    with a lot of Pipeline volume elsewhere doesn't dominate a chart
    that's only about this subset."""
    all_managers = [m for group in report["office_groups"] for m in group["managers"]]
    max_total = max((sum(m["counts"][s] for s in stages) for m in all_managers), default=0)

    chart_groups = []
    for group in report["office_groups"]:
        rows = []
        for manager in group["managers"]:
            subset_total = sum(manager["counts"][s] for s in stages)
            segments = []
            for stage in stages:
                count = manager["counts"][stage]
                if count <= 0:
                    continue
                width_pct = (count / max_total * 100) if max_total > 0 else 0
                segments.append({"stage": stage, "count": count, "width_pct": width_pct})

            rows.append({"name": manager["name"], "total": subset_total, "segments": segments})
        chart_groups.append({"office": group["office"], "rows": rows})
    return chart_groups


# Groups STAGES into the same buckets as the Company Dashboard's own
# Pending Assessment/Offer/Enrolment and Enrolled This Intake tiles (see
# company_dashboard.PENDING_ASSESSMENT_STAGES/PENDING_OFFER_STAGES/
# PENDING_ENROLMENT_STAGES/count_enrolled_this_intake), plus a 5th Lost
# bucket the Company Dashboard tiles don't have - kept here as a separate
# copy rather than imported, since pipeline.py has no reverse dependency
# on company_dashboard.py and this grouping is just reused for the
# Dashboard page's own Application Manager Pipeline Health chart, not
# recomputing those tiles' own live figures. 02-PendingQA and
# 03-PendingSubmission are the only 2 of STAGES left out entirely (no
# equivalent tile on either page). Colors are each group's own "furthest
# along" member stage from STAGE_COLORS, keeping the same blue-to-green
# progression the rest of the app uses, with Lost kept as the same
# distinct red used everywhere else it appears.
PIPELINE_HEALTH_STAGE_GROUPS = (
    {
        "key": "pending_assessment",
        "label": "Pending Assessment",
        "stages": ("04-Onboarding", "05-Assessment"),
        "color": STAGE_COLORS["05-Assessment"],
    },
    {
        "key": "pending_offer",
        "label": "Pending Offer",
        "stages": ("06-Decision",),
        "color": STAGE_COLORS["06-Decision"],
    },
    {
        "key": "pending_enrolment",
        "label": "Pending Enrolment",
        "stages": ("07-Ready", "08-Pre-Enrolled"),
        "color": STAGE_COLORS["08-Pre-Enrolled"],
    },
    {
        "key": "enrolled_this_intake",
        "label": "Enrolled This Intake",
        "stages": ("09-Enrolled",),
        # A lighter green than STAGE_COLORS' own "09-Enrolled" (#16a34a) -
        # that shade sits too close to Pending Enrolment's color right
        # next to it on this chart (STAGE_COLORS' "08-Pre-Enrolled",
        # #189a61) to tell apart at a glance. Overridden here only, not
        # in STAGE_COLORS itself, so every other page's Enrolled color
        # (Dashboard/University Report/Just Jon/KPI/...) is unaffected.
        "color": "#4ade80",
    },
    {
        "key": "lost",
        "label": "Lost",
        "stages": ("10-Lost",),
        "color": STAGE_COLORS["10-Lost"],
    },
)


def build_stage_group_chart_groups(report, stage_groups, forecast_percentages):
    """Like build_stage_subset_chart_groups(), but each segment sums a
    named group of several stages together (see PIPELINE_HEALTH_STAGE_GROUPS)
    rather than showing one segment per individual stage - for a chart
    that mirrors the Company Dashboard's own Pending Assessment/Offer/
    Enrolment/Enrolled This Intake tiles at a per-manager level, plus a
    Lost bucket of its own.

    Each row's Total, Forecast and Conversion are computed over just the
    stages covered by `stage_groups` combined (not the manager's full
    Grand Total from `report`, which also includes 02-PendingQA/
    03-PendingSubmission) - same forecast/conversion maths as
    build_pipeline_report's own stage_forecast_raw/conversion, just
    scoped to this subset, so Total/Forecast/Conversion here always agree
    with what the chart's own bars/legend actually represent. A manager's
    bar length (and the shared scaling denominator) is based on that same
    subset total, not their full Grand Total, same convention as
    build_stage_subset_chart_groups."""
    all_managers = [m for group in report["office_groups"] for m in group["managers"]]
    subset_stages = [s for stage_group in stage_groups for s in stage_group["stages"]]

    def group_subset_total(manager):
        return sum(manager["counts"][s] for s in subset_stages)

    def group_subset_forecast(manager):
        forecast_raw = sum(
            manager["counts"][s] * (forecast_percentages.get(s, 0) / 100.0) for s in subset_stages
        )
        return round_half_up(forecast_raw)

    max_total = max((group_subset_total(m) for m in all_managers), default=0)

    chart_groups = []
    for group in report["office_groups"]:
        rows = []
        for manager in group["managers"]:
            subset_total = group_subset_total(manager)
            subset_forecast = group_subset_forecast(manager)
            subset_conversion = round_half_up(subset_forecast / subset_total * 100) if subset_total > 0 else 0
            segments = []
            for stage_group in stage_groups:
                count = sum(manager["counts"][s] for s in stage_group["stages"])
                if count <= 0:
                    continue
                width_pct = (count / max_total * 100) if max_total > 0 else 0
                segments.append(
                    {
                        "key": stage_group["key"],
                        "label": stage_group["label"],
                        "color": stage_group["color"],
                        "count": count,
                        "width_pct": width_pct,
                    }
                )
            rows.append(
                {
                    "name": manager["name"],
                    "total": subset_total,
                    "forecast": subset_forecast,
                    "conversion": subset_conversion,
                    "segments": segments,
                }
            )
        chart_groups.append({"office": group["office"], "rows": rows})
    return chart_groups


def _fold_unassigned(value):
    """Same blank-folding rule as build_pipeline_report's blank_person_label
    - shared so a row can be matched back to one of its already-computed
    person rows (e.g. one University) using the exact same identity."""
    return (value or "").strip() or "Unassigned"


def application_records(rows, extra=None):
    """The click-through window's list: one plain dict per application - PES
    Code, Student, University, Intake, Consultant, Application Manager (a
    blank Consultant / Application Manager / University reads "Unassigned", as
    on the charts) - sorted by Student then PES Code. `extra`, if given, is
    called with each row and returns more fields for its record."""
    records = []
    for row in rows:
        record = {
            "code": (row.get("Student Code") or "").strip(),
            "student": (row.get("Student Name") or "").strip(),
            "university": _fold_unassigned(row.get("University Name")),
            "intake": (row.get("Intake") or "").strip(),
            "consultant": _fold_unassigned(row.get("Consultant")),
            "manager": _fold_unassigned(row.get("Application")),
        }
        if extra is not None:
            record.update(extra(row))
        records.append(record)
    return sorted(records, key=lambda r: (r["student"].lower(), r["code"]))


APPLICATION_RECORD_COLUMNS = [
    ["PES Code", "code"], ["Student", "student"], ["University", "university"],
    ["Intake", "intake"], ["Consultant", "consultant"], ["Application Manager", "manager"],
]
DAYS_RECORD_COLUMNS = APPLICATION_RECORD_COLUMNS + [["Days", "days"]]


def days_since_submitted(row, today, waiting):
    """The Days column of the Application Manager Pipeline Health window, counted
    from the application's Submitted To Uni date: while it is still Pending
    Assessment (`waiting`) it is today minus that date; in any other stage it is
    the Offer Accepted Date minus that date. Blank when a date it needs is
    missing (e.g. no offer accepted yet)."""
    submitted = safe_date(row.get("Submitted To Uni"))
    end = today if waiting else safe_date(row.get("Offer Accepted Date"))
    if submitted is None or end is None:
        return {"days": ""}
    return {"days": str((end - submitted).days)}


def chart_segment_records(rows, university, stages):
    """The applications behind one piece of the University Pipeline chart: the
    rows of `university` (a blank University Name is "Unassigned", as on the
    chart) whose Status is one of `stages`, as application_records()."""
    return application_records(
        row
        for row in rows
        if _fold_unassigned(row.get("University Name")) == university and (row.get("Status") or "").strip() in stages
    )


def report_segment_rows(report, name, stage):
    """The rows counted in `stage` for the person called `name` in a
    build_pipeline_report(keep_rows=True) report - [] when that person has no
    row of their own in it (hidden or excluded) or the stage is unknown."""
    for group in report["office_groups"]:
        for person in group["managers"]:
            if person["name"] == name:
                return list(person.get("rows_by_stage", {}).get(stage, []))
    return []


def report_group_rows(report, name, stages):
    """The rows counted in any of `stages` for the person called `name` in a
    build_pipeline_report(keep_rows=True) report (see report_segment_rows) - one
    piece of a stage-group chart, such as Pending Assessment (04-Onboarding +
    05-Assessment). Their number is exactly the sum of those stages' counts."""
    rows = []
    for stage in stages:
        rows.extend(report_segment_rows(report, name, stage))
    return rows


def filter_by_person(rows, person_field, person):
    """Return only the rows build_pipeline_report(person_field=...,
    blank_person_label="Unassigned") would have grouped under `person` -
    for drilling into one already-selected report row (e.g. one University)
    without re-deriving its blank-folding rule elsewhere."""
    return [row for row in rows if _fold_unassigned(row.get(person_field)) == person]


def count_by_stage(rows):
    """Return ({stage: count}, total) for an arbitrary row set, using the
    same "only a status in STAGES counts" rule as build_pipeline_report (a
    status outside STAGES, e.g. 00-QARejected, isn't counted in any stage or
    the total) - for a flat stage breakdown with no person/group structure
    (e.g. one Course within a University Report)."""
    counts = {s: 0 for s in STAGES}
    for row in rows:
        status = row.get("Status") or ""
        if status in counts:
            counts[status] += 1
    return counts, sum(counts.values())


def build_stage_breakdown(counts, total):
    """Return one entity's own stage segments, each width expressed as a
    percentage of that entity's OWN total - unlike build_chart_groups()
    (which sizes every row against the single busiest person, so bars are
    comparable to each other), this shows the shape of one person's/group's
    pipeline on its own (e.g. a single University Report page), so its bar
    is always full width. Stages with a zero count are omitted, same
    convention as build_chart_groups()."""
    segments = []
    for stage in STAGES:
        count = counts[stage]
        if count <= 0:
            continue
        width_pct = (count / total * 100) if total > 0 else 0
        segments.append({"stage": stage, "count": count, "width_pct": width_pct})
    return segments


# Statuses that don't count toward the Application Manager/Consultant
# Pipeline reports at all - a row in one of these statuses is dropped
# before resolve_pipeline_rows_by_student() below even groups rows by
# student, so it can never be the row that represents a student there:
#   - 00-QARejected / 01-NewApp / 02-PendingQA: never actually submitted
#     (rejected before QA, a brand new application, or still waiting on
#     QA).
#   - 11-Deferred: deferred to another intake, so it isn't real activity
#     in THIS Intake year's pipeline.
# Deliberately NOT applied to the University Pipeline, which still counts
# every row as before.
EXCLUDED_PIPELINE_STATUSES = {"00-QARejected", "01-NewApp", "02-PendingQA", "11-Deferred"}

# The one raw (pre-lookup) Application Status value that's allowed to
# still count as 10-Lost after resolve_pipeline_rows_by_student() picks a
# student's single representative row - every other raw status that maps
# to 10-Lost (e.g. "App Rejected") is dropped from the Pipeline reports
# entirely once a student is reduced to a single Lost row, since only a
# Cancelled application is meant to still show up as pipeline volume.
_SURVIVING_LOST_RAW_STATUS = "Cancelled"


def resolve_pipeline_rows_by_student(rows):
    """Collapse `rows` (already filtered to one Intake year) down to at
    most one row per Student Code, for the Application Manager/Consultant
    Pipeline reports only - NOT the University Pipeline, which keeps
    counting every row unchanged. A student applying to several courses is
    one prospect, not one per course.

    Rows in EXCLUDED_PIPELINE_STATUSES are dropped first and can never
    be the row chosen to represent a student - a student whose only
    application(s) are all in an excluded status contributes nothing here.

    Resolution per student, among whatever rows remain:
      - If any row isn't 10-Lost, keep the most recently Created of those
        - an open application means any Lost application(s) for the same
          student can be ignored.
      - If every remaining row is 10-Lost, keep only the most recently
        Created one - a student is only really lost once, not once per
        course they were rejected/withdrew from.
      - If the row that survives is 10-Lost, it only counts if its raw
        (pre-lookup) Application Status was "Cancelled" (see
        _SURVIVING_LOST_RAW_STATUS) - any other Lost reason is dropped
        from these reports entirely, not just de-duplicated.

    A tie between two candidate rows with the same Created date is broken
    by keeping whichever appeared first in `rows` - deterministic (the
    student is never shown twice), but not meaningful beyond that; in
    practice there are only a handful of these company-wide.

    A row with a blank Student Code can never be identified as the same
    student as any other row, so it's always kept as its own group of one.
    """
    eligible_rows = [row for row in rows if (row.get("Status") or "").strip() not in EXCLUDED_PIPELINE_STATUSES]

    grouped = {}
    ungrouped_rows = []
    for row in eligible_rows:
        code = (row.get("Student Code") or "").strip()
        if not code:
            ungrouped_rows.append(row)
            continue
        grouped.setdefault(code, []).append(row)

    resolved_rows = []
    for group in grouped.values():
        open_rows = [row for row in group if (row.get("Status") or "").strip() != "10-Lost"]
        candidates = open_rows if open_rows else group

        if len(candidates) > 1:
            candidates = sorted(candidates, key=lambda row: row.get("Created") or "", reverse=True)
        winner = candidates[0]

        if (winner.get("Status") or "").strip() == "10-Lost":
            raw_status = ((winner.get("_raw") or {}).get("Application Status") or "").strip()
            if raw_status != _SURVIVING_LOST_RAW_STATUS:
                continue

        resolved_rows.append(winner)

    resolved_rows.extend(ungrouped_rows)
    return resolved_rows


def drop_carried_forward_losses(resolved_rows, all_rows, year):
    """Drop any 10-Lost row in `resolved_rows` (the output of
    resolve_pipeline_rows_by_student() for Intake year `year`) if that
    same student also has a live application in a LATER Intake year -
    found by searching `all_rows` (every Intake year, unfiltered by year).

    A student who reappears with a live application next year wasn't
    really lost this year - typically a course change/carried-forward
    application (or a data entry glitch), not a genuine loss - so it
    shouldn't count as one in this year's report at all.

    "Live" means a status that's neither 10-Lost nor one of
    EXCLUDED_PIPELINE_STATUSES - an unsubmitted or deferred application in
    a later year doesn't prove anything was actually carried forward.

    Only a strictly LATER Intake year counts as "later"; an earlier or
    same-year row for the same student is never considered here (that's
    resolve_pipeline_rows_by_student()'s job, within one year)."""
    live_student_codes_in_a_later_year = set()
    for row in all_rows:
        row_year = _intake_year(row.get("Intake"))
        if row_year is None or row_year <= year:
            continue
        status = (row.get("Status") or "").strip()
        if status == "10-Lost" or status in EXCLUDED_PIPELINE_STATUSES:
            continue
        code = (row.get("Student Code") or "").strip()
        if code:
            live_student_codes_in_a_later_year.add(code)

    kept_rows = []
    for row in resolved_rows:
        if (row.get("Status") or "").strip() == "10-Lost":
            code = (row.get("Student Code") or "").strip()
            if code and code in live_student_codes_in_a_later_year:
                continue
        kept_rows.append(row)
    return kept_rows


def build_consultant_enrolled_chart(rows, manual_adjustments=None, group_as_other=None, use_month_buckets=False):
    """The Enrolled Dashboard's Consultant chart - one flat row per live
    Consultant (no Sales Office grouping, ranked by combined total
    descending - name ascending as the tie-break), split into up to three
    Intake segments (see ENROLLED_INTAKE_COLORS/ENROLLED_INTAKE_LABELS):
    "intake_01"/"intake_02" are the manually-entered pre-CRM-migration
    backfill for that Consultant (from `manual_adjustments` - see
    lookups.list_lookup_rows("sales_office"), the Consultant Lookup
    table's own Intake 01/Intake 02 fields; pass [] for an Intake year the
    backfill doesn't apply to, e.g. 2027), and "intake_03" is that
    Consultant's live 09-Enrolled count from `rows` (already filtered to
    one Intake year) - the current CRM's own data, since the migration
    means this app's own export effectively starts at Intake 03 2026.

    manual_adjustments: [{"consultant", "sales_office", "intake_01", "intake_02"}, ...]
    ("sales_office" is accepted but unused here - this chart doesn't
    group by office) - a Consultant present only in manual_adjustments
    (no live 09-Enrolled rows at all, e.g. someone who left before the
    CRM migration) still gets a row here.

    group_as_other: an optional set of Consultant names (case-insensitive)
    to leave off this chart entirely (see the Consultant Lookup table's
    own "Group as Other" checkbox, Admin page) - this view is scoped to
    live team members only, so a flagged (e.g. departed) Consultant's
    figures don't get a row here at all, not even an aggregate one.

    use_month_buckets: for an Intake year with no manual backfill (2027
    onwards - see intake_buckets_available_for_year), each live
    09-Enrolled row is bucketed into intake_01/02/03 by its own Intake
    month (see _intake_month_bucket) instead of always landing in
    intake_03 - a row whose Intake month isn't recognised is dropped
    rather than guessed at, same as filter_by_intake_bucket."""
    manual_adjustments = manual_adjustments or []
    group_as_other = {name.strip().lower() for name in (group_as_other or []) if name and name.strip()}

    # consultant -> {"intake_01": int, "intake_02": int, "intake_03": int}
    people = {}

    def _entry(consultant):
        return people.setdefault(consultant, {"intake_01": 0, "intake_02": 0, "intake_03": 0})

    for row in rows:
        if (row.get("Status") or "").strip() != "09-Enrolled":
            continue
        consultant = (row.get("Consultant") or "").strip()
        if not consultant or consultant.lower() in group_as_other:
            continue
        if use_month_buckets:
            bucket = _intake_month_bucket(row.get("Intake"))
            if bucket is None:
                continue
            _entry(consultant)[bucket] += 1
        else:
            _entry(consultant)["intake_03"] += 1

    for adjustment in manual_adjustments:
        consultant = (adjustment.get("consultant") or "").strip()
        if not consultant or consultant.lower() in group_as_other:
            continue
        entry = _entry(consultant)
        entry["intake_01"] += adjustment.get("intake_01") or 0
        entry["intake_02"] += adjustment.get("intake_02") or 0

    max_total = max((sum(data.values()) for data in people.values()), default=0)

    rows_out = []
    for consultant, data in people.items():
        total = sum(data.values())
        width_pct = (total / max_total * 100) if max_total > 0 else 0
        segments = []
        for kind in ("intake_01", "intake_02", "intake_03"):
            count = data[kind]
            if count <= 0:
                continue
            segments.append(
                {"kind": kind, "count": count, "width_pct": (count / max_total * 100) if max_total > 0 else 0}
            )
        rows_out.append(
            {
                "name": consultant,
                "intake_01": data["intake_01"],
                "intake_02": data["intake_02"],
                "intake_03": data["intake_03"],
                "total": total,
                "width_pct": width_pct,
                "segments": segments,
            }
        )

    rows_out.sort(key=lambda r: (-r["total"], r["name"].lower()))
    return rows_out


# Scale-reference lines for a bar chart whose rows are sized relative to the
# busiest row's total (e.g. build_consultant_enrolled_chart) - these round
# numbers give a viewer a sense of where each bar actually lands.
CHART_SCALE_MARKER_VALUES = [40, 60, 80, 100, 150, 200]


def build_chart_scale_markers(rows, values=CHART_SCALE_MARKER_VALUES):
    """Vertical scale-marker positions for a chart whose row widths are
    `total / max_total * 100` (see build_consultant_enrolled_chart) - one
    marker per value in `values` that is no bigger than the busiest row's
    total, positioned the same way ("value / max_total * 100") so it lines
    up with where a bar of that exact total would end. A value bigger than
    the busiest row's total is left out rather than clipped or drawn past
    the chart - it "appears" once some row's total reaches it."""
    max_total = max((row["total"] for row in rows), default=0)
    if max_total <= 0:
        return []
    return [{"value": v, "pct": round(v / max_total * 100, 2)} for v in values if v <= max_total]
