"""Shared Excel-export helpers.

Two unrelated pieces of work share this one module:

- safe_append_row() (Finding 11) - the formula-injection safety fix.
- safe_sheet_title()/unique_sheet_title()/apply_column_widths()/
  apply_date_format() (Finding 14) - narrow, behavior-neutral
  duplication cleanup, extracted verbatim from the 4-7 export modules
  that each reimplemented them identically. None of these four change
  any workbook's appearance or behavior versus the code they replace -
  they are the same logic, just defined once instead of several times.
  Deliberately NOT a generic "workbook builder" abstraction - each
  export module still owns its own sheet structure, header styling, and
  column set; only these specific, byte-identical-everywhere pieces
  moved here.

Empirically verified against this project's actual openpyxl version
(3.1.5, confirmed identical in the dev venv and bare system python3) by
writing real files and inspecting the raw XML, not assumed:

- A plain string value passed to ws.append()/cell.value starting with "="
  is auto-promoted by openpyxl into a genuine stored formula cell
  (<f>...</f> in the saved XML) - Excel will execute it on open. This is
  the one real, confirmed risk.
- Strings starting with "+", "-", or "@" are NOT auto-promoted by this
  openpyxl version under any tested circumstance (including leading
  whitespace before a later "="): they are always stored as plain
  inline-string cells. Native .xlsx cells carry an explicit type in their
  XML, and Excel trusts that type when opening the file - unlike CSV
  import, where Excel has no type information and falls back to sniffing
  the leading character. Leaving these three untouched is a deliberate,
  evidence-based decision, not an oversight.
- The check is on the raw, unstripped first character - leading
  whitespace before "=" (" =SUM(...)") is already never promoted by
  openpyxl, so there is nothing to additionally guard there.
- Forcing a cell's data_type to TYPE_STRING *after* ws.append() has
  already placed it produces a plain string cell containing the exact
  original text (confirmed via save+reload round-trip) - no leading
  apostrophe or other character is ever added, unlike the common
  "prefix with '" approach, which is visibly different from the
  original value once opened in Excel.

This app has no legitimate, intentionally-authored formulas anywhere in
its own code (confirmed by repo-wide search) - safe_append_row() is
therefore applied unconditionally to every externally-derived data row,
with nothing to preserve or special-case.
"""

import re

from openpyxl.cell.cell import TYPE_STRING
from openpyxl.utils import get_column_letter


def safe_append_row(ws, values):
    """ws.append(values), then force any cell whose value is a string
    starting with "=" back to a plain string type, so it can never be
    stored (or later execute) as an Excel formula. Every other value -
    any string not starting with "=", and every non-string (int, float,
    bool, None, date, datetime) - is left completely untouched; openpyxl
    already gives each of those their own correct data_type with no
    intervention needed here."""
    ws.append(values)
    row_index = ws.max_row
    for col_index, value in enumerate(values, start=1):
        if isinstance(value, str) and value.startswith("="):
            ws.cell(row=row_index, column=col_index).data_type = TYPE_STRING


# Excel worksheet titles can't contain \ / ? * [ ] : and are capped at 31
# characters - extracted verbatim from the 4 export modules that each
# defined this identically (enrolled_export.py, application_manager_export.py,
# just_jon_export.py, offer_days.py).
_ILLEGAL_SHEET_TITLE_CHARS = re.compile(r'[\\/?*\[\]:]')


def safe_sheet_title(label, fallback="Unassigned"):
    """Sanitize `label` into a valid Excel worksheet title: strip the
    characters Excel won't allow, trim whitespace, fall back to
    `fallback` if that leaves nothing, and cap at Excel's 31-character
    limit."""
    cleaned = _ILLEGAL_SHEET_TITLE_CHARS.sub("", label or "").strip()
    return (cleaned or fallback)[:31]


def unique_sheet_title(base_name, used_titles, fallback="Unassigned"):
    """safe_sheet_title(base_name, fallback), then de-duplicate against
    `used_titles` by appending " (2)", " (3)", etc. - trimming further if
    needed to stay within Excel's 31-character limit on collision."""
    sanitized = safe_sheet_title(base_name, fallback=fallback)
    if sanitized not in used_titles:
        return sanitized

    counter = 2
    while True:
        suffix = f" ({counter})"
        candidate = f"{sanitized[:31 - len(suffix)]}{suffix}"
        if candidate not in used_titles:
            return candidate
        counter += 1


def apply_column_widths(ws, columns):
    """Set each of `columns`' width to max(12, min(40, len(name) + 4)) -
    the same heuristic duplicated identically across all 7 export
    modules."""
    for i, column_name in enumerate(columns, start=1):
        width = max(12, min(40, len(column_name) + 4))
        ws.column_dimensions[get_column_letter(i)].width = width


def apply_date_format(ws, columns, date_columns, header_row=1):
    """Apply the "DD/MM/YYYY" number_format to every column in `columns`
    whose name is in `date_columns`, for every row below `header_row`
    (the 1-indexed row number the header actually sits on - 1 for every
    export except application_manager_export.py, which has a title row
    above its header and so passes its own header_row_index here)."""
    for i, column_name in enumerate(columns, start=1):
        if column_name in date_columns:
            for cell in ws[get_column_letter(i)][header_row:]:
                cell.number_format = "DD/MM/YYYY"
