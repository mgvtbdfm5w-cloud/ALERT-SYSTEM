"""Lost Reasons dashboard calculation logic.

Mirrors offer_days.py/kpi.py's architecture: this module does all the
filtering and grouping; the route/template only render already-prepared
data. Nothing here is persisted - everything is recalculated from the
current active dataset on every page load.

Scope: only records currently at Status "10-Lost" (App Rejected/Cancelled,
via the Status lookup table) count here - this is a breakdown of why
already-lost applications were lost, not a live pipeline count. Grouped by
Intake year (like Offer Days' year tabs), via pipeline.filter_by_intake_year,
reused rather than duplicated.

Chart shape: Lost Reason is a group header (like Sales Office/Office group
the Consultant/Application Manager charts elsewhere), and each Lost Sub
Reason under it is its own chart row with its own bar - the same
group-then-row structure as pipeline.build_chart_groups(), not a single
segmented bar per Reason. Every row's bar width is a percentage of the
single busiest Sub Reason across the WHOLE report (not just within its own
Reason group), so bar length is directly comparable across every row on
the page, matching that same convention.
"""

LOST_STATUS = "10-Lost"

# Current Data field names for the two optional filters on this page -
# "Application" is the same field pipeline.py calls the Application
# Manager (person_field="Application" there too).
CONSULTANT_FIELD = "Consultant"
APPLICATION_MANAGER_FIELD = "Application"


def _fold_unassigned(value):
    return (value or "").strip() or "Unassigned"


def list_distinct_values(rows, field):
    """Return every distinct value of `field` (blank folded to
    "Unassigned") among currently-10-Lost rows, alphabetically
    (case-insensitive) - used to populate the Consultant/Application
    Manager filter dropdowns, scoped to values that actually have at least
    one Lost application so the dropdown never offers an empty option."""
    lost = [r for r in rows if (r.get("Status") or "").strip() == LOST_STATUS]
    return sorted({_fold_unassigned(r.get(field)) for r in lost}, key=str.lower)


def filter_by_field(rows, field, value):
    """Return only rows whose `field` (blank folded to "Unassigned")
    equals `value` - shared by the Consultant and Application Manager
    filters, since both are the same "match one folded field value"
    operation against a different column."""
    return [r for r in rows if _fold_unassigned(r.get(field)) == value]

# Every Sub Reason row uses this one colour - there's no further breakdown
# within a Sub Reason to distinguish by colour (unlike Pipeline's per-stage
# segments), so a single consistent colour reads more honestly than an
# arbitrary rotating palette that would imply a meaning it doesn't have.
# Reuses the same blue already used for the Submissions/Doc Check tables'
# cell-intensity shading (rgba(37, 99, 235, ...)).
BAR_COLOR = "#2563eb"


def build_lost_reason_report(rows):
    """Return a plain dict report for every currently-10-Lost record in
    `rows` (the caller filters by Intake year first, via
    pipeline.filter_by_intake_year, before calling this).

    reason_groups: one entry per Lost Reason (rank_by_total order - the
    reason with the most lost applications first, name ascending as the
    tie-break, matching offer_days.py's University/Manager convention),
    each containing "rows": one per that reason's distinct Lost Sub
    Reasons (also rank_by_total order). Blank Reason/Sub Reason both fold
    into "Unassigned", same convention used everywhere else in this app.
    """
    reasons = {}  # reason -> {sub_reason: count}
    total = 0
    for row in rows:
        status = (row.get("Status") or "").strip()
        if status != LOST_STATUS:
            continue

        reason = (row.get("Lost Reason") or "").strip() or "Unassigned"
        sub_reason = (row.get("Lost Sub Reason") or "").strip() or "Unassigned"

        entry = reasons.setdefault(reason, {})
        entry[sub_reason] = entry.get(sub_reason, 0) + 1
        total += 1

    ordered_reasons = sorted(
        reasons.keys(), key=lambda name: (-sum(reasons[name].values()), name.lower())
    )

    # The single busiest Sub Reason count across the WHOLE report (every
    # Reason group combined) - the shared denominator for every row's bar
    # width, so a row's length is comparable to any other row on the page,
    # not just the other rows in its own Reason group.
    max_sub_reason_count = max(
        (count for sub_counts in reasons.values() for count in sub_counts.values()),
        default=0,
    )

    reason_groups = []
    for reason in ordered_reasons:
        sub_counts = reasons[reason]
        reason_total = sum(sub_counts.values())

        sub_reason_rows = []
        for sub_reason in sorted(sub_counts.keys(), key=lambda name: (-sub_counts[name], name.lower())):
            count = sub_counts[sub_reason]
            width_pct = (count / max_sub_reason_count * 100) if max_sub_reason_count > 0 else 0
            sub_reason_rows.append({"name": sub_reason, "count": count, "width_pct": width_pct})

        reason_groups.append({"reason": reason, "total": reason_total, "rows": sub_reason_rows})

    return {"reason_groups": reason_groups, "total": total, "bar_color": BAR_COLOR}
