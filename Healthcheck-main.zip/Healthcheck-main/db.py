import json
import logging
import os
import re
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path

from role_access import default_rows

# DATA_DIR lets a host (e.g. Railway) keep the database on a persistent
# volume; locally it defaults to ./data exactly as before.
DATA_DIR = Path(os.environ.get("DATA_DIR") or Path(__file__).parent / "data")
DB_PATH = DATA_DIR / "app.db"

logger = logging.getLogger(__name__)

# active_dataset and active_leads_dataset each grow by one row on every
# upload AND every reprocess (both are pure INSERTs - see
# processing.save_active_dataset()/leads.save_active_leads_dataset()), but
# every single read path (get_active_dataset_row(), load_active_dataset(),
# get_active_leads_dataset_row(), load_active_leads_dataset() below) only
# ever reads the single highest-id row. Older rows are kept purely as a
# short safety margin, not because anything reads them - this is the one
# place that number is defined, so both save functions prune to the same
# limit rather than each hardcoding it separately.
ACTIVE_DATASET_RETENTION_LIMIT = 5

# SQLite stores INTEGER columns as signed 64-bit values; binding a Python int
# outside this range raises OverflowError ("Python int too large to convert
# to SQLite INTEGER"), which used to surface as an HTTP 500. Anything a user
# can type that ends up in an INTEGER column must be range-checked with
# fits_sqlite_integer() BEFORE it reaches the database, so it can be refused
# with an ordinary validation message instead.
SQLITE_INT_MIN = -(2**63)
SQLITE_INT_MAX = 2**63 - 1


def fits_sqlite_integer(value):
    return SQLITE_INT_MIN <= value <= SQLITE_INT_MAX

# The only two tables prune_active_dataset_table() is meant to operate on -
# guards against a typo'd table name, since a table name can't be a `?`
# parameter the way a value can (SQL only parameterises values, not
# identifiers), so this has to be an f-string rather than the usual
# parameterised query style used everywhere else in this module.
_PRUNABLE_TABLES = {"active_dataset", "active_leads_dataset"}


def prune_active_dataset_table(conn, table_name):
    """Delete every row in `table_name` except the
    ACTIVE_DATASET_RETENTION_LIMIT most recent ones (highest id) - keeping
    the newly-inserted row (always the new highest id) and a small buffer
    of recent snapshots, never the row currently being read as "active".

    Does not commit. Callers (save_active_dataset()/
    save_active_leads_dataset()) run this in the same transaction as their
    own INSERT and commit once at the end, so a pruning failure rolls back
    the insert too rather than leaving an unpruned table with a dangling
    uncommitted row."""
    if table_name not in _PRUNABLE_TABLES:
        raise ValueError(f"prune_active_dataset_table() does not support table {table_name!r}")
    conn.execute(
        f"DELETE FROM {table_name} WHERE id NOT IN "
        f"(SELECT id FROM {table_name} ORDER BY id DESC LIMIT ?)",
        (ACTIVE_DATASET_RETENTION_LIMIT,),
    )


# The exact two shapes app.py's upload()/leads_upload() ever construct:
#   Applications: f"{timestamp}_{filename}"       e.g. "20260812121449_x.xlsx"
#   Leads:        f"leads_{timestamp}_{filename}" e.g. "leads_20260911074402_x.xlsx"
# timestamp is always datetime.utcnow().strftime("%Y%m%d%H%M%S") - 14 digits.
# Deliberately narrow: a file that doesn't match this exact shape is never
# touched by cleanup_orphaned_uploads() below, no matter what the database
# does or doesn't reference - this is what "positively identified as a
# managed upload" means in practice.
_MANAGED_UPLOAD_FILENAME_PATTERN = re.compile(r"(leads_)?\d{14}_.+\.xlsx")


# An unreferenced managed upload younger than this is NEVER deleted. Between
# a request saving its workbook (file.save in app.py) and its snapshot row
# being committed (save_active_dataset) the file is legitimately unreferenced,
# and a second user's upload finishing in that window would otherwise delete
# it from under the first. A whole request takes seconds (measured: about
# 3 s for an Applications upload, about 10 s for a Leads upload with the
# spreadsheet export) and no request is expected to run past a 2 minute server
# timeout, so 5 minutes is a wide margin; a genuine orphan (e.g. from a failed
# upload) is simply removed by the first cleanup after that.
ORPHAN_MIN_AGE_SECONDS = 5 * 60


def _is_managed_upload_filename(filename):
    return bool(_MANAGED_UPLOAD_FILENAME_PATTERN.fullmatch(filename))


def _resolve_within_uploads_dir(uploads_dir, filename):
    """Return the resolved path for `filename` inside `uploads_dir`, or
    None if it would resolve to anywhere else. A bare `os.listdir()` result
    can never actually contain a path-traversal sequence (a directory entry
    name cannot contain "/"), but this guard is kept as a hard, independent
    check before any deletion regardless - defence in depth, not reliance
    on that guarantee holding forever."""
    uploads_dir = Path(uploads_dir).resolve()
    candidate = (uploads_dir / filename).resolve()
    if candidate.parent != uploads_dir:
        return None
    return candidate


def cleanup_orphaned_uploads(conn, uploads_dir, min_age_seconds=None, now=None):
    """Delete every file in `uploads_dir` that both (a) matches this app's
    own managed-upload naming convention and (b) is not the stored_filename
    of any row currently in active_dataset or active_leads_dataset - the
    filesystem half of the same keep-latest-N retention policy
    prune_active_dataset_table() applies to the database rows themselves
    (Finding 7, following Finding 6). Queries both tables regardless of
    which one's save triggered this call, since both share the one
    uploads/ folder.

    Never raises - this runs after a save has already committed
    successfully, and a cleanup problem must never be allowed to look like
    (or cause) a failed upload. Any error, for the whole pass or for one
    file, is logged and otherwise ignored. Returns the list of filenames
    actually deleted (callers aren't required to use it; tests do, to
    assert on exactly what happened).

    Conservative by construction: a file that isn't a regular file, that
    doesn't match the managed-upload naming pattern (e.g. .gitkeep, a
    directory, or any file someone dropped in by hand), or that fails the
    path-containment check above, is left alone - regardless of whether
    the database happens to reference a row with that exact name, since a
    non-matching name can never be "positively identified" as one of this
    app's own uploads in the first place.

    Also never deletes a file younger than `min_age_seconds` (default
    ORPHAN_MIN_AGE_SECONDS, judged by the file's modification time against
    `now`, default the current time): it may belong to another request that
    has saved its workbook but not yet committed the row that references it.
    A file whose age cannot be determined, or whose modification time is in
    the future, is treated the same way - left alone."""
    deleted = []
    if min_age_seconds is None:
        min_age_seconds = ORPHAN_MIN_AGE_SECONDS
    if now is None:
        now = time.time()
    try:
        uploads_dir = Path(uploads_dir).resolve()
        retained = {row["stored_filename"] for row in conn.execute("SELECT stored_filename FROM active_dataset")}
        retained |= {
            row["stored_filename"] for row in conn.execute("SELECT stored_filename FROM active_leads_dataset")
        }

        for name in os.listdir(uploads_dir):
            if name in retained:
                continue
            if not _is_managed_upload_filename(name):
                continue
            candidate = _resolve_within_uploads_dir(uploads_dir, name)
            if candidate is None or not candidate.is_file():
                continue
            try:
                age_seconds = now - candidate.stat().st_mtime
            except OSError:
                continue
            if age_seconds < min_age_seconds:
                continue
            try:
                candidate.unlink()
                deleted.append(name)
            except OSError:
                logger.exception("Failed to delete orphaned upload %s", name)
    except Exception:
        logger.exception("Orphaned upload cleanup failed")
    return deleted


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


@contextmanager
def db_connection():
    """Own a database connection for the duration of a `with` block:

        with db_connection() as conn:
            ...

    GUARANTEES the connection is closed however the block ends - success, an
    ordinary exception, KeyboardInterrupt or any other BaseException - so a
    failing request can never leave a connection (and, if it was mid-write,
    the database's write lock) lying around waiting for garbage collection.

    If the block exits because of an exception while a transaction is open,
    that transaction is rolled back explicitly before the close.

    It deliberately does NOT commit on a successful exit. Every write helper
    in this app already commits (or rolls back) explicitly, and an implicit
    commit here would silently persist whatever a block happened to leave
    pending. This is different from sqlite3's own `with conn:`, which
    commits/rolls back but never closes the connection.

    The connection itself comes from get_connection() unchanged (same
    timeout, row factory and pragmas)."""
    conn = get_connection()
    try:
        yield conn
    except BaseException:
        try:
            if conn.in_transaction:
                conn.rollback()
        except sqlite3.Error:
            pass  # a broken connection: close() below discards the transaction anyway
        raise
    finally:
        conn.close()


def get_active_dataset_row(conn):
    """Return the current active_dataset row (the most recently uploaded or
    reprocessed dataset), or None if nothing has ever been uploaded.

    Callers that only need metadata (filename, uploaded_at, row_count) and
    not the parsed rows themselves - e.g. reprocess(), which reads the
    original file from disk rather than the stored JSON - should use this
    directly instead of load_active_dataset(), to avoid parsing a JSON blob
    that would just be discarded unused.
    """
    return conn.execute(
        "SELECT * FROM active_dataset ORDER BY id DESC LIMIT 1"
    ).fetchone()


def load_active_dataset(conn):
    """Return (dataset_row, rows) for the current active dataset.

    dataset_row is the raw sqlite3.Row (for metadata like uploaded_at,
    original_filename, row_count), or None if nothing has been uploaded yet.
    rows is the parsed list of processed dataset rows, or an empty list if
    there is no active dataset yet.

    A malformed/corrupted data_json value is never allowed to crash the
    calling page: it's logged and treated the same as "no rows", while the
    dataset row itself (and its metadata) is still returned so a page can
    still show e.g. "last successful upload: ..." even in that situation.
    """
    dataset = get_active_dataset_row(conn)
    if not dataset:
        return None, []

    try:
        rows = json.loads(dataset["data_json"])
    except (TypeError, ValueError):
        logger.exception(
            "Failed to parse data_json for active_dataset id=%s (uploaded_at=%s) - "
            "treating as no rows for this request.",
            dataset["id"],
            dataset["uploaded_at"],
        )
        return dataset, []

    return dataset, rows


def get_active_leads_dataset_row(conn):
    """Same idea as get_active_dataset_row() above, for the separate Leads
    Generated upload (active_leads_dataset) - the most recently uploaded
    Leads workbook, or None if nothing has ever been uploaded."""
    return conn.execute(
        "SELECT * FROM active_leads_dataset ORDER BY id DESC LIMIT 1"
    ).fetchone()


def load_active_leads_dataset(conn):
    """Return (dataset_row, columns, rows) for the current active Leads
    Generated dataset - same shape/error-handling as load_active_dataset()
    above, plus `columns` (the ordered list of column headers from the
    uploaded workbook) since, unlike Applications, the Leads schema isn't a
    fixed constant - it's whatever the uploaded workbook actually contains.
    (None, [], []) if nothing has been uploaded yet."""
    dataset = get_active_leads_dataset_row(conn)
    if not dataset:
        return None, [], []

    try:
        columns = json.loads(dataset["columns_json"])
        rows = json.loads(dataset["data_json"])
    except (TypeError, ValueError):
        logger.exception(
            "Failed to parse columns_json/data_json for active_leads_dataset id=%s "
            "(uploaded_at=%s) - treating as no rows for this request.",
            dataset["id"],
            dataset["uploaded_at"],
        )
        return dataset, [], []

    return dataset, columns, rows


def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with db_connection() as conn:
        _create_schema_and_migrate(conn)


# Database-level backing for the lookup duplicate rule, so two requests that
# both pass the application's duplicate check cannot both write the same
# mapping. It uses SQLite's lower() - the same expression the application's
# check (lookups._has_duplicate) compares against - so "same lookup table +
# same value ignoring (ASCII) case" is unique. Whitespace needs no handling
# here: every writer strips source_value before storing it.
LOOKUP_UNIQUE_INDEX_NAME = "idx_lookup_tables_table_value"
LOOKUP_UNIQUE_INDEX_SQL = (
    f"CREATE UNIQUE INDEX IF NOT EXISTS {LOOKUP_UNIQUE_INDEX_NAME} "
    "ON lookup_tables(table_name, lower(source_value))"
)


def find_duplicate_lookups(conn):
    """Groups of lookup_tables rows that the unique index would reject:
    [(table_name, lower(source_value), how_many, "id,id,..."), ...]."""
    return conn.execute(
        "SELECT table_name, lower(source_value), COUNT(*), GROUP_CONCAT(id) "
        "FROM lookup_tables GROUP BY table_name, lower(source_value) HAVING COUNT(*) > 1 "
        "ORDER BY table_name, lower(source_value)"
    ).fetchall()


def ensure_lookup_unique_index(conn):
    """Idempotently make sure the lookup uniqueness index exists. Returns one
    of "exists", "created", "skipped_duplicates" or "skipped_error".

    NEVER stops the application starting: a database that already contains
    duplicate lookup rows is left exactly as it is (nothing is deleted or
    merged), a clear WARNING names the offending rows, and the index is simply
    not created - the application's own duplicate check keeps working as it
    always has. Once the duplicates have been removed by hand, the next start
    creates the index."""
    if conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type = 'index' AND name = ?", (LOOKUP_UNIQUE_INDEX_NAME,)
    ).fetchone():
        return "exists"

    duplicates = find_duplicate_lookups(conn)
    if duplicates:
        groups = "; ".join(
            f"{table!r} / {key!r} (ids {ids})" for table, key, _count, ids in duplicates
        )
        logger.warning(
            "Lookup uniqueness index %s NOT created: lookup_tables already contains duplicate "
            "mappings - %s. Nothing was changed. Remove the extra rows on the Admin page "
            "(or in the database) and restart to enable the protection.",
            LOOKUP_UNIQUE_INDEX_NAME, groups,
        )
        return "skipped_duplicates"

    try:
        conn.execute(LOOKUP_UNIQUE_INDEX_SQL)
        conn.commit()
    except sqlite3.Error:
        # IntegrityError: a duplicate was written between the check above and
        # the CREATE. OperationalError: e.g. a SQLite too old for expression
        # indexes. Either way the app must still start.
        conn.rollback()
        logger.warning(
            "Lookup uniqueness index %s could not be created; continuing without it.",
            LOOKUP_UNIQUE_INDEX_NAME, exc_info=True,
        )
        return "skipped_error"
    return "created"


# Paid Ad spend tracking (Admin page / Paid Ads page). Money is stored as whole
# pence so it is exact. paid_ad_spend holds one row per calendar month
# ("YYYY-MM"): the spend, whether it is the month's FINAL figure or still
# month-to-date, and an optional budget for just that month. paid_ad_settings
# holds the two global figures.
PAID_AD_MONTHLY_BUDGET_KEY = "monthly_budget"
PAID_AD_REVENUE_PER_ENROLLED_KEY = "revenue_per_enrolled"
PAID_AD_SETTING_DEFAULTS = {
    PAID_AD_MONTHLY_BUDGET_KEY: 16000_00,           # GBP 16,000.00
    PAID_AD_REVENUE_PER_ENROLLED_KEY: 1800_00,      # GBP 1,800.00
}
# Seeded ONCE, when the paid_ad_spend table is first created (never again, so
# a month deleted from the Admin page stays deleted): (month_key, pence, is_final)
PAID_AD_SPEND_SEED = (
    ("2026-08", 2537392, 1),
    ("2026-09", 1430802, 1),
    ("2026-10", 238227, 0),      # October 2026 month-to-date
)


def _create_schema_and_migrate(conn):
    paid_ad_spend_table_existed = conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'paid_ad_spend'"
    ).fetchone() is not None

    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS active_dataset (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            original_filename TEXT NOT NULL,
            stored_filename TEXT NOT NULL,
            uploaded_at TEXT NOT NULL,
            row_count INTEGER,
            data_json TEXT
        );

        CREATE TABLE IF NOT EXISTS active_leads_dataset (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            original_filename TEXT NOT NULL,
            stored_filename TEXT NOT NULL,
            uploaded_at TEXT NOT NULL,
            row_count INTEGER,
            columns_json TEXT,
            data_json TEXT
        );

        CREATE TABLE IF NOT EXISTS lookup_tables (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            table_name TEXT NOT NULL,
            source_value TEXT NOT NULL,
            mapped_value TEXT,
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS unmapped_lookup_values (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            table_name TEXT NOT NULL,
            value TEXT NOT NULL,
            first_seen_at TEXT NOT NULL,
            resolved INTEGER DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS forecast_settings (
            stage TEXT PRIMARY KEY,
            forecast_percent REAL NOT NULL
        );

        CREATE TABLE IF NOT EXISTS kpi_targets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            year INTEGER NOT NULL,
            month INTEGER NOT NULL,
            target_type TEXT NOT NULL,
            target_value INTEGER NOT NULL,
            UNIQUE(year, month, target_type)
        );

        CREATE TABLE IF NOT EXISTS paid_ad_spend (
            month_key TEXT PRIMARY KEY,
            amount_pence INTEGER NOT NULL CHECK (amount_pence >= 0),
            is_final INTEGER NOT NULL DEFAULT 1,
            budget_pence INTEGER CHECK (budget_pence IS NULL OR budget_pence >= 0),
            updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS role_access (
            role TEXT NOT NULL,
            permission TEXT NOT NULL,
            allowed INTEGER NOT NULL CHECK (allowed IN (0, 1)),
            updated_at TEXT NOT NULL,
            PRIMARY KEY (role, permission)
        );

        CREATE TABLE IF NOT EXISTS paid_ad_settings (
            setting_key TEXT PRIMARY KEY,
            value_pence INTEGER NOT NULL CHECK (value_pence >= 0)
        );
        """
    )

    # Admin access grid: every switch gets its default once (never overwritten,
    # so an edited grid survives restarts and new switches appear at their default).
    conn.executemany(
        "INSERT OR IGNORE INTO role_access (role, permission, allowed, updated_at) VALUES (?, ?, ?, '2026-10-06T00:00:00')",
        default_rows(),
    )

    for key, value in PAID_AD_SETTING_DEFAULTS.items():
        conn.execute("INSERT OR IGNORE INTO paid_ad_settings (setting_key, value_pence) VALUES (?, ?)", (key, value))
    if not paid_ad_spend_table_existed:
        conn.executemany(
            "INSERT OR IGNORE INTO paid_ad_spend (month_key, amount_pence, is_final, budget_pence, updated_at) "
            "VALUES (?, ?, ?, NULL, '2026-10-05T00:00:00')",
            PAID_AD_SPEND_SEED,
        )

    existing_columns = {
        row["name"] for row in conn.execute("PRAGMA table_info(unmapped_lookup_values)")
    }
    if "occurrence_count" not in existing_columns:
        conn.execute(
            "ALTER TABLE unmapped_lookup_values ADD COLUMN occurrence_count INTEGER DEFAULT 1"
        )

    # Manual Intake 01/Intake 02 Enrolled backfill counts (Consultant Lookup
    # table only - see lookups.py) for the pre-CRM-migration period. Nullable
    # (0 default) and meaningless for the status/office lookup tables, which
    # simply never populate them.
    lookup_columns = {row["name"] for row in conn.execute("PRAGMA table_info(lookup_tables)")}
    if "intake_01_count" not in lookup_columns:
        conn.execute("ALTER TABLE lookup_tables ADD COLUMN intake_01_count INTEGER DEFAULT 0")
    if "intake_02_count" not in lookup_columns:
        conn.execute("ALTER TABLE lookup_tables ADD COLUMN intake_02_count INTEGER DEFAULT 0")

    # Consultant Lookup table only (see lookups.py) - when checked, this
    # Consultant's rows are folded into a generic "Other" row on
    # Consultant-grouped reports instead of showing under their own name
    # (e.g. a departed employee whose individual figures aren't
    # meaningful anymore, but whose volume should still count somewhere).
    # Meaningless for the status/office lookup tables.
    if "group_as_other" not in lookup_columns:
        conn.execute("ALTER TABLE lookup_tables ADD COLUMN group_as_other INTEGER DEFAULT 0")

    conn.commit()

    ensure_lookup_unique_index(conn)
