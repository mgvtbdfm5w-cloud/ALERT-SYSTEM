"""Loss Reasons by Application Manager: the chart under the Application Manager Pipeline Health chart.

It breaks the Lost applications of the page's own tabs (year, Intake and Intake month)
down by Application Manager and main Lost Reason, from the 2027 intakes onwards. The Lost
applications are exactly the ones the Pipeline Health chart counts in its Lost bar -
the same report, read with keep_rows=True - so the two always agree.

Nothing is stored: it is rebuilt from the current active Applications data on every
page load, like everything else on that page.
"""

import re

from colors import assign_categorical_colors
from pipeline import _fold_unassigned, application_records

LOSS_REASONS_FROM_YEAR = 2027
LOST_STATUS = "10-Lost"

# The click-through window's columns: heading, key in a record.
LOSS_RECORD_COLUMNS = [
    ["PES Code", "code"], ["Student", "student"], ["Application Manager", "manager"],
    ["Consultant", "consultant"], ["University", "university"],
    ["Loss Reason", "reason"], ["Sub Reason", "sub_reason"],
]


def in_scope(selected_year):
    """Whether the chart is shown for the page's year tab (2027 intakes onwards)."""
    return selected_year >= LOSS_REASONS_FROM_YEAR


def lost_rows(report):
    """Every application counted as Lost in a build_pipeline_report(keep_rows=True) report."""
    return [
        row
        for group in report["office_groups"]
        for person in group["managers"]
        for row in person.get("rows_by_stage", {}).get(LOST_STATUS, [])
    ]


def spaced(text):
    """A Lost Reason as it should be read: the source system joins the words up
    ("StudentWithdrew", "QAFailed"), so a space goes in where a capital starts a new word."""
    text = re.sub(r"(?<=[a-z0-9])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])", " ", (text or "").replace("_", " "))
    return " ".join(text.split())


def _reason(row):
    return _fold_unassigned(spaced(row.get("Lost Reason")))


def _sub_reason(row):
    return _fold_unassigned(spaced(row.get("Lost Sub Reason")))


def build_loss_reason_chart(rows):
    """The chart for `rows` (the Lost applications, see lost_rows):

    - "reasons": every main Lost Reason, most applications first (A to Z on a tie), as
      {"name", "color", "count"} - the legend, and the order colours are given in. A
      blank Reason is "Unassigned" (grey), as on the Lost Reasons page.
    - "rows": one per Application Manager (a blank one is "Unassigned"), most
      applications first, A to Z on a tie, "Unassigned" last, as {"name", "total",
      "main_reason", "segments"} - segments being that manager's reasons, as {"reason",
      "color", "count", "width_pct"} in the legend's order, drawn against the busiest
      manager's total.
    - "total": all the applications."""
    by_reason = {}
    by_manager = {}
    for row in rows:
        reason = _reason(row)
        by_reason[reason] = by_reason.get(reason, 0) + 1
        counts = by_manager.setdefault(_fold_unassigned(row.get("Application")), {})
        counts[reason] = counts.get(reason, 0) + 1

    order = sorted(by_reason, key=lambda name: (-by_reason[name], name.lower(), name))
    colors = dict(zip(order, assign_categorical_colors(order)))
    reasons = [{"name": name, "color": colors[name], "count": by_reason[name]} for name in order]

    totals = {name: sum(counts.values()) for name, counts in by_manager.items()}
    busiest = max(totals.values(), default=0)
    names = sorted(by_manager, key=lambda name: (name == "Unassigned", -totals[name], name.lower(), name))
    chart_rows = []
    for name in names:
        counts = by_manager[name]
        segments = [
            {"reason": reason, "color": colors[reason], "count": counts[reason], "width_pct": counts[reason] / busiest * 100}
            for reason in order
            if reason in counts
        ]
        chart_rows.append({"name": name, "total": totals[name], "main_reason": max(segments, key=lambda s: s["count"])["reason"], "segments": segments})
    return {"reasons": reasons, "rows": chart_rows, "total": len(rows)}


def loss_reason_records(rows, manager, reason):
    """The applications behind one piece of the chart: `manager`'s applications lost
    for `reason`, as the click-through window's records (see pipeline.application_records)."""
    return application_records(
        (row for row in rows if _fold_unassigned(row.get("Application")) == manager and _reason(row) == reason),
        extra=lambda row: {"reason": _reason(row), "sub_reason": _sub_reason(row)},
    )
