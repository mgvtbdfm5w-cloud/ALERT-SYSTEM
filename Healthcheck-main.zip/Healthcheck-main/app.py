import calendar
import hmac
import logging
import os
import time
from datetime import datetime, timedelta, timezone
from functools import wraps
from pathlib import Path

from flask import Flask, abort, jsonify, request, render_template, redirect, url_for, session, flash, send_file, make_response
from flask_wtf import CSRFProtect
from flask_wtf.csrf import CSRFError, validate_csrf
from werkzeug.utils import secure_filename
from wtforms.validators import ValidationError

from authorization import ALLOW, DENY, REQUIRE_LOGIN, authorize
from role_access import ROLE_COLUMN_LABELS, build_grid, load_access, reset_access, save_access
from dateutils import UK_TIMEZONE, safe_date, today_uk
from db import (
    get_active_dataset_row,
    db_connection,
    fits_sqlite_integer,
    init_db,
    load_active_dataset,
    load_active_leads_dataset,
)
from processing import (
    LOOKUP_TABLE_INFO,
    ProcessingError,
    build_export_workbook,
    process_workbook,
    save_active_dataset,
)
from leads import (
    LEAD_STAGE_COLORS,
    LEAD_STAGE_ORDER,
    LeadsProcessingError,
    build_leads_export_workbook,
    process_leads_workbook,
    save_active_leads_dataset,
)
from leads_dashboard import (
    build_allocation_report,
    allocation_segment_rows,
    lead_records,
    LEAD_RECORD_COLUMNS,
    UNASSIGNED_LABEL as UNASSIGNED_LEAD_STAGE,
    MIN_AGE_DAYS,
    filter_by_min_age_days,
    build_split_report,
    build_lead_source_report,
    build_lead_source_summary,
    build_month_summary,
    filter_by_creation_month,
    filter_inbound_call_leads,
    filter_just_jon_leads,
    filter_paid_ad_leads,
)
from lookups import (
    DuplicateLookupError,
    LookupValidationError,
    add_lookup,
    delete_lookup,
    list_lookup_rows,
    update_lookup,
)
from healthcheck import run_healthcheck
import db as db_module
from data_restore import MAX_BUNDLE_BYTES, RestoreError, restore_bundle, restore_enabled
from login_throttle import (
    FAILURE_WINDOW_SECONDS,
    LOCKOUT_SECONDS,
    MAX_FAILED_ATTEMPTS,
    LoginThrottle,
)
from bonus import BONUS_RECORD_COLUMNS, STATUSES as BONUS_STATUSES, STATUS_COLORS as BONUS_STATUS_COLORS, bonus_records, build_bonus_chart, status_slug as bonus_status_slug, in_scope as bonus_in_scope, submitted_date, submitted_months
from loss_reasons_chart import LOSS_RECORD_COLUMNS, build_loss_reason_chart, in_scope as loss_reasons_in_scope, loss_reason_records, lost_rows
from incentives import INCENTIVES, INCENTIVES_BY_KEY, INCENTIVE_TABS, LIST_COLUMN_LABELS, build_incentive, incentive_records
from interviews import build_interview_groups, day_label, get_operational_days, interview_window_rows
from paid_ads import (
    PaidAdValidationError,
    build_paid_ads_report,
    build_paid_leads_by_office,
    delete_spend as delete_paid_ad_spend,
    forecast_month as forecast_paid_ad_month,
    format_gbp,
    get_settings as get_paid_ad_settings,
    list_spend as list_paid_ad_spend,
    save_settings as save_paid_ad_settings,
    save_spend as save_paid_ad_spend,
)
from enrolled_export import build_enrolled_export, export_filename as enrolled_export_filename
from just_jon_leads_export import (
    build_just_jon_leads_export,
    export_filename as just_jon_leads_export_filename,
)
from university_pipeline_export import (
    build_summary_rows,
    build_university_pipeline_export,
    export_filename as university_pipeline_export_filename,
)
from enrolled_intake_export import (
    build_enrolled_current_intake_export,
    export_filename as enrolled_current_intake_export_filename,
)
from thirty_days_export import build_thirty_days_export, export_filename as thirty_days_export_filename
from application_manager_export import (
    build_application_manager_pipeline_export,
    export_filename as application_manager_export_filename,
)
from just_jon_export import build_just_jon_export, export_filename as just_jon_export_filename
from pipeline import (
    ENROLLED_INTAKE_COLORS,
    ENROLLED_INTAKE_LABELS,
    INTAKE_BUCKET_KEYS,
    INTAKE_BUCKET_LABELS,
    STAGES,
    STAGE_COLORS,
    EXCLUDED_MANAGERS,
    FAHEEM_CONSULTANT,
    HIDDEN_CONSULTANTS,
    JUST_JON_SUB_SOURCES,
    PIPELINE_HEALTH_STAGE_GROUPS,
    PIPELINE_INTAKE_YEAR,
    PIPELINE_INTAKE_YEARS,
    ForecastValidationError,
    build_chart_groups,
    build_chart_scale_markers,
    build_consultant_enrolled_by_year,
    build_consultant_enrolled_chart,
    build_paid_split_cards,
    build_pipeline_report,
    build_stage_breakdown,
    build_stage_group_chart_groups,
    DAYS_RECORD_COLUMNS,
    application_records,
    days_since_submitted,
    chart_segment_records,
    report_group_rows,
    report_segment_rows,
    build_summary_cards,
    count_by_stage,
    drop_carried_forward_losses,
    filter_by_intake_bucket,
    filter_by_intake_months,
    filter_by_intake_year,
    filter_by_consultant,
    filter_by_person,
    filter_by_sub_source,
    get_forecast_percentages,
    intake_buckets_available_for_year,
    list_application_managers,
    list_consultant_names,
    list_consultants,
    list_qa_officers,
    list_sales_offices,
    list_forecast_settings,
    list_intake_months,
    list_statuses,
    regroup_sources,
    resolve_consultant_name,
    resolve_pipeline_rows_by_student,
    seed_forecast_settings_if_empty,
    update_forecast_setting,
)
from kpi import (
    COMPANY_TARGET_TYPE,
    CONSULTANT_STATUS_REMAINING_COLOR,
    CONSULTANT_TARGET_TYPE,
    KpiTargetValidationError,
    build_kpi_progress_chart,
    build_kpi_report,
    build_month_options,
    build_oxford_kpi_matrix,
    build_backlog_box,
    build_pipeline_backlog_summary,
    build_submission_pending_by_year,
    format_month_label,
    get_kpi_targets,
    list_available_months,
    list_sales_offices_for_month,
    month_key,
    parse_month_key,
    set_kpi_target,
)
from offer_days import (
    BUCKET_COLORS,
    BUCKET_EXPORT_SLUGS,
    BUCKETS,
    TOTAL_EXPORT_SLUG,
    build_manager_average_age_by_group,
    build_offer_days_export,
    build_offer_days_report,
    build_offer_days_total_export,
    build_university_average_age_by_group,
    export_filename,
    list_qualifying_records,
    resolve_export_bucket,
)
import company_dashboard as company_dashboard_module
from lost_reasons import (
    APPLICATION_MANAGER_FIELD,
    CONSULTANT_FIELD,
    build_lost_reason_report,
    filter_by_field,
    list_distinct_values,
)
from submissions import (
    build_daily_matrix,
    count_hold,
    count_pending_submission,
    list_available_months as list_available_submission_months,
)

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).parent
# UPLOAD_DIR lets a host (e.g. Railway) keep uploaded workbooks on a
# persistent volume; locally it defaults to ./uploads exactly as before.
UPLOAD_FOLDER = Path(os.environ.get("UPLOAD_DIR") or BASE_DIR / "uploads")
ALLOWED_EXTENSIONS = {".xlsx"}

# Download names for the Applications / Leads spreadsheets (browser downloads
# only - nothing is written anywhere on the server).
APPLICATIONS_EXPORT_FILENAME = "Applications.xlsx"
LEADS_EXPORT_FILENAME = "Leads.xlsx"


def _build_applications_export():
    """The current Applications workbook as an in-memory buffer (None if
    there is no active dataset), as served by the browser download."""
    with db_connection() as conn:
        dataset, rows = load_active_dataset(conn)
    return build_export_workbook(rows) if dataset else None


def _build_leads_export():
    """Same as _build_applications_export(), for the Leads dataset."""
    with db_connection() as conn:
        dataset, _columns, rows = load_active_leads_dataset(conn)
    return build_leads_export_workbook(rows) if dataset else None


# Every role logs in with its own shared password (no usernames yet) -
# matches how login already worked before (one shared password), just
# with 4 of them now instead of 1. "full" preserves the original
# behaviour/env var name so an existing HEALTHCHECK_PASSWORD deployment
# keeps working unchanged as the Full-access login; FULL_PASSWORD (if
# set) takes priority over it for a deployment that wants to rename it.
#
# What each role may DO is decided in authorization.py (the single
# endpoint -> roles policy table, enforced by _enforce_authorization
# below); `session["role"]` is the value that policy is checked against
# and is also shown in the nav bar. login_required() below only checks
# that someone is logged in - it is the second layer, not the policy.
ROLE_PASSWORDS = {
    "full": os.environ.get("FULL_PASSWORD") or os.environ.get("HEALTHCHECK_PASSWORD"),
    "admissions": os.environ.get("ADMISSIONS_PASSWORD"),
    "consultants": os.environ.get("CONSULTANTS_PASSWORD"),
    "marketing": os.environ.get("MARKETING_PASSWORD"),
}

# No insecure defaults - every role's password must come from the
# environment. Fail loudly at startup rather than silently running with a
# missing/blank password that would let that role in with any input.
_missing_password_env_vars = [
    env_name
    for role, env_name in {
        "full": "FULL_PASSWORD (or the legacy HEALTHCHECK_PASSWORD)",
        "admissions": "ADMISSIONS_PASSWORD",
        "consultants": "CONSULTANTS_PASSWORD",
        "marketing": "MARKETING_PASSWORD",
    }.items()
    if not ROLE_PASSWORDS[role]
]
if _missing_password_env_vars:
    raise RuntimeError(
        "Missing required environment variable(s): "
        + ", ".join(_missing_password_env_vars)
        + ". Set these before starting the app - there is no insecure default."
    )

ROLE_LABELS = {
    "full": "Full Access",
    "admissions": "Admissions",
    "consultants": "Consultants",
    "marketing": "Marketing",
}


# Longest password /login will even compare. Anything longer is simply a
# failed login (same generic message, still counted by the throttle) and is
# never compared against the configured passwords.
MAX_PASSWORD_LENGTH = 256


def _resolve_role(password):
    """Return the role name whose password matches `password`, or None if
    it matches none of them - a pure lookup, kept separate from the
    /login route itself so it's trivially testable without a request
    context.

    Any text at all is safe to pass: comparison is on UTF-8 bytes
    (hmac.compare_digest on str only accepts ASCII and would raise
    TypeError for e.g. "p\u00e4ssword"), using "surrogatepass" so even a
    lone surrogate encodes to its own distinct bytes rather than colliding
    with a real character. Empty or over-long input never matches."""
    if not password or len(password) > MAX_PASSWORD_LENGTH:
        return None
    submitted = password.encode("utf-8", "surrogatepass")
    for role, role_password in ROLE_PASSWORDS.items():
        if hmac.compare_digest(submitted, role_password.encode("utf-8", "surrogatepass")):
            return role
    return None

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY")
if not app.secret_key:
    raise RuntimeError(
        "Missing required environment variable: FLASK_SECRET_KEY. "
        "Set this before starting the app - there is no insecure default."
    )

# Applies globally to every POST/PUT/PATCH/DELETE route by default - every
# state-changing route in this app is a plain HTML form POST (confirmed by
# a repo-wide search: no fetch()/XMLHttpRequest/AJAX anywhere), so the
# default behaviour is exactly what's needed with no per-route decorators
# or exemptions. Uses app.secret_key above to sign tokens, so this must be
# configured after that's set.
CSRFProtect(app)

# The largest real upload seen in uploads/ to date is ~2.7MB (a workbook
# named Arden2027.xlsx) - 20MB gives well over 7x headroom above that for
# normal growth, while still bounding worst-case memory/disk use from an
# accidental or malicious oversized upload.
app.config["MAX_CONTENT_LENGTH"] = 20 * 1024 * 1024

UPLOAD_FOLDER.mkdir(parents=True, exist_ok=True)
init_db()

with db_connection() as _seed_conn:
    seed_forecast_settings_if_empty(_seed_conn)


@app.template_filter("ukdate")
def ukdate(value):
    if not value:
        return ""
    try:
        year, month, day = value.split("-")
        return f"{day}/{month}/{year}"
    except ValueError:
        return value


@app.template_filter("ukdatetime")
def ukdatetime(value):
    """Format a stored UTC ISO timestamp as UK local time (GMT/BST-aware),
    since all timestamps are recorded with datetime.utcnow()."""
    if not value:
        return ""
    try:
        dt = datetime.fromisoformat(value).replace(tzinfo=timezone.utc)
        return dt.astimezone(UK_TIMEZONE).strftime("%d/%m/%Y %H:%M")
    except ValueError:
        return value


@app.template_filter("ukfulldate")
def ukfulldate(value):
    if not value:
        return ""
    return f"{value.strftime('%A')} {value.day} {value.strftime('%B %Y')}"


@app.template_filter("cleanpct")
def cleanpct(value):
    value = float(value)
    if value == int(value):
        return str(int(value))
    return f"{value:g}"


@app.template_filter("gbp")
def gbp(pence):
    """Whole pence -> '£1,234.56' (a dash for None)."""
    return format_gbp(pence)


@app.context_processor
def _inject_current_role():
    """Make the logged-in role's display label available to every
    template (the nav bar) without every one of the ~26 routes having to
    pass it through explicitly."""
    role = session.get("role")
    return {"current_role_label": ROLE_LABELS.get(role) if role else None}


# The Admin page's access grid (role_access.py), cached in memory so a request
# does not hit the database just to be authorized. It is reloaded the moment
# the grid is saved or reset, and re-read at most every
# ACCESS_REFRESH_SECONDS so that, if the app ever ran with more than one
# worker, a change made on one would still reach the others quickly.
ACCESS_REFRESH_SECONDS = 60
_access_cache = {"access": None, "loaded_at": 0.0}


def reload_role_access(conn=None):
    """Re-read the grid into the cache (using `conn` if the caller already
    has a connection open, so a request never needs a second one)."""
    if conn is None:
        with db_connection() as own_conn:
            access = load_access(own_conn)
    else:
        access = load_access(conn)
    _access_cache["access"] = access
    _access_cache["loaded_at"] = time.monotonic()
    return access


def current_role_access():
    stale = time.monotonic() - _access_cache["loaded_at"] > ACCESS_REFRESH_SECONDS
    if _access_cache["access"] is None:
        return reload_role_access()
    if stale:
        try:
            return reload_role_access()
        except Exception:
            logger.exception("Could not refresh the access grid; keeping the last known one.")
            _access_cache["loaded_at"] = time.monotonic()
    return _access_cache["access"]


def _authorize_current_session(endpoint):
    logged_in = session.get("logged_in")
    access = current_role_access() if logged_in else None
    return authorize(endpoint, logged_in, session.get("role"), access)


reload_role_access()      # start-up load (init_db() above has already created and seeded the table)


# Where a login lands: the first of these its access grid allows.
LANDING_ENDPOINTS = ("company_dashboard", "consultants", "todo", "admin")


def _landing_endpoint():
    """The first main page the current session may open, or None if the access
    grid leaves it with none (it then sees the Access Denied page)."""
    for endpoint in LANDING_ENDPOINTS:
        if _authorize_current_session(endpoint) == ALLOW:
            return endpoint
    return None


@app.context_processor
def _inject_permission_helper():
    """Template helper `can(endpoint_name)`: True if the current session
    may use that endpoint, answered by the same authorization.authorize()
    policy the request hook enforces. Presentation only - it decides which
    links/controls to RENDER; the server-side hook remains the real
    boundary and still returns 403 for a denied direct request."""
    def can(endpoint):
        return _authorize_current_session(endpoint) == ALLOW
    return {"can": can}


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("login"))
        return view(*args, **kwargs)

    return wrapped


# Global authorization check - the single enforcement point for the
# policy in authorization.py. Registered here, after CSRFProtect(app)
# above, so Flask runs it AFTER the CSRF check: a POST with a missing or
# invalid token is rejected with 400 before authorization is ever
# consulted (same as before this hook existed, when an unauthenticated
# POST without a token was already a 400), and only a request that
# passes CSRF reaches this check. tests/test_authorization.py locks that
# ordering in. The per-route @login_required decorators are deliberately
# kept as a second, independent layer.
@app.before_request
def _enforce_authorization():
    decision = _authorize_current_session(request.endpoint)
    if decision == REQUIRE_LOGIN:
        return redirect(url_for("login"))
    if decision == DENY:
        abort(403)


@app.errorhandler(403)
def _forbidden(error):
    return render_template("403.html"), 403


# "Any age": larger than any real page lifetime, so a validate_csrf() call
# with this limit checks everything EXCEPT how old the token is.
_ANY_TOKEN_AGE_SECONDS = 10 * 365 * 24 * 60 * 60


def _csrf_token_is_genuine_but_expired():
    """True only when token AGE is genuinely why the request was rejected:
    the submitted token fails validation under the app's normal time limit,
    yet passes when age is ignored - i.e. it is a real token for THIS
    session that has simply grown too old.

    Flask-WTF reports every failure as a CSRFError carrying just a message
    string - there is no structured "expired" signal - so instead of
    matching on that text this makes two calls to its public
    validate_csrf():

      1. with the NORMAL limit (WTF_CSRF_TIME_LIMIT, untouched). If this
         SUCCEEDS the token is current and valid, so the request was
         rejected for some other reason (e.g. the HTTPS referrer / same-
         origin check) and must keep the ordinary 400.
      2. with age ignored. A missing token, a bad signature, or another
         session's token fail here too, so they keep the ordinary 400.

    Only "fails normally, passes with age ignored" counts as expired."""
    token = request.form.get(app.config.get("WTF_CSRF_FIELD_NAME", "csrf_token"))
    try:
        validate_csrf(token)
    except ValidationError:
        pass
    else:
        return False
    try:
        validate_csrf(token, time_limit=_ANY_TOKEN_AGE_SECONDS)
    except ValidationError:
        return False
    return True


@app.errorhandler(CSRFError)
def _csrf_failed(error):
    """Every CSRF failure keeps Flask-WTF's normal 400 response EXCEPT one
    deliberate friendly case: a still-logged-in user whose Logout button
    (a page left open past WTF_CSRF_TIME_LIMIT) has expired. They are sent
    to a normal page, which renders a fresh token, with a short message;
    the session is NOT cleared, so a failed or forged request can never log
    anyone out."""
    if (
        request.endpoint == "logout"
        and session.get("logged_in")
        and _csrf_token_is_genuine_but_expired()
    ):
        flash("Your Logout button expired. Please try again.", "warning")
        return redirect(url_for(_landing_endpoint() or "index"))
    return error


@app.route("/")
def index():
    if session.get("logged_in"):
        landing = _landing_endpoint()
        if landing is None:
            abort(403)          # signed in, but the access grid leaves this login no pages
        return redirect(url_for(landing))
    return redirect(url_for("login"))


# Failed-login throttle: MAX_FAILED_ATTEMPTS failures within
# FAILURE_WINDOW_SECONDS lock the client address out for LOCKOUT_SECONDS.
# In-memory and per process (see login_throttle.py for what that implies).
# Keyed on request.remote_addr ONLY - X-Forwarded-For is client-controlled
# unless a trusted proxy overwrites it, so it is deliberately never used.
login_throttle = LoginThrottle()

LOGIN_LOCKED_MESSAGE = "Too many failed attempts. Please wait a few minutes and try again."


def _login_locked_response(retry_after):
    flash(LOGIN_LOCKED_MESSAGE, "error")
    response = make_response(render_template("login.html"), 429)
    response.headers["Retry-After"] = str(retry_after)
    return response


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        # (CSRF has already been checked by the time we get here, and a CSRF
        # failure never reaches this code - so it is never counted below.)
        address = request.remote_addr or "unknown"

        if login_throttle.is_locked(address):
            # Locked out: the submitted password is not even looked at, so a
            # correct guess during a lockout gains nothing and no session is
            # created.
            if login_throttle.record_rejection(address) == 1:
                logger.warning("Login attempt rejected from %s: locked out.", address)
            return _login_locked_response(login_throttle.retry_after(address))

        # _resolve_role() handles every kind of USER input itself (empty,
        # wrong, any Unicode, over-length) by returning None, and all of
        # those are counted below as ordinary failed attempts. An
        # UNEXPECTED exception here is a real bug or broken configuration;
        # it is deliberately not caught: Flask's normal 500 handling logs
        # the traceback (no form data) and returns a generic error page,
        # no session is created, and it is not mistaken for a wrong password.
        role = _resolve_role(request.form.get("password", ""))

        if role:
            login_throttle.clear(address)
            session["logged_in"] = True
            session["role"] = role
            return redirect(url_for(_landing_endpoint() or "index"))

        result = login_throttle.record_failure(address)
        logger.warning(
            "Failed login from %s (%d of %d allowed in %d minutes).",
            address, result.count, MAX_FAILED_ATTEMPTS, FAILURE_WINDOW_SECONDS // 60,
        )
        if result.locked:
            logger.warning("Login locked out for %s for %d minutes.", address, LOCKOUT_SECONDS // 60)
            return _login_locked_response(result.retry_after)
        flash("Incorrect password.", "error")
    return render_template("login.html")


@app.route("/logout", methods=["POST"])
def logout():
    """POST-only (a GET/HEAD would let any cross-site link or prefetch log a
    user out) and CSRF-protected like every other POST. Deliberately
    undecorated and listed in authorization.PUBLIC_ENDPOINTS, outside role
    authorization, so ANY session - including one with an unknown or
    tampered role - can always clear itself. Clearing an already-empty
    session is harmless, so a valid-token POST without a login simply
    redirects to the login page."""
    session.clear()
    return redirect(url_for("login"))


@app.route("/company-dashboard")
@login_required
def company_dashboard():
    """Eight top-level number tiles for an at-a-glance company health
    snapshot - four month-scoped (Leads Generated/Docs Approved/QA
    Passed/Submitted to University, via company_dashboard.build_month_scoped_tiles)
    that follow this page's own month filter, and four live/point-in-time
    figures (Open Applications, Offer Days average age, Enrolled This
    Intake, Enrolled This Year) that don't - see company_dashboard.py's
    module docstring for exactly which existing page/calculation backs
    each tile, so none of these numbers can ever disagree with what that
    same figure shows on its own page."""
    with db_connection() as conn:
        dataset, rows = load_active_dataset(conn)
        leads_dataset, _, leads_rows = load_active_leads_dataset(conn)
        sales_office_lookup_rows = list_lookup_rows(conn, "sales_office")
        forecast_percentages = get_forecast_percentages(conn)

    available_months = company_dashboard_module.list_available_months(rows, leads_rows)

    requested = parse_month_key(request.args.get("month"))
    selected = requested if requested in available_months else None
    if selected is None:
        selected = available_months[0] if available_months else None

    today = today_uk()

    month_tiles = None
    month_tile_statuses = None
    selected_key = None
    selected_label = None
    progress = None
    if selected:
        year, month = selected
        selected_key = month_key(year, month)
        selected_label = format_month_label(year, month)

        with db_connection() as kpi_conn:
            company_target = get_kpi_targets(kpi_conn, year, month).get(COMPANY_TARGET_TYPE)

        month_tiles = company_dashboard_module.build_month_scoped_tiles(
            rows, leads_rows, year, month, company_target
        )
        month_tile_statuses = {
            "leads_generated": company_dashboard_module.classify_month_tile(
                "leads_generated", month_tiles["leads_generated"]
            ),
            "docs_approved": company_dashboard_module.classify_month_tile(
                "docs_approved", month_tiles["docs_approved"]
            ),
            "qa_passed": month_tiles["qa_passed_status"],
            "submitted_to_uni": company_dashboard_module.classify_month_tile(
                "submitted_to_uni", month_tiles["submitted_to_uni"]
            ),
        }
        progress = company_dashboard_module.month_progress(year, month, today)

    pipeline_stage_tiles = company_dashboard_module.build_pipeline_stage_tiles(rows)

    # Enrolled This Intake's Forecast - the exact same Consultant Pipeline
    # Overall Forecast figure the Enrolled tab itself shows (via
    # _build_pipeline_dashboard_context, same as that page's own route),
    # for the same Intake year and with no Intake bucket sub-filter -
    # matching count_enrolled_this_intake()'s own scope exactly.
    group_as_other = {row["source_value"] for row in sales_office_lookup_rows if row["group_as_other"]}
    enrolled_intake_dashboard_context = _build_pipeline_dashboard_context(
        rows, PIPELINE_INTAKE_YEAR, forecast_percentages, None, group_as_other
    )
    enrolled_this_intake_forecast = enrolled_intake_dashboard_context["consultant_report"]["grand_total_forecast"]

    # The CRM-migration-era manual Intake 01/02 backfill (Consultant
    # Lookup table, Admin page) only has meaning for 2026 - see the
    # Enrolled page's own equivalent manual_adjustments - so it's only
    # folded into Enrolled This Year when the calendar year is 2026.
    manual_backfill_total = 0
    if today.year == 2026:
        manual_backfill_total = sum(
            (row["intake_01_count"] or 0) + (row["intake_02_count"] or 0) for row in sales_office_lookup_rows
        )

    # Enrolled This Year's Forecast, for the whole year rather than just
    # the live pipeline's own Intake year: the manual Intake 01/02
    # backfill (already happened, so it's certain rather than forecast)
    # plus the live pipeline's own Forecast above (which already
    # includes this Intake year's actual Enrolled count, weighted at
    # 100% - see build_pipeline_report's forecast_percentages).
    enrolled_this_year_forecast = manual_backfill_total + enrolled_this_intake_forecast

    return render_template(
        "company_dashboard.html",
        dataset=dataset,
        month_options=build_month_options(available_months),
        selected_key=selected_key,
        selected_label=selected_label,
        month_tiles=month_tiles,
        month_tile_statuses=month_tile_statuses,
        progress=progress,
        pipeline_stage_tiles=pipeline_stage_tiles,
        pending_tiles_year=company_dashboard_module.PENDING_TILES_INTAKE_YEAR,
        submission_pending_by_year=build_submission_pending_by_year(rows),
        doc_check_pending=build_backlog_box(rows, "doc_check"),
        enrolled_this_intake=company_dashboard_module.count_enrolled_this_intake(rows),
        enrolled_this_intake_forecast=enrolled_this_intake_forecast,
        enrolled_this_intake_year=PIPELINE_INTAKE_YEAR,
        enrolled_by_office=company_dashboard_module.build_enrolled_by_office(rows),
        enrolled_this_calendar_year=company_dashboard_module.count_enrolled_this_calendar_year(
            rows, today.year, manual_backfill_total
        ),
        enrolled_this_year_forecast=enrolled_this_year_forecast,
        calendar_year=today.year,
    )


@app.route("/todo")
@login_required
def todo():
    with db_connection() as conn:
        dataset, rows = load_active_dataset(conn)

    issues = run_healthcheck(rows)
    return render_template("todo.html", dataset=dataset, issues=issues)


@app.route("/interviews")
@login_required
def interviews():
    """The Interviews page: the next five business days (see
    interviews.get_operational_days), one table each, narrowed by the optional
    Application Manager / QA Officer / Consultant filters. The filters' options
    are the people who have an interview in those five days; a value that is not
    one of them is ignored."""
    with db_connection() as conn:
        dataset, rows = load_active_dataset(conn)

    days = get_operational_days()
    window_rows = interview_window_rows(rows, days)
    manager_options = list_application_managers(window_rows)
    qa_options = list_qa_officers(window_rows)
    consultant_options = list_consultants(window_rows)
    selected_manager = request.args.get("manager")
    selected_qa = request.args.get("qa")
    selected_consultant = request.args.get("consultant")
    if selected_manager not in manager_options:
        selected_manager = None
    if selected_qa not in qa_options:
        selected_qa = None
    if selected_consultant not in consultant_options:
        selected_consultant = None
    if selected_manager:
        rows = filter_by_person(rows, "Application", selected_manager)
    if selected_qa:
        rows = filter_by_person(rows, "QA", selected_qa)
    if selected_consultant:
        rows = filter_by_person(rows, "Consultant", selected_consultant)

    sections = []
    for index, day in enumerate(days):
        label = day_label(index, day)
        sections.append(
            {
                "label": label,
                "date": day,
                "groups": build_interview_groups(rows, day),
                "empty_message": f"No interviews scheduled for {label.lower() if index < 2 else label}.",
            }
        )

    return render_template(
        "interviews.html",
        dataset=dataset,
        sections=sections,
        manager_options=manager_options,
        selected_manager=selected_manager,
        qa_options=qa_options,
        selected_qa=selected_qa,
        consultant_options=consultant_options,
        selected_consultant=selected_consultant,
    )


def _resolve_pipeline_year():
    """Read/validate the ?year= query param against PIPELINE_INTAKE_YEARS,
    falling back to PIPELINE_INTAKE_YEAR for anything missing or invalid."""
    try:
        selected_year = int(request.args.get("year", PIPELINE_INTAKE_YEAR))
    except (TypeError, ValueError):
        selected_year = PIPELINE_INTAKE_YEAR
    if selected_year not in PIPELINE_INTAKE_YEARS:
        selected_year = PIPELINE_INTAKE_YEAR
    return selected_year


def _resolve_intake_bucket(selected_year):
    """Read/validate the ?intake= query param against INTAKE_BUCKET_KEYS -
    only meaningful when the selected year supports the Intake 01/02/03
    month sub-tabs (see intake_buckets_available_for_year); otherwise, or
    for anything missing/invalid, there's no sub-filter and the whole year
    is shown, same as before these sub-tabs existed."""
    if not intake_buckets_available_for_year(selected_year):
        return None
    bucket = request.args.get("intake")
    return bucket if bucket in INTAKE_BUCKET_KEYS else None


def _intake_bucket_template_context(selected_year, selected_intake_bucket):
    """Template kwargs shared by every page with the Intake 01/02/03 month
    sub-tabs, so each route only has to spread one dict rather than repeat
    these 4 keys."""
    return {
        "intake_buckets_available": intake_buckets_available_for_year(selected_year),
        "selected_intake_bucket": selected_intake_bucket,
        "intake_bucket_keys": INTAKE_BUCKET_KEYS,
        "intake_bucket_labels": INTAKE_BUCKET_LABELS,
    }


def _resolve_intake_month(rows, selected_year, selected_intake_bucket):
    """The Application Manager Pipeline page's third tab row, below the year and the
    Intake 01/02/03 tabs: the Intake months (1-12) present in the selected year /
    Intake tab, and the one the ?intake_month= query param picks (None for all of
    them - also for anything missing, invalid or not in this year / Intake tab)."""
    scoped = filter_by_intake_year(rows, selected_year)
    if selected_intake_bucket:
        scoped = filter_by_intake_bucket(scoped, selected_intake_bucket)
    available = list_intake_months(scoped)
    try:
        requested = int(request.args.get("intake_month", ""))
    except ValueError:
        requested = None
    return (requested if requested in available else None), available


def _intake_month_template_context(available, selected_month):
    return {
        "intake_month_options": [{"value": number, "label": calendar.month_name[number]} for number in available],
        "selected_intake_month": selected_month,
    }


def _build_pipeline_dashboard_context(
    rows, selected_year, forecast_percentages, selected_intake_bucket=None, group_as_other=None,
    include_source_report=False, reveal_hidden_consultants=False, keep_rows=False, selected_intake_month=None,
):
    """Build the Application Manager / Consultant / University Pipeline
    reports shared by the main Dashboard and any filtered copy of it (e.g.
    Just Jon) - keeps both pages' report-building logic identical.

    `rows` is unfiltered by Intake year (every year) - needed so
    drop_carried_forward_losses() below can look at LATER years than
    `selected_year` while resolving this year's reports. `selected_intake_bucket`
    (see intake_buckets_available_for_year/filter_by_intake_bucket) further
    narrows the selected year down to a 3-month Intake 01/02/03 window when
    set, and `selected_intake_month` (1-12) to a single Intake month - applied only to this year's own rows, not to the unfiltered
    `rows` drop_carried_forward_losses() looks at, since that cross-year
    carry-forward check is unrelated to which month within the year a row
    falls in.

    The Application Manager and Consultant Pipeline reports count each
    Student Code once, and drop a Lost record entirely if that student
    has a live application in a later Intake year (see
    resolve_pipeline_rows_by_student() and drop_carried_forward_losses()
    in pipeline.py) - University Pipeline deliberately keeps counting
    every row for `selected_year`, unaffected by either rule.

    `group_as_other` (from the Consultant Lookup table's own "Group as
    Other" checkbox, Admin page - see lookups.list_lookup_rows) is merged
    into the Consultant Pipeline's hidden_persons alongside the static
    HIDDEN_CONSULTANTS list: a flagged Consultant's volume still counts
    toward their Sales Office and Grand Totals, but they don't get their
    own row/bar - same convention as everyone else in HIDDEN_CONSULTANTS,
    just driven by the Lookup table instead of hard-coded."""
    pipeline_rows = filter_by_intake_year(rows, selected_year)
    if selected_intake_bucket:
        pipeline_rows = filter_by_intake_bucket(pipeline_rows, selected_intake_bucket)
    if selected_intake_month:
        pipeline_rows = filter_by_intake_months(pipeline_rows, [selected_intake_month])

    deduped_rows = resolve_pipeline_rows_by_student(pipeline_rows)
    deduped_rows = drop_carried_forward_losses(deduped_rows, rows, selected_year)

    am_report = build_pipeline_report(
        deduped_rows,
        forecast_percentages,
        person_field="Application",
        group_field="Office",
        excluded_persons=EXCLUDED_MANAGERS,
        group_priority=("EG", "UK"),
        keep_rows=keep_rows,
    )
    am_summary_cards = build_summary_cards(am_report)
    am_chart_groups = build_chart_groups(am_report)

    consultant_hidden_persons = HIDDEN_CONSULTANTS | {
        name.strip().lower() for name in (group_as_other or []) if name and name.strip()
    }
    if reveal_hidden_consultants:
        # The Consultants page is scoped to ONE chosen Consultant, so that
        # person must show up even if they are normally folded away on the
        # team-wide pages (HIDDEN_CONSULTANTS / "Group as Other").
        consultant_hidden_persons = set()
    consultant_report = build_pipeline_report(
        deduped_rows,
        forecast_percentages,
        person_field="Consultant",
        group_field="Sales Office",
        excluded_persons=None,
        hidden_persons=consultant_hidden_persons,
        group_priority=None,
        keep_rows=keep_rows,
    )
    consultant_summary_cards = build_summary_cards(consultant_report)
    consultant_chart_groups = build_chart_groups(consultant_report)

    university_report = build_pipeline_report(
        pipeline_rows,
        forecast_percentages,
        person_field="University Name",
        group_field=None,
        excluded_persons=None,
        hidden_persons=None,
        group_priority=None,
        blank_person_label="Unassigned",
        rank_by_total=True,
        keep_rows=keep_rows,
    )
    university_chart_groups = build_chart_groups(university_report)

    context_extra = {}
    if include_source_report:
        # Application pipeline by lead Source (Paid Ad, Agent, Student
        # Referral, ...): the same report shape as the others, ungrouped and
        # ranked by total. Built from the same one-row-per-student
        # `deduped_rows` as the Application Manager and Consultant reports,
        # so its Grand Total always agrees with theirs. Inbound Call, Website,
        # Social Media and Employee are shown together as "Inbound" (see
        # pipeline.CONSULTANT_PAGE_SOURCE_GROUPS); only this report is regrouped.
        # Its summary cards are only Paid Ads / Non Paid / Overall.
        source_report = build_pipeline_report(
            regroup_sources(deduped_rows),   # Inbound Call / Website / Social Media / Employee -> "Inbound"
            forecast_percentages,
            person_field="Source",
            group_field=None,
            excluded_persons=None,
            hidden_persons=None,
            group_priority=None,
            blank_person_label="Unassigned",
            rank_by_total=True,
        )
        context_extra = {
            "source_report": source_report,
            "source_summary_cards": build_paid_split_cards(deduped_rows, forecast_percentages),
            "source_chart_groups": build_chart_groups(source_report),
        }

    return {
        **context_extra,
        "stages": STAGES,
        "stage_colors": STAGE_COLORS,
        "am_report": am_report,
        "am_summary_cards": am_summary_cards,
        "am_chart_groups": am_chart_groups,
        "consultant_report": consultant_report,
        "consultant_summary_cards": consultant_summary_cards,
        "consultant_chart_groups": consultant_chart_groups,
        "university_chart_groups": university_chart_groups,
        "university_report": university_report,
        "today_display": today_uk().strftime("%d/%m/%Y"),
    }


def _bonus_view(rows):
    """The Bonus Eligibility charts for the "Submitted to uni in" month in the query
    string (see bonus.py for which applications are in scope): {"manager": the chart
    by Application Manager, "qa": the same applications by QA Officer}, the month
    options, the chosen month key (None for all months) - shared by the page, its
    download and the charts' click-through endpoint so they can never disagree."""
    today = today_uk()
    scoped = bonus_in_scope(rows)
    available = submitted_months(rows, today)
    requested = parse_month_key(request.args.get("sub_month"))
    selected = requested if requested in available else None
    if selected:
        scoped = [r for r in scoped if (submitted_date(r).year, submitted_date(r).month) == selected]
    charts = {"manager": build_bonus_chart(scoped, today), "qa": build_bonus_chart(scoped, today, person_field="QA")}
    return charts, build_month_options(available), (month_key(*selected) if selected else None)


@app.route("/dashboard")
@login_required
def dashboard():
    """Application Manager Pipeline - same year tabs and report logic as
    every other Pipeline page, plus a per-manager Pending Assessment/
    Offer/Enrolment/Enrolled This Intake/Lost breakdown (mirroring the
    Company Dashboard's own tiles) and each manager's Offer Days
    averages for the Pending Assessment/Pending Offer buckets."""
    with db_connection() as conn:
        dataset, rows = load_active_dataset(conn)
        forecast_percentages = get_forecast_percentages(conn)

    selected_year = _resolve_pipeline_year()
    selected_intake_bucket = _resolve_intake_bucket(selected_year)
    selected_intake_month, available_intake_months = _resolve_intake_month(rows, selected_year, selected_intake_bucket)

    context = _build_pipeline_dashboard_context(
        rows, selected_year, forecast_percentages, selected_intake_bucket, keep_rows=True, selected_intake_month=selected_intake_month
    )
    pending_stage_chart_groups = build_stage_group_chart_groups(
        context["am_report"], PIPELINE_HEALTH_STAGE_GROUPS, forecast_percentages
    )
    # Under the Pipeline Health chart: its Lost applications by Application Manager and main Lost Reason
    # (2027 intakes onwards), read off the same report so it agrees with the chart's Lost bar.
    loss_reason_chart = build_loss_reason_chart(lost_rows(context["am_report"])) if loss_reasons_in_scope(selected_year) else None

    # Offer Days averages (see offer_days.QUALIFYING_STATUSES - the same
    # 04-Onboarding/05-Assessment/06-Decision statuses as this chart's own
    # Pending Assessment/Pending Offer buckets), scoped to the same
    # year/Intake bucket tabs as everything else on this page.
    offer_days_year_rows = filter_by_intake_year(rows, selected_year)
    if selected_intake_bucket:
        offer_days_year_rows = filter_by_intake_bucket(offer_days_year_rows, selected_intake_bucket)
    if selected_intake_month:
        offer_days_year_rows = filter_by_intake_months(offer_days_year_rows, [selected_intake_month])
    offer_days_qualifying = list_qualifying_records(offer_days_year_rows, today_uk())
    manager_average_offer_days = build_manager_average_age_by_group(
        offer_days_qualifying,
        [g for g in PIPELINE_HEALTH_STAGE_GROUPS if g["key"] in ("pending_assessment", "pending_offer")],
    )

    return render_template(
        "dashboard.html",
        dataset=dataset,
        selected_year=selected_year,
        available_years=PIPELINE_INTAKE_YEARS,
        pending_stage_groups=PIPELINE_HEALTH_STAGE_GROUPS,
        pending_stage_chart_groups=pending_stage_chart_groups,
        loss_reason_chart=loss_reason_chart,
        manager_average_offer_days=manager_average_offer_days,
        **_intake_bucket_template_context(selected_year, selected_intake_bucket),
        **_intake_month_template_context(available_intake_months, selected_intake_month),
        **context,
    )


@app.route("/dashboard/records")
@login_required
def dashboard_records():
    """The applications inside one clickable piece of the Application Manager
    Pipeline chart - one manager's bar, one stage group (Pending Assessment,
    Pending Offer, ...) - as JSON for the page's pop-up window. The page's year
    / Intake tab comes in the query string. The list is read off the very report
    the chart is drawn from (build_pipeline_report(keep_rows=True)), so it holds
    exactly the applications that were counted - one row per student, a Lost
    record dropped when the student has a live application next year, and so on."""
    group_key = request.args.get("group", "")
    group = next((g for g in PIPELINE_HEALTH_STAGE_GROUPS if g["key"] == group_key), None)
    if group is None:
        response = jsonify(error="Unknown chart group.")
        response.status_code = 400
        return response

    with db_connection() as conn:
        dataset, rows = load_active_dataset(conn)
        forecast_percentages = get_forecast_percentages(conn)

    selected_year = _resolve_pipeline_year()
    selected_intake_bucket = _resolve_intake_bucket(selected_year)
    selected_intake_month, _ = _resolve_intake_month(rows, selected_year, selected_intake_bucket)
    context = _build_pipeline_dashboard_context(
        rows, selected_year, forecast_percentages, selected_intake_bucket, keep_rows=True, selected_intake_month=selected_intake_month
    )
    manager = request.args.get("manager", "")
    today = today_uk()
    waiting = group["key"] == "pending_assessment"
    records = application_records(
        report_group_rows(context["am_report"], manager, group["stages"]),
        extra=lambda row: days_since_submitted(row, today, waiting),
    )
    response = jsonify(manager=manager, group=group["label"], columns=DAYS_RECORD_COLUMNS, count=len(records), records=records)
    response.headers["Cache-Control"] = "no-store"
    return response


@app.route("/dashboard/loss-records")
@login_required
def dashboard_loss_records():
    """The applications inside one clickable piece of the Loss Reasons by Application Manager
    chart - one manager's bar, one main Lost Reason - as JSON for the page's pop-up
    window. The page's year / Intake tab comes in the query string and goes through
    the same report as the chart, so the list holds exactly the applications counted."""
    with db_connection() as conn:
        dataset, rows = load_active_dataset(conn)
        forecast_percentages = get_forecast_percentages(conn)

    selected_year = _resolve_pipeline_year()
    selected_intake_bucket = _resolve_intake_bucket(selected_year)
    selected_intake_month, _ = _resolve_intake_month(rows, selected_year, selected_intake_bucket)
    context = _build_pipeline_dashboard_context(
        rows, selected_year, forecast_percentages, selected_intake_bucket, keep_rows=True, selected_intake_month=selected_intake_month
    )
    manager = request.args.get("manager", "")
    reason = request.args.get("reason", "")
    records = loss_reason_records(lost_rows(context["am_report"]), manager, reason) if loss_reasons_in_scope(selected_year) else []
    response = jsonify(manager=manager, reason=reason, columns=LOSS_RECORD_COLUMNS, count=len(records), records=records)
    response.headers["Cache-Control"] = "no-store"
    return response


@app.route("/thirty-days")
@login_required
def thirty_days():
    """30 Days: the Bonus Eligibility chart (see bonus.py) - for every 2027 Intake
    application submitted to a university since 1 October 2026, whether the offer was
    accepted within 30 days of it - by Application Manager, with a "Submitted to uni
    in" month and year filter."""
    with db_connection() as conn:
        dataset, rows = load_active_dataset(conn)

    bonus_charts, bonus_month_options, selected_bonus_month = _bonus_view(rows)

    return render_template(
        "thirty_days.html",
        dataset=dataset,
        today_display=today_uk().strftime("%d/%m/%Y"),
        bonus_chart=bonus_charts["manager"],
        bonus_qa_chart=bonus_charts["qa"],
        bonus_month_options=bonus_month_options,
        selected_bonus_month=selected_bonus_month,
        bonus_statuses=BONUS_STATUSES,
        bonus_status_colors=BONUS_STATUS_COLORS,
    )


@app.route("/thirty-days/records")
@login_required
def thirty_days_records():
    """The applications inside one clickable piece of a Bonus Eligibility chart - one
    Application Manager's bar (or, with by=qa, one QA Officer's) and one status (Eligible,
    Open, Missed or Not Eligible) - as JSON for the page's pop-up window. The page's "Submitted to uni in" month comes in the query string
    and goes through the same scoping as the chart, so the list holds exactly the
    applications that were counted."""
    status_key = request.args.get("status", "")
    by = request.args.get("by", "manager")
    if status_key not in {bonus_status_slug(s) for s in BONUS_STATUSES} or by not in ("manager", "qa"):
        response = jsonify(error="Unknown chart piece.")
        response.status_code = 400
        return response

    with db_connection() as conn:
        _, rows = load_active_dataset(conn)

    charts, _, _ = _bonus_view(rows)
    chart = charts[by]
    manager = request.args.get("manager", "")
    records = bonus_records(chart, manager, status_key, today_uk())
    response = jsonify(manager=manager, status=status_key, noun="application", columns=BONUS_RECORD_COLUMNS, count=len(records), records=records)
    response.headers["Cache-Control"] = "no-store"
    return response


@app.route("/thirty-days/export")
@login_required
def thirty_days_export():
    """Excel download for the 30 Day Offers Accepted page - the Eligible applications the
    chart counts (for the "Submitted to uni in" month in the query string, or every
    month), sorted by Application Manager. See thirty_days_export.py."""
    with db_connection() as conn:
        dataset, rows = load_active_dataset(conn)

    if not dataset:
        flash("There is no active dataset to export yet.", "error")
        return redirect(url_for("thirty_days"))

    charts, _, selected_month = _bonus_view(rows)
    chart = charts["manager"]
    month_label = format_month_label(*parse_month_key(selected_month)) if selected_month else None
    return send_file(
        build_thirty_days_export(chart, today_uk(), month_label),
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name=thirty_days_export_filename(today_uk(), month_label),
    )


@app.route("/dashboard/export")
@login_required
def dashboard_export():
    """Excel download for the Apps page - the exact same deduplicated
    population its own chart/Number Breakdown table show (see
    dashboard()/_build_pipeline_dashboard_context), for whichever year/
    Intake bucket query params the page itself is currently on. One
    worksheet per Application Manager (see
    application_manager_export.build_application_manager_pipeline_export)."""
    with db_connection() as conn:
        dataset, rows = load_active_dataset(conn)

    if not dataset:
        flash("There is no active dataset to export yet.", "error")
        return redirect(url_for("dashboard"))

    selected_year = _resolve_pipeline_year()
    selected_intake_bucket = _resolve_intake_bucket(selected_year)
    selected_intake_month, _ = _resolve_intake_month(rows, selected_year, selected_intake_bucket)
    pipeline_rows = filter_by_intake_year(rows, selected_year)
    if selected_intake_bucket:
        pipeline_rows = filter_by_intake_bucket(pipeline_rows, selected_intake_bucket)
    if selected_intake_month:
        pipeline_rows = filter_by_intake_months(pipeline_rows, [selected_intake_month])
    deduped_rows = resolve_pipeline_rows_by_student(pipeline_rows)
    deduped_rows = drop_carried_forward_losses(deduped_rows, rows, selected_year)

    buffer = build_application_manager_pipeline_export(deduped_rows, today_uk())
    intake_bucket_label = INTAKE_BUCKET_LABELS.get(selected_intake_bucket) if selected_intake_bucket else None
    download_name = application_manager_export_filename(
        today_uk(), intake_year=selected_year, intake_bucket_label=intake_bucket_label,
        intake_month_label=calendar.month_name[selected_intake_month] if selected_intake_month else None,
    )

    return send_file(
        buffer,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name=download_name,
    )


def _university_pipeline_view(rows, forecast_percentages):
    """Everything the University Pipeline page shows, for the year / Intake
    tab / Application Manager / Intake Month in the query string - shared by
    the page and its Excel download so the two can never disagree.

    University Pipeline deliberately counts every row for the selected year
    (not deduplicated by student, and not dropping carried-forward losses) -
    same rule _build_pipeline_dashboard_context's own University Pipeline
    uses, since a student applying to the same University via more than one
    course is still real volume for that University."""
    selected_year = _resolve_pipeline_year()
    selected_intake_bucket = _resolve_intake_bucket(selected_year)
    pipeline_rows = filter_by_intake_year(rows, selected_year)
    if selected_intake_bucket:
        pipeline_rows = filter_by_intake_bucket(pipeline_rows, selected_intake_bucket)

    # The filters: their options are whatever this year / Intake tab
    # contains; anything else typed into the URL is ignored ("no filter").
    manager_options = list_application_managers(pipeline_rows)
    selected_manager = request.args.get("manager")
    if selected_manager not in manager_options:
        selected_manager = None
    office_options = list_sales_offices(pipeline_rows)
    selected_office = request.args.get("office")
    if selected_office not in office_options:
        selected_office = None
    consultant_options = list_consultants(pipeline_rows)
    selected_consultant = request.args.get("consultant")
    if selected_consultant not in consultant_options:
        selected_consultant = None
    status_options = list_statuses(pipeline_rows)
    requested_statuses = set(request.args.getlist("status"))
    selected_statuses = [status for status in status_options if status in requested_statuses]
    intake_month_numbers = list_intake_months(pipeline_rows)
    requested_months = set()
    for value in request.args.getlist("intake_month"):
        try:
            requested_months.add(int(value))
        except ValueError:
            pass
    selected_intake_months = sorted(requested_months & set(intake_month_numbers))
    if selected_manager:
        pipeline_rows = filter_by_person(pipeline_rows, "Application", selected_manager)
    if selected_office:
        pipeline_rows = filter_by_person(pipeline_rows, "Sales Office", selected_office)
    if selected_consultant:
        pipeline_rows = filter_by_person(pipeline_rows, "Consultant", selected_consultant)
    if selected_statuses:
        pipeline_rows = [row for row in pipeline_rows if (row.get("Status") or "").strip() in selected_statuses]
    if selected_intake_months:
        pipeline_rows = filter_by_intake_months(pipeline_rows, selected_intake_months)

    university_report = build_pipeline_report(
        pipeline_rows,
        forecast_percentages,
        person_field="University Name",
        group_field=None,
        excluded_persons=None,
        hidden_persons=None,
        group_priority=None,
        blank_person_label="Unassigned",
        rank_by_total=True,
    )
    university_summary_cards = [
        {
            "label": "Overall",
            "total": university_report["grand_total_records"],
            "forecast": university_report["grand_total_forecast"],
            "conversion": university_report["grand_total_conversion"],
        }
    ]
    pending_stage_chart_groups = build_stage_group_chart_groups(
        university_report, PIPELINE_HEALTH_STAGE_GROUPS, forecast_percentages
    )

    offer_days_qualifying = list_qualifying_records(pipeline_rows, today_uk())
    university_average_offer_days = build_university_average_age_by_group(
        offer_days_qualifying,
        [g for g in PIPELINE_HEALTH_STAGE_GROUPS if g["key"] in ("pending_assessment", "pending_offer")],
    )
    return {
        "selected_year": selected_year,
        "selected_intake_bucket": selected_intake_bucket,
        "pipeline_rows": pipeline_rows,
        "report": university_report,
        "manager_options": manager_options,
        "selected_manager": selected_manager,
        "office_options": office_options,
        "selected_office": selected_office,
        "consultant_options": consultant_options,
        "selected_consultant": selected_consultant,
        "status_options": status_options,
        "selected_statuses": selected_statuses,
        "intake_month_options": [
            {"value": number, "label": f"{calendar.month_name[number]} {selected_year}"} for number in intake_month_numbers
        ],
        "selected_intake_months": selected_intake_months,
        "university_summary_cards": university_summary_cards,
        "pending_stage_chart_groups": pending_stage_chart_groups,
        # False when no university has anything the chart draws (no rows at all, or only
        # applications at 02-PendingQA / 03-PendingSubmission, which it leaves out)
        "chart_has_data": any(row["total"] > 0 for group in pending_stage_chart_groups for row in group["rows"]),
        "university_average_offer_days": university_average_offer_days,
    }


@app.route("/university-pipeline")
@login_required
def university_pipeline():
    """University Pipeline - same year/Intake tabs and Pending Assessment/
    Offer/Enrolment/Enrolled This Intake/Lost chart style as the Apps
    page (see dashboard()), just grouped by University Name instead of
    Application Manager and ranked by total applications descending (the
    University with the most applications first) - matching
    pipeline.build_pipeline_report's own rank_by_total convention for
    University Pipeline everywhere else it appears (e.g.
    _build_pipeline_dashboard_context's university_chart_groups).

    Unlike Application Manager, there's no Office grouping for
    Universities, so this page gets a single "Overall" summary card
    instead of Apps' EG/UK/Overall three. Filterable by Application Manager
    and Intake Month (see _university_pipeline_view)."""
    with db_connection() as conn:
        dataset, rows = load_active_dataset(conn)
        forecast_percentages = get_forecast_percentages(conn)

    view = _university_pipeline_view(rows, forecast_percentages)
    return render_template(
        "university_pipeline.html",
        dataset=dataset,
        selected_year=view["selected_year"],
        available_years=PIPELINE_INTAKE_YEARS,
        pending_stage_groups=PIPELINE_HEALTH_STAGE_GROUPS,
        pending_stage_chart_groups=view["pending_stage_chart_groups"],
        chart_has_data=view["chart_has_data"],
        university_summary_cards=view["university_summary_cards"],
        manager_average_offer_days=view["university_average_offer_days"],
        manager_options=view["manager_options"],
        selected_manager=view["selected_manager"],
        office_options=view["office_options"],
        selected_office=view["selected_office"],
        consultant_options=view["consultant_options"],
        selected_consultant=view["selected_consultant"],
        status_options=view["status_options"],
        selected_statuses=view["selected_statuses"],
        stage_colors=STAGE_COLORS,
        intake_month_options=view["intake_month_options"],
        selected_intake_months=view["selected_intake_months"],
        today_display=today_uk().strftime("%d/%m/%Y"),
        **_intake_bucket_template_context(view["selected_year"], view["selected_intake_bucket"]),
    )


@app.route("/university-pipeline/export")
@login_required
def university_pipeline_export():
    """Excel download of the University Pipeline page exactly as filtered
    (year, Intake tab, Application Manager, Intake Month) - a Summary sheet
    of the chart's figures and an Applications sheet of the records behind
    them (see university_pipeline_export.py)."""
    with db_connection() as conn:
        dataset, rows = load_active_dataset(conn)
        forecast_percentages = get_forecast_percentages(conn)

    if not dataset:
        flash("There is no active dataset to export yet.", "error")
        return redirect(url_for("university_pipeline"))

    view = _university_pipeline_view(rows, forecast_percentages)
    year = view["selected_year"]
    bucket_label = INTAKE_BUCKET_LABELS.get(view["selected_intake_bucket"]) if view["selected_intake_bucket"] else None
    month_labels = [o["label"] for o in view["intake_month_options"] if o["value"] in view["selected_intake_months"]]
    card = view["university_summary_cards"][0]
    title = f"University Pipeline {year}" + (f" - {bucket_label}" if bucket_label else "")
    filter_lines = (
        f"Office: {view['selected_office'] or 'All'}  |  Application Manager: {view['selected_manager'] or 'All'}  |  Consultant: {view['selected_consultant'] or 'All'}  |  Status: {', '.join(view['selected_statuses']) or 'All'}"
        f"  |  Intake Month: {', '.join(month_labels) or 'All'}  |  Downloaded {today_uk().strftime('%d/%m/%Y')}"
    )
    overall_line = f"Overall: {card['total']:,} apps  |  Forecast {card['forecast']:,}  |  Conversion {card['conversion']}%"

    buffer = build_university_pipeline_export(
        view["pipeline_rows"],
        build_summary_rows(view["pending_stage_chart_groups"], view["report"], view["university_average_offer_days"]),
        title,
        filter_lines,
        overall_line,
    )
    return send_file(
        buffer,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name=university_pipeline_export_filename(
            today_uk(), year, bucket_label, view["selected_manager"], view["selected_statuses"], month_labels,
            consultant=view["selected_consultant"],
            office=view["selected_office"],
        ),
    )


@app.route("/incentives")
@login_required
def incentives():
    """Incentives: for each campaign in incentives.INCENTIVES on the chosen tab (?tab=, the
    first tab if it is missing or unknown - see INCENTIVE_TABS), the pipeline of its
    qualifying applications by Consultant (the University Pipeline's chart style,
    with the click-through window) and how close each Consultant is to the
    enrolment trigger."""
    with db_connection() as conn:
        dataset, rows = load_active_dataset(conn)
        forecast_percentages = get_forecast_percentages(conn)

    selected_tab = request.args.get("tab", "")
    if selected_tab not in dict(INCENTIVE_TABS):
        selected_tab = INCENTIVE_TABS[0][0]

    return render_template(
        "incentives.html",
        dataset=dataset,
        tabs=INCENTIVE_TABS,
        selected_tab=selected_tab,
        incentives=[build_incentive(rows, incentive, forecast_percentages) for incentive in INCENTIVES if incentive.tab == selected_tab],
        pending_stage_groups=PIPELINE_HEALTH_STAGE_GROUPS,
        list_column_labels=LIST_COLUMN_LABELS,
        today_display=today_uk().strftime("%d/%m/%Y"),
    )


@app.route("/incentives/records")
@login_required
def incentives_records():
    """The applications inside one clickable piece of an incentive's chart - one
    Consultant's bar, one stage group - as JSON for the page's pop-up window. Read
    off the very report the chart is drawn from, so the list always has exactly the
    number of applications the piece shows."""
    incentive = INCENTIVES_BY_KEY.get(request.args.get("incentive", ""))
    group_key = request.args.get("group", "")
    if incentive is None or not incentive.has_chart or not any(g["key"] == group_key for g in PIPELINE_HEALTH_STAGE_GROUPS):
        response = jsonify(error="Unknown chart piece.")
        response.status_code = 400
        return response

    with db_connection() as conn:
        _, rows = load_active_dataset(conn)
        forecast_percentages = get_forecast_percentages(conn)

    built = build_incentive(rows, incentive, forecast_percentages)
    consultant = request.args.get("consultant", "")
    records = incentive_records(built["report"], consultant, group_key)
    response = jsonify(incentive=incentive.key, consultant=consultant, group=group_key, count=len(records), records=records)
    response.headers["Cache-Control"] = "no-store"
    return response


@app.route("/university-pipeline/records")
@login_required
def university_pipeline_records():
    """The applications inside one clickable piece of the University Pipeline
    chart - one University's bar, one of its stage groups (Pending Assessment,
    Pending Offer, ...) - as JSON for the page's pop-up window. The page's own
    query string (year, Intake tab, Application Manager, Consultant, Status,
    Intake Month) is sent along with `university` and `group`, and goes
    through the very same filtering as the page itself (see
    _university_pipeline_view), so the list always has exactly as many
    records as the piece of chart that was clicked says."""
    group_key = request.args.get("group", "")
    group = next((g for g in PIPELINE_HEALTH_STAGE_GROUPS if g["key"] == group_key), None)
    if group is None:
        response = jsonify(error="Unknown chart group.")
        response.status_code = 400
        return response

    with db_connection() as conn:
        dataset, rows = load_active_dataset(conn)
        forecast_percentages = get_forecast_percentages(conn)

    view = _university_pipeline_view(rows, forecast_percentages)
    university = request.args.get("university", "")
    records = chart_segment_records(view["pipeline_rows"], university, group["stages"])
    response = jsonify(university=university, group=group["label"], count=len(records), records=records)
    response.headers["Cache-Control"] = "no-store"
    return response


def _just_jon_context(keep_rows=False, with_leads=False):
    """The Just Jon page's reports for the year / Intake tab in the query string
    (see just_jon() and just_jon_records()): (dataset, selected_year,
    selected_intake_bucket, context, leads). `leads` is None unless
    `with_leads`; then it is {"dataset", "rows", "office_by_consultant",
    "other_consultants"} - the Leads data and the Consultant lookup the
    Leads-by-Office chart needs, read on the same connection."""
    with db_connection() as conn:
        dataset, rows = load_active_dataset(conn)
        forecast_percentages = get_forecast_percentages(conn)
        sales_office_lookup_rows = list_lookup_rows(conn, "sales_office")
        leads = None
        if with_leads:
            leads_dataset, _, leads_rows = load_active_leads_dataset(conn)
            leads = {"dataset": leads_dataset, "rows": leads_rows}

    rows = filter_by_sub_source(rows, JUST_JON_SUB_SOURCES)

    selected_year = _resolve_pipeline_year()
    selected_intake_bucket = _resolve_intake_bucket(selected_year)
    group_as_other = {row["source_value"] for row in sales_office_lookup_rows if row["group_as_other"]}

    context = _build_pipeline_dashboard_context(
        rows, selected_year, forecast_percentages, selected_intake_bucket, group_as_other, keep_rows=keep_rows
    )
    if leads is not None:
        leads["office_by_consultant"], leads["other_consultants"] = _consultant_offices(sales_office_lookup_rows)
    return dataset, selected_year, selected_intake_bucket, context, leads


def _consultant_offices(sales_office_lookup_rows):
    """({consultant, lower case: Office}, {consultants set to "Group as Other"}) from the Consultant lookup table."""
    office_by_consultant = {
        (row["source_value"] or "").strip().lower(): row["mapped_value"] for row in sales_office_lookup_rows
    }
    other_consultants = {
        (row["source_value"] or "").strip().lower() for row in sales_office_lookup_rows if row["group_as_other"]
    }
    return office_by_consultant, other_consultants


def _just_jon_leads_scope(leads_rows):
    """(leads to chart, month options, selected month key) for the Just Jon
    Leads-by-Office chart: the Just Jon leads (see filter_just_jon_leads), all
    months unless ?lead_month=YYYY-MM names one of the months they were
    created in (anything else is ignored)."""
    just_jon_leads = filter_just_jon_leads(leads_rows)
    available_months = list_available_submission_months(just_jon_leads, date_field="Creation Date")
    requested = parse_month_key(request.args.get("lead_month"))
    selected = requested if requested in available_months else None
    scoped = filter_by_creation_month(just_jon_leads, *selected) if selected else just_jon_leads
    return scoped, build_month_options(available_months), (month_key(*selected) if selected else None)


@app.route("/dashboard/just-jon")
@login_required
def just_jon():
    """A copy of the Dashboard page scoped to only Just Jon Sub-Source
    records (see pipeline.JUST_JON_SUB_SOURCES for every spelling this
    covers) - same year tabs and report logic, just filtered to a
    narrower slice of `rows` before the reports are built."""
    dataset, selected_year, selected_intake_bucket, context, leads = _just_jon_context(with_leads=True)

    scoped_leads, lead_month_options, selected_lead_month = _just_jon_leads_scope(leads["rows"])
    return render_template(
        "dashboard_just_jon.html",
        dataset=dataset,
        selected_year=selected_year,
        available_years=PIPELINE_INTAKE_YEARS,
        leads_dataset=leads["dataset"],
        lead_month_options=lead_month_options,
        selected_lead_month=selected_lead_month,
        lead_report=build_allocation_report(scoped_leads, leads["office_by_consultant"], leads["other_consultants"]),
        lead_stages=LEAD_STAGE_ORDER,
        lead_stage_colors=LEAD_STAGE_COLORS,
        **_intake_bucket_template_context(selected_year, selected_intake_bucket),
        **context,
    )


# The three charts on the Just Jon page, by the name its click-through pieces send.
JUST_JON_RECORD_REPORTS = {"manager": "am_report", "consultant": "consultant_report", "university": "university_report"}


@app.route("/dashboard/just-jon/records")
@login_required
def just_jon_records():
    """The applications inside one clickable piece of a Just Jon chart - one
    Application Manager's / Consultant's / University's bar and one pipeline
    stage - as JSON for the page's pop-up window. The page's year / Intake tab
    comes along in the query string. The list is read straight off the report
    the chart was drawn from (build_pipeline_report(keep_rows=True)), so it is
    exactly the applications that were counted, de-duplication and all."""
    chart = request.args.get("chart", "")
    stage = request.args.get("stage", "")
    if chart not in JUST_JON_RECORD_REPORTS or stage not in STAGES:
        response = jsonify(error="Unknown chart piece.")
        response.status_code = 400
        return response

    _, _, _, context, _ = _just_jon_context(keep_rows=True)
    name = request.args.get("name", "")
    records = application_records(report_segment_rows(context[JUST_JON_RECORD_REPORTS[chart]], name, stage))
    response = jsonify(chart=chart, name=name, stage=stage, count=len(records), records=records)
    response.headers["Cache-Control"] = "no-store"
    return response


@app.route("/dashboard/just-jon/lead-records")
@login_required
def just_jon_lead_records():
    """The leads inside one clickable piece of the Just Jon Leads-by-Office chart -
    one Office / Consultant row and one lead stage - as JSON for the page's
    pop-up window. `lead_month` (if the chart is showing one month) comes along
    in the query string and goes through the same scoping as the page."""
    stage = request.args.get("stage", "")
    if stage not in LEAD_STAGE_ORDER + [UNASSIGNED_LEAD_STAGE]:
        response = jsonify(error="Unknown chart piece.")
        response.status_code = 400
        return response

    with db_connection() as conn:
        _, _, leads_rows = load_active_leads_dataset(conn)
        sales_office_lookup_rows = list_lookup_rows(conn, "sales_office")
    office_by_consultant, other_consultants = _consultant_offices(sales_office_lookup_rows)

    scoped_leads, _, _ = _just_jon_leads_scope(leads_rows)
    office, name = request.args.get("office", ""), request.args.get("name", "")
    records = lead_records(allocation_segment_rows(scoped_leads, office, name, stage, office_by_consultant, other_consultants))
    response = jsonify(office=office, name=name, stage=stage, noun="lead", columns=LEAD_RECORD_COLUMNS, count=len(records), records=records)
    response.headers["Cache-Control"] = "no-store"
    return response


@app.route("/dashboard/just-jon/leads-export")
@login_required
def just_jon_leads_export():
    """Excel download of the Just Jon Lead Allocates chart: the same leads the
    chart is drawn from (for the month picked above it), one print-ready
    worksheet per Consultant - see just_jon_leads_export.py."""
    with db_connection() as conn:
        dataset, _, leads_rows = load_active_leads_dataset(conn)

    if not dataset:
        flash("There is no active Leads dataset to export yet.", "error")
        return redirect(url_for("just_jon"))

    scoped_leads, month_options, selected_month = _just_jon_leads_scope(leads_rows)
    month_label = next((option["label"] for option in month_options if option["key"] == selected_month), None)
    buffer = build_just_jon_leads_export(scoped_leads, month_label or "All months", today_uk())
    return send_file(
        buffer,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name=just_jon_leads_export_filename(today_uk(), month_label),
    )


@app.route("/dashboard/just-jon/export")
@login_required
def just_jon_export():
    """Excel download for the Just Jon page - the exact same Just-Jon-
    filtered, deduplicated population its own chart/Number Breakdown
    table show (see just_jon()/_build_pipeline_dashboard_context), for
    whichever year/Intake bucket query params the page itself is
    currently on. One worksheet per Application Manager, sorted by
    pipeline stage (see just_jon_export.build_just_jon_export)."""
    with db_connection() as conn:
        dataset, rows = load_active_dataset(conn)

    if not dataset:
        flash("There is no active dataset to export yet.", "error")
        return redirect(url_for("just_jon"))

    rows = filter_by_sub_source(rows, JUST_JON_SUB_SOURCES)

    selected_year = _resolve_pipeline_year()
    selected_intake_bucket = _resolve_intake_bucket(selected_year)
    pipeline_rows = filter_by_intake_year(rows, selected_year)
    if selected_intake_bucket:
        pipeline_rows = filter_by_intake_bucket(pipeline_rows, selected_intake_bucket)
    deduped_rows = resolve_pipeline_rows_by_student(pipeline_rows)
    deduped_rows = drop_carried_forward_losses(deduped_rows, rows, selected_year)

    buffer = build_just_jon_export(deduped_rows)
    intake_bucket_label = INTAKE_BUCKET_LABELS.get(selected_intake_bucket) if selected_intake_bucket else None
    download_name = just_jon_export_filename(
        today_uk(), intake_year=selected_year, intake_bucket_label=intake_bucket_label
    )

    return send_file(
        buffer,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name=download_name,
    )


@app.route("/dashboard/faheem")
@login_required
def faheem():
    """Old bookmark for the former Faheem-only page: now the Consultants
    page with Faheem selected."""
    return redirect(url_for("consultants", consultant=FAHEEM_CONSULTANT))


def _manual_enrolled_adjustments_by_year(sales_office_lookup_rows):
    """The Consultant Lookup table's manual Intake 01/02 Enrolled backfill,
    keyed by Intake year in the shape build_consultant_enrolled_by_year()
    wants - the same figures the Enrolled page uses, which only exist for
    2026 (the pre-CRM-migration year)."""
    adjustments = []
    for row in sales_office_lookup_rows:
        intake_01 = row["intake_01_count"] or 0
        intake_02 = row["intake_02_count"] or 0
        if intake_01 or intake_02:
            adjustments.append(
                {"consultant": row["source_value"], "intake_01": intake_01, "intake_02": intake_02}
            )
    return {2026: adjustments}


def _consultants_context(keep_rows=False):
    """The Consultants page's data for the Consultant / year / Intake tab in the
    query string (see consultants() and consultants_records()): the page's own
    values and, when a Consultant is picked, "context" - the pipeline reports
    built from only that Consultant's rows."""
    with db_connection() as conn:
        dataset, rows = load_active_dataset(conn)
        forecast_percentages = get_forecast_percentages(conn)
        sales_office_lookup_rows = list_lookup_rows(conn, "sales_office")

    # Only Consultants whose "Group as Other" is No on the Admin page are
    # available for analysis; a Consultant with no lookup row yet counts as
    # No (the setting's default), so someone new does not vanish. A flagged
    # name typed into the URL is simply not recognised (picker only).
    group_as_other = {row["source_value"] for row in sales_office_lookup_rows if row["group_as_other"]}
    consultant_names = list_consultant_names(rows, exclude=group_as_other)
    selected_consultant = resolve_consultant_name(consultant_names, request.args.get("consultant"))
    selected_year = _resolve_pipeline_year()
    selected_intake_bucket = _resolve_intake_bucket(selected_year)

    context = {}
    enrolled_by_year = []
    if selected_consultant:
        consultant_rows = filter_by_consultant(rows, selected_consultant)
        context = _build_pipeline_dashboard_context(
            consultant_rows, selected_year, forecast_percentages, selected_intake_bucket, None,
            include_source_report=True, reveal_hidden_consultants=True, keep_rows=keep_rows,
        )
        enrolled_by_year = build_consultant_enrolled_by_year(
            rows, selected_consultant, PIPELINE_INTAKE_YEARS,
            _manual_enrolled_adjustments_by_year(sales_office_lookup_rows),
        )
    return {
        "dataset": dataset,
        "selected_year": selected_year,
        "selected_intake_bucket": selected_intake_bucket,
        "consultant_names": consultant_names,
        "selected_consultant": selected_consultant,
        "enrolled_by_year": enrolled_by_year,
        "context": context,
    }


@app.route("/consultants")
@login_required
def consultants():
    """Per-consultant report: pick a Consultant (?consultant=) and see their
    Enrolled figures for every Intake year, then - for the selected year and
    Intake tab - their Application Manager, Consultant, Source and
    University pipelines. The pipeline reports are the Dashboard's own,
    built from only that Consultant's rows (see _build_pipeline_dashboard_context).
    Consultants flagged "Group as Other" on the Admin page are not offered.
    With no (or an unknown) consultant picked, only the picker is shown.
    The Application Manager and University charts can be clicked (see
    consultants_records)."""
    page = _consultants_context()
    selected_year = page["selected_year"]
    return render_template(
        "dashboard_consultants.html",
        dataset=page["dataset"],
        selected_year=selected_year,
        available_years=PIPELINE_INTAKE_YEARS,
        consultant_names=page["consultant_names"],
        selected_consultant=page["selected_consultant"],
        enrolled_by_year=page["enrolled_by_year"],
        **_intake_bucket_template_context(selected_year, page["selected_intake_bucket"]),
        **page["context"],
    )


# The charts on the Consultants page that can be clicked, by the name their pieces send.
CONSULTANT_RECORD_REPORTS = {"manager": "am_report", "university": "university_report"}


@app.route("/consultants/records")
@login_required
def consultants_records():
    """The applications inside one clickable piece of a Consultants page chart -
    one Application Manager's / University's bar and one pipeline stage - as JSON
    for the page's pop-up window. The picked Consultant and the year / Intake tab
    come along in the query string. The list is read straight off the report the
    chart was drawn from (build_pipeline_report(keep_rows=True)), so it is exactly
    the applications that were counted. No (or an unrecognised) Consultant gives
    an empty list."""
    chart = request.args.get("chart", "")
    stage = request.args.get("stage", "")
    if chart not in CONSULTANT_RECORD_REPORTS or stage not in STAGES:
        response = jsonify(error="Unknown chart piece.")
        response.status_code = 400
        return response

    page = _consultants_context(keep_rows=True)
    name = request.args.get("name", "")
    report = page["context"].get(CONSULTANT_RECORD_REPORTS[chart])
    records = application_records(report_segment_rows(report, name, stage)) if report else []
    response = jsonify(chart=chart, name=name, stage=stage, count=len(records), records=records)
    response.headers["Cache-Control"] = "no-store"
    return response


@app.route("/enrolled")
@login_required
def enrolled():
    """Consultant Enrolled chart - live team members only (see
    build_consultant_enrolled_chart), split into 3 Intake segments. For
    2026, Intake 01/02 are each Consultant's manual pre-CRM-migration
    backfill total from the Consultant Lookup table (Admin page - the
    numbers that predate this app's own data), and Intake 03 is their live
    09-Enrolled count from the current CRM export (this app's data
    effectively starts at Intake 03 2026, since Intake 01/02 predate the
    migration). From 2027 onwards there's no migration to work around, so
    the same 3 segments instead come straight from each live row's own
    Intake month (see intake_buckets_available_for_year/
    build_consultant_enrolled_chart's use_month_buckets).

    The page's top summary cards show "Total" (Intake 01 + 02 + 03
    combined) alongside each Intake's own individual total, so the full
    year's figure and its breakdown are both visible at a glance. A
    Consultant with "Group as Other" checked in the Lookup table is left
    off the chart entirely, rather than shown under their own name or
    folded into a shared "Other" row - this page is scoped to live team
    members only for now (the Application Manager Pipeline panel is also
    parked for now - see build_stage_subset_chart_groups for the still-
    available building block if it comes back)."""
    with db_connection() as conn:
        dataset, rows = load_active_dataset(conn)
        sales_office_lookup_rows = list_lookup_rows(conn, "sales_office")
        forecast_percentages = get_forecast_percentages(conn)

    selected_year = _resolve_pipeline_year()
    selected_intake_bucket = _resolve_intake_bucket(selected_year)
    pipeline_rows = filter_by_intake_year(rows, selected_year)
    use_month_buckets = intake_buckets_available_for_year(selected_year)

    # Consultant Pipeline (every stage, not just Enrolled) - moved here from
    # the Dashboard page so Consultant-focused reporting lives in one place;
    # shares that page's report-building logic exactly (see
    # _build_pipeline_dashboard_context), just rendered with a different
    # page-specific chart title/heading. Unlike the Enrolled chart above,
    # this section is scoped by the Intake 01/02/03 sub-tabs when the
    # selected year supports them (2027 onwards).
    group_as_other = {row["source_value"] for row in sales_office_lookup_rows if row["group_as_other"]}

    dashboard_context = _build_pipeline_dashboard_context(
        rows, selected_year, forecast_percentages, selected_intake_bucket, group_as_other
    )

    manual_adjustments = []
    if selected_year == 2026:
        for row in sales_office_lookup_rows:
            intake_01 = row["intake_01_count"] or 0
            intake_02 = row["intake_02_count"] or 0
            if intake_01 or intake_02:
                manual_adjustments.append(
                    {
                        "consultant": row["source_value"],
                        "sales_office": row["mapped_value"],
                        "intake_01": intake_01,
                        "intake_02": intake_02,
                    }
                )

    consultant_chart_rows = build_consultant_enrolled_chart(
        pipeline_rows, manual_adjustments, group_as_other, use_month_buckets=use_month_buckets
    )
    consultant_chart_scale_markers = build_chart_scale_markers(consultant_chart_rows)

    enrolled_rows = [row for row in pipeline_rows if (row.get("Status") or "").strip() == "09-Enrolled"]
    if use_month_buckets:
        intake_01_total = len(filter_by_intake_bucket(enrolled_rows, "intake_01"))
        intake_02_total = len(filter_by_intake_bucket(enrolled_rows, "intake_02"))
        intake_03_total = len(filter_by_intake_bucket(enrolled_rows, "intake_03"))
    else:
        intake_01_total = sum(a["intake_01"] for a in manual_adjustments)
        intake_02_total = sum(a["intake_02"] for a in manual_adjustments)
        intake_03_total = len(enrolled_rows)
    combined_enrolled_total = intake_01_total + intake_02_total + intake_03_total
    summary_cards = [
        {
            "label": "Total",
            "description": "Enrolled Intake 01, 02 and 03",
            "total": combined_enrolled_total,
        },
        {"label": "Intake 01", "description": "Manual backfill", "total": intake_01_total},
        {"label": "Intake 02", "description": "Manual backfill", "total": intake_02_total},
        {"label": "Intake 03", "description": "Live CRM", "total": intake_03_total},
    ]

    return render_template(
        "enrolled.html",
        dataset=dataset,
        selected_year=selected_year,
        available_years=PIPELINE_INTAKE_YEARS,
        summary_cards=summary_cards,
        consultant_chart_rows=consultant_chart_rows,
        consultant_chart_scale_markers=consultant_chart_scale_markers,
        intake_colors=ENROLLED_INTAKE_COLORS,
        intake_labels=ENROLLED_INTAKE_LABELS,
        **_intake_bucket_template_context(selected_year, selected_intake_bucket),
        **dashboard_context,
    )


@app.route("/enrolled/export/intake-03")
@login_required
def enrolled_export_intake_03():
    """Excel download for the Enrolled page's Intake 03 summary card - the
    exact same population that number counts (see enrolled()): this
    Intake year's live 09-Enrolled rows, narrowed to the Intake 03 month
    window (Jul-Dec) once month buckets apply (2027 onwards - see
    intake_buckets_available_for_year). One worksheet per University Name
    (see enrolled_export.build_enrolled_export).

    Intake 01/02 aren't exportable this way: for 2026 (the only year they
    currently have any figures), they're a manually-entered aggregate
    count from the Consultant Lookup table with no underlying student
    rows to list."""
    with db_connection() as conn:
        dataset, rows = load_active_dataset(conn)

    if not dataset:
        flash("There is no active dataset to export yet.", "error")
        return redirect(url_for("enrolled"))

    selected_year = _resolve_pipeline_year()
    pipeline_rows = filter_by_intake_year(rows, selected_year)
    enrolled_rows = [row for row in pipeline_rows if (row.get("Status") or "").strip() == "09-Enrolled"]
    if intake_buckets_available_for_year(selected_year):
        enrolled_rows = filter_by_intake_bucket(enrolled_rows, "intake_03")

    buffer = build_enrolled_export(enrolled_rows)
    download_name = enrolled_export_filename(today_uk(), intake_year=selected_year)

    return send_file(
        buffer,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name=download_name,
    )


@app.route("/enrolled/export/current-intake")
@login_required
def enrolled_export_current_intake():
    """Excel download - every 09-Enrolled record for the current Intake
    (July-December 2026, "Intake 03" - see enrolled_intake_export.py's
    module docstring), as a single flat sheet with a wider column set
    than the Enrolled page's own per-University Intake 03 download
    (enrolled_export_intake_03() above) - a separate report for a
    different audience, not a replacement for that one."""
    with db_connection() as conn:
        dataset, rows = load_active_dataset(conn)

    if not dataset:
        flash("There is no active dataset to export yet.", "error")
        return redirect(url_for("admin"))

    intake_year = PIPELINE_INTAKE_YEAR
    pipeline_rows = filter_by_intake_year(rows, intake_year)
    pipeline_rows = filter_by_intake_bucket(pipeline_rows, "intake_03")
    enrolled_rows = [row for row in pipeline_rows if (row.get("Status") or "").strip() == "09-Enrolled"]

    buffer = build_enrolled_current_intake_export(enrolled_rows)
    download_name = enrolled_current_intake_export_filename(today_uk(), intake_year=intake_year)

    return send_file(
        buffer,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name=download_name,
    )


@app.route("/university-report")
@login_required
def university_report():
    """One University's pipeline broken down by stage - built for sharing
    with the university itself (e.g. a partner meeting), so it deliberately
    shows only stage counts for the one selected University Name rather
    than the full Application Manager/Consultant breakdown."""
    with db_connection() as conn:
        dataset, rows = load_active_dataset(conn)
        forecast_percentages = get_forecast_percentages(conn)

    selected_year = _resolve_pipeline_year()
    selected_intake_bucket = _resolve_intake_bucket(selected_year)
    pipeline_rows = filter_by_intake_year(rows, selected_year)
    if selected_intake_bucket:
        pipeline_rows = filter_by_intake_bucket(pipeline_rows, selected_intake_bucket)

    report = build_pipeline_report(
        pipeline_rows,
        forecast_percentages,
        person_field="University Name",
        group_field=None,
        excluded_persons=None,
        hidden_persons=None,
        group_priority=None,
        blank_person_label="Unassigned",
        rank_by_total=True,
    )
    universities = report["office_groups"][0]["managers"] if report["office_groups"] else []
    available_universities = [u["name"] for u in universities]

    raw_university = request.args.get("university")
    university_is_all = raw_university == "__all__"
    if university_is_all:
        selected_university = None
    elif raw_university in available_universities:
        selected_university = raw_university
    else:
        selected_university = available_universities[0] if available_universities else None
    university_query_value = "__all__" if university_is_all else selected_university

    university_rows = (
        pipeline_rows
        if university_is_all
        else (filter_by_person(pipeline_rows, "University Name", selected_university) if selected_university else [])
    )

    available_courses = sorted(
        {(row.get("Course Name") or "").strip() for row in university_rows if (row.get("Course Name") or "").strip()},
        key=str.lower,
    )

    selected_course = request.args.get("course") or None
    if selected_course not in available_courses:
        selected_course = None

    course_rows = university_rows
    if selected_course:
        course_rows = [row for row in course_rows if (row.get("Course Name") or "").strip() == selected_course]

    selected_data = None
    stage_segments = []
    if university_rows:
        counts, total = count_by_stage(course_rows)
        selected_data = {"counts": counts, "total": total}
        stage_segments = build_stage_breakdown(counts, total)

    return render_template(
        "university_report.html",
        dataset=dataset,
        selected_year=selected_year,
        available_years=PIPELINE_INTAKE_YEARS,
        available_universities=available_universities,
        selected_university=selected_university,
        university_is_all=university_is_all,
        university_query_value=university_query_value,
        available_courses=available_courses,
        selected_course=selected_course,
        selected_data=selected_data,
        stage_segments=stage_segments,
        stages=STAGES,
        stage_colors=STAGE_COLORS,
        **_intake_bucket_template_context(selected_year, selected_intake_bucket),
    )


@app.route("/kpi")
@login_required
def kpi():
    with db_connection() as conn:
        dataset, rows = load_active_dataset(conn)

    available_months = list_available_months(rows)

    requested = parse_month_key(request.args.get("month"))
    selected = requested if requested in available_months else None
    if selected is None:
        selected = available_months[0] if available_months else None

    report = None
    selected_key = None
    selected_label = None
    oxford_matrix = None
    progress_chart = None

    if selected:
        year, month = selected
        selected_key = month_key(year, month)
        selected_label = format_month_label(year, month)

        with db_connection() as conn:
            targets = get_kpi_targets(conn, year, month)

        sales_office_targets = {
            k: v for k, v in targets.items() if k not in (COMPANY_TARGET_TYPE, CONSULTANT_TARGET_TYPE)
        }
        company_target = targets.get(COMPANY_TARGET_TYPE)
        consultant_target = targets.get(CONSULTANT_TARGET_TYPE)
        report = build_kpi_report(rows, year, month, sales_office_targets, company_target, consultant_target)
        oxford_matrix = build_oxford_kpi_matrix(rows, year, month)
        progress_chart = build_kpi_progress_chart(rows, year, month, sales_office_targets, today_uk())

    month_options = build_month_options(available_months)

    # Live backlog snapshot, independent of the selected month/Intake year
    # - see PIPELINE_BACKLOG_BOXES in kpi.py for why.
    backlog_summary = build_pipeline_backlog_summary(rows)

    return render_template(
        "kpi.html",
        dataset=dataset,
        month_options=month_options,
        selected_key=selected_key,
        selected_label=selected_label,
        report=report,
        consultant_status_remaining_color=CONSULTANT_STATUS_REMAINING_COLOR,
        backlog_summary=backlog_summary,
        oxford_matrix=oxford_matrix,
        progress_chart=progress_chart,
    )


@app.route("/offer-days")
@login_required
def offer_days():
    with db_connection() as conn:
        dataset, rows = load_active_dataset(conn)

    selected_year = _resolve_pipeline_year()
    selected_intake_bucket = _resolve_intake_bucket(selected_year)
    year_rows = filter_by_intake_year(rows, selected_year)
    if selected_intake_bucket:
        year_rows = filter_by_intake_bucket(year_rows, selected_intake_bucket)

    report = build_offer_days_report(year_rows, today_uk())

    return render_template(
        "offer_days.html",
        dataset=dataset,
        report=report,
        buckets=BUCKETS,
        bucket_colors=BUCKET_COLORS,
        bucket_export_slugs=BUCKET_EXPORT_SLUGS,
        total_export_slug=TOTAL_EXPORT_SLUG,
        selected_year=selected_year,
        available_years=PIPELINE_INTAKE_YEARS,
        **_intake_bucket_template_context(selected_year, selected_intake_bucket),
    )


@app.route("/offer-days/export/<bucket_slug>")
@login_required
def offer_days_export(bucket_slug):
    bucket_label, display_label = resolve_export_bucket(bucket_slug)
    if display_label is None:
        flash("Unknown Offer Days export.", "error")
        return redirect(url_for("offer_days"))

    with db_connection() as conn:
        dataset, rows = load_active_dataset(conn)

    if not dataset:
        flash("There is no active dataset to export yet.", "error")
        return redirect(url_for("offer_days"))

    selected_year = _resolve_pipeline_year()
    selected_intake_bucket = _resolve_intake_bucket(selected_year)
    year_rows = filter_by_intake_year(rows, selected_year)
    if selected_intake_bucket:
        year_rows = filter_by_intake_bucket(year_rows, selected_intake_bucket)

    today = today_uk()
    qualifying = list_qualifying_records(year_rows, today)

    if bucket_label is None:
        # Total download: one worksheet per Application Manager, grouped
        # from this same qualifying-records list.
        buffer = build_offer_days_total_export(qualifying)
    else:
        bucket_records = [rec for rec in qualifying if rec["bucket"] == bucket_label]
        buffer = build_offer_days_export(bucket_records, sheet_title=display_label)

    download_name = export_filename(
        bucket_slug,
        today,
        intake_year=selected_year,
        intake_bucket_label=INTAKE_BUCKET_LABELS.get(selected_intake_bucket),
    )

    return send_file(
        buffer,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name=download_name,
    )


@app.route("/lost-reasons")
@login_required
def lost_reasons():
    with db_connection() as conn:
        dataset, rows = load_active_dataset(conn)

    selected_year = _resolve_pipeline_year()
    selected_intake_bucket = _resolve_intake_bucket(selected_year)
    year_rows = filter_by_intake_year(rows, selected_year)
    if selected_intake_bucket:
        year_rows = filter_by_intake_bucket(year_rows, selected_intake_bucket)

    # Dropdown options are scoped to this year's Lost applications only,
    # so neither filter ever offers a person with zero matches.
    available_consultants = list_distinct_values(year_rows, CONSULTANT_FIELD)
    available_managers = list_distinct_values(year_rows, APPLICATION_MANAGER_FIELD)

    selected_consultant = request.args.get("consultant") or None
    selected_manager = request.args.get("manager") or None

    filtered_rows = year_rows
    if selected_consultant:
        filtered_rows = filter_by_field(filtered_rows, CONSULTANT_FIELD, selected_consultant)
    if selected_manager:
        filtered_rows = filter_by_field(filtered_rows, APPLICATION_MANAGER_FIELD, selected_manager)

    report = build_lost_reason_report(filtered_rows)

    return render_template(
        "lost_reasons.html",
        dataset=dataset,
        report=report,
        selected_year=selected_year,
        available_years=PIPELINE_INTAKE_YEARS,
        available_consultants=available_consultants,
        available_managers=available_managers,
        selected_consultant=selected_consultant,
        selected_manager=selected_manager,
        **_intake_bucket_template_context(selected_year, selected_intake_bucket),
    )


def _build_daily_matrix_context(rows, date_field, person_field, requested_month_key):
    """Shared by /submissions and /doc-check - both pages are the same
    daily person-by-date matrix (via submissions.build_daily_matrix),
    just grouped by a different date field and person field. Returns the
    template context common to both; each route adds its own page-specific
    extras (e.g. Submissions' Pending Submission/Hold cards) on top."""
    available_months = list_available_submission_months(rows, date_field=date_field)

    requested = parse_month_key(requested_month_key)
    selected = requested if requested in available_months else None
    if selected is None:
        selected = available_months[0] if available_months else None

    selected_key = None
    selected_label = None
    grand_total = None
    support_people = []
    day_rows = []
    support_totals = []
    max_cell = 0
    person_rows = []

    if selected:
        year, month = selected
        selected_key = month_key(year, month)
        selected_label = format_month_label(year, month)

        matrix = build_daily_matrix(rows, year, month, date_field=date_field, person_field=person_field)
        grand_total = matrix["grand_total"]
        support_people = matrix["support_people"]
        day_rows = matrix["day_rows"]
        support_totals = matrix["support_totals"]
        max_cell = matrix["max_cell"]
        person_rows = matrix["person_rows"]

    return {
        "month_options": build_month_options(available_months),
        "selected_key": selected_key,
        "selected_label": selected_label,
        "grand_total": grand_total,
        "support_people": support_people,
        "day_rows": day_rows,
        "support_totals": support_totals,
        "max_cell": max_cell,
        "person_rows": person_rows,
    }


@app.route("/submissions")
@login_required
def submissions():
    with db_connection() as conn:
        dataset, rows = load_active_dataset(conn)

    context = _build_daily_matrix_context(rows, "Submitted To Uni", "Support", request.args.get("month"))
    submitted_this_month = context.pop("grand_total")

    return render_template(
        "submissions.html",
        dataset=dataset,
        pending_submission=count_pending_submission(rows),
        hold=count_hold(rows),
        submitted_this_month=submitted_this_month,
        **context,
    )


@app.route("/doc-check")
@login_required
def doc_check():
    with db_connection() as conn:
        dataset, rows = load_active_dataset(conn)

    context = _build_daily_matrix_context(rows, "Docs Approved", "QA", request.args.get("month"))
    docs_approved_this_month = context.pop("grand_total")

    return render_template(
        "doc_check.html",
        dataset=dataset,
        docs_approved_this_month=docs_approved_this_month,
        **context,
    )


@app.route("/download")
@login_required
def download():
    # Read-only: builds the workbook in memory and returns it. Nothing is
    # written anywhere.
    buffer = _build_applications_export()

    if buffer is None:
        flash("There is no active dataset to download yet.", "error")
        return redirect(url_for("admin"))

    return send_file(
        buffer,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name=APPLICATIONS_EXPORT_FILENAME,
    )


@app.route("/upload", methods=["POST"])
@login_required
def upload():
    file = request.files.get("excel_file")

    if not file or file.filename == "":
        flash("No file selected.", "error")
        return redirect(url_for("admin"))

    filename = secure_filename(file.filename)
    ext = Path(filename).suffix.lower()

    if ext not in ALLOWED_EXTENSIONS:
        flash("Only .xlsx files are accepted.", "error")
        return redirect(url_for("admin"))

    timestamp = datetime.utcnow().strftime("%Y%m%d%H%M%S")
    stored_filename = f"{timestamp}_{filename}"
    stored_path = UPLOAD_FOLDER / stored_filename
    file.save(stored_path)

    now_iso = datetime.utcnow().isoformat(timespec="seconds")
    try:
        with db_connection() as conn:
            rows, unmapped_count = process_workbook(stored_path, conn, now_iso)
            save_active_dataset(conn, filename, stored_filename, now_iso, rows, UPLOAD_FOLDER)
    except ProcessingError as exc:
        flash(f"Upload failed: {exc}", "error")
        return redirect(url_for("admin"))
    except Exception:
        logger.exception("Upload failed due to an unexpected error.")
        flash("Upload failed due to an unexpected error. Please try again or contact support.", "error")
        return redirect(url_for("admin"))

    flash(
        f"Upload succeeded. {len(rows)} rows processed, {unmapped_count} unmapped lookup value(s) found.",
        "success",
    )
    return redirect(url_for("admin"))


@app.route("/leads/download")
@login_required
def leads_download():
    # Read-only - see download().
    buffer = _build_leads_export()

    if buffer is None:
        flash("There is no active Leads dataset to download yet.", "error")
        return redirect(url_for("admin"))

    return send_file(
        buffer,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name=LEADS_EXPORT_FILENAME,
    )


@app.route("/leads/upload", methods=["POST"])
@login_required
def leads_upload():
    file = request.files.get("excel_file")

    if not file or file.filename == "":
        flash("No file selected.", "error")
        return redirect(url_for("admin"))

    filename = secure_filename(file.filename)
    ext = Path(filename).suffix.lower()

    if ext not in ALLOWED_EXTENSIONS:
        flash("Only .xlsx files are accepted.", "error")
        return redirect(url_for("admin"))

    timestamp = datetime.utcnow().strftime("%Y%m%d%H%M%S")
    stored_filename = f"leads_{timestamp}_{filename}"
    stored_path = UPLOAD_FOLDER / stored_filename
    file.save(stored_path)

    now_iso = datetime.utcnow().isoformat(timespec="seconds")
    try:
        with db_connection() as conn:
            columns, rows = process_leads_workbook(stored_path)
            save_active_leads_dataset(conn, filename, stored_filename, now_iso, columns, rows, UPLOAD_FOLDER)
    except LeadsProcessingError as exc:
        flash(f"Upload failed: {exc}", "error")
        return redirect(url_for("admin"))
    except Exception:
        logger.exception("Leads upload failed due to an unexpected error.")
        flash("Upload failed due to an unexpected error. Please try again or contact support.", "error")
        return redirect(url_for("admin"))

    flash(
        f"Upload succeeded. {len(rows)} row(s) processed, {len(columns)} column(s) found.",
        "success",
    )
    return redirect(url_for("admin"))


def _enrolled_student_codes(application_rows):
    """Student Codes of the Applications data's 09-Enrolled rows."""
    codes = {
        (row.get("Student Code") or "").strip()
        for row in application_rows
        if (row.get("Status") or "").strip() == "09-Enrolled"
    }
    codes.discard("")
    return codes


@app.route("/leads-dashboard")
@login_required
def leads_dashboard():
    with db_connection() as conn:
        dataset, columns, rows = load_active_leads_dataset(conn)
        _, application_rows = load_active_dataset(conn)
        sales_office_lookup_rows = list_lookup_rows(conn, "sales_office")

    # Consultant filter: the Consultants named in the Leads data, except any
    # set to "Group as Other" on the Admin page (the same rule as the
    # Consultants page). Anything else typed into the URL means "everyone".
    group_as_other = {row["source_value"] for row in sales_office_lookup_rows if row["group_as_other"]}
    consultant_names = list_consultant_names(rows, exclude=group_as_other)
    selected_consultant = resolve_consultant_name(consultant_names, request.args.get("consultant"))

    # Students the Applications data shows as Enrolled: a lead with one of
    # these PES Codes counts as enrolled even if its CRM stage was never moved.
    enrolled_student_codes = _enrolled_student_codes(application_rows)

    available_months = list_available_submission_months(rows, date_field="Creation Date")

    requested = parse_month_key(request.args.get("month"))
    selected = requested if requested in available_months else None
    if selected is None:
        selected = available_months[0] if available_months else None

    report = None
    source_summary_rows = []
    month_summary = None
    selected_key = None
    selected_label = None

    if selected:
        year, month = selected
        selected_key = month_key(year, month)
        selected_label = format_month_label(year, month)
        month_rows = filter_by_creation_month(rows, year, month)
        if selected_consultant:
            month_rows = filter_by_consultant(month_rows, selected_consultant)
        report = build_lead_source_report(month_rows)
        source_summary_rows = build_lead_source_summary(report)
        month_summary = build_month_summary(month_rows, enrolled_student_codes)

    month_options = build_month_options(available_months)

    return render_template(
        "leads_dashboard.html",
        consultant_names=consultant_names,
        selected_consultant=selected_consultant,
        dataset=dataset,
        month_options=month_options,
        selected_key=selected_key,
        selected_label=selected_label,
        source_summary_rows=source_summary_rows,
        month_summary=month_summary,
        report=report,
        stages=LEAD_STAGE_ORDER,
        stage_colors=LEAD_STAGE_COLORS,
    )


@app.route("/paid-ads")
@login_required
def paid_ads():
    """Paid Ad leads, spend and cost per lead / application / enrolled, by
    month (see paid_ads.py for exactly how each figure is counted)."""
    with db_connection() as conn:
        dataset, application_rows = load_active_dataset(conn)
        leads_dataset, _, leads_rows = load_active_leads_dataset(conn)
        spend_rows = list_paid_ad_spend(conn)
        settings = get_paid_ad_settings(conn)
        sales_office_lookup_rows = list_lookup_rows(conn, "sales_office")

    report = build_paid_ads_report(leads_rows, application_rows, spend_rows, settings, today_uk())
    office_by_consultant, other_consultants = _consultant_offices(sales_office_lookup_rows)
    # The newest month's days stop where the Leads data does: the day it was uploaded.
    as_of = today_uk()
    uploaded = safe_date((leads_dataset["uploaded_at"] or "")[:10]) if leads_dataset else None
    if uploaded:
        as_of = min(as_of, uploaded)
    office_report = build_paid_leads_by_office(leads_rows, office_by_consultant, other_consultants, as_of)
    return render_template(
        "paid_ads.html",
        dataset=dataset,
        leads_dataset=leads_dataset,
        report=report,
        office_report=office_report,
        settings=settings,
        month_label=lambda row: format_month_label(row["year"], row["month"]),
    )


@app.route("/allocation")
@login_required
def allocation():
    """Where each month's leads sit: the Leads by Lead Source chart's style,
    grouped by Office with a row per Consultant - first for Paid Ad leads
    only, then for Inbound (Inbound Call) leads only, then for Just Jon leads
    (by Sub Source, whatever the Lead Source). A Consultant's Office is their Sales Office
    on the Admin page's Consultant lookup table; Consultants set to "Group as
    Other" there are added together in one "Other" row per Office."""
    with db_connection() as conn:
        dataset, columns, rows = load_active_leads_dataset(conn)
        sales_office_lookup_rows = list_lookup_rows(conn, "sales_office")

    office_by_consultant = {
        (row["source_value"] or "").strip().lower(): row["mapped_value"] for row in sales_office_lookup_rows
    }
    other_consultants = {
        (row["source_value"] or "").strip().lower() for row in sales_office_lookup_rows if row["group_as_other"]
    }

    available_months = list_available_submission_months(rows, date_field="Creation Date")
    requested = parse_month_key(request.args.get("month"))
    selected = requested if requested in available_months else None
    if selected is None:
        selected = available_months[0] if available_months else None

    selected_key = selected_label = None
    month_rows = []
    if selected:
        year, month = selected
        selected_key = month_key(year, month)
        selected_label = format_month_label(year, month)
        month_rows = filter_by_creation_month(rows, year, month)

    return render_template(
        "allocation.html",
        dataset=dataset,
        month_options=build_month_options(available_months),
        selected_key=selected_key,
        selected_label=selected_label,
        paid_report=build_allocation_report(filter_paid_ad_leads(month_rows), office_by_consultant, other_consultants),
        inbound_report=build_allocation_report(filter_inbound_call_leads(month_rows), office_by_consultant, other_consultants),
        just_jon_report=build_allocation_report(filter_just_jon_leads(month_rows), office_by_consultant, other_consultants),
        stages=LEAD_STAGE_ORDER,
        stage_colors=LEAD_STAGE_COLORS,
    )


@app.route("/ninety-days")
@login_required
def ninety_days():
    """Leads that were created 90 or more days ago (any month, any Stage),
    in the Allocation page's chart: grouped by Office with a row per
    Consultant, so you can see where the old leads sit and how far they got."""
    with db_connection() as conn:
        dataset, columns, rows = load_active_leads_dataset(conn)
        sales_office_lookup_rows = list_lookup_rows(conn, "sales_office")

    office_by_consultant = {
        (row["source_value"] or "").strip().lower(): row["mapped_value"] for row in sales_office_lookup_rows
    }
    other_consultants = {
        (row["source_value"] or "").strip().lower() for row in sales_office_lookup_rows if row["group_as_other"]
    }

    today = today_uk()
    old_rows = filter_by_min_age_days(rows, today)
    return render_template(
        "ninety_days.html",
        dataset=dataset,
        cutoff_label=(today - timedelta(days=MIN_AGE_DAYS)).strftime("%d/%m/%Y"),
        report=build_allocation_report(old_rows, office_by_consultant, other_consultants),
        stages=LEAD_STAGE_ORDER,
        stage_colors=LEAD_STAGE_COLORS,
    )


@app.route("/split")
@login_required
def split():
    """Paid Leads vs Non Paid, by Office and Consultant (laid out like the
    Allocation page): leads allocated, then how many are Applications, then
    how many are Enrolled - each split Paid / Non Paid / Total. The month's
    leads are counted by Creation Date and Applications/Enrolled are those
    same leads' outcomes, so the figures tie to the Leads Dashboard cards."""
    with db_connection() as conn:
        dataset, columns, rows = load_active_leads_dataset(conn)
        _, application_rows = load_active_dataset(conn)
        sales_office_lookup_rows = list_lookup_rows(conn, "sales_office")

    office_by_consultant = {
        (row["source_value"] or "").strip().lower(): row["mapped_value"] for row in sales_office_lookup_rows
    }
    other_consultants = {
        (row["source_value"] or "").strip().lower() for row in sales_office_lookup_rows if row["group_as_other"]
    }

    available_months = list_available_submission_months(rows, date_field="Creation Date")
    requested = parse_month_key(request.args.get("month"))
    selected = requested if requested in available_months else None
    if selected is None:
        selected = available_months[0] if available_months else None

    selected_key = selected_label = None
    month_rows = []
    if selected:
        year, month = selected
        selected_key = month_key(year, month)
        selected_label = format_month_label(year, month)
        month_rows = filter_by_creation_month(rows, year, month)

    return render_template(
        "split.html",
        dataset=dataset,
        month_options=build_month_options(available_months),
        selected_key=selected_key,
        selected_label=selected_label,
        report=build_split_report(
            month_rows, office_by_consultant, other_consultants, _enrolled_student_codes(application_rows)
        ),
    )


# Display labels for the reserved (non-Sales-Office) KPI target types -
# shared between the Admin editor's row list and the Save flash message so
# the two can never show different names for the same target_type.
KPI_TARGET_TYPE_LABELS = {
    CONSULTANT_TARGET_TYPE: "Consultant Target (all consultants)",
    COMPANY_TARGET_TYPE: "Company Total",
}


@app.route("/admin")
@login_required
def admin():
    with db_connection() as conn:
        lookup_data = {
            table_name: list_lookup_rows(conn, table_name) for table_name in LOOKUP_TABLE_INFO
        }
        forecast_settings = list_forecast_settings(conn)
        paid_ad_spend = list_paid_ad_spend(conn)
        paid_ad_settings = get_paid_ad_settings(conn)
        access_grid = build_grid(load_access(conn))

        dataset, rows = load_active_dataset(conn)
        leads_dataset, _, _ = load_active_leads_dataset(conn)
        kpi_available_months = list_available_months(rows)

        kpi_targets_editor = None
        if kpi_available_months:
            requested_kpi = parse_month_key(request.args.get("kpi_month"))
            selected_kpi = requested_kpi if requested_kpi in kpi_available_months else kpi_available_months[0]
            year, month = selected_kpi

            relevant_offices = list_sales_offices_for_month(rows, year, month)
            stored_targets = get_kpi_targets(conn, year, month)

            # One shared row list (rather than offices + a hand-duplicated
            # Company Total block, now also a hand-duplicated Consultant
            # Target block) - every row_editor row shares the same
            # label/value/Edit form markup, driven from this single loop.
            kpi_targets_editor = {
                "month_key": month_key(year, month),
                "rows": (
                    [
                        {"target_type": office, "label": office, "value": stored_targets.get(office), "bold": False}
                        for office in relevant_offices
                    ]
                    + [
                        {
                            "target_type": target_type,
                            "label": label,
                            "value": stored_targets.get(target_type),
                            "bold": True,
                        }
                        for target_type, label in KPI_TARGET_TYPE_LABELS.items()
                    ]
                ),
            }


    active_tab = request.args.get("tab", "status")
    if active_tab not in LOOKUP_TABLE_INFO:
        active_tab = "status"

    kpi_month_options = build_month_options(kpi_available_months)

    today = today_uk()
    paid_ad_rows = [
        {
            **row,
            "budget_override_pence": row["budget_pence"],      # None = uses the global monthly budget
            "label": format_month_label(int(row["month_key"][:4]), int(row["month_key"][5:7])),
            **forecast_paid_ad_month(row, today, paid_ad_settings["monthly_budget_pence"]),
            "in_progress": (today.year, today.month) == (int(row["month_key"][:4]), int(row["month_key"][5:7])),
        }
        for row in paid_ad_spend
    ]

    return render_template(
        "admin.html",
        access_grid=access_grid,
        access_role_labels=ROLE_COLUMN_LABELS,
        paid_ad_rows=paid_ad_rows,
        paid_ad_settings=paid_ad_settings,
        paid_ad_default_month=month_key(today.year, today.month),
        dataset=dataset,
        leads_dataset=leads_dataset,
        lookup_table_info=LOOKUP_TABLE_INFO,
        lookup_data=lookup_data,
        active_tab=active_tab,
        forecast_settings=forecast_settings,
        kpi_month_options=kpi_month_options,
        kpi_targets_editor=kpi_targets_editor,
    )


@app.route("/admin/kpi-targets/<target_type>", methods=["POST"])
@login_required
def update_kpi_target_route(target_type):
    month_key_value = request.form.get("month_key", "")
    raw_value = request.form.get("target_value", "")

    parsed = parse_month_key(month_key_value)
    # A year too large for SQLite to store is simply not a valid month (the
    # form's month_key is a hidden field, so it can be tampered with).
    if not parsed or not fits_sqlite_integer(parsed[0]):
        flash("Invalid month.", "error")
        return redirect(url_for("admin"))
    year, month = parsed

    try:
        with db_connection() as conn:
            set_kpi_target(conn, year, month, target_type, raw_value)
    except KpiTargetValidationError as exc:
        flash(str(exc), "error")
        return redirect(url_for("admin", kpi_month=month_key_value) + "#kpi-targets")

    label = KPI_TARGET_TYPE_LABELS.get(target_type, target_type)
    flash(f"Target for {label} saved.", "success")
    return redirect(url_for("admin", kpi_month=month_key_value) + "#kpi-targets")


@app.route("/admin/paid-ads/spend", methods=["POST"])
@login_required
def save_paid_ad_spend_route():
    try:
        with db_connection() as conn:
            saved_month = save_paid_ad_spend(
                conn,
                request.form.get("month_key", ""),
                request.form.get("amount", ""),
                request.form.get("status", ""),
                request.form.get("budget", ""),
                datetime.utcnow().isoformat(timespec="seconds"),
            )
    except PaidAdValidationError as exc:
        flash(str(exc), "error")
        return redirect(url_for("admin") + "#paid-ad-spend")
    flash(f"Paid Ad spend for {saved_month} saved.", "success")
    return redirect(url_for("admin") + "#paid-ad-spend")


@app.route("/admin/paid-ads/spend/<month_key_value>/delete", methods=["POST"])
@login_required
def delete_paid_ad_spend_route(month_key_value):
    try:
        with db_connection() as conn:
            deleted_month = delete_paid_ad_spend(conn, month_key_value)
    except PaidAdValidationError as exc:
        flash(str(exc), "error")
        return redirect(url_for("admin") + "#paid-ad-spend")
    flash(f"Paid Ad spend for {deleted_month} removed.", "success")
    return redirect(url_for("admin") + "#paid-ad-spend")


@app.route("/admin/paid-ads/settings", methods=["POST"])
@login_required
def save_paid_ad_settings_route():
    try:
        with db_connection() as conn:
            save_paid_ad_settings(
                conn, request.form.get("monthly_budget", ""), request.form.get("revenue_per_enrolled", "")
            )
    except PaidAdValidationError as exc:
        flash(str(exc), "error")
        return redirect(url_for("admin") + "#paid-ad-spend")
    flash("Paid Ad budget and average earning saved.", "success")
    return redirect(url_for("admin") + "#paid-ad-spend")


@app.route("/admin/forecast-settings/<stage>", methods=["POST"])
@login_required
def update_forecast_setting_route(stage):
    raw_value = request.form.get("forecast_percent", "")
    try:
        with db_connection() as conn:
            update_forecast_setting(conn, stage, raw_value)
    except ForecastValidationError as exc:
        flash(str(exc), "error")
        return redirect(url_for("admin"))

    flash(f"Forecast % for {stage} updated.", "success")
    return redirect(url_for("admin"))


@app.route("/admin/lookups/<table_name>/add", methods=["POST"])
@login_required
def add_lookup_route(table_name):
    if table_name not in LOOKUP_TABLE_INFO:
        flash("Unknown lookup table.", "error")
        return redirect(url_for("admin"))

    source_value = request.form.get("source_value", "")
    mapped_value = request.form.get("mapped_value", "")
    intake_01_count = request.form.get("intake_01_count", "")
    intake_02_count = request.form.get("intake_02_count", "")
    group_as_other = request.form.get("group_as_other") == "on"
    now_iso = datetime.utcnow().isoformat(timespec="seconds")

    try:
        with db_connection() as conn:
            add_lookup(
                conn, table_name, source_value, mapped_value, now_iso,
                intake_01_count, intake_02_count, group_as_other,
            )
    except (DuplicateLookupError, LookupValidationError) as exc:
        flash(str(exc), "error")
        return redirect(url_for("admin", tab=table_name))

    flash("Mapping added.", "success")
    return redirect(url_for("admin", tab=table_name))


@app.route("/admin/lookups/<table_name>/<int:lookup_id>/edit", methods=["POST"])
@login_required
def edit_lookup_route(table_name, lookup_id):
    if table_name not in LOOKUP_TABLE_INFO:
        flash("Unknown lookup table.", "error")
        return redirect(url_for("admin"))

    source_value = request.form.get("source_value", "")
    mapped_value = request.form.get("mapped_value", "")
    intake_01_count = request.form.get("intake_01_count", "")
    intake_02_count = request.form.get("intake_02_count", "")
    group_as_other = request.form.get("group_as_other") == "on"

    try:
        with db_connection() as conn:
            update_lookup(
                conn, lookup_id, table_name, source_value, mapped_value,
                intake_01_count, intake_02_count, group_as_other,
            )
    except (DuplicateLookupError, LookupValidationError) as exc:
        flash(str(exc), "error")
        return redirect(url_for("admin", tab=table_name))

    flash("Mapping updated.", "success")
    return redirect(url_for("admin", tab=table_name))


@app.route("/admin/lookups/<table_name>/<int:lookup_id>/delete", methods=["POST"])
@login_required
def delete_lookup_route(table_name, lookup_id):
    with db_connection() as conn:
        delete_lookup(conn, lookup_id, table_name)

    flash("Mapping deleted.", "success")
    return redirect(url_for("admin", tab=table_name))


@app.route("/admin/reprocess", methods=["POST"])
@login_required
def reprocess():
    with db_connection() as conn:
        dataset = get_active_dataset_row(conn)

        if not dataset:
            flash("There is no active dataset to reprocess yet. Upload a workbook first.", "error")
            return redirect(url_for("admin"))

        stored_path = UPLOAD_FOLDER / dataset["stored_filename"]
        if not stored_path.exists():
            flash(
                "The original uploaded workbook could not be found on disk, so it cannot be reprocessed.",
                "error",
            )
            return redirect(url_for("admin"))

        now_iso = datetime.utcnow().isoformat(timespec="seconds")
        try:
            rows, unmapped_count = process_workbook(stored_path, conn, now_iso)
            save_active_dataset(
                conn, dataset["original_filename"], dataset["stored_filename"], now_iso, rows, UPLOAD_FOLDER
            )
        except ProcessingError as exc:
            flash(f"Reprocessing failed: {exc}", "error")
            return redirect(url_for("admin"))
        except Exception:
            logger.exception("Reprocessing failed due to an unexpected error.")
            flash("Reprocessing failed due to an unexpected error. Please try again or contact support.", "error")
            return redirect(url_for("admin"))

    flash(
        f"Reprocessing succeeded. {len(rows)} rows processed, {unmapped_count} unmapped lookup value(s) found.",
        "success",
    )
    return redirect(url_for("admin"))


@app.route("/admin/access", methods=["POST"])
@login_required
def save_role_access_route():
    """Save the Admin page's access grid (see role_access.py). A box that is
    ticked is a switch that is ON; Full Access cannot be changed."""
    with db_connection() as conn:
        save_access(conn, set(request.form.keys()), datetime.utcnow().isoformat(timespec="seconds"))
        reload_role_access(conn)
    logger.info("Access grid saved from the Admin page.")
    flash("Access settings saved.", "success")
    return redirect(url_for("admin") + "#access-settings")


@app.route("/admin/access/reset", methods=["POST"])
@login_required
def reset_role_access_route():
    """Put every access switch back to its default."""
    with db_connection() as conn:
        reset_access(conn, datetime.utcnow().isoformat(timespec="seconds"))
        reload_role_access(conn)
    logger.info("Access grid reset to the defaults from the Admin page.")
    flash("Access settings reset to the defaults.", "success")
    return redirect(url_for("admin") + "#access-settings")


@app.route("/admin/restore", methods=["GET", "POST"])
@login_required
def admin_restore():
    """One-time data restore (see data_restore.py). 404 unless
    ENABLE_DATA_RESTORE=1; Full Access only via authorization.py."""
    if not restore_enabled():
        abort(404)
    if request.method == "GET":
        return render_template("restore.html")
    # Bundles are bigger than ordinary workbook uploads.
    request.max_content_length = MAX_BUNDLE_BYTES
    bundle = request.files.get("bundle")
    if not bundle or not bundle.filename:
        flash("Choose a bundle file to restore.", "error")
        return redirect(url_for("admin_restore"))
    try:
        restored = restore_bundle(bundle.stream, db_module.DB_PATH, UPLOAD_FOLDER)
    except RestoreError as exc:
        flash(str(exc), "error")
        return redirect(url_for("admin_restore"))
    except Exception:
        logger.exception("Data restore failed.")
        flash("The restore failed. Nothing was changed.", "error")
        return redirect(url_for("admin_restore"))
    init_db()
    flash(f"Data restored: database plus {restored} workbook(s).", "success")
    return redirect(url_for("admin"))


if __name__ == "__main__":
    app.run(
        debug=os.environ.get("FLASK_DEBUG") == "1",
        port=int(os.environ.get("PORT", 5050)),
    )
