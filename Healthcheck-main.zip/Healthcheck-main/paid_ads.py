"""Paid Ad spend: the Admin figures (monthly spend, budget, average revenue per
enrolled student) and the Paid Ads page's cost figures.

MONEY is held as whole pence (integers) everywhere in here so nothing is ever
rounded by floating point; templates show it with the `gbp` filter.

THE PAID ADS PAGE'S COUNTS, per calendar month:
- Paid leads: Leads-export rows whose Lead Source is "Paid Ad", by Creation
  Date month.
- Applications / Enrolled: PAID AD students from the Applications data, one
  per Student Code, placed in the month their application was CREATED (the
  earliest Created date of that student's Paid Ad rows). A student counts as
  an application if at least one of their rows is a real, submitted
  application (a status outside pipeline.EXCLUDED_PIPELINE_STATUSES - so not
  QA-rejected, New App, Pending QA or Deferred), and as enrolled if any row
  is 09-Enrolled. A recent month therefore keeps rising as its applications
  mature.
- Cost per lead / application / enrolled = that month's spend divided by the
  count (None when the count is zero or no spend has been entered).
"""

import re
from calendar import monthrange
from datetime import date, timedelta
from decimal import Decimal, InvalidOperation

from dateutils import safe_date
from db import (
    PAID_AD_MONTHLY_BUDGET_KEY,
    PAID_AD_REVENUE_PER_ENROLLED_KEY,
    PAID_AD_SETTING_DEFAULTS,
)
from leads_dashboard import UNASSIGNED_LABEL, allocation_office
from pipeline import EXCLUDED_PIPELINE_STATUSES, OFFICE_FILTER_ORDER

PAID_AD_SOURCE = "Paid Ad"
ENROLLED_STATUS = "09-Enrolled"

MAX_MONEY_PENCE = 1_000_000_000_00   # GBP 1,000,000,000.00 - far above any real figure, far below SQLite's limit
MIN_YEAR, MAX_YEAR = 2000, 2100

_MONTH_KEY = re.compile(r"([0-9]{4})-([0-9]{2})")      # ASCII digits only (\d would also match e.g. Arabic-Indic digits)
_MONEY = re.compile(r"[0-9]+(\.[0-9]{1,2})?")


class PaidAdValidationError(Exception):
    """A user-fixable problem with a submitted figure; the message is shown
    to the user as-is, so it is never built from a caught exception's text."""


# --------------------------------------------------------------- parsing
def parse_money_pence(text, label):
    """'£14,308.02' / '1430.8' / '16000' -> whole pence. Rejects blanks,
    negatives, more than 2 decimal places, anything non-numeric (including
    nan/inf/exponents) and absurdly large values."""
    cleaned = (text or "").strip().replace("£", "").replace(",", "").replace(" ", "")
    if not cleaned:
        raise PaidAdValidationError(f"{label} is required.")
    if not _MONEY.fullmatch(cleaned):
        raise PaidAdValidationError(f"{label} must be an amount in pounds, like 1234.56.")
    try:
        pence = int((Decimal(cleaned) * 100).to_integral_value())
    except InvalidOperation:
        raise PaidAdValidationError(f"{label} must be an amount in pounds, like 1234.56.") from None
    if pence > MAX_MONEY_PENCE:
        raise PaidAdValidationError(f"{label} is too large.")
    return pence


def validate_month_key(text):
    """'2026-08' -> '2026-08'; anything else raises. The year is bounded."""
    match = _MONTH_KEY.fullmatch((text or "").strip())
    if not match:
        raise PaidAdValidationError("Choose a valid month.")
    year, month = int(match.group(1)), int(match.group(2))
    if not (1 <= month <= 12) or not (MIN_YEAR <= year <= MAX_YEAR):
        raise PaidAdValidationError("Choose a valid month.")
    return f"{year:04d}-{month:02d}"


def format_gbp(pence):
    """12345 -> '£123.45'; None -> a dash. Whole pounds keep their pence."""
    if pence is None:
        return "-"
    sign = "-" if pence < 0 else ""
    pounds, remainder = divmod(abs(pence), 100)
    return f"{sign}£{pounds:,}.{remainder:02d}"


# --------------------------------------------------------------- storage
def get_settings(conn):
    """{"monthly_budget_pence", "revenue_per_enrolled_pence"} - the stored
    values, or the defaults for any that are missing."""
    stored = {row["setting_key"]: row["value_pence"] for row in conn.execute("SELECT setting_key, value_pence FROM paid_ad_settings")}
    return {
        "monthly_budget_pence": stored.get(PAID_AD_MONTHLY_BUDGET_KEY, PAID_AD_SETTING_DEFAULTS[PAID_AD_MONTHLY_BUDGET_KEY]),
        "revenue_per_enrolled_pence": stored.get(
            PAID_AD_REVENUE_PER_ENROLLED_KEY, PAID_AD_SETTING_DEFAULTS[PAID_AD_REVENUE_PER_ENROLLED_KEY]
        ),
    }


def save_settings(conn, monthly_budget_text, revenue_per_enrolled_text):
    """Validate both, then store both (nothing is written if either is bad)."""
    budget = parse_money_pence(monthly_budget_text, "Monthly budget")
    revenue = parse_money_pence(revenue_per_enrolled_text, "Average earning per enrolled student")
    for key, value in ((PAID_AD_MONTHLY_BUDGET_KEY, budget), (PAID_AD_REVENUE_PER_ENROLLED_KEY, revenue)):
        conn.execute(
            "INSERT INTO paid_ad_settings (setting_key, value_pence) VALUES (?, ?) "
            "ON CONFLICT(setting_key) DO UPDATE SET value_pence = excluded.value_pence",
            (key, value),
        )
    conn.commit()


def list_spend(conn):
    """Every stored month, oldest first: [{"month_key", "amount_pence",
    "is_final" (bool), "budget_pence" (or None)}, ...]."""
    return [
        {
            "month_key": row["month_key"],
            "amount_pence": row["amount_pence"],
            "is_final": bool(row["is_final"]),
            "budget_pence": row["budget_pence"],
        }
        for row in conn.execute(
            "SELECT month_key, amount_pence, is_final, budget_pence FROM paid_ad_spend ORDER BY month_key"
        )
    ]


def save_spend(conn, month_key, amount_text, status, budget_text, now_iso):
    """Add or replace one month. `status` is "final" or "mtd"; `budget_text`
    may be blank (use the global budget)."""
    month_key = validate_month_key(month_key)
    amount = parse_money_pence(amount_text, "Spend")
    if status not in ("final", "mtd"):
        raise PaidAdValidationError("Choose Final or Month to date.")
    budget = parse_money_pence(budget_text, "Budget") if (budget_text or "").strip() else None
    conn.execute(
        "INSERT INTO paid_ad_spend (month_key, amount_pence, is_final, budget_pence, updated_at) "
        "VALUES (?, ?, ?, ?, ?) "
        "ON CONFLICT(month_key) DO UPDATE SET amount_pence = excluded.amount_pence, "
        "is_final = excluded.is_final, budget_pence = excluded.budget_pence, updated_at = excluded.updated_at",
        (month_key, amount, 1 if status == "final" else 0, budget, now_iso),
    )
    conn.commit()
    return month_key


def delete_spend(conn, month_key):
    month_key = validate_month_key(month_key)
    conn.execute("DELETE FROM paid_ad_spend WHERE month_key = ?", (month_key,))
    conn.commit()
    return month_key


# ------------------------------------------------------------- forecasting
def month_progress(month_key, today):
    """(days_elapsed, days_in_month) for `month_key` as of `today`: the day of
    the month so far for the current month, the whole month for a past one,
    and None for a month that has not started."""
    year, month = int(month_key[:4]), int(month_key[5:7])
    days_in_month = monthrange(year, month)[1]
    if (today.year, today.month) == (year, month):
        return today.day, days_in_month
    if (today.year, today.month) > (year, month):
        return days_in_month, days_in_month
    return None


def forecast_month(spend_row, today, global_budget_pence):
    """Spend forecast for one stored month.

    A FINAL month's forecast is simply its spend. A month-to-date month in
    progress is run-rated: spend so far / days gone x days in the month. A
    month-to-date row for a month that has already ended is taken as
    complete; one for a month that has not started has no forecast.
    Returns {"forecast_pence", "budget_pence", "variance_pence"} where
    variance is forecast minus budget (positive = over budget)."""
    budget = spend_row["budget_pence"] if spend_row["budget_pence"] is not None else global_budget_pence
    amount = spend_row["amount_pence"]
    if spend_row["is_final"]:
        forecast = amount
    else:
        progress = month_progress(spend_row["month_key"], today)
        if progress is None:
            forecast = None
        else:
            elapsed, days_in_month = progress
            forecast = (amount * days_in_month + elapsed // 2) // elapsed
    variance = None if forecast is None else forecast - budget
    return {"forecast_pence": forecast, "budget_pence": budget, "variance_pence": variance}


# ----------------------------------------------------------------- report
def _divide(pence, count):
    """pence / count, rounded to the nearest penny (halves up); None when
    there is no spend figure or nothing to divide by."""
    if pence is None or not count:
        return None
    return (pence * 2 + count) // (count * 2)


def _paid(source):
    return (source or "").strip().lower() == PAID_AD_SOURCE.lower()


def count_paid_leads_by_month(leads_rows):
    counts = {}
    for row in leads_rows:
        if not _paid(row.get("Lead Source")):
            continue
        created = safe_date(row.get("Creation Date"))
        if created:
            key = f"{created.year:04d}-{created.month:02d}"
            counts[key] = counts.get(key, 0) + 1
    return counts


def build_paid_leads_by_office(leads_rows, office_by_consultant, other_consultants, as_of):
    """Paid Ad leads (Lead Source "Paid Ad", by Creation Date) counted in the Sales
    Office of the Consultant each was allocated to - the Paid Ads page's by-office
    table. Returns {"offices", "months", "totals"}:

    - offices: the column headings - LON, CAR, MAN, OXF always (in that order),
      then any other office a lead sits under ("Other" for a Consultant not on
      the Consultant lookup yet), then "Unassigned" if some lead has no Consultant.
    - months: newest first, each {"month_key", "year", "month", "total",
      "counts": {office: n}, "days": [...]}. days are newest first, every calendar
      day of the month (up to today for the month in progress) as {"date",
      "total", "counts"} - a day with no Paid Ad leads is there with zeros.
      The newest month stops at `as_of` (the day the Leads data runs to - the
      upload date), so days nobody has uploaded yet are not shown as zeros;
      every older month has all its days.
    - totals: {"total", "counts"} over every month.
    Every row's total is the sum of its office counts, a month's counts are the sum
    of its days', and the grand total the sum of the months'."""
    by_day = {}
    present = set()
    for row in leads_rows:
        if not _paid(row.get("Lead Source")):
            continue
        created = safe_date(row.get("Creation Date"))
        if not created:
            continue
        office = allocation_office(row, office_by_consultant, other_consultants)
        present.add(office)
        counts = by_day.setdefault(created, {})
        counts[office] = counts.get(office, 0) + 1

    known = list(OFFICE_FILTER_ORDER)
    others = sorted((o for o in present if o not in known and o != UNASSIGNED_LABEL), key=str.lower)
    offices = known + others + ([UNASSIGNED_LABEL] if UNASSIGNED_LABEL in present else [])

    def empty():
        return {office: 0 for office in offices}

    months = {}
    for day in by_day:
        months.setdefault((day.year, day.month), []).append(day)

    result_months = []
    grand = empty()
    ordered_months = sorted(months, reverse=True)
    for (year, month) in ordered_months:
        month_start = date(year, month, 1)
        month_end = date(year, month, monthrange(year, month)[1])
        last = month_end
        if (year, month) == ordered_months[0]:
            last = min(month_end, max(as_of, max(months[(year, month)])))
        days = []
        month_counts = empty()
        day = last
        while day >= month_start:
            counts = empty()
            for office, n in by_day.get(day, {}).items():
                counts[office] = n
                month_counts[office] += n
                grand[office] += n
            days.append({"date": day, "total": sum(counts.values()), "counts": counts})
            day -= timedelta(days=1)
        result_months.append({
            "month_key": f"{year:04d}-{month:02d}",
            "year": year,
            "month": month,
            "total": sum(month_counts.values()),
            "counts": month_counts,
            "days": days,
        })
    return {"offices": offices, "months": result_months, "totals": {"total": sum(grand.values()), "counts": grand}}


def count_paid_applications_by_month(application_rows):
    """({month_key: applications}, {month_key: enrolled}) - see the module
    docstring for exactly how a Paid Ad student is counted and dated."""
    students = {}
    for row in application_rows:
        if not _paid(row.get("Source")):
            continue
        code = (row.get("Student Code") or "").strip()
        if not code:
            continue
        status = (row.get("Status") or "").strip()
        entry = students.setdefault(code, {"created": None, "live": False, "enrolled": False})
        created = safe_date(row.get("Created"))
        if created and (entry["created"] is None or created < entry["created"]):
            entry["created"] = created
        if status not in EXCLUDED_PIPELINE_STATUSES:
            entry["live"] = True
        if status == ENROLLED_STATUS:
            entry["enrolled"] = True
    applications, enrolled = {}, {}
    for entry in students.values():
        if entry["created"] is None or not entry["live"]:
            continue
        key = f"{entry['created'].year:04d}-{entry['created'].month:02d}"
        applications[key] = applications.get(key, 0) + 1
        if entry["enrolled"]:
            enrolled[key] = enrolled.get(key, 0) + 1
    return applications, enrolled


def build_paid_ads_report(leads_rows, application_rows, spend_rows, settings, today):
    """The Paid Ads page: one row per month (oldest first) that has either a
    spend figure or Paid Ad leads, a totals row over the months WITH spend,
    and a `live` entry per month-to-date month in progress with its forecast.
    """
    revenue_per_enrolled = settings["revenue_per_enrolled_pence"]
    leads_by_month = count_paid_leads_by_month(leads_rows)
    applications_by_month, enrolled_by_month = count_paid_applications_by_month(application_rows)
    spend_by_month = {row["month_key"]: row for row in spend_rows}

    months = sorted(set(spend_by_month) | set(leads_by_month))
    rows = []
    for key in months:
        spend_row = spend_by_month.get(key)
        spend = spend_row["amount_pence"] if spend_row else None
        leads = leads_by_month.get(key, 0)
        applications = applications_by_month.get(key, 0)
        enrolled = enrolled_by_month.get(key, 0)
        revenue = enrolled * revenue_per_enrolled
        rows.append({
            "month_key": key,
            "year": int(key[:4]),
            "month": int(key[5:7]),
            "paid_leads": leads,
            "applications": applications,
            "enrolled": enrolled,
            "spend_pence": spend,
            "is_final": spend_row["is_final"] if spend_row else None,
            "cost_per_lead_pence": _divide(spend, leads),
            "cost_per_application_pence": _divide(spend, applications),
            "cost_per_enrolled_pence": _divide(spend, enrolled),
            "revenue_pence": revenue,
            "net_pence": None if spend is None else revenue - spend,
        })

    with_spend = [r for r in rows if r["spend_pence"] is not None]
    total_spend = sum(r["spend_pence"] for r in with_spend)
    totals = {
        "paid_leads": sum(r["paid_leads"] for r in with_spend),
        "applications": sum(r["applications"] for r in with_spend),
        "enrolled": sum(r["enrolled"] for r in with_spend),
        "spend_pence": total_spend if with_spend else None,
    }
    totals.update({
        "cost_per_lead_pence": _divide(totals["spend_pence"], totals["paid_leads"]),
        "cost_per_application_pence": _divide(totals["spend_pence"], totals["applications"]),
        "cost_per_enrolled_pence": _divide(totals["spend_pence"], totals["enrolled"]),
        "revenue_pence": totals["enrolled"] * revenue_per_enrolled,
        "net_pence": (totals["enrolled"] * revenue_per_enrolled - total_spend) if with_spend else None,
    })

    live = []
    for spend_row in spend_rows:
        year, month = int(spend_row["month_key"][:4]), int(spend_row["month_key"][5:7])
        if spend_row["is_final"] or (today.year, today.month) != (year, month):
            continue          # only a month-to-date figure for the month in progress is "live"
        elapsed, days_in_month = month_progress(spend_row["month_key"], today)
        live.append({
            "month_key": spend_row["month_key"],
            "year": year,
            "month": month,
            "spend_to_date_pence": spend_row["amount_pence"],
            "days_elapsed": elapsed,
            "days_in_month": days_in_month,
            **forecast_month(spend_row, today, settings["monthly_budget_pence"]),
        })

    return {"rows": rows, "totals": totals, "live": live, "revenue_per_enrolled_pence": revenue_per_enrolled}
