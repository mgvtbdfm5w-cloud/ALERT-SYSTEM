import sqlite3
import unittest

from lookups import (
    DuplicateLookupError,
    LookupValidationError,
    add_lookup,
    delete_lookup,
    list_lookup_rows,
    update_lookup,
)


class LookupTablesTestCase(unittest.TestCase):
    def setUp(self):
        self.conn = sqlite3.connect(":memory:")
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(
            """
            CREATE TABLE lookup_tables (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                table_name TEXT NOT NULL,
                source_value TEXT NOT NULL,
                mapped_value TEXT,
                created_at TEXT NOT NULL,
                intake_01_count INTEGER DEFAULT 0,
                intake_02_count INTEGER DEFAULT 0,
                group_as_other INTEGER DEFAULT 0
            );
            """
        )
        self.conn.commit()

    def tearDown(self):
        self.conn.close()


class AddLookupTests(LookupTablesTestCase):
    def test_add_without_intake_counts_defaults_to_zero(self):
        add_lookup(self.conn, "sales_office", "Raneen", "OXF", "2026-01-01T00:00:00")
        row = list_lookup_rows(self.conn, "sales_office")[0]
        self.assertEqual(row["intake_01_count"], 0)
        self.assertEqual(row["intake_02_count"], 0)

    def test_add_with_intake_counts(self):
        add_lookup(self.conn, "sales_office", "Raneen", "OXF", "2026-01-01T00:00:00", "5", "3")
        row = list_lookup_rows(self.conn, "sales_office")[0]
        self.assertEqual(row["intake_01_count"], 5)
        self.assertEqual(row["intake_02_count"], 3)

    def test_blank_intake_counts_default_to_zero(self):
        add_lookup(self.conn, "sales_office", "Raneen", "OXF", "2026-01-01T00:00:00", "", "")
        row = list_lookup_rows(self.conn, "sales_office")[0]
        self.assertEqual(row["intake_01_count"], 0)
        self.assertEqual(row["intake_02_count"], 0)

    def test_non_numeric_intake_count_is_rejected(self):
        with self.assertRaises(LookupValidationError):
            add_lookup(self.conn, "sales_office", "Raneen", "OXF", "2026-01-01T00:00:00", "abc", "0")

    def test_negative_intake_count_is_rejected(self):
        with self.assertRaises(LookupValidationError):
            add_lookup(self.conn, "sales_office", "Raneen", "OXF", "2026-01-01T00:00:00", "-1", "0")

    def test_duplicate_source_value_still_rejected(self):
        add_lookup(self.conn, "sales_office", "Raneen", "OXF", "2026-01-01T00:00:00")
        with self.assertRaises(DuplicateLookupError):
            add_lookup(self.conn, "sales_office", "raneen", "MAN", "2026-01-01T00:00:00")

    def test_blank_source_value_is_rejected(self):
        with self.assertRaises(LookupValidationError):
            add_lookup(self.conn, "sales_office", "", "OXF", "2026-01-01T00:00:00")

    def test_group_as_other_defaults_to_false(self):
        add_lookup(self.conn, "sales_office", "Raneen", "OXF", "2026-01-01T00:00:00")
        row = list_lookup_rows(self.conn, "sales_office")[0]
        self.assertEqual(row["group_as_other"], 0)

    def test_group_as_other_true_is_stored(self):
        add_lookup(
            self.conn, "sales_office", "Daniel", "OXF", "2026-01-01T00:00:00",
            group_as_other=True,
        )
        row = list_lookup_rows(self.conn, "sales_office")[0]
        self.assertEqual(row["group_as_other"], 1)


class UpdateLookupTests(LookupTablesTestCase):
    def test_update_changes_intake_counts(self):
        add_lookup(self.conn, "sales_office", "Raneen", "OXF", "2026-01-01T00:00:00", "5", "3")
        lookup_id = list_lookup_rows(self.conn, "sales_office")[0]["id"]
        update_lookup(self.conn, lookup_id, "sales_office", "Raneen", "OXF", "10", "7")
        row = list_lookup_rows(self.conn, "sales_office")[0]
        self.assertEqual(row["intake_01_count"], 10)
        self.assertEqual(row["intake_02_count"], 7)

    def test_update_without_intake_counts_resets_to_zero(self):
        add_lookup(self.conn, "sales_office", "Raneen", "OXF", "2026-01-01T00:00:00", "5", "3")
        lookup_id = list_lookup_rows(self.conn, "sales_office")[0]["id"]
        update_lookup(self.conn, lookup_id, "sales_office", "Raneen", "OXF")
        row = list_lookup_rows(self.conn, "sales_office")[0]
        self.assertEqual(row["intake_01_count"], 0)
        self.assertEqual(row["intake_02_count"], 0)

    def test_update_can_toggle_group_as_other_on(self):
        add_lookup(self.conn, "sales_office", "Daniel", "OXF", "2026-01-01T00:00:00")
        lookup_id = list_lookup_rows(self.conn, "sales_office")[0]["id"]
        update_lookup(self.conn, lookup_id, "sales_office", "Daniel", "OXF", group_as_other=True)
        row = list_lookup_rows(self.conn, "sales_office")[0]
        self.assertEqual(row["group_as_other"], 1)

    def test_update_without_group_as_other_resets_to_false(self):
        add_lookup(self.conn, "sales_office", "Daniel", "OXF", "2026-01-01T00:00:00", group_as_other=True)
        lookup_id = list_lookup_rows(self.conn, "sales_office")[0]["id"]
        update_lookup(self.conn, lookup_id, "sales_office", "Daniel", "OXF")
        row = list_lookup_rows(self.conn, "sales_office")[0]
        self.assertEqual(row["group_as_other"], 0)

    def test_update_invalid_intake_count_is_rejected(self):
        add_lookup(self.conn, "sales_office", "Raneen", "OXF", "2026-01-01T00:00:00")
        lookup_id = list_lookup_rows(self.conn, "sales_office")[0]["id"]
        with self.assertRaises(LookupValidationError):
            update_lookup(self.conn, lookup_id, "sales_office", "Raneen", "OXF", "not-a-number", "0")


class DeleteLookupTests(LookupTablesTestCase):
    def test_delete_removes_the_row(self):
        add_lookup(self.conn, "sales_office", "Raneen", "OXF", "2026-01-01T00:00:00", "5", "3")
        lookup_id = list_lookup_rows(self.conn, "sales_office")[0]["id"]
        delete_lookup(self.conn, lookup_id, "sales_office")
        self.assertEqual(list_lookup_rows(self.conn, "sales_office"), [])


if __name__ == "__main__":
    unittest.main()
