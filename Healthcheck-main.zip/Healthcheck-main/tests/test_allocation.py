"""The Allocation page: Paid Ad leads, then all leads, grouped by Office with a
row per Consultant (the Lead Source chart's style), for one month.

Pure builder tests, then route tests through the real upload/lookups routes."""

import io
import re
import unittest
from contextlib import contextmanager

import openpyxl
from flask import template_rendered

from leads_dashboard import build_allocation_report, filter_inbound_call_leads, filter_just_jon_leads, filter_paid_ad_leads
from leads import REQUIRED_LEADS_SOURCE_COLUMNS
from tests.flask_test_support import IsolatedAppTestCase, app_module, extract_token

OFFICES = {"mel": "OXF", "hannah": "OXF", "kian": "MAN", "raymond": "LON"}


def row(consultant, stage="01 - New Lead", source="Paid Ad"):
    return {"Consultant": consultant, "Stage": stage, "Lead Source": source}


def rows_of(report):
    return {g["office"]: {r["name"]: r["count"] for r in g["rows"]} for g in report["groups"]}


# ----------------------------------------------------------------- builder
class BuilderTests(unittest.TestCase):
    def test_groups_by_office_with_a_row_per_consultant(self):
        report = build_allocation_report([row("Mel"), row("Mel"), row("Hannah"), row("Kian")], OFFICES)
        self.assertEqual(rows_of(report), {"OXF": {"Mel": 2, "Hannah": 1}, "MAN": {"Kian": 1}})
        self.assertEqual(report["total"], 4)

    def test_offices_and_rows_are_ranked_by_total_then_name(self):
        rows = [row("Kian")] * 2 + [row("Hannah")] + [row("Mel")] * 3
        report = build_allocation_report(rows, OFFICES)
        self.assertEqual([g["office"] for g in report["groups"]], ["OXF", "MAN"])         # OXF 4 vs MAN 2
        self.assertEqual([r["name"] for r in report["groups"][0]["rows"]], ["Mel", "Hannah"])
        tie = build_allocation_report([row("Hannah"), row("Mel")], OFFICES)
        self.assertEqual([r["name"] for r in tie["groups"][0]["rows"]], ["Hannah", "Mel"])    # equal totals: name A-Z

    def test_the_group_label_shows_the_office_total(self):
        report = build_allocation_report([row("Mel"), row("Hannah"), row("Kian")], OFFICES)
        self.assertEqual({g["office"]: g["label"] for g in report["groups"]}, {"OXF": "OXF (2)", "MAN": "MAN (1)"})
        for g in report["groups"]:
            self.assertEqual(g["total"], sum(r["count"] for r in g["rows"]))

    def test_a_consultant_with_no_office_goes_under_other(self):
        report = build_allocation_report([row("Newbie"), row("newbie")], OFFICES)
        self.assertEqual(rows_of(report), {"Other": {"Newbie": 2}})

    def test_a_lead_with_no_consultant_is_unassigned(self):
        report = build_allocation_report([row(""), row(None), row("   ")], OFFICES)
        self.assertEqual(rows_of(report), {"Unassigned": {"Unassigned": 3}})

    def test_consultants_set_to_group_as_other_are_added_together_in_their_offices_other_row(self):
        offices = {**OFFICES, "jon": "OXF"}
        report = build_allocation_report([row("Mel"), row("Jon"), row("jon"), row("Raymond")], offices, {"jon", "raymond"})
        self.assertEqual(rows_of(report), {"OXF": {"Other": 2, "Mel": 1}, "LON": {"Other": 1}})
        self.assertEqual({g["office"]: g["total"] for g in report["groups"]}, {"OXF": 3, "LON": 1})
        self.assertEqual(report["total"], 4)

    def test_a_consultants_name_in_different_case_is_one_row(self):
        report = build_allocation_report([row("Mel"), row("mel"), row("MEL")], OFFICES)
        self.assertEqual([(r["name"], r["count"]) for r in report["groups"][0]["rows"]], [("Mel", 3)])

    def test_stage_segments_applications_and_percentage(self):
        rows = [row("Mel", "01 - New Lead"), row("Mel", "04 - Applied"), row("Mel", "05 - Enrolled"), row("Mel", "08 - Not Interested")]
        r = build_allocation_report(rows, OFFICES)["groups"][0]["rows"][0]
        self.assertEqual((r["count"], r["applications"], r["applications_pct"]), (4, 2, 50))
        self.assertEqual({s["stage"]: s["count"] for s in r["segments"]},
                         {"01 - New Lead": 1, "04 - Applied": 1, "05 - Enrolled": 1, "08 - Not Interested": 1})

    def test_bars_are_scaled_to_the_busiest_row_across_every_office(self):
        report = build_allocation_report([row("Mel")] * 4 + [row("Kian")], OFFICES)
        widths = {r["name"]: sum(s["width_pct"] for s in r["segments"]) for g in report["groups"] for r in g["rows"]}
        self.assertAlmostEqual(widths["Mel"], 100.0)
        self.assertAlmostEqual(widths["Kian"], 25.0)

    def test_unknown_stages_fold_into_unassigned(self):
        r = build_allocation_report([row("Mel", ""), row("Mel", "weird")], OFFICES)["groups"][0]["rows"][0]
        self.assertEqual([(s["stage"], s["count"]) for s in r["segments"]], [("Unassigned", 2)])

    def test_empty_input(self):
        self.assertEqual(build_allocation_report([], OFFICES), {"groups": [], "total": 0})

    def test_paid_ad_filter(self):
        rows = [row("Mel", source="Paid Ad"), row("Mel", source=" paid ad "), row("Mel", source="Agent"), row("Mel", source=None), row("Mel", source="Paid Ads")]
        self.assertEqual(len(filter_paid_ad_leads(rows)), 2)

    def test_just_jon_filter_matches_the_three_sub_sources_whatever_the_lead_source(self):
        def sub(value, source="Agent"):
            return {"Consultant": "Mel", "Stage": "01 - New Lead", "Lead Source": source, "Sub Source": value}
        rows = [sub("Jon Daniels"), sub("Jon Daniels TT", "Staff Referral"), sub("Just Jon"), sub(" just jon "), sub("JON DANIELS tt", "Paid Ad"),
                sub("Riley Jonathan"), sub("Jon"), sub("Just Jon Extra"), sub("Jon Daniels TT2"), sub("Daniels"), sub(""), sub(None)]
        self.assertEqual([r["Sub Source"] for r in filter_just_jon_leads(rows)],
                         ["Jon Daniels", "Jon Daniels TT", "Just Jon", " just jon ", "JON DANIELS tt"])

    def test_inbound_filter_is_inbound_call_only(self):
        rows = [row("Mel", source="Inbound Call"), row("Mel", source=" inbound call "), row("Mel", source="INBOUND CALL"),
                row("Mel", source="Website"), row("Mel", source="Social Media"), row("Mel", source="Employee"),
                row("Mel", source="Inbound"), row("Mel", source="Inbound Calls"), row("Mel", source="Paid Ad"), row("Mel", source=None)]
        self.assertEqual(len(filter_inbound_call_leads(rows)), 3)

    def test_the_input_is_not_modified(self):
        rows = [row("Mel")]
        build_allocation_report(rows, OFFICES, {"mel"})
        self.assertEqual(rows, [row("Mel")])


# ------------------------------------------------------------------- route
def leads_book(rows):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Leads"
    ws.append(REQUIRED_LEADS_SOURCE_COLUMNS)
    for r in rows:
        full = {c: "" for c in REQUIRED_LEADS_SOURCE_COLUMNS}
        full.update(r)
        ws.append([full[c] for c in REQUIRED_LEADS_SOURCE_COLUMNS])
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def lead(code, consultant, created, status="New Lead", source="Paid Ad/Google"):
    return {"Student Id": code, "Name": code, "Counsellor": consultant, "Creation Date": created, "Lead Status": status, "Lead Source": source}


LEADS = [
    # August
    lead("M1", "Mel X", "03/08/2026"), lead("M2", "Mel X", "04/08/2026", "Applied"), lead("M3", "Mel X", "05/08/2026", source="Agent/Z"),
    lead("H1", "Hannah Y", "03/08/2026"), lead("K1", "Kian Q", "03/08/2026", source="Inbound Call/Phone"),
    lead("R1", "Raymond P", "03/08/2026"), lead("U1", "", "04/08/2026"),
    lead("J1", "Mel X", "08/08/2026", source="Staff Referral/Jon Daniels TT"), lead("J2", "Kian Q", "08/08/2026", "Applied", "Agent/Just Jon"),
    lead("J3", "Hannah Y", "08/08/2026", source="Student Referral/Riley Jonathan"), lead("J4", "Raymond P", "09/08/2026", source="Agent/Just Jon"),
    lead("J5", "", "09/08/2026", source="Staff Referral/Jon Daniels TT"), lead("J7", "Mel X", "10/08/2026", source="Agent/Just Jon"),
    lead("M6", "Mel X", "07/08/2026", source="Inbound Call/Phone"), lead("R2", "Raymond P", "07/08/2026", "Applied", "Inbound Call/Phone"),
    lead("U2", "", "07/08/2026", source="Inbound Call/Phone"), lead("W1", "Hannah Y", "07/08/2026", source="Website/Organic"),
    # September
    lead("M4", "Mel X", "02/09/2026"), lead("K2", "Kian Q", "02/09/2026"), lead("J6", "Hannah Y", "03/09/2026", source="Staff Referral/Jon Daniels TT"),
]


@contextmanager
def captured():
    rendered = []

    def record(sender, template, context, **extra):
        rendered.append((template.name, dict(context)))

    template_rendered.connect(record, app_module.app)
    try:
        yield rendered
    finally:
        template_rendered.disconnect(record, app_module.app)


class AllocationRouteTests(IsolatedAppTestCase):
    def setUp(self):
        super().setUp()
        self.full = self._client_logged_in_as("full")
        token = lambda: extract_token(self.full.get("/login").get_data(as_text=True))
        self.assertEqual(self.full.post("/leads/upload", data={"csrf_token": token(), "excel_file": (io.BytesIO(leads_book(LEADS)), "l.xlsx")},
                                        content_type="multipart/form-data").status_code, 302)
        for consultant, office, other in (("Mel", "OXF", False), ("Hannah", "OXF", False), ("Kian", "MAN", False), ("Raymond", "LON", True)):
            data = {"csrf_token": token(), "source_value": consultant, "mapped_value": office}
            if other:
                data["group_as_other"] = "on"
            self.assertEqual(self.full.post("/admin/lookups/sales_office/add", data=data).status_code, 302)

    def page(self, query="?month=2026-08", client=None):
        with captured() as rendered:
            r = (client or self.full).get("/allocation" + query)
        self.assertEqual(r.status_code, 200)
        context = next(c for name, c in rendered if name == "allocation.html")
        return r.get_data(as_text=True), context

    def test_the_first_chart_is_paid_ad_leads_only_and_the_second_is_inbound_only(self):
        html, context = self.page()
        self.assertEqual(rows_of(context["paid_report"]), {"OXF": {"Mel": 2, "Hannah": 1}, "LON": {"Other": 1}, "Unassigned": {"Unassigned": 1}})
        self.assertEqual(rows_of(context["inbound_report"]),
                         {"OXF": {"Mel": 1}, "MAN": {"Kian": 1}, "LON": {"Other": 1}, "Unassigned": {"Unassigned": 1}})
        self.assertLess(html.index("Paid Ad Leads by Office and Consultant"), html.index("Inbound Leads by Office and Consultant"))

    def test_the_third_chart_is_just_jon_by_sub_source(self):
        html, context = self.page()
        self.assertEqual(rows_of(context["just_jon_report"]),
                         {"OXF": {"Mel": 2}, "MAN": {"Kian": 1}, "LON": {"Other": 1}, "Unassigned": {"Unassigned": 1}})
        self.assertEqual(context["just_jon_report"]["total"], 5)         # Riley Jonathan (Hannah) is not Just Jon
        self.assertLess(html.index("Inbound Leads by Office and Consultant"), html.index("Just Jon Leads by Office and Consultant"))
        self.assertNotIn("Hannah", [r["name"] for g in context["just_jon_report"]["groups"] for r in g["rows"]])

    def drawn(self, html, title):
        """{office label: {consultant: count}} exactly as drawn in the chart called `title`."""
        start = html.index(f"<h2>{title}</h2>")
        section = html[start:html.index("</section>", start)]
        result = {}
        for group in section.split('<div class="chart-office-group">')[1:]:
            label = re.search(r'chart-office-label">([^<]+)<', group).group(1)
            result[label] = {m.group(1): int(m.group(2)) for m in re.finditer(
                r'chart-manager-name">([^<]+)</div>.*?chart-col-total">(\d+)<', group, re.S)}
        return result

    def test_each_chart_draws_its_own_report_not_another_ones(self):
        html, context = self.page()
        expected = {
            "Paid Ad Leads by Office and Consultant": context["paid_report"],
            "Inbound Leads by Office and Consultant": context["inbound_report"],
            "Just Jon Leads by Office and Consultant": context["just_jon_report"],
        }
        drawn = {title: self.drawn(html, title) for title in expected}
        for title, report in expected.items():
            self.assertEqual(drawn[title], {g["label"]: {r["name"]: r["count"] for r in g["rows"]} for g in report["groups"]}, title)
        self.assertEqual(len({repr(v) for v in drawn.values()}), 3, "the three charts differ on this data")
        self.assertEqual(drawn["Just Jon Leads by Office and Consultant"]["OXF (2)"], {"Mel": 2})
        self.assertEqual(drawn["Inbound Leads by Office and Consultant"]["OXF (1)"], {"Mel": 1})

    def test_just_jon_follows_the_month_and_has_its_own_empty_message(self):
        _, sep = self.page("?month=2026-09")
        self.assertEqual(rows_of(sep["just_jon_report"]), {"OXF": {"Hannah": 1}})
        token = extract_token(self.full.get("/login").get_data(as_text=True))
        self.full.post("/leads/upload", data={"csrf_token": token, "excel_file": (io.BytesIO(leads_book([lead("A1", "Mel X", "05/10/2026", source="Agent/Z")])), "l.xlsx")},
                       content_type="multipart/form-data")
        html, context = self.page("?month=2026-10")
        self.assertEqual(context["just_jon_report"]["groups"], [])
        self.assertIn("No Just Jon leads found for this month.", html)

    def test_there_is_no_all_leads_chart(self):
        html, context = self.page()
        self.assertNotIn("All Leads by Office and Consultant", html)
        self.assertNotIn("all_report", context)
        self.assertEqual(html.count('class="chart-office-group"') > 0, True)
        self.assertEqual(html.count("<h2>"), 3, "exactly three charts: Paid Ad, Inbound, Just Jon")

    def test_the_second_chart_is_called_inbound_and_only_counts_inbound_call_leads(self):
        html, context = self.page()
        self.assertNotIn("Inbound Call Leads", html)
        # Hannah's only August lead besides the paid one is a Website lead: she must not appear in the Inbound chart
        self.assertNotIn("Hannah", [r["name"] for g in context["inbound_report"]["groups"] for r in g["rows"]])
        self.assertEqual(context["inbound_report"]["total"], 4)

    def test_office_comes_from_the_consultant_lookup_and_group_as_other_is_folded(self):
        _, context = self.page()
        for report in ("paid_report", "inbound_report"):
            groups = {g["office"]: g for g in context[report]["groups"]}
            self.assertEqual([r["name"] for r in groups["LON"]["rows"]], ["Other"], report)      # Raymond is Group as Other
            self.assertNotIn("Raymond", [r["name"] for g in context[report]["groups"] for r in g["rows"]], report)

    def test_group_labels_show_office_totals_in_the_page(self):
        html, _ = self.page()
        text = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html))
        self.assertIn("OXF (3)", text)                          # paid: Mel 2 + Hannah 1
        self.assertIn("OXF (1)", text)                          # inbound: Mel 1
        self.assertIn("MAN (1)", text)                          # inbound: Kian

    def test_the_month_filter_changes_both_charts(self):
        html, sep = self.page("?month=2026-09")
        self.assertEqual(rows_of(sep["paid_report"]), {"OXF": {"Mel": 1}, "MAN": {"Kian": 1}})
        self.assertEqual(sep["inbound_report"]["groups"], [])
        self.assertIn("No Inbound leads found for this month.", html)
        self.assertIn('<option value="2026-09" selected>', html)

    def test_defaults_to_the_latest_month_and_ignores_a_bad_month(self):
        for query in ("", "?month=garbage", "?month=2026-13", "?month=%3Cscript%3E"):
            html, context = self.page(query)
            self.assertEqual(context["selected_key"], "2026-09", query)
            self.assertNotIn("<script>", html.split("<main")[1].split("</main>")[0].replace("<script src", ""))

    def test_each_chart_has_its_own_empty_message(self):
        # a month with only Agent leads: neither chart has anything
        token = extract_token(self.full.get("/login").get_data(as_text=True))
        self.full.post("/leads/upload", data={"csrf_token": token, "excel_file": (io.BytesIO(leads_book([lead("A1", "Mel X", "05/10/2026", source="Agent/Z")])), "l.xlsx")},
                       content_type="multipart/form-data")
        html, context = self.page("?month=2026-10")
        self.assertEqual((context["paid_report"]["groups"], context["inbound_report"]["groups"]), ([], []))
        self.assertIn("No Paid Ad leads found for this month.", html)
        self.assertIn("No Inbound leads found for this month.", html)

    def test_the_chart_uses_the_same_markup_as_the_lead_source_chart(self):
        html, _ = self.page()
        for fragment in ('class="chart-office-group"', 'class="chart-office-label"', 'class="chart-segment"', 'class="chart-col-applications"', 'class="chart-legend"'):
            self.assertIn(fragment, html)
        self.assertIn('<div class="chart-manager-name">Consultant</div>', html)

    def test_the_button_sits_next_to_paid_ads_on_the_leads_dashboard(self):
        html = self.full.get("/leads-dashboard?month=2026-08").get_data(as_text=True)
        paid, alloc = html.index('href="/paid-ads"'), html.index('href="/allocation"')
        self.assertLess(paid, alloc)
        self.assertLess(alloc - paid, 120, "the two buttons are adjacent")
        self.assertIn(">Allocation</a>", html)

    def test_every_role_sees_the_button_and_can_open_the_page_but_only_some_see_paid_ads(self):
        for role in ("full", "admissions", "consultants", "marketing"):
            client = self._client_logged_in_as(role)
            html = client.get("/leads-dashboard?month=2026-08").get_data(as_text=True)
            self.assertIn('href="/allocation"', html, role)
            self.assertEqual(client.get("/allocation").status_code, 200, role)
            self.assertEqual('href="/paid-ads"' in html, role in ("full", "admissions"), role)

    def test_login_is_required(self):
        r = app_module.app.test_client().get("/allocation")
        self.assertEqual(r.status_code, 302)
        self.assertIn("/login", r.headers["Location"])

    def test_no_money_on_the_page(self):
        html, _ = self.page()
        for text in ("£", "Revenue", "Ad Spend", "spend"):
            self.assertNotIn(text, html, text)

    def test_with_no_leads_file_there_is_a_friendly_message(self):
        import sqlite3
        from tests.flask_test_support import db_module
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute("DELETE FROM active_leads_dataset")
        conn.commit()
        conn.close()
        r = self.full.get("/allocation")
        self.assertEqual(r.status_code, 200)
        self.assertIn("No active Leads dataset yet.", r.get_data(as_text=True))


if __name__ == "__main__":
    unittest.main()
