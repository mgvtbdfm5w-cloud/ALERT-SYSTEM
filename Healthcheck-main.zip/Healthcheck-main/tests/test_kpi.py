import sqlite3
import unittest
from datetime import date

import kpi
from kpi import (
    DEFAULT_CONSULTANT_TARGET,
    KpiTargetValidationError,
    build_consultant_status_tiers,
    build_kpi_progress_chart,
    build_kpi_report,
    build_month_options,
    build_oxford_kpi_matrix,
    build_pipeline_backlog_summary,
    classify_consultant_status,
    classify_status,
    format_month_label,
    get_kpi_targets,
    list_available_months,
    list_sales_offices_for_month,
    month_key,
    parse_month_key,
    set_kpi_target,
)


class MonthExtractionTests(unittest.TestCase):
    def test_extracts_distinct_year_month_pairs_from_qa_passed(self):
        rows = [
            {"QA Passed": "2026-08-01"},
            {"QA Passed": "2026-08-15"},
            {"QA Passed": "2026-07-01"},
        ]
        self.assertEqual(list_available_months(rows), [(2026, 8), (2026, 7)])

    def test_newest_month_sorts_first(self):
        rows = [
            {"QA Passed": "2026-01-05"},
            {"QA Passed": "2026-08-05"},
            {"QA Passed": "2025-12-05"},
        ]
        self.assertEqual(list_available_months(rows), [(2026, 8), (2026, 1), (2025, 12)])

    def test_blank_and_malformed_qa_passed_are_ignored_safely(self):
        rows = [{"QA Passed": None}, {"QA Passed": ""}, {"QA Passed": "not-a-date"}]
        self.assertEqual(list_available_months(rows), [])

    def test_month_key_and_parse_month_key_round_trip(self):
        key = month_key(2026, 8)
        self.assertEqual(key, "2026-08")
        self.assertEqual(parse_month_key(key), (2026, 8))

    def test_parse_month_key_never_raises_on_bad_input(self):
        self.assertIsNone(parse_month_key(None))
        self.assertIsNone(parse_month_key(""))
        self.assertIsNone(parse_month_key("bogus"))
        self.assertIsNone(parse_month_key("2026-13"))
        self.assertIsNone(parse_month_key("2026-00"))

    def test_format_month_label(self):
        self.assertEqual(format_month_label(2026, 8), "August 2026")

    def test_build_month_options(self):
        # Shared by the KPI, Submissions, and Admin KPI-targets month
        # dropdowns - each entry pairs month_key() with format_month_label()
        # for the same (year, month), in the input list's order.
        options = build_month_options([(2026, 8), (2026, 7)])
        self.assertEqual(
            options,
            [
                {"key": "2026-08", "label": "August 2026"},
                {"key": "2026-07", "label": "July 2026"},
            ],
        )

    def test_build_month_options_empty_list(self):
        self.assertEqual(build_month_options([]), [])


class ClassifyStatusThresholdTests(unittest.TestCase):
    def test_below_80_percent_is_red(self):
        self.assertEqual(classify_status(31, 40), "red")

    def test_exactly_80_percent_is_yellow(self):
        self.assertEqual(classify_status(32, 40), "yellow")

    def test_just_below_100_percent_is_yellow(self):
        self.assertEqual(classify_status(39, 40), "yellow")

    def test_exactly_100_percent_is_green(self):
        self.assertEqual(classify_status(40, 40), "green")

    def test_above_100_percent_is_still_green(self):
        self.assertEqual(classify_status(48, 40), "green")

    def test_missing_target_is_none(self):
        self.assertIsNone(classify_status(10, None))

    def test_zero_target_is_none_not_a_crash(self):
        self.assertIsNone(classify_status(10, 0))


class ClassifyConsultantStatusThresholdTests(unittest.TestCase):
    """The 5-tier Consultant scale, ratio-based against whatever target is
    passed in (the Admin-editable Consultant Target for the month) -
    distinct from classify_status()'s 3-tier ratio scale used for Sales
    Office/Company cards. At target=40 these reproduce the scale's
    original whole-number cutoffs (22/27/32/39) exactly."""

    def test_just_below_23_is_dark_red(self):
        self.assertEqual(classify_consultant_status(22, 40), "dark-red")

    def test_zero_is_dark_red(self):
        self.assertEqual(classify_consultant_status(0, 40), "dark-red")

    def test_23_is_orange(self):
        self.assertEqual(classify_consultant_status(23, 40), "orange")

    def test_27_is_still_orange(self):
        self.assertEqual(classify_consultant_status(27, 40), "orange")

    def test_28_is_yellow(self):
        self.assertEqual(classify_consultant_status(28, 40), "yellow")

    def test_32_is_still_yellow(self):
        self.assertEqual(classify_consultant_status(32, 40), "yellow")

    def test_33_is_olive(self):
        self.assertEqual(classify_consultant_status(33, 40), "olive")

    def test_39_is_still_olive(self):
        self.assertEqual(classify_consultant_status(39, 40), "olive")

    def test_40_is_green(self):
        self.assertEqual(classify_consultant_status(40, 40), "green")

    def test_above_40_is_still_green(self):
        self.assertEqual(classify_consultant_status(48, 40), "green")

    def test_missing_target_is_none(self):
        self.assertIsNone(classify_consultant_status(30, None))

    def test_zero_target_is_none_not_a_crash(self):
        self.assertIsNone(classify_consultant_status(30, 0))


class BuildConsultantStatusTiersTests(unittest.TestCase):
    """build_consultant_status_tiers(target) is the single source of truth
    passed to the KPI template's legend - these tests protect that
    classify_consultant_status() stays in sync with it (they can no longer
    drift apart, since the legend is now rendered directly from this list
    rather than hand-duplicated text in the template), and that the whole
    scale correctly rescales when the month's Consultant Target changes."""

    def test_default_target_reproduces_the_original_whole_number_cutoffs(self):
        tiers = build_consultant_status_tiers(40)
        uppers = [t["upper"] for t in tiers]
        self.assertEqual(uppers, [22, 27, 32, 39, None])

    def test_every_tier_boundary_classifies_to_its_own_status(self):
        tiers = build_consultant_status_tiers(40)
        for tier in tiers:
            probe = tier["upper"] if tier["upper"] is not None else 999
            self.assertEqual(classify_consultant_status(probe, 40), tier["status"])

    def test_five_tiers_in_ascending_order(self):
        tiers = build_consultant_status_tiers(40)
        self.assertEqual(len(tiers), 5)
        uppers = [t["upper"] for t in tiers[:-1]]
        self.assertEqual(uppers, sorted(uppers))
        self.assertIsNone(tiers[-1]["upper"])

    def test_labels_match_the_original_wording_at_the_default_target(self):
        tiers = build_consultant_status_tiers(40)
        labels = [t["label"] for t in tiers]
        self.assertEqual(labels, ["Below 23", "23 to 27", "28 to 32", "33 to 39", "40 and above"])

    def test_scales_proportionally_for_a_different_target(self):
        # A target of 50 should scale every cutoff by the same ratios
        # (0.55, 0.675, 0.8, 0.975) that reproduce 22/27/32/39 at 40,
        # rounded half-up: 27.5->28, 33.75->34, 40, 48.75->49.
        tiers = build_consultant_status_tiers(50)
        uppers = [t["upper"] for t in tiers]
        self.assertEqual(uppers, [28, 34, 40, 49, None])

    def test_scaled_tiers_still_classify_correctly(self):
        tiers = build_consultant_status_tiers(50)
        self.assertEqual(classify_consultant_status(28, 50), "dark-red")
        self.assertEqual(classify_consultant_status(29, 50), "orange")
        self.assertEqual(classify_consultant_status(50, 50), "green")
        # Verify the objects agree, not just coincidentally matching values.
        for tier in tiers:
            probe = tier["upper"] if tier["upper"] is not None else 999
            self.assertEqual(classify_consultant_status(probe, 50), tier["status"])


class BarAndAchievementPctTests(unittest.TestCase):
    def test_bar_caps_at_100_even_when_actual_exceeds_target(self):
        self.assertEqual(kpi._bar_pct(48, 40), 100.0)

    def test_bar_is_uncapped_below_target(self):
        self.assertEqual(kpi._bar_pct(20, 40), 50.0)

    def test_bar_is_zero_for_missing_target(self):
        self.assertEqual(kpi._bar_pct(20, None), 0)

    def test_achievement_pct_can_exceed_100(self):
        # 48/40 = 120% - the displayed percentage is explicitly allowed to
        # exceed 100, unlike the bar fill.
        self.assertEqual(kpi._achievement_pct(48, 40), 120)

    def test_achievement_pct_is_none_for_missing_target(self):
        self.assertIsNone(kpi._achievement_pct(20, None))


class BuildKpiReportTests(unittest.TestCase):
    def setUp(self):
        self.rows = [
            {"QA Passed": "2026-08-01", "Consultant": "Raneen", "Sales Office": "OXF"},
            {"QA Passed": "2026-08-05", "Consultant": "Raneen", "Sales Office": "OXF"},
            {"QA Passed": "2026-08-10", "Consultant": "Hassan", "Sales Office": "OXF"},
            {"QA Passed": "2026-08-15", "Consultant": "Mo", "Sales Office": ""},
            {"QA Passed": "2026-08-20", "Consultant": "", "Sales Office": ""},
            {"QA Passed": "2026-07-01", "Consultant": "Raneen", "Sales Office": "OXF"},
            {"QA Passed": None, "Consultant": "Raneen", "Sales Office": "OXF"},
        ]
        self.report = build_kpi_report(
            self.rows, 2026, 8, sales_office_targets={"OXF": 3}, company_target=10
        )

    def test_company_actual_counts_all_qualifying_rows_regardless_of_attribution(self):
        # 5 rows fall in August 2026 with a valid QA Passed date, including
        # the blank-Consultant and blank-Sales-Office ones.
        self.assertEqual(self.report["company"]["actual"], 5)

    def test_other_month_and_blank_date_rows_are_excluded(self):
        self.assertEqual(self.report["company"]["actual"], 5)  # not 6 or 7

    def test_blank_sales_office_count_tracked_separately(self):
        self.assertEqual(self.report["blank_sales_office_count"], 1)

    def test_consultant_actual_counts(self):
        oxf = self._office("OXF")
        raneen = self._consultant(oxf, "Raneen")
        hassan = self._consultant(oxf, "Hassan")
        self.assertEqual(raneen["actual"], 2)
        self.assertEqual(hassan["actual"], 1)

    def test_consultant_target_defaults_to_40_when_not_configured(self):
        # No consultant_target was passed to build_kpi_report() in setUp -
        # falls back to DEFAULT_CONSULTANT_TARGET.
        oxf = self._office("OXF")
        raneen = self._consultant(oxf, "Raneen")
        self.assertEqual(raneen["target"], DEFAULT_CONSULTANT_TARGET)
        self.assertEqual(self.report["consultant_target"], DEFAULT_CONSULTANT_TARGET)

    def test_consultant_status_uses_the_5_tier_scale_not_the_ratio_scale(self):
        # Raneen (actual=2) and Hassan (actual=1) are both far below the
        # dark-red/orange boundary, so under the Consultant scale both
        # should be dark-red - not the ratio-based classify_status()
        # result (which would have called 2/40=5% and 1/40=2.5% both
        # "red", a different label entirely).
        oxf = self._office("OXF")
        raneen = self._consultant(oxf, "Raneen")
        hassan = self._consultant(oxf, "Hassan")
        self.assertEqual(raneen["status"], classify_consultant_status(raneen["actual"], DEFAULT_CONSULTANT_TARGET))
        self.assertEqual(hassan["status"], classify_consultant_status(hassan["actual"], DEFAULT_CONSULTANT_TARGET))
        self.assertEqual(raneen["status"], "dark-red")
        self.assertEqual(hassan["status"], "dark-red")

    def test_consultant_rows_carry_a_marker_pct_for_the_guide_line(self):
        # target defaults to 40, so marker_pct is the "Bare Min" cutoff
        # (22+1=23) / 40 * 100 = 57.5.
        oxf = self._office("OXF")
        raneen = self._consultant(oxf, "Raneen")
        self.assertEqual(raneen["marker_pct"], 57.5)

    def test_explicit_consultant_target_is_used_and_rescales_the_tiers(self):
        report = build_kpi_report(
            self.rows, 2026, 8, sales_office_targets={"OXF": 3}, company_target=10, consultant_target=50,
        )
        self.assertEqual(report["consultant_target"], 50)
        oxf = next(o for o in report["sales_offices"] if o["label"] == "OXF")
        raneen = next(c for c in oxf["consultants"] if c["label"] == "Raneen")
        self.assertEqual(raneen["target"], 50)
        # marker_pct tracks the rescaled "Bare Min" cutoff (28+1=29) as a
        # % of the new target: 29/50*100 = 58.0. Whole-number rounding of
        # the cutoff means this isn't always exactly the original 57.5%.
        self.assertEqual(raneen["marker_pct"], 58.0)

    def test_report_exposes_the_tier_table_for_the_legend(self):
        tiers = self.report["consultant_status_tiers"]
        self.assertEqual(len(tiers), 5)
        self.assertEqual(tiers[0]["label"], "Below 23")
        self.assertEqual(tiers[-1]["label"], "40 and above")

    def test_sales_office_status_still_uses_the_ratio_based_scale(self):
        # OXF: actual=3, target=3 -> ratio 100% -> "green" under the
        # existing ratio-based classify_status(); must NOT be reclassified
        # under the Consultant-only 5-tier raw-count scale (which would
        # call a raw "3" dark-red).
        oxf = self._office("OXF")
        self.assertEqual(oxf["status"], "green")

    def test_consultants_with_blank_sales_office_are_excluded_from_the_office_breakdown(self):
        oxf = self._office("OXF")
        names = [c["label"] for c in oxf["consultants"]]
        self.assertNotIn("Mo", names)

    def test_sales_office_grouping_and_actual(self):
        oxf = self._office("OXF")
        self.assertEqual(oxf["actual"], 3)  # Raneen(2) + Hassan(1)

    def test_consultant_ordering_by_actual_descending_then_name(self):
        oxf = self._office("OXF")
        names = [c["label"] for c in oxf["consultants"]]
        self.assertEqual(names, ["Raneen", "Hassan"])

    def test_missing_office_target_is_not_treated_as_zero(self):
        report = build_kpi_report(self.rows, 2026, 8, sales_office_targets={}, company_target=None)
        oxf = next(o for o in report["sales_offices"] if o["label"] == "OXF")
        self.assertIsNone(oxf["target"])
        self.assertIsNone(oxf["achievement_pct"])
        self.assertIsNone(oxf["status"])

    def test_missing_company_target_is_not_treated_as_zero(self):
        report = build_kpi_report(self.rows, 2026, 8, sales_office_targets={"OXF": 3}, company_target=None)
        self.assertIsNone(report["company"]["target"])
        self.assertIsNone(report["company"]["achievement_pct"])

    def _office(self, label):
        return next(o for o in self.report["sales_offices"] if o["label"] == label)

    def _consultant(self, office, label):
        return next(c for c in office["consultants"] if c["label"] == label)


class StudentCodeDeduplicationTests(unittest.TestCase):
    """A Student Code counts once for the month even with multiple
    qualifying rows (e.g. two applications for the same student both QA
    Passed in the same month)."""

    def test_same_student_code_twice_in_month_counts_once_for_company(self):
        rows = [
            {"QA Passed": "2026-08-01", "Student Code": "PES111", "Consultant": "Raneen", "Sales Office": "OXF"},
            {"QA Passed": "2026-08-15", "Student Code": "PES111", "Consultant": "Raneen", "Sales Office": "OXF"},
        ]
        report = build_kpi_report(rows, 2026, 8, sales_office_targets={"OXF": 3}, company_target=10)
        self.assertEqual(report["company"]["actual"], 1)

    def test_same_student_code_twice_in_month_counts_once_for_consultant(self):
        rows = [
            {"QA Passed": "2026-08-01", "Student Code": "PES111", "Consultant": "Raneen", "Sales Office": "OXF"},
            {"QA Passed": "2026-08-15", "Student Code": "PES111", "Consultant": "Raneen", "Sales Office": "OXF"},
        ]
        report = build_kpi_report(rows, 2026, 8, sales_office_targets={"OXF": 3}, company_target=10)
        oxf = next(o for o in report["sales_offices"] if o["label"] == "OXF")
        raneen = next(c for c in oxf["consultants"] if c["label"] == "Raneen")
        self.assertEqual(raneen["actual"], 1)
        self.assertEqual(oxf["actual"], 1)

    def test_duplicate_in_different_months_counts_separately(self):
        rows = [
            {"QA Passed": "2026-08-01", "Student Code": "PES111", "Consultant": "Raneen", "Sales Office": "OXF"},
            {"QA Passed": "2026-09-01", "Student Code": "PES111", "Consultant": "Raneen", "Sales Office": "OXF"},
        ]
        august = build_kpi_report(rows, 2026, 8, sales_office_targets={"OXF": 3}, company_target=10)
        september = build_kpi_report(rows, 2026, 9, sales_office_targets={"OXF": 3}, company_target=10)
        self.assertEqual(august["company"]["actual"], 1)
        self.assertEqual(september["company"]["actual"], 1)

    def test_different_student_codes_still_each_count(self):
        rows = [
            {"QA Passed": "2026-08-01", "Student Code": "PES111", "Consultant": "Raneen", "Sales Office": "OXF"},
            {"QA Passed": "2026-08-15", "Student Code": "PES222", "Consultant": "Raneen", "Sales Office": "OXF"},
        ]
        report = build_kpi_report(rows, 2026, 8, sales_office_targets={"OXF": 3}, company_target=10)
        self.assertEqual(report["company"]["actual"], 2)

    def test_blank_student_codes_are_never_collapsed_together(self):
        rows = [
            {"QA Passed": "2026-08-01", "Student Code": "", "Consultant": "Raneen", "Sales Office": "OXF"},
            {"QA Passed": "2026-08-15", "Student Code": "", "Consultant": "Raneen", "Sales Office": "OXF"},
        ]
        report = build_kpi_report(rows, 2026, 8, sales_office_targets={"OXF": 3}, company_target=10)
        self.assertEqual(report["company"]["actual"], 2)

    def test_duplicate_with_blank_office_on_one_row_still_attributes_correctly(self):
        # Same student, one row missing Sales Office - the row that does
        # carry a Consultant/Office pairing is what gets used.
        rows = [
            {"QA Passed": "2026-08-01", "Student Code": "PES111", "Consultant": "", "Sales Office": ""},
            {"QA Passed": "2026-08-15", "Student Code": "PES111", "Consultant": "Raneen", "Sales Office": "OXF"},
        ]
        report = build_kpi_report(rows, 2026, 8, sales_office_targets={"OXF": 3}, company_target=10)
        oxf = next(o for o in report["sales_offices"] if o["label"] == "OXF")
        raneen = next(c for c in oxf["consultants"] if c["label"] == "Raneen")
        self.assertEqual(raneen["actual"], 1)
        self.assertEqual(report["company"]["actual"], 1)

    def test_first_row_has_a_consultant_but_blank_office_later_row_qualifies(self):
        # A student reassigned mid-month: the first-listed row has a
        # Consultant with no Sales Office mapping (e.g. newly added,
        # unmapped), the second row has a properly-mapped Consultant. The
        # student must be attributed to the qualifying row, not dropped
        # into blank_sales_office_count just because the first row didn't
        # pair a Consultant with an Office.
        rows = [
            {"QA Passed": "2026-08-01", "Student Code": "PES111", "Consultant": "Unmapped", "Sales Office": ""},
            {"QA Passed": "2026-08-15", "Student Code": "PES111", "Consultant": "Raneen", "Sales Office": "OXF"},
        ]
        report = build_kpi_report(rows, 2026, 8, sales_office_targets={"OXF": 3}, company_target=10)
        self.assertEqual(report["blank_sales_office_count"], 0)
        oxf = next(o for o in report["sales_offices"] if o["label"] == "OXF")
        raneen = next(c for c in oxf["consultants"] if c["label"] == "Raneen")
        self.assertEqual(raneen["actual"], 1)
        self.assertEqual(report["company"]["actual"], 1)

    def test_no_row_pairs_consultant_with_office_falls_back_to_blank_count(self):
        # Every qualifying row has a Consultant but none of them has a
        # Sales Office - still correctly counted as blank_sales_office,
        # same as before this row was ever deduplicated.
        rows = [
            {"QA Passed": "2026-08-01", "Student Code": "PES111", "Consultant": "Unmapped", "Sales Office": ""},
            {"QA Passed": "2026-08-15", "Student Code": "PES111", "Consultant": "AlsoUnmapped", "Sales Office": ""},
        ]
        report = build_kpi_report(rows, 2026, 8, sales_office_targets={"OXF": 3}, company_target=10)
        self.assertEqual(report["blank_sales_office_count"], 1)
        self.assertEqual(report["company"]["actual"], 1)


class ListSalesOfficesForMonthTests(unittest.TestCase):
    def test_matches_offices_shown_by_the_full_report(self):
        rows = [
            {"QA Passed": "2026-08-01", "Consultant": "Raneen", "Sales Office": "OXF"},
            {"QA Passed": "2026-08-02", "Consultant": "Mo", "Sales Office": ""},
        ]
        self.assertEqual(list_sales_offices_for_month(rows, 2026, 8), ["OXF"])

    def test_multiple_offices_are_alphabetical_and_deduplicated(self):
        rows = [
            {"QA Passed": "2026-08-01", "Consultant": "Raneen", "Sales Office": "OXF"},
            {"QA Passed": "2026-08-02", "Consultant": "Mel", "Sales Office": "MAN"},
            {"QA Passed": "2026-08-03", "Consultant": "Mustapha", "Sales Office": "CAR"},
            {"QA Passed": "2026-08-04", "Consultant": "Raneen", "Sales Office": "OXF"},
        ]
        self.assertEqual(list_sales_offices_for_month(rows, 2026, 8), ["CAR", "MAN", "OXF"])


class BuildPipelineBacklogSummaryTests(unittest.TestCase):
    """The KPI page "pending action" boxes - Doc Check (01-NewApp) and QA
    (02-PendingQA) are live counts across the whole dataset, deliberately
    ignoring Intake year and QA Passed month (the opposite scoping to
    build_kpi_report()); Submitting (03-PendingSubmission) is split into
    one box per Intake year instead."""

    def _rows(self, status, count, **extra):
        return [{"Status": status, **extra} for _ in range(count)]

    def test_counts_each_box_independently(self):
        rows = (
            self._rows("01-NewApp", 3)
            + self._rows("02-PendingQA", 2)
            + self._rows("03-PendingSubmission", 5, Intake="September 2026")
        )
        summary = build_pipeline_backlog_summary(rows)
        counts = {box["label"]: box["count"] for box in summary}
        self.assertEqual(
            counts, {"Doc Check": 3, "QA": 2, "Submitting (2026)": 5, "Submitting (2027)": 0}
        )

    def test_other_statuses_are_ignored(self):
        rows = self._rows("01-NewApp", 1) + self._rows("09-Enrolled", 50) + self._rows("10-Lost", 50)
        summary = build_pipeline_backlog_summary(rows)
        counts = {box["label"]: box["count"] for box in summary}
        self.assertEqual(counts["Doc Check"], 1)

    def test_intake_year_and_qa_passed_date_are_irrelevant(self):
        # Unlike build_kpi_report(), there is no year/month parameter at
        # all - every matching row counts regardless of any date field.
        rows = (
            self._rows("01-NewApp", 1, Intake="September 2025", **{"QA Passed": None})
            + self._rows("01-NewApp", 1, Intake="January 2027", **{"QA Passed": "2020-01-01"})
        )
        summary = build_pipeline_backlog_summary(rows)
        counts = {box["label"]: box["count"] for box in summary}
        self.assertEqual(counts["Doc Check"], 2)

    def test_doc_check_thresholds(self):
        self.assertEqual(self._status_for("Doc Check", 10), "green")
        self.assertEqual(self._status_for("Doc Check", 11), "yellow")
        self.assertEqual(self._status_for("Doc Check", 15), "yellow")
        self.assertEqual(self._status_for("Doc Check", 16), "red")

    def test_qa_thresholds(self):
        self.assertEqual(self._status_for("QA", 8), "green")
        self.assertEqual(self._status_for("QA", 9), "yellow")
        self.assertEqual(self._status_for("QA", 12), "yellow")
        self.assertEqual(self._status_for("QA", 13), "red")

    def test_submitting_thresholds(self):
        self.assertEqual(self._status_for("Submitting (2026)", 20), "green")
        self.assertEqual(self._status_for("Submitting (2026)", 21), "yellow")
        self.assertEqual(self._status_for("Submitting (2026)", 30), "yellow")
        self.assertEqual(self._status_for("Submitting (2026)", 31), "red")

    def test_submitting_is_split_by_intake_year(self):
        rows = self._rows("03-PendingSubmission", 3, Intake="September 2026") + self._rows(
            "03-PendingSubmission", 7, Intake="January 2027"
        )
        summary = build_pipeline_backlog_summary(rows)
        counts = {box["label"]: box["count"] for box in summary}
        self.assertEqual(counts["Submitting (2026)"], 3)
        self.assertEqual(counts["Submitting (2027)"], 7)

    def test_submitting_rows_with_unparseable_intake_are_excluded_from_both_year_boxes(self):
        rows = self._rows("03-PendingSubmission", 4, Intake=None) + self._rows(
            "03-PendingSubmission", 2, Intake="September 2026"
        )
        summary = build_pipeline_backlog_summary(rows)
        counts = {box["label"]: box["count"] for box in summary}
        self.assertEqual(counts["Submitting (2026)"], 2)
        self.assertEqual(counts["Submitting (2027)"], 0)

    def test_zero_count_is_green(self):
        summary = build_pipeline_backlog_summary([])
        for box in summary:
            self.assertEqual(box["count"], 0)
            self.assertEqual(box["status"], "green")
            self.assertIsNone(box["average_days"])

    def test_average_days_is_the_mean_stage_length(self):
        rows = [
            {"Status": "01-NewApp", "Stage Length": "2 Days ago"},
            {"Status": "01-NewApp", "Stage Length": "4 Days ago"},
        ]
        summary = build_pipeline_backlog_summary(rows)
        doc_check = next(b for b in summary if b["label"] == "Doc Check")
        self.assertEqual(doc_check["average_days"], 3.0)

    def test_average_days_rounds_to_one_decimal_place(self):
        rows = [
            {"Status": "01-NewApp", "Stage Length": "0 Day ago"},
            {"Status": "01-NewApp", "Stage Length": "0 Day ago"},
            {"Status": "01-NewApp", "Stage Length": "1 Day ago"},
        ]
        summary = build_pipeline_backlog_summary(rows)
        doc_check = next(b for b in summary if b["label"] == "Doc Check")
        self.assertEqual(doc_check["average_days"], 0.3)

    def test_average_days_can_be_below_one(self):
        rows = [
            {"Status": "02-PendingQA", "Stage Length": "0 Day ago"},
            {"Status": "02-PendingQA", "Stage Length": "0 Day ago"},
            {"Status": "02-PendingQA", "Stage Length": "0 Day ago"},
            {"Status": "02-PendingQA", "Stage Length": "1 Day ago"},
        ]
        summary = build_pipeline_backlog_summary(rows)
        qa = next(b for b in summary if b["label"] == "QA")
        self.assertEqual(qa["average_days"], 0.3)

    def test_rows_with_unparseable_stage_length_are_excluded_from_the_average_but_still_counted(self):
        rows = [
            {"Status": "01-NewApp", "Stage Length": "4 Days ago"},
            {"Status": "01-NewApp", "Stage Length": ""},
            {"Status": "01-NewApp", "Stage Length": "not a value"},
        ]
        summary = build_pipeline_backlog_summary(rows)
        doc_check = next(b for b in summary if b["label"] == "Doc Check")
        self.assertEqual(doc_check["count"], 3)
        self.assertEqual(doc_check["average_days"], 4.0)

    def test_average_days_is_independent_per_box(self):
        rows = [
            {"Status": "01-NewApp", "Stage Length": "10 Days ago"},
            {"Status": "02-PendingQA", "Stage Length": "2 Days ago"},
        ]
        summary = build_pipeline_backlog_summary(rows)
        by_label = {b["label"]: b["average_days"] for b in summary}
        self.assertEqual(by_label["Doc Check"], 10.0)
        self.assertEqual(by_label["QA"], 2.0)

    def _status_for(self, label, count):
        box_status = {
            "Doc Check": "01-NewApp",
            "QA": "02-PendingQA",
            "Submitting (2026)": "03-PendingSubmission",
        }[label]
        extra = {"Intake": "September 2026"} if label == "Submitting (2026)" else {}
        rows = self._rows(box_status, count, **extra)
        summary = build_pipeline_backlog_summary(rows)
        return next(b["status"] for b in summary if b["label"] == label)


class BuildOxfordKpiMatrixTests(unittest.TestCase):
    """The KPI page's Oxford KPI section - a daily Consultant-by-date QA
    Passed matrix restricted to Sales Office "OXF", with a fixed per-cell
    colour rule (0 = red, 1 = yellow, 2+ = green)."""

    def test_only_oxf_sales_office_rows_are_included(self):
        rows = [
            {"QA Passed": "2026-09-02", "Consultant": "Raneen", "Sales Office": "OXF"},
            {"QA Passed": "2026-09-02", "Consultant": "Mustapha", "Sales Office": "CAR"},
        ]
        matrix = build_oxford_kpi_matrix(rows, 2026, 9)
        self.assertEqual(matrix["support_people"], ["Raneen"])
        self.assertEqual(matrix["grand_total"], 1)

    def test_consultants_across_top_and_dates_down_the_side(self):
        rows = [
            {"QA Passed": "2026-09-02", "Consultant": "Raneen", "Sales Office": "OXF"},
            {"QA Passed": "2026-09-02", "Consultant": "Solyman", "Sales Office": "OXF"},
            {"QA Passed": "2026-09-03", "Consultant": "Raneen", "Sales Office": "OXF"},
        ]
        matrix = build_oxford_kpi_matrix(rows, 2026, 9)
        self.assertEqual(matrix["support_people"], ["Raneen", "Solyman"])
        self.assertEqual([d["label"] for d in matrix["day_rows"]], ["02 Sep", "03 Sep"])
        self.assertEqual(matrix["day_rows"][0]["counts"], [1, 1])
        self.assertEqual(matrix["day_rows"][1]["counts"], [1, 0])

    def test_cell_status_zero_is_red_one_is_yellow_two_is_green(self):
        rows = (
            [{"QA Passed": "2026-09-02", "Consultant": "Raneen", "Sales Office": "OXF"}]
            + [{"QA Passed": "2026-09-02", "Consultant": "Solyman", "Sales Office": "OXF"} for _ in range(2)]
        )
        matrix = build_oxford_kpi_matrix(rows, 2026, 9)
        day = matrix["day_rows"][0]
        raneen_idx = matrix["support_people"].index("Raneen")
        solyman_idx = matrix["support_people"].index("Solyman")
        self.assertEqual(day["cell_status"][raneen_idx], "yellow")
        self.assertEqual(day["cell_status"][solyman_idx], "green")

    def test_cell_status_three_or_more_is_dark_green(self):
        rows = [{"QA Passed": "2026-09-02", "Consultant": "Solyman", "Sales Office": "OXF"} for _ in range(3)]
        matrix = build_oxford_kpi_matrix(rows, 2026, 9)
        day = matrix["day_rows"][0]
        solyman_idx = matrix["support_people"].index("Solyman")
        self.assertEqual(day["cell_status"][solyman_idx], "dark-green")
        self.assertEqual(day["counts"][solyman_idx], 3)

    def test_a_consultant_with_zero_on_a_day_another_consultant_has_activity_is_red(self):
        rows = [
            {"QA Passed": "2026-09-02", "Consultant": "Raneen", "Sales Office": "OXF"},
            {"QA Passed": "2026-09-03", "Consultant": "Solyman", "Sales Office": "OXF"},
        ]
        matrix = build_oxford_kpi_matrix(rows, 2026, 9)
        day_2 = next(d for d in matrix["day_rows"] if d["label"] == "02 Sep")
        solyman_idx = matrix["support_people"].index("Solyman")
        self.assertEqual(day_2["cell_status"][solyman_idx], "red")
        self.assertEqual(day_2["counts"][solyman_idx], 0)

    def test_rows_outside_the_selected_month_are_excluded(self):
        rows = [
            {"QA Passed": "2026-08-02", "Consultant": "Raneen", "Sales Office": "OXF"},
            {"QA Passed": "2026-09-02", "Consultant": "Raneen", "Sales Office": "OXF"},
        ]
        matrix = build_oxford_kpi_matrix(rows, 2026, 9)
        self.assertEqual(matrix["grand_total"], 1)

    def test_no_oxf_rows_this_month_gives_empty_matrix(self):
        rows = [{"QA Passed": "2026-09-02", "Consultant": "Mustapha", "Sales Office": "CAR"}]
        matrix = build_oxford_kpi_matrix(rows, 2026, 9)
        self.assertEqual(matrix["day_rows"], [])
        self.assertEqual(matrix["support_people"], [])

    def test_a_student_with_two_qualifying_applications_this_month_counts_once(self):
        # Same Student Code, two applications (e.g. two courses), both QA
        # Passed within the month - must count as 1, not 2, matching
        # _group_qualifying_rows()'s Student-Code dedup rule so this
        # section's Month Total always agrees with the OXF card's Actual.
        rows = [
            {
                "Student Code": "PES1",
                "QA Passed": "2026-09-02",
                "Consultant": "Raneen",
                "Sales Office": "OXF",
            },
            {
                "Student Code": "PES1",
                "QA Passed": "2026-09-03",
                "Consultant": "Raneen",
                "Sales Office": "OXF",
            },
        ]
        matrix = build_oxford_kpi_matrix(rows, 2026, 9)
        self.assertEqual(matrix["grand_total"], 1)
        self.assertEqual(sum(day["total"] for day in matrix["day_rows"]), 1)

    def test_grand_total_always_matches_build_kpi_report_oxf_actual(self):
        rows = [
            {
                "Student Code": "PES1",
                "QA Passed": "2026-09-02",
                "Consultant": "Raneen",
                "Sales Office": "OXF",
            },
            {
                "Student Code": "PES1",
                "QA Passed": "2026-09-03",
                "Consultant": "Raneen",
                "Sales Office": "OXF",
            },
            {
                "Student Code": "PES2",
                "QA Passed": "2026-09-04",
                "Consultant": "Solyman",
                "Sales Office": "OXF",
            },
            {
                "Student Code": "PES3",
                "QA Passed": "2026-09-05",
                "Consultant": "Mustapha",
                "Sales Office": "CAR",
            },
        ]
        matrix = build_oxford_kpi_matrix(rows, 2026, 9)
        report = build_kpi_report(rows, 2026, 9, {}, None)
        oxf_actual = next(so["actual"] for so in report["sales_offices"] if so["label"] == "OXF")
        self.assertEqual(matrix["grand_total"], oxf_actual)


class BuildKpiProgressChartTests(unittest.TestCase):
    """The KPI page's Sales Office Progress line chart - a cumulative
    QA-Passed-vs-target % line per Sales Office across the selected month,
    with a "pace to target" segment from today to month end when the
    selected month is the current one."""

    def _row(self, student_code, qa_passed, consultant, office):
        return {
            "Student Code": student_code,
            "QA Passed": qa_passed,
            "Consultant": consultant,
            "Sales Office": office,
        }

    def test_offices_without_a_target_are_excluded(self):
        rows = [self._row("P1", "2026-09-02", "Raneen", "OXF")]
        chart = build_kpi_progress_chart(rows, 2026, 9, {}, today=None)
        self.assertEqual(chart["lines"], [])

    def test_a_zero_or_negative_target_is_treated_as_not_set(self):
        rows = [self._row("P1", "2026-09-02", "Raneen", "OXF")]
        chart = build_kpi_progress_chart(rows, 2026, 9, {"OXF": 0}, today=None)
        self.assertEqual(chart["lines"], [])
        chart = build_kpi_progress_chart(rows, 2026, 9, {"OXF": -5}, today=None)
        self.assertEqual(chart["lines"], [])

    def test_cumulative_totals_build_up_across_the_month(self):
        rows = [
            self._row("P1", "2026-09-01", "Raneen", "OXF"),
            self._row("P2", "2026-09-03", "Raneen", "OXF"),
            self._row("P3", "2026-09-03", "Solyman", "OXF"),
        ]
        chart = build_kpi_progress_chart(rows, 2026, 9, {"OXF": 10}, today=None)
        line = chart["lines"][0]
        by_day = {p["day"]: p["actual"] for p in line["actual_points"]}
        self.assertEqual(by_day[1], 1)
        self.assertEqual(by_day[2], 1)  # unchanged - no QA Passed that day
        self.assertEqual(by_day[3], 3)
        self.assertEqual(line["final_actual"], 3)
        self.assertEqual(line["final_pct"], 30.0)

    def test_a_student_with_two_qualifying_applications_this_month_counts_once(self):
        rows = [
            self._row("P1", "2026-09-01", "Raneen", "OXF"),
            self._row("P1", "2026-09-02", "Raneen", "OXF"),
        ]
        chart = build_kpi_progress_chart(rows, 2026, 9, {"OXF": 10}, today=None)
        self.assertEqual(chart["lines"][0]["final_actual"], 1)

    def test_final_actual_matches_build_kpi_reports_actual_for_that_office(self):
        rows = [
            self._row("P1", "2026-09-01", "Raneen", "OXF"),
            self._row("P2", "2026-09-05", "Solyman", "OXF"),
            self._row("P3", "2026-09-10", "Mustapha", "CAR"),
        ]
        targets = {"OXF": 100, "CAR": 50}
        chart = build_kpi_progress_chart(rows, 2026, 9, targets, today=None)
        report = build_kpi_report(rows, 2026, 9, targets, None)
        report_by_office = {so["label"]: so["actual"] for so in report["sales_offices"]}
        for line in chart["lines"]:
            self.assertEqual(line["final_actual"], report_by_office[line["office"]])

    def test_no_pace_segment_when_today_is_not_given(self):
        rows = [self._row("P1", "2026-09-01", "Raneen", "OXF")]
        chart = build_kpi_progress_chart(rows, 2026, 9, {"OXF": 10}, today=None)
        self.assertFalse(chart["on_target_month"])
        self.assertEqual(chart["lines"][0]["pace_points"], [])
        # The whole month's actual data is present - not cut off at "today".
        self.assertEqual(len(chart["lines"][0]["actual_points"]), 30)

    def test_no_pace_segment_when_today_is_in_a_different_month(self):
        rows = [self._row("P1", "2026-09-01", "Raneen", "OXF")]
        chart = build_kpi_progress_chart(rows, 2026, 9, {"OXF": 10}, today=date(2026, 10, 5))
        self.assertFalse(chart["on_target_month"])
        self.assertEqual(chart["lines"][0]["pace_points"], [])

    def test_pace_segment_present_when_today_is_within_the_selected_month(self):
        rows = [
            self._row("P1", "2026-09-01", "Raneen", "OXF"),
            self._row("P2", "2026-09-02", "Raneen", "OXF"),
        ]
        chart = build_kpi_progress_chart(rows, 2026, 9, {"OXF": 10}, today=date(2026, 9, 10))
        self.assertTrue(chart["on_target_month"])
        self.assertEqual(chart["today_day"], 10)
        line = chart["lines"][0]
        # Actual data only goes up to today (day 10) - not the whole month.
        self.assertEqual(len(line["actual_points"]), 10)
        self.assertEqual(line["actual_points"][-1]["day"], 10)
        self.assertEqual(line["final_actual"], 2)
        self.assertEqual(line["final_pct"], 20.0)
        # Pace segment runs from today's actual % to 100% on the last day.
        self.assertEqual(line["pace_points"], [{"day": 10, "pct": 20.0}, {"day": 30, "pct": 100.0}])

    def test_no_pace_segment_when_today_is_the_last_day_of_the_month(self):
        rows = [self._row("P1", "2026-09-01", "Raneen", "OXF")]
        chart = build_kpi_progress_chart(rows, 2026, 9, {"OXF": 10}, today=date(2026, 9, 30))
        self.assertTrue(chart["on_target_month"])
        self.assertEqual(chart["lines"][0]["pace_points"], [])

    def test_max_pct_scales_up_when_an_office_exceeds_target(self):
        rows = [self._row(f"P{i}", "2026-09-01", "Raneen", "OXF") for i in range(15)]
        chart = build_kpi_progress_chart(rows, 2026, 9, {"OXF": 10}, today=None)
        self.assertEqual(chart["lines"][0]["final_pct"], 150.0)
        self.assertGreater(chart["max_pct"], 100.0)
        # y_ticks always extend at least to the actual max, in steps of 25.
        self.assertEqual(chart["y_ticks"][-1]["pct"], 150)

    def test_y_ticks_top_out_at_100_when_nothing_exceeds_target(self):
        rows = [self._row("P1", "2026-09-01", "Raneen", "OXF")]
        chart = build_kpi_progress_chart(rows, 2026, 9, {"OXF": 10}, today=None)
        self.assertEqual([t["pct"] for t in chart["y_ticks"]], [0, 25, 50, 75, 100])

    def test_svg_points_span_the_full_x_axis_width(self):
        rows = [self._row("P1", "2026-09-01", "Raneen", "OXF")]
        chart = build_kpi_progress_chart(rows, 2026, 9, {"OXF": 10}, today=None)
        points = chart["lines"][0]["actual_svg_points"].split(" ")
        first_x = float(points[0].split(",")[0])
        last_x = float(points[-1].split(",")[0])
        self.assertEqual(first_x, 0.0)
        self.assertEqual(last_x, 100.0)

    def test_each_office_gets_a_distinct_color(self):
        rows = [
            self._row("P1", "2026-09-01", "Raneen", "OXF"),
            self._row("P2", "2026-09-01", "Mustapha", "CAR"),
        ]
        chart = build_kpi_progress_chart(rows, 2026, 9, {"OXF": 10, "CAR": 10}, today=None)
        colors = [line["color"] for line in chart["lines"]]
        self.assertEqual(len(colors), len(set(colors)))

    def test_num_days_matches_the_calendar_month(self):
        rows = []
        chart = build_kpi_progress_chart(rows, 2026, 2, {"OXF": 10}, today=None)  # Feb 2026 (not a leap year)
        self.assertEqual(chart["num_days"], 28)


class KpiTargetPersistenceTests(unittest.TestCase):
    """Uses an isolated in-memory SQLite connection - never touches the
    real application database."""

    def setUp(self):
        self.conn = sqlite3.connect(":memory:")
        self.conn.row_factory = sqlite3.Row
        self.conn.execute(
            """
            CREATE TABLE kpi_targets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                year INTEGER NOT NULL,
                month INTEGER NOT NULL,
                target_type TEXT NOT NULL,
                target_value INTEGER NOT NULL,
                UNIQUE(year, month, target_type)
            )
            """
        )
        self.conn.commit()

    def tearDown(self):
        self.conn.close()

    def test_set_and_get_round_trip(self):
        set_kpi_target(self.conn, 2026, 8, "OXF", "280")
        targets = get_kpi_targets(self.conn, 2026, 8)
        self.assertEqual(targets["OXF"], 280)

    def test_update_replaces_previous_value_for_same_month(self):
        set_kpi_target(self.conn, 2026, 8, "OXF", "100")
        set_kpi_target(self.conn, 2026, 8, "OXF", "280")
        targets = get_kpi_targets(self.conn, 2026, 8)
        self.assertEqual(targets["OXF"], 280)

    def test_targets_are_independent_across_months(self):
        set_kpi_target(self.conn, 2026, 8, "OXF", "280")
        set_kpi_target(self.conn, 2026, 9, "OXF", "999")
        self.assertEqual(get_kpi_targets(self.conn, 2026, 8)["OXF"], 280)
        self.assertEqual(get_kpi_targets(self.conn, 2026, 9)["OXF"], 999)

    def test_negative_value_is_rejected(self):
        with self.assertRaises(KpiTargetValidationError):
            set_kpi_target(self.conn, 2026, 8, "OXF", "-10")

    def test_non_numeric_value_is_rejected(self):
        with self.assertRaises(KpiTargetValidationError):
            set_kpi_target(self.conn, 2026, 8, "OXF", "abc")

    def test_missing_target_returns_no_key_not_zero(self):
        targets = get_kpi_targets(self.conn, 2026, 8)
        self.assertNotIn("OXF", targets)


if __name__ == "__main__":
    unittest.main()
