import io
import unittest
from datetime import date, datetime

import openpyxl
from openpyxl.cell.cell import TYPE_FORMULA, TYPE_STRING
from openpyxl.utils import get_column_letter

from excel_export_helpers import (
    apply_column_widths,
    apply_date_format,
    safe_append_row,
    safe_sheet_title,
    unique_sheet_title,
)


class SafeAppendRowTests(unittest.TestCase):
    """safe_append_row() - Finding 11's formula-injection fix. The
    approved rule, based on empirically testing this project's actual
    openpyxl version (3.1.5) by writing real files and inspecting the
    raw saved XML, not assumed:

    - Only a string starting with "=" is protected (openpyxl auto-
      promotes it to a live formula cell otherwise - confirmed via the
      saved <f> element).
    - Strings starting with "+", "-", or "@" are deliberately left
      untouched - confirmed these are already stored as plain string
      cells by this openpyxl version, never auto-promoted.
    - The check is on the raw, unstripped first character - leading
      whitespace before "=" already isn't promoted by openpyxl, so there
      is nothing to additionally guard.
    - A protected cell must contain the exact original text, with
      nothing added or removed - confirmed via a save+reload round-trip
      through a real file, not just the in-memory API.
    """

    def _fresh_sheet(self):
        wb = openpyxl.Workbook()
        return wb, wb.active

    def _round_trip(self, wb):
        """Save to a real in-memory buffer and reload with openpyxl -
        catches anything the in-memory API alone would miss."""
        buffer = io.BytesIO()
        wb.save(buffer)
        buffer.seek(0)
        return openpyxl.load_workbook(buffer)

    def test_normal_text_remains_unchanged(self):
        wb, ws = self._fresh_sheet()
        safe_append_row(ws, ["Student Name", "TSD", ""])
        reloaded = self._round_trip(wb).active
        self.assertEqual([c.value for c in reloaded[1]], ["Student Name", "TSD", None])
        self.assertEqual(reloaded["A1"].data_type, TYPE_STRING)

    def test_equals_prefixed_string_is_neutralised_but_visually_identical(self):
        wb, ws = self._fresh_sheet()
        safe_append_row(ws, ["=SUM(A1:A2)"])
        self.assertEqual(ws["A1"].data_type, TYPE_STRING)
        self.assertEqual(ws["A1"].value, "=SUM(A1:A2)")

        reloaded = self._round_trip(wb).active
        self.assertEqual(reloaded["A1"].value, "=SUM(A1:A2)")
        self.assertEqual(reloaded["A1"].data_type, TYPE_STRING)

    def test_leading_whitespace_before_equals_is_left_unchanged(self):
        wb, ws = self._fresh_sheet()
        safe_append_row(ws, [" =SUM(A1:A2)"])
        # Already stored as a plain string by openpyxl itself (confirmed
        # empirically) - safe_append_row must not alter it further.
        self.assertEqual(ws["A1"].data_type, TYPE_STRING)
        self.assertEqual(ws["A1"].value, " =SUM(A1:A2)")

    def test_plus_prefixed_string_is_left_unchanged(self):
        wb, ws = self._fresh_sheet()
        safe_append_row(ws, ["+1+1"])
        self.assertEqual(ws["A1"].value, "+1+1")
        self.assertEqual(ws["A1"].data_type, TYPE_STRING)

    def test_minus_prefixed_string_is_left_unchanged(self):
        wb, ws = self._fresh_sheet()
        safe_append_row(ws, ["-1+1"])
        self.assertEqual(ws["A1"].value, "-1+1")
        self.assertEqual(ws["A1"].data_type, TYPE_STRING)

    def test_at_prefixed_string_is_left_unchanged(self):
        wb, ws = self._fresh_sheet()
        safe_append_row(ws, ["@SUM(1,1)"])
        self.assertEqual(ws["A1"].value, "@SUM(1,1)")
        self.assertEqual(ws["A1"].data_type, TYPE_STRING)

    def test_genuine_negative_number_is_not_corrupted(self):
        wb, ws = self._fresh_sheet()
        safe_append_row(ws, [-42, -3.14])
        self.assertEqual(ws["A1"].value, -42)
        self.assertEqual(ws["A1"].data_type, "n")
        self.assertEqual(ws["B1"].value, -3.14)
        self.assertEqual(ws["B1"].data_type, "n")

    def test_date_and_datetime_values_remain_their_original_type(self):
        wb, ws = self._fresh_sheet()
        d = date(2026, 1, 15)
        dt = datetime(2026, 1, 15, 9, 30)
        safe_append_row(ws, [d, dt])
        self.assertEqual(ws["A1"].value, d)
        self.assertEqual(ws["A1"].data_type, "d")
        self.assertEqual(ws["B1"].value, dt)
        self.assertEqual(ws["B1"].data_type, "d")

    def test_bool_and_none_remain_their_original_type(self):
        wb, ws = self._fresh_sheet()
        safe_append_row(ws, [True, False, None])
        self.assertEqual(ws["A1"].value, True)
        self.assertEqual(ws["A1"].data_type, "b")
        self.assertEqual(ws["B1"].value, False)
        self.assertEqual(ws["B1"].data_type, "b")
        self.assertIsNone(ws["C1"].value)

    def test_without_the_fix_openpyxl_would_have_promoted_it_to_a_formula(self):
        # Confirms the fixture itself is meaningful - a bare ws.append()
        # really would produce a live formula cell, so the protection
        # above is actually doing something, not passing vacuously.
        wb, ws = self._fresh_sheet()
        ws.append(["=SUM(A1:A2)"])
        self.assertEqual(ws["A1"].data_type, TYPE_FORMULA)

    def test_workbook_opens_successfully_after_mixed_row(self):
        wb, ws = self._fresh_sheet()
        safe_append_row(ws, ["Student Name", "=SUM(1,1)", -5, date(2026, 1, 1), None])
        reloaded = self._round_trip(wb).active
        self.assertEqual(reloaded["A1"].value, "Student Name")
        self.assertEqual(reloaded["B1"].value, "=SUM(1,1)")
        self.assertEqual(reloaded["B1"].data_type, TYPE_STRING)
        self.assertEqual(reloaded["C1"].value, -5)
        self.assertEqual(reloaded["D1"].value, datetime(2026, 1, 1, 0, 0))
        self.assertIsNone(reloaded["E1"].value)


class SafeSheetTitleTests(unittest.TestCase):
    """safe_sheet_title() - extracted verbatim from the 4 export modules
    that each defined this identically (Finding 14)."""

    def test_illegal_characters_are_stripped(self):
        self.assertEqual(safe_sheet_title(r'A\B/C?D*E[F]G:H'), "ABCDEFGH")

    def test_thirty_one_character_limit_is_enforced(self):
        label = "A" * 50
        result = safe_sheet_title(label)
        self.assertEqual(len(result), 31)
        self.assertEqual(result, "A" * 31)

    def test_blank_label_falls_back_to_default(self):
        self.assertEqual(safe_sheet_title(""), "Unassigned")
        self.assertEqual(safe_sheet_title(None), "Unassigned")
        # Illegal-characters-only also reduces to nothing, same as blank.
        self.assertEqual(safe_sheet_title("///"), "Unassigned")

    def test_custom_fallback_is_used_instead_of_the_default(self):
        self.assertEqual(safe_sheet_title("", fallback="Offer Days"), "Offer Days")
        self.assertEqual(safe_sheet_title(None, fallback="Offer Days"), "Offer Days")

    def test_whitespace_only_label_falls_back(self):
        self.assertEqual(safe_sheet_title("   "), "Unassigned")

    def test_normal_label_is_unchanged(self):
        self.assertEqual(safe_sheet_title("TSD"), "TSD")


class UniqueSheetTitleTests(unittest.TestCase):
    """unique_sheet_title() - the collision-avoiding wrapper, also
    extracted verbatim from all 4 modules."""

    def test_first_use_of_a_title_is_unchanged(self):
        self.assertEqual(unique_sheet_title("TSD", set()), "TSD")

    def test_collision_appends_numbered_suffix(self):
        self.assertEqual(unique_sheet_title("TSD", {"TSD"}), "TSD (2)")
        self.assertEqual(unique_sheet_title("TSD", {"TSD", "TSD (2)"}), "TSD (3)")

    def test_suffix_still_respects_the_thirty_one_character_maximum(self):
        label = "A" * 31
        used = {label}
        result = unique_sheet_title(label, used)
        self.assertEqual(len(result), 31)
        self.assertEqual(result, "A" * 27 + " (2)")

    def test_fallback_is_applied_before_de_duplication(self):
        self.assertEqual(unique_sheet_title("", {"Unassigned"}, fallback="Unassigned"), "Unassigned (2)")


class ApplyColumnWidthsTests(unittest.TestCase):
    """apply_column_widths() - max(12, min(40, len(name) + 4)), identical
    across all 7 export modules before this extraction."""

    def test_lower_clamp_for_short_column_names(self):
        wb = openpyxl.Workbook()
        ws = wb.active
        apply_column_widths(ws, ["ID"])
        self.assertEqual(ws.column_dimensions["A"].width, 12)

    def test_upper_clamp_for_long_column_names(self):
        wb = openpyxl.Workbook()
        ws = wb.active
        apply_column_widths(ws, ["A Very Long Column Name That Exceeds The Cap"])
        self.assertEqual(ws.column_dimensions["A"].width, 40)

    def test_middle_width_is_name_length_plus_four(self):
        wb = openpyxl.Workbook()
        ws = wb.active
        apply_column_widths(ws, ["Student Name"])  # len=12 -> 12+4=16
        self.assertEqual(ws.column_dimensions["A"].width, 16)

    def test_each_column_gets_its_own_independent_width(self):
        wb = openpyxl.Workbook()
        ws = wb.active
        apply_column_widths(ws, ["ID", "Student Name", "A Very Long Column Name That Exceeds The Cap"])
        self.assertEqual(ws.column_dimensions["A"].width, 12)
        self.assertEqual(ws.column_dimensions["B"].width, 16)
        self.assertEqual(ws.column_dimensions["C"].width, 40)


class ApplyDateFormatTests(unittest.TestCase):
    """apply_date_format() - applies "DD/MM/YYYY" only to the named date
    columns, starting below whichever row the header actually sits on."""

    def test_formats_only_the_specified_date_columns(self):
        wb = openpyxl.Workbook()
        ws = wb.active
        columns = ["Student Name", "Enrolled Date", "Status"]
        ws.append(columns)
        ws.append(["Nina", date(2026, 9, 1), "09-Enrolled"])
        apply_date_format(ws, columns, {"Enrolled Date"})
        self.assertEqual(ws["B2"].number_format, "DD/MM/YYYY")
        # Non-date columns must not be touched.
        self.assertNotEqual(ws["A2"].number_format, "DD/MM/YYYY")
        self.assertNotEqual(ws["C2"].number_format, "DD/MM/YYYY")

    def test_header_row_itself_is_never_formatted(self):
        wb = openpyxl.Workbook()
        ws = wb.active
        columns = ["Enrolled Date"]
        ws.append(columns)
        ws.append([date(2026, 9, 1)])
        apply_date_format(ws, columns, {"Enrolled Date"})
        self.assertNotEqual(ws["A1"].number_format, "DD/MM/YYYY")
        self.assertEqual(ws["A2"].number_format, "DD/MM/YYYY")

    def test_header_row_offset_respected_for_a_two_row_header(self):
        # application_manager_export.py's shape: a title row above the
        # header, so the real header sits on row 2 and data starts row 3.
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.append(["Title Row"])
        ws.append(["Date Submitted to University"])
        ws.append([date(2026, 9, 1)])
        apply_date_format(ws, ["Date Submitted to University"], {"Date Submitted to University"}, header_row=2)
        self.assertNotEqual(ws["A2"].number_format, "DD/MM/YYYY")
        self.assertEqual(ws["A3"].number_format, "DD/MM/YYYY")

    def test_no_date_columns_present_leaves_everything_unformatted(self):
        wb = openpyxl.Workbook()
        ws = wb.active
        columns = ["Student Name", "Status"]
        ws.append(columns)
        ws.append(["Nina", "09-Enrolled"])
        apply_date_format(ws, columns, set())
        self.assertNotEqual(ws["A2"].number_format, "DD/MM/YYYY")
        self.assertNotEqual(ws["B2"].number_format, "DD/MM/YYYY")


if __name__ == "__main__":
    unittest.main()
