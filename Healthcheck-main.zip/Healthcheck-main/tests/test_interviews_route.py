"""The rendered /interviews page: students whose Status is 00-QARejected, 08-Pre-Enrolled,
09-Enrolled or 10-Lost are left off every day's table (Today and Tomorrow checked here),
through a real upload, so the status lookup is exercised too."""

import io
from datetime import date, timedelta
from unittest import mock

from interviews import EXCLUDED_INTERVIEW_STATUSES
from tests.flask_test_support import IsolatedAppTestCase, app_module, extract_token
from tests.test_upload_atomicity import book, row

TODAY, TOMORROW = date(2026, 8, 13), date(2026, 8, 14)
STATUS_LOOKUP = [
    ("QA Rejected", "00-QARejected"), ("Pending QA", "02-PendingQA"), ("Assessment", "05-Assessment"), ("Ready", "07-Ready"),
    ("Pre Enrolled", "08-Pre-Enrolled"), ("Enrolled", "09-Enrolled"), ("Lost", "10-Lost"),
]
# (student, raw status, interview day) - every student has an interview booked
STUDENTS = [
    ("Kept Pending", "Pending QA", "13/08/2026"), ("Kept Assessment", "Assessment", "13/08/2026"),
    ("Hidden QARejected", "QA Rejected", "13/08/2026"), ("Hidden PreEnrolled", "Pre Enrolled", "13/08/2026"), ("Hidden Enrolled", "Enrolled", "13/08/2026"),
    ("Hidden Lost", "Lost", "13/08/2026"),
    ("Kept Ready", "Ready", "14/08/2026"), ("Hidden QARejected Tmrw", "QA Rejected", "14/08/2026"), ("Hidden PreEnrolled Tmrw", "Pre Enrolled", "14/08/2026"),
    ("Hidden Enrolled Tmrw", "Enrolled", "14/08/2026"), ("Hidden Lost Tmrw", "Lost", "14/08/2026"),
]


class InterviewsPageStatusTests(IsolatedAppTestCase):
    def setUp(self):
        super().setUp()
        self.client = self._client_logged_in_as("full")
        rows = [
            row(**{"Student Code": f"PES-{i}", "Student Name": name, "Application Status": status,
                   "Counsellor": "Gina X", "Admission Officer": "Alice Brown", "University Name": "Test Uni",
                   "Intake": "September 2026", "Interview Booked Date/Time": f"{day} 10:00"})
            for i, (name, status, day) in enumerate(STUDENTS, start=1)
        ]
        data = book(rows, lookups={"status": STATUS_LOOKUP})
        token = extract_token(self.client.get("/login").get_data(as_text=True))
        response = self.client.post(
            "/upload", data={"csrf_token": token, "excel_file": (io.BytesIO(data), "t.xlsx")},
            content_type="multipart/form-data",
        )
        self.assertEqual(response.status_code, 302)

    def page(self):
        with mock.patch.object(app_module, "get_operational_days", return_value=[TODAY, TOMORROW] + [TOMORROW + timedelta(days=n) for n in (4, 5, 6)]):
            response = self.client.get("/interviews")
        self.assertEqual(response.status_code, 200)
        return response.get_data(as_text=True)

    def test_excluded_statuses_are_not_listed_in_either_section(self):
        page = self.page()
        for name, status, _day in STUDENTS:
            if name.startswith("Hidden"):
                self.assertNotIn(name, page, name)

    def test_other_students_are_still_listed_in_the_right_section(self):
        page = self.page()
        tomorrow_start = page.index("Interviews Tomorrow")
        for name in ("Kept Pending", "Kept Assessment"):
            self.assertIn(name, page)
            self.assertLess(page.index(name), tomorrow_start, name)
        self.assertIn("Kept Ready", page)
        self.assertGreater(page.index("Kept Ready"), tomorrow_start)

    def test_the_excluded_status_values_never_appear_in_the_status_column(self):
        page = self.page()
        for status in EXCLUDED_INTERVIEW_STATUSES:
            self.assertNotIn(f"<td>{status}</td>", page)
        self.assertIn("<td>05-Assessment</td>", page)

    def test_a_day_with_only_excluded_students_shows_the_empty_message(self):
        only_excluded = [r for r in STUDENTS if r[1] in ("QA Rejected", "Lost", "Enrolled", "Pre Enrolled")]
        self.assertTrue(only_excluded)
        days = [date(2026, 8, 14), date(2026, 8, 17), date(2026, 8, 18), date(2026, 8, 19), date(2026, 8, 20)]
        with mock.patch.object(app_module, "get_operational_days", return_value=days):
            page = self.client.get("/interviews").get_data(as_text=True)
        self.assertIn("Kept Ready", page)
        self.assertNotIn("Hidden", page)
        self.assertIn("No interviews scheduled for tomorrow.", page)
