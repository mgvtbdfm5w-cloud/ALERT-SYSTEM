"""Login brute-force protection.

POLICY (approved): 5 failed password attempts within 10 minutes -> the 5th
failure locks that client address out for 15 minutes. Keyed on
request.remote_addr only (X-Forwarded-For is never trusted); in memory, no
database, no new dependency. While locked the password is not even compared,
so a correct guess during a lockout gains nothing. Unicode and over-long
(>256 chars) passwords are just ordinary failed attempts - and count.

Two layers are tested here:
  1. LoginThrottle itself (pure unit tests, FakeClock, no Flask);
  2. the /login route through the shared isolated Flask test client, which
     gives every test a fresh throttle on a FakeClock (see
     tests/flask_test_support.py) - so nothing here ever sleeps, and no test
     can lock another one out.

Nothing touches the real data/app.db or uploads/ folder.
"""

import logging
import re
import threading
import unittest
from unittest import mock

from login_throttle import (
    FAILURE_WINDOW_SECONDS,
    LOCKOUT_SECONDS,
    MAX_FAILED_ATTEMPTS,
    MAX_TRACKED_CLIENTS,
    LoginThrottle,
)
from tests.flask_test_support import (
    ROLE_PASSWORDS,
    FakeClock,
    IsolatedAppTestCase,
    app_module,
    extract_token,
)

GENERIC_FAILURE = "Incorrect password."
LOCKED_MESSAGE = "Too many failed attempts. Please wait a few minutes and try again."
UNICODE_PASSWORDS = ["pässword", "pw😀", "パスワード", "пароль", "éclair", "‮evil", "𝕳𝖊𝖆𝖑𝖙𝖍"]


def make_throttle(**kwargs):
    clock = FakeClock()
    return LoginThrottle(clock=clock, **kwargs), clock


# =========================================================================
# 1. The limiter on its own
# =========================================================================
class PolicyConstantsTests(unittest.TestCase):
    def test_the_approved_policy(self):
        self.assertEqual(MAX_FAILED_ATTEMPTS, 5)
        self.assertEqual(FAILURE_WINDOW_SECONDS, 10 * 60)
        self.assertEqual(LOCKOUT_SECONDS, 15 * 60)
        self.assertGreaterEqual(MAX_TRACKED_CLIENTS, 100)

    def test_defaults_are_used_by_a_plain_instance(self):
        throttle = LoginThrottle()
        self.assertEqual(
            (throttle.max_failures, throttle.window_seconds, throttle.lockout_seconds, throttle.max_clients),
            (MAX_FAILED_ATTEMPTS, FAILURE_WINDOW_SECONDS, LOCKOUT_SECONDS, MAX_TRACKED_CLIENTS),
        )

    def test_invalid_configuration_is_refused(self):
        with self.assertRaises(ValueError):
            LoginThrottle(max_failures=0)
        with self.assertRaises(ValueError):
            LoginThrottle(max_clients=0)


class FailureCountingTests(unittest.TestCase):
    def test_failures_one_to_four_are_counted_and_do_not_lock(self):
        throttle, _ = make_throttle()
        for expected in (1, 2, 3, 4):
            result = throttle.record_failure("a")
            self.assertEqual((result.count, result.locked, result.retry_after), (expected, False, 0))
            self.assertFalse(throttle.is_locked("a"))

    def test_the_fifth_failure_locks_for_fifteen_minutes(self):
        throttle, _ = make_throttle()
        for _ in range(4):
            throttle.record_failure("a")
        result = throttle.record_failure("a")
        self.assertTrue(result.locked)
        self.assertEqual(result.count, 5)
        self.assertEqual(result.retry_after, 900)
        self.assertTrue(throttle.is_locked("a"))
        self.assertEqual(throttle.retry_after("a"), 900)

    def test_retry_after_counts_down_rounds_up_and_is_never_zero_while_locked(self):
        throttle, clock = make_throttle()
        for _ in range(5):
            throttle.record_failure("a")
        clock.advance(300)
        self.assertEqual(throttle.retry_after("a"), 600)
        clock.advance(0.2)
        self.assertEqual(throttle.retry_after("a"), 600)        # 599.8 -> rounded UP
        clock.advance(599.7)                                    # 0.1 s left
        self.assertTrue(throttle.is_locked("a"))
        self.assertEqual(throttle.retry_after("a"), 1)
        self.assertEqual(throttle.retry_after("never-seen"), 0)

    def test_the_lockout_expires_after_exactly_fifteen_minutes_and_state_resets(self):
        throttle, clock = make_throttle()
        for _ in range(5):
            throttle.record_failure("a")
        clock.advance(899.9)
        self.assertTrue(throttle.is_locked("a"))
        clock.advance(0.1)                                      # t = 900 s
        self.assertFalse(throttle.is_locked("a"))
        self.assertEqual(throttle.tracked_clients(), 0, "an expired lockout clears the client's whole state")
        self.assertEqual(throttle.record_failure("a").count, 1, "counting starts again from zero")

    def test_failures_expire_out_of_the_ten_minute_window(self):
        throttle, clock = make_throttle()
        for _ in range(4):
            throttle.record_failure("a")
        clock.advance(601)
        result = throttle.record_failure("a")
        self.assertEqual((result.count, result.locked), (1, False))

    def test_the_window_boundary_is_exact(self):
        throttle, clock = make_throttle()
        for _ in range(4):
            throttle.record_failure("a")
        clock.advance(599.9)                                    # still inside the window -> this is the 5th
        self.assertTrue(throttle.record_failure("a").locked)

        throttle, clock = make_throttle()
        for _ in range(4):
            throttle.record_failure("a")
        clock.advance(600)                                      # exactly 10 minutes old -> no longer counts
        self.assertEqual(throttle.record_failure("a").count, 1)

    def test_the_window_slides(self):
        throttle, clock = make_throttle()
        for _ in range(3):
            throttle.record_failure("a")                        # t = 0
        clock.advance(300)
        throttle.record_failure("a")                            # t = 300 (4 counted)
        clock.advance(301)                                      # t = 601: the three at t=0 are gone
        result = throttle.record_failure("a")
        self.assertEqual((result.count, result.locked), (2, False))

    def test_a_failure_reported_while_locked_is_not_counted_and_does_not_extend_the_lockout(self):
        throttle, clock = make_throttle()
        for _ in range(5):
            throttle.record_failure("a")
        clock.advance(100)
        result = throttle.record_failure("a")
        self.assertTrue(result.locked)
        self.assertEqual(throttle.retry_after("a"), 800)        # unchanged by the extra failure

    def test_clear_forgets_a_client(self):
        throttle, _ = make_throttle()
        for _ in range(4):
            throttle.record_failure("a")
        throttle.clear("a")
        self.assertEqual(throttle.tracked_clients(), 0)
        self.assertEqual(throttle.record_failure("a").count, 1)
        throttle.clear("never-seen")                            # harmless

    def test_clients_are_independent(self):
        throttle, _ = make_throttle()
        for _ in range(5):
            throttle.record_failure("a")
        self.assertTrue(throttle.is_locked("a"))
        self.assertFalse(throttle.is_locked("b"))
        self.assertEqual(throttle.record_failure("b").count, 1)

    def test_rejections_are_counted_per_lockout_so_callers_can_log_the_first_only(self):
        throttle, clock = make_throttle()
        self.assertEqual(throttle.record_rejection("a"), 0)     # not locked
        for _ in range(5):
            throttle.record_failure("a")
        self.assertEqual([throttle.record_rejection("a") for _ in range(3)], [1, 2, 3])
        clock.advance(900)
        self.assertEqual(throttle.record_rejection("a"), 0)     # lockout over
        for _ in range(5):
            throttle.record_failure("a")
        self.assertEqual(throttle.record_rejection("a"), 1, "a new lockout starts a new rejection count")


class MemoryBoundTests(unittest.TestCase):
    def test_stale_entries_are_pruned_by_prune(self):
        throttle, clock = make_throttle()
        for i in range(10):
            throttle.record_failure(f"addr-{i}")
        self.assertEqual(throttle.tracked_clients(), 10)
        clock.advance(601)
        throttle.prune()
        self.assertEqual(throttle.tracked_clients(), 0)

    def test_locked_entries_survive_pruning_until_the_lockout_ends(self):
        throttle, clock = make_throttle()
        for _ in range(5):
            throttle.record_failure("locked")
        throttle.record_failure("just-failed-once")
        clock.advance(601)                                      # failure window over, lockout (900 s) not
        throttle.prune()
        self.assertEqual(throttle.tracked_clients(), 1)
        self.assertTrue(throttle.is_locked("locked"))
        clock.advance(300)
        throttle.prune()
        self.assertEqual(throttle.tracked_clients(), 0)

    def test_stale_entries_are_dropped_whenever_a_new_address_is_added(self):
        throttle, clock = make_throttle()
        for i in range(50):
            throttle.record_failure(f"old-{i}")
        clock.advance(601)
        throttle.record_failure("new")                          # adding a key sweeps the stale ones
        self.assertEqual(throttle.tracked_clients(), 1)

    def test_the_hard_cap_can_never_be_exceeded(self):
        throttle, _ = make_throttle(max_clients=5)
        for i in range(500):
            throttle.record_failure(f"addr-{i}")                # all fresh, none stale
            self.assertLessEqual(throttle.tracked_clients(), 5)
        self.assertEqual(throttle.tracked_clients(), 5)

    def test_the_cap_holds_even_when_every_entry_is_locked(self):
        throttle, _ = make_throttle(max_clients=3)
        for i in range(10):
            for _ in range(5):
                throttle.record_failure(f"addr-{i}")            # each one gets locked
            self.assertLessEqual(throttle.tracked_clients(), 3)
        self.assertEqual(throttle.tracked_clients(), 3)

    def test_eviction_prefers_unlocked_entries_so_a_lockout_survives_churn(self):
        throttle, _ = make_throttle(max_clients=3)
        for _ in range(5):
            throttle.record_failure("locked")
        for i in range(20):
            throttle.record_failure(f"churn-{i}")
        self.assertTrue(throttle.is_locked("locked"))
        self.assertLessEqual(throttle.tracked_clients(), 3)

    def test_the_default_cap_is_honoured_under_a_flood_of_addresses(self):
        throttle, _ = make_throttle()
        for i in range(MAX_TRACKED_CLIENTS * 3):
            throttle.record_failure(f"10.{i // 65536}.{(i // 256) % 256}.{i % 256}")
        self.assertEqual(throttle.tracked_clients(), MAX_TRACKED_CLIENTS)


class RestartAndConcurrencyTests(unittest.TestCase):
    def test_a_restart_forgets_everything_by_design(self):
        """State is per process and in memory only (documented in
        login_throttle.py): a new instance - what a restart gives - starts
        clean, and reset_all() does the same in place."""
        throttle, _ = make_throttle()
        for _ in range(5):
            throttle.record_failure("a")
        self.assertTrue(throttle.is_locked("a"))
        restarted, _ = make_throttle()
        self.assertFalse(restarted.is_locked("a"))
        throttle.reset_all()
        self.assertFalse(throttle.is_locked("a"))
        self.assertEqual(throttle.tracked_clients(), 0)

    def test_the_throttle_never_touches_the_database_or_the_filesystem(self):
        import inspect
        import login_throttle
        source = inspect.getsource(login_throttle)
        code = "\n".join(line for line in source.splitlines() if not line.lstrip().startswith(("#", '"""')))
        for forbidden in ("sqlite3", "open(", "pathlib", "get_connection"):
            self.assertNotIn(forbidden, code)

    def test_concurrent_failures_are_all_counted_exactly(self):
        throttle, _ = make_throttle(max_failures=1000)
        errors = []

        def worker():
            try:
                for _ in range(50):
                    throttle.record_failure("shared")
            except Exception as exc:  # pragma: no cover - only on a race bug
                errors.append(exc)

        threads = [threading.Thread(target=worker) for _ in range(20)]       # 20 * 50 = 1000 failures
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        self.assertEqual(errors, [])
        self.assertTrue(throttle.is_locked("shared"), "exactly the 1000th failure must have locked it")

    def test_concurrent_new_addresses_respect_the_cap(self):
        throttle, _ = make_throttle(max_clients=50)

        def worker(n):
            for i in range(200):
                throttle.record_failure(f"t{n}-{i}")

        threads = [threading.Thread(target=worker, args=(n,)) for n in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        self.assertLessEqual(throttle.tracked_clients(), 50)


# =========================================================================
# 2. The /login route
# =========================================================================
class LoginRouteTestCase(IsolatedAppTestCase):
    SECRET_GUESS = "SuperSecret-Guess-7q9Z!"

    def client_at(self, address="127.0.0.1"):
        client = app_module.app.test_client()
        client.environ_base["REMOTE_ADDR"] = address
        return client

    def token(self, client):
        return extract_token(client.get("/login").get_data(as_text=True))

    def attempt(self, client, password, token=None, **kwargs):
        return client.post("/login", data={"password": password, "csrf_token": token or self.token(client)}, **kwargs)

    def fail(self, client, times, password="wrong"):
        return [self.attempt(client, password) for _ in range(times)]

    def is_logged_in(self, client):
        with client.session_transaction() as sess:
            return bool(sess.get("logged_in"))

    def assert_client_is_now_locked(self, client, address="127.0.0.1"):
        """The counted failures really locked THIS address: the throttle says
        so, and even the correct password is refused afterwards."""
        self.assertTrue(app_module.login_throttle.is_locked(address))
        self.assertEqual(self.attempt(client, ROLE_PASSWORDS["full"]).status_code, 429)
        self.assertFalse(self.is_logged_in(client))

    @staticmethod
    def normalised(response):
        return re.sub(r'value="[^"]{20,}"', 'value="T"', response.get_data(as_text=True))


class ThresholdAndLockoutRouteTests(LoginRouteTestCase):
    def test_failures_one_to_four_are_the_generic_error_with_http_200(self):
        client = self.client_at()
        for resp in self.fail(client, 4):
            self.assertEqual(resp.status_code, 200)
            self.assertIn(GENERIC_FAILURE, resp.get_data(as_text=True))
            self.assertNotIn("Retry-After", resp.headers)

    def test_the_fifth_failure_is_429_with_the_generic_lockout_message(self):
        client = self.client_at()
        responses = self.fail(client, 5)
        self.assertEqual([r.status_code for r in responses], [200, 200, 200, 200, 429])
        body = responses[4].get_data(as_text=True)
        self.assertIn(LOCKED_MESSAGE, body)
        self.assertNotIn(GENERIC_FAILURE, body)
        self.assertIn('name="password"', body, "the login form is still shown")

    def test_retry_after_is_present_and_sensible(self):
        client = self.client_at()
        fifth = self.fail(client, 5)[4]
        self.assertEqual(fifth.headers["Retry-After"], "900")
        self.clock.advance(300)
        later = self.attempt(client, "wrong")
        self.assertEqual(later.status_code, 429)
        self.assertEqual(later.headers["Retry-After"], "600")
        self.assertTrue(later.headers["Retry-After"].isdigit())

    def test_the_correct_password_during_a_lockout_is_still_blocked_and_never_compared(self):
        client = self.client_at()
        self.fail(client, 5)
        with mock.patch.object(app_module, "_resolve_role", wraps=app_module._resolve_role) as resolve:
            for _ in range(3):
                resp = self.attempt(client, ROLE_PASSWORDS["full"])
                self.assertEqual(resp.status_code, 429)
                self.assertIn("Retry-After", resp.headers)
            resolve.assert_not_called()

    def test_no_authenticated_session_is_created_during_a_lockout(self):
        for role, password in ROLE_PASSWORDS.items():
            with self.subTest(role=role):
                self.clock.advance(1000)                          # a clean slate between roles
                client = self.client_at()
                self.fail(client, 5)
                self.attempt(client, password)
                self.assertFalse(self.is_logged_in(client))
                with client.session_transaction() as sess:
                    self.assertNotIn("role", sess)
                self.assertEqual(client.get("/company-dashboard").status_code, 302)

    def test_the_lockout_expires_after_fifteen_minutes(self):
        client = self.client_at()
        self.fail(client, 5)
        self.clock.advance(899)
        self.assertEqual(self.attempt(client, ROLE_PASSWORDS["full"]).status_code, 429)
        self.clock.advance(1)
        resp = self.attempt(client, ROLE_PASSWORDS["full"])
        self.assertEqual(resp.status_code, 302)
        self.assertTrue(self.is_logged_in(client))

    def test_after_expiry_the_counter_starts_again_from_zero(self):
        client = self.client_at()
        self.fail(client, 5)
        self.clock.advance(900)
        self.assertEqual([r.status_code for r in self.fail(client, 4)], [200, 200, 200, 200])
        self.assertEqual(self.attempt(client, "wrong").status_code, 429)

    def test_the_ten_minute_window_expires_old_failures(self):
        client = self.client_at()
        self.fail(client, 4)
        self.clock.advance(601)
        self.assertEqual([r.status_code for r in self.fail(client, 4)], [200] * 4)   # not a lockout: old ones expired
        self.assertEqual(self.attempt(client, "wrong").status_code, 429)             # 5 within the window now

    def test_a_successful_login_clears_earlier_failures(self):
        client = self.client_at()
        self.fail(client, 4)
        self.assertEqual(self.attempt(client, ROLE_PASSWORDS["full"]).status_code, 302)
        other = self.client_at()                                  # same address, fresh session
        self.assertEqual([r.status_code for r in self.fail(other, 4)], [200] * 4)
        self.assertEqual(self.attempt(other, "wrong").status_code, 429)

    def test_all_four_roles_still_authenticate_normally(self):
        for role, password in ROLE_PASSWORDS.items():
            with self.subTest(role=role):
                client = self.client_at()
                self.fail(client, 3)                              # near the limit, not over it
                resp = self.attempt(client, password)
                self.assertEqual(resp.status_code, 302)
                self.assertTrue(resp.headers["Location"].endswith("/company-dashboard"))
                with client.session_transaction() as sess:
                    self.assertEqual(sess["role"], role)

    def test_get_login_is_unaffected_by_a_lockout(self):
        client = self.client_at()
        self.fail(client, 5)
        resp = client.get("/login")
        self.assertEqual(resp.status_code, 200)
        self.assertNotIn(LOCKED_MESSAGE, resp.get_data(as_text=True))

    def test_an_already_logged_in_session_is_not_affected_by_its_addresss_lockout(self):
        member = self.client_at()
        self.attempt(member, ROLE_PASSWORDS["admissions"])
        attacker = self.client_at()
        self.fail(attacker, 5)
        self.assertEqual(member.get("/company-dashboard").status_code, 200)


class CsrfInteractionTests(LoginRouteTestCase):
    def test_csrf_is_still_required_on_login(self):
        client = self.client_at()
        self.assertEqual(client.post("/login", data={"password": ROLE_PASSWORDS["full"]}).status_code, 400)
        self.assertEqual(
            client.post("/login", data={"password": ROLE_PASSWORDS["full"], "csrf_token": "nope"}).status_code, 400
        )
        self.assertFalse(self.is_logged_in(client))

    def test_csrf_failures_do_not_count_towards_the_throttle(self):
        client = self.client_at()
        for _ in range(12):
            self.assertEqual(client.post("/login", data={"password": "x"}).status_code, 400)
            self.assertEqual(client.post("/login", data={"password": "x", "csrf_token": "bad"}).status_code, 400)
        self.assertEqual(app_module.login_throttle.tracked_clients(), 0)
        self.assertEqual([r.status_code for r in self.fail(client, 4)], [200] * 4)   # a full allowance remains

    def test_csrf_is_checked_before_the_lockout(self):
        client = self.client_at()
        self.fail(client, 5)
        self.assertEqual(client.post("/login", data={"password": "x"}).status_code, 400)
        self.assertEqual(self.attempt(client, "x").status_code, 429)


class UnicodeAndLengthTests(LoginRouteTestCase):
    def test_unicode_passwords_are_ordinary_failures_not_a_500(self):
        client = self.client_at()
        for password in UNICODE_PASSWORDS[:4]:
            with self.subTest(password=password):
                resp = self.attempt(client, password)
                self.assertEqual(resp.status_code, 200)       # TESTING=True would re-raise a TypeError
                self.assertIn(GENERIC_FAILURE, resp.get_data(as_text=True))
                self.assertFalse(self.is_logged_in(client))

    def test_unicode_failures_count_towards_the_throttle(self):
        client = self.client_at()
        statuses = [self.attempt(client, pw).status_code for pw in UNICODE_PASSWORDS[:5]]
        self.assertEqual(statuses, [200, 200, 200, 200, 429])
        self.assert_client_is_now_locked(client)

    def test_resolve_role_never_raises_and_never_matches_odd_input(self):
        for password in UNICODE_PASSWORDS + ["", "\x00", "a\x00b", "\ud800", "x\udfffy", "\U0010ffff"]:
            with self.subTest(password=repr(password)):
                self.assertIsNone(app_module._resolve_role(password))

    def test_configured_passwords_still_resolve_exactly_as_before(self):
        for role, password in ROLE_PASSWORDS.items():
            self.assertEqual(app_module._resolve_role(password), role)
            self.assertIsNone(app_module._resolve_role(password + "x"))
            self.assertIsNone(app_module._resolve_role(password[:-1]))
            self.assertIsNone(app_module._resolve_role(password.upper() if password.upper() != password else password + " "))

    def test_a_lone_surrogate_cannot_collide_with_a_real_character(self):
        with mock.patch.dict(app_module.ROLE_PASSWORDS, {"full": "pass?"}):
            self.assertEqual(app_module._resolve_role("pass?"), "full")
            self.assertIsNone(app_module._resolve_role("pass\ud800"))     # must not be turned into "pass?"

    def test_a_non_ascii_configured_password_would_also_work(self):
        with mock.patch.dict(app_module.ROLE_PASSWORDS, {"full": "päss😀word"}):
            self.assertEqual(app_module._resolve_role("päss😀word"), "full")

    def test_a_256_character_password_is_compared_normally_and_fails_generically(self):
        client = self.client_at()
        resp = self.attempt(client, "a" * 256)
        self.assertEqual(resp.status_code, 200)
        self.assertIn(GENERIC_FAILURE, resp.get_data(as_text=True))

    def test_over_length_passwords_fail_with_the_same_generic_message_and_are_never_compared(self):
        client = self.client_at()
        reference = self.normalised(self.attempt(client, "wrong"))
        # Spy on the `hmac` name INSIDE app.py only (patching hmac itself would also
        # catch Flask-WTF's own token comparisons).
        spy = mock.Mock(wraps=app_module.hmac)
        with mock.patch.object(app_module, "hmac", spy):
            for length in (257, 300, 5000):
                with self.subTest(length=length):
                    spy.compare_digest.reset_mock()
                    resp = self.attempt(client, "a" * length)
                    self.assertEqual(resp.status_code, 200)
                    self.assertEqual(self.normalised(resp), reference, "no hint that length was the reason")
                    spy.compare_digest.assert_not_called()
            spy.compare_digest.reset_mock()
            self.attempt(client, "a" * 256)                    # control: a legal-length guess IS compared
            self.assertTrue(spy.compare_digest.called)
        self.assertEqual(app_module.login_throttle._entries["127.0.0.1"].locked_until is not None, True)

    def test_even_an_over_long_string_that_starts_with_the_real_password_is_rejected(self):
        client = self.client_at()
        resp = self.attempt(client, ROLE_PASSWORDS["full"] + "x" * 300)
        self.assertEqual(resp.status_code, 200)
        self.assertFalse(self.is_logged_in(client))

    def test_over_length_attempts_count_towards_the_throttle(self):
        client = self.client_at()
        statuses = [self.attempt(client, "a" * 400).status_code for _ in range(5)]
        self.assertEqual(statuses, [200, 200, 200, 200, 429])
        self.assert_client_is_now_locked(client)

    def test_empty_passwords_count_towards_the_throttle(self):
        client = self.client_at()
        statuses = [self.attempt(client, "").status_code for _ in range(5)]
        self.assertEqual(statuses, [200, 200, 200, 200, 429])
        self.assert_client_is_now_locked(client)

    def test_a_missing_password_field_counts_too(self):
        client = self.client_at()
        token = self.token(client)
        statuses = [client.post("/login", data={"csrf_token": token}).status_code for _ in range(5)]
        self.assertEqual(statuses, [200, 200, 200, 200, 429])
        self.assert_client_is_now_locked(client)


class UnexpectedInternalErrorTests(LoginRouteTestCase):
    """An UNEXPECTED exception while checking a password (a programming bug
    or broken configuration) is NOT disguised as "Incorrect password.": it
    takes Flask's normal unexpected-error path - generic 500 page, traceback
    logged by the application - and never creates a session. Expected user
    input (empty / Unicode / over-length) is handled explicitly instead and
    stays an ordinary, counted failed login (see UnicodeAndLengthTests)."""

    SECRET = "TopSecret-Guess-ZzQ9!-ünï-😀"

    def production_error_handling(self):
        """Behave like a deployed app (TESTING re-raises instead of
        returning a 500, which would hide what production does)."""
        return mock.patch.dict(app_module.app.config, {"TESTING": False, "PROPAGATE_EXCEPTIONS": False})

    def post_with_injected_error(self, client, error=RuntimeError("internal-detail-xyz")):
        with self.production_error_handling(), \
                mock.patch.object(app_module, "_resolve_role", side_effect=error), \
                self.assertLogs(app_module.app.logger, level="ERROR") as logs:
            resp = self.attempt(client, self.SECRET)
        return resp, logs

    def test_an_unexpected_exception_is_not_turned_into_an_incorrect_password_response(self):
        client = self.client_at()
        resp, _ = self.post_with_injected_error(client)
        body = resp.get_data(as_text=True)
        self.assertEqual(resp.status_code, 500)
        self.assertNotIn(GENERIC_FAILURE, body)
        self.assertNotIn("Incorrect", body)

    def test_it_creates_no_authenticated_session(self):
        client = self.client_at()
        self.post_with_injected_error(client)
        self.assertFalse(self.is_logged_in(client))
        with client.session_transaction() as sess:
            self.assertNotIn("role", sess)
        self.assertEqual(client.get("/company-dashboard").status_code, 302)

    def test_the_real_exception_is_logged_by_the_applications_normal_error_handling(self):
        client = self.client_at()
        resp, logs = self.post_with_injected_error(client)
        self.assertEqual(len(logs.records), 1)
        record = logs.records[0]
        self.assertEqual(record.levelno, logging.ERROR)
        self.assertIn("Exception on /login [POST]", record.getMessage())
        self.assertIsNotNone(record.exc_info)
        self.assertIs(record.exc_info[0], RuntimeError)
        self.assertEqual(str(record.exc_info[1]), "internal-detail-xyz")

    def test_neither_the_response_nor_the_log_contains_the_submitted_password(self):
        client = self.client_at()
        resp, logs = self.post_with_injected_error(client)
        import traceback
        log_text = "\n".join(
            [r.getMessage() for r in logs.records]
            + ["".join(traceback.format_exception(*r.exc_info)) for r in logs.records if r.exc_info]
        )
        for fragment in (self.SECRET, self.SECRET[:6], self.SECRET[-6:], "TopSecret", "ünï"):
            self.assertNotIn(fragment, log_text)
            self.assertNotIn(fragment, resp.get_data(as_text=True))

    def test_the_user_sees_no_internal_detail(self):
        client = self.client_at()
        resp, _ = self.post_with_injected_error(client)
        body = resp.get_data(as_text=True)
        for leaked in ("internal-detail-xyz", "RuntimeError", "Traceback", "_resolve_role", "app.py", ".py"):
            self.assertNotIn(leaked, body)

    def test_it_is_not_counted_as_a_failed_attempt(self):
        client = self.client_at()
        for _ in range(6):
            self.post_with_injected_error(client)
        self.assertEqual(app_module.login_throttle.tracked_clients(), 0)
        self.assertFalse(app_module.login_throttle.is_locked("127.0.0.1"))

    def test_broken_configuration_surfaces_as_an_error_not_as_wrong_passwords(self):
        client = self.client_at()
        with self.production_error_handling(), \
                mock.patch.dict(app_module.ROLE_PASSWORDS, {"full": None}), \
                self.assertLogs(app_module.app.logger, level="ERROR") as logs:
            resp = self.attempt(client, "anything")
        self.assertEqual(resp.status_code, 500)
        self.assertNotIn(GENERIC_FAILURE, resp.get_data(as_text=True))
        self.assertTrue(logs.records[0].exc_info)

    def test_the_route_has_no_blanket_exception_handler_around_the_password_check(self):
        import ast
        import inspect
        tree = ast.parse(inspect.getsource(app_module.login))
        self.assertEqual([n for n in ast.walk(tree) if isinstance(n, (ast.Try, ast.ExceptHandler))], [])

    def test_a_failing_throttle_fails_closed_never_open(self):
        client = self.client_at()
        with self.production_error_handling(), \
                mock.patch.object(app_module.login_throttle, "is_locked", side_effect=RuntimeError("limiter broke")), \
                self.assertLogs(app_module.app.logger, level="ERROR"):
            resp = self.attempt(client, ROLE_PASSWORDS["full"])
        self.assertEqual(resp.status_code, 500)
        self.assertFalse(self.is_logged_in(client))

    def test_expected_user_input_is_still_an_ordinary_counted_failure(self):
        """The explicit handling that replaced the safety net: each of these
        is a normal 200 "Incorrect password." and counts towards lockout."""
        cases = {
            "unicode": ["pässword"] * 5,
            "emoji / unusual unicode": ["pw😀", "\u202eevil", "e\u0301", "𝕳𝖊𝖆𝖑𝖙𝖍", "パスワード"],
            "over 256 characters": ["a" * 257, "a" * 300, "b" * 1000, "c" * 258, "d" * 4096],
            "empty": [""] * 5,
        }
        for label, passwords in cases.items():
            with self.subTest(case=label):
                self.clock.advance(1000)                                   # fresh slate for each case
                client = self.client_at()
                responses = [self.attempt(client, pw) for pw in passwords]
                self.assertEqual([r.status_code for r in responses], [200, 200, 200, 200, 429])
                for resp in responses[:4]:
                    self.assertIn(GENERIC_FAILURE, resp.get_data(as_text=True))
                self.assertTrue(app_module.login_throttle.is_locked("127.0.0.1"))
                self.assertEqual(self.attempt(client, ROLE_PASSWORDS["full"]).status_code, 429)


class AddressIdentityTests(LoginRouteTestCase):
    def test_separate_remote_addresses_have_separate_counters(self):
        a, b = self.client_at("10.0.0.1"), self.client_at("10.0.0.2")
        self.fail(a, 5)
        self.assertEqual(self.attempt(a, "x").status_code, 429)
        self.assertEqual(self.attempt(b, "x").status_code, 200)                 # B unaffected
        self.assertEqual(self.attempt(b, ROLE_PASSWORDS["full"]).status_code, 302)
        self.assertEqual(self.attempt(a, ROLE_PASSWORDS["full"]).status_code, 429)

    def test_a_spoofed_x_forwarded_for_neither_evades_nor_transfers_a_lockout(self):
        attacker = self.client_at("10.0.0.1")
        spoofs = [f"203.0.113.{i}" for i in range(1, 7)]
        statuses = [self.attempt(attacker, "x", headers={"X-Forwarded-For": spoof}).status_code for spoof in spoofs[:5]]
        self.assertEqual(statuses, [200, 200, 200, 200, 429], "rotating the header does not reset the counter")
        resp = self.attempt(attacker, ROLE_PASSWORDS["full"], headers={"X-Forwarded-For": spoofs[5]})
        self.assertEqual(resp.status_code, 429)

        victim = self.client_at("10.0.0.9")
        resp = self.attempt(victim, "x", headers={"X-Forwarded-For": "10.0.0.1"})  # claims to be the locked address
        self.assertEqual(resp.status_code, 200)

    def test_the_limiter_key_is_remote_addr_only(self):
        client = self.client_at("10.0.0.3")
        self.attempt(client, "x", headers={"X-Forwarded-For": "1.2.3.4", "X-Real-IP": "5.6.7.8", "Forwarded": "for=9.9.9.9"})
        self.assertEqual(list(app_module.login_throttle._entries), ["10.0.0.3"])

    def test_the_app_does_not_install_proxyfix(self):
        self.assertNotIn("ProxyFix", type(app_module.app.wsgi_app).__name__)


class MessageAndRestartTests(LoginRouteTestCase):
    ROLE_WORDS = ("full access", "admissions", "consultants", "marketing")

    def test_failure_messages_reveal_nothing_about_roles_or_passwords(self):
        client = self.client_at()
        valid = ROLE_PASSWORDS["full"]
        guesses = ["", "zzz", valid[:-1], valid + "x", "X" + valid[1:], valid.upper() + "!", "pässword", "a" * 300]
        bodies = []
        for guess in guesses:
            self.clock.advance(1000)                               # keep each guess a "first" failure
            resp = self.attempt(client, guess)
            self.assertEqual(resp.status_code, 200)
            bodies.append(self.normalised(resp))
        self.assertEqual(len(set(bodies)), 1, "every wrong guess produces a byte-identical page")
        lowered = bodies[0].lower()
        for word in self.ROLE_WORDS:
            self.assertNotIn(word, lowered)

    def test_the_lockout_message_is_generic_and_identical_for_right_and_wrong_passwords(self):
        client = self.client_at()
        self.fail(client, 5)
        wrong = self.attempt(client, "wrong")
        right = self.attempt(client, ROLE_PASSWORDS["admissions"])
        self.assertEqual(self.normalised(wrong), self.normalised(right))
        body = wrong.get_data(as_text=True)
        self.assertIn(LOCKED_MESSAGE, body)
        lowered = body.lower()
        for word in self.ROLE_WORDS + ("correct", "valid", "length", "256", "ascii", "unicode", "character"):
            self.assertNotIn(word, lowered)

    def test_a_restart_clears_a_lockout(self):
        client = self.client_at()
        self.fail(client, 5)
        self.assertEqual(self.attempt(client, ROLE_PASSWORDS["full"]).status_code, 429)
        app_module.login_throttle = LoginThrottle(clock=self.clock)       # what a process restart gives
        self.assertEqual(self.attempt(client, ROLE_PASSWORDS["full"]).status_code, 302)

    def test_the_app_uses_one_module_level_in_memory_throttle(self):
        self.assertIsInstance(app_module.login_throttle, LoginThrottle)
        self.assertEqual(
            (app_module.login_throttle.max_failures, app_module.login_throttle.window_seconds,
             app_module.login_throttle.lockout_seconds),
            (5, 600, 900),
        )


class LoggingTests(LoginRouteTestCase):
    """WARNING-level lines for failures and lockouts; nothing sensitive, and
    no success logging in this phase."""

    class Capture(logging.Handler):
        def __init__(self):
            super().__init__(level=logging.DEBUG)
            self.records = []

        def emit(self, record):
            self.records.append(record)

        def text(self):
            parts = []
            for r in self.records:
                parts += [r.getMessage(), str(r.args), r.exc_text or "", r.name, r.pathname]
                if r.exc_info:
                    import traceback
                    parts.append("".join(traceback.format_exception(*r.exc_info)))
            return "\\n".join(parts)

    def setUp(self):
        super().setUp()
        self.capture = self.Capture()
        self._old_level = app_module.logger.level
        app_module.logger.addHandler(self.capture)
        app_module.logger.setLevel(logging.DEBUG)

    def tearDown(self):
        app_module.logger.removeHandler(self.capture)
        app_module.logger.setLevel(self._old_level)
        super().tearDown()

    def messages(self, level=None):
        return [r.getMessage() for r in self.capture.records if level is None or r.levelno == level]

    def test_failed_logins_are_logged_at_warning_with_address_and_count(self):
        client = self.client_at("10.1.2.3")
        self.fail(client, 3)
        failed = [m for m in self.messages(logging.WARNING) if m.startswith("Failed login")]
        self.assertEqual(failed, [f"Failed login from 10.1.2.3 ({n} of 5 allowed in 10 minutes)." for n in (1, 2, 3)])

    def test_lockout_activation_is_logged_with_address_and_duration(self):
        client = self.client_at("10.1.2.3")
        self.fail(client, 5)
        self.assertIn("Login locked out for 10.1.2.3 for 15 minutes.", self.messages(logging.WARNING))

    def test_lockout_rejections_are_logged_once_per_lockout_not_per_request(self):
        client = self.client_at("10.1.2.3")
        self.fail(client, 5)
        for _ in range(10):
            self.attempt(client, "x")
        rejected = [m for m in self.messages(logging.WARNING) if "rejected" in m]
        self.assertEqual(rejected, ["Login attempt rejected from 10.1.2.3: locked out."])

    def test_no_secret_data_reaches_the_logs(self):
        client = self.client_at("10.1.2.3")
        token = self.token(client)
        session_cookie = client.get_cookie("session").value
        secrets_ = [self.SECRET_GUESS, "pässword-ünïcode-😀", "L" * 301, ROLE_PASSWORDS["full"], token, session_cookie]
        for secret in secrets_[:3]:
            self.attempt(client, secret)
        self.attempt(client, "x" * 5)
        self.attempt(client, ROLE_PASSWORDS["full"])                     # during/after lockout
        text = self.capture.text()
        for secret in secrets_:
            self.assertNotIn(secret, text)
            for fragment in (secret[:6], secret[-6:]):
                if len(fragment) >= 6:
                    self.assertNotIn(fragment, text)
        for configured in ROLE_PASSWORDS.values():
            self.assertNotIn(configured, text)
        self.assertNotIn("301", " ".join(self.messages()), "the submitted length is never logged")
        self.assertNotIn("csrf", text.lower())
        self.assertNotIn("cookie", text.lower())

    def test_password_lengths_are_not_logged_for_any_attempt(self):
        client = self.client_at("10.1.2.3")
        self.attempt(client, "q" * 411)
        self.attempt(client, "short")
        joined = " ".join(self.messages())
        self.assertNotIn("411", joined)
        self.assertNotRegex(joined, r"length|chars|characters|bytes")

    def test_successful_logins_are_not_logged_in_this_phase(self):
        client = self.client_at("10.1.2.3")
        self.attempt(client, ROLE_PASSWORDS["full"])
        self.assertEqual(self.messages(), [])

    def test_a_correct_password_during_lockout_is_not_logged_as_such(self):
        client = self.client_at("10.1.2.3")
        self.fail(client, 5)
        self.capture.records.clear()
        self.attempt(client, ROLE_PASSWORDS["admissions"])
        joined = " ".join(self.messages()).lower()
        for word in ("correct", "valid", "admissions", "role"):
            self.assertNotIn(word, joined)


if __name__ == "__main__":
    unittest.main()
