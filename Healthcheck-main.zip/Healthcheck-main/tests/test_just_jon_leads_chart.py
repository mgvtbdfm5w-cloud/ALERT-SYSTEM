"""Just Jon: the Number Breakdown is gone and a Leads-by-Office-and-Consultant
chart (the Allocation page's chart, for the Just Jon leads) sits in its place,
with the same click-through window as the other charts."""

import io
import re
import unittest
from contextlib import contextmanager
from urllib.parse import parse_qs, unquote_plus, urlencode

from flask import template_rendered

from leads_dashboard import (
    LEAD_RECORD_COLUMNS,
    allocation_segment_rows,
    build_allocation_report,
    filter_just_jon_leads,
    lead_records,
)
from tests.flask_test_support import IsolatedAppTestCase, app_module, extract_token
from tests.test_allocation import lead, leads_book
from tests.test_just_jon_records import LOOKUPS as APP_LOOKUPS, ROWS as APP_ROWS
from tests.test_upload_atomicity import book

LEADS = [
    # August
    lead("J1", "Mel X", "03/08/2026", "New Lead", "Staff Referral/Jon Daniels TT"),
    lead("J2", "Kian Q", "04/08/2026", "Applied", "Agent/Just Jon"),
    lead("J3", "Hannah Y", "05/08/2026", "New Lead", "Student Referral/Riley Jonathan"),         # not Just Jon
    lead("J4", "Raymond P", "06/08/2026", "Qualified", "Agent/Just Jon"),                        # Group as Other
    lead("J5", "", "07/08/2026", "New Lead", "Staff Referral/Jon Daniels TT"),                   # nobody allocated
    lead("J6", "Mel X", "08/08/2026", "Enrolled Student", "Agent/Just Jon"),
    lead("J7", "Hannah Y", "09/08/2026", "New Lead", "Paid Ad/Jon Daniels"),                     # Sub Source decides, not the Lead Source
    lead("J8", "Mel X", "10/08/2026", "Totally New Status", "Agent/Jon Daniels TT"),            # unrecognised status: the grey piece
    lead("J12", "Newbie Z", "11/08/2026", "New Lead", "Agent/Just Jon"),                         # a consultant with no Office yet
    lead("N1", "Mel X", "03/08/2026", "New Lead", "Paid Ad/Google"),                             # not Just Jon
    # September
    lead("J9", "Hannah Y", "02/09/2026", "Qualified", "Staff Referral/Jon Daniels TT"),
    lead("J10", "Mel X", "03/09/2026", "Applied", "Agent/Just Jon"),
    lead("N2", "Kian Q", "04/09/2026", "New Lead", "Agent/Someone"),
    # October: only non-Just-Jon leads
    lead("N3", "Mel X", "05/10/2026", "New Lead", "Paid Ad/Google"),
]
STAGE = {"New Lead": "01 - New Lead", "Qualified": "02 - Qualified", "Applied": "04 - Applied", "Enrolled Student": "05 - Enrolled"}


@contextmanager
def captured():
    rendered = []

    def record(sender, template, context, **extra):
        rendered.append((template.name, dict(context)))

    template_rendered.connect(record, app_module.app)
    try:
        yield rendered
    finally:
        template_rendered.disconnect(record, app_module.app)


def rows_of(report):
    return {g["office"]: {r["name"]: r["count"] for r in g["rows"]} for g in report["groups"]}


class HelperTests(unittest.TestCase):
    def rows(self):
        return [
            {"PES Code": "B", "Name": "zed", "Lead Source": "Agent", "Sub Source": "Just Jon", "Lead Status": "Applied", "Consultant": "Mel", "Stage": "04 - Applied", "Creation Date": "2026-08-03"},
            {"PES Code": "A", "Name": "Amy", "Lead Source": "Paid Ad", "Sub Source": "x", "Lead Status": "Weird", "Consultant": "", "Stage": "", "Creation Date": "bad"},
            {"PES Code": "C", "Name": "Amy", "Lead Source": "Agent", "Sub Source": "", "Lead Status": "Applied", "Consultant": "Raymond", "Stage": "04 - Applied", "Creation Date": None},
            {"PES Code": "D", "Name": "Bob", "Lead Source": "Agent", "Sub Source": "", "Lead Status": "Applied", "Consultant": "Mel", "Stage": "01 - New Lead", "Creation Date": "2026-08-04"},
        ]

    def test_lead_records_fields_formats_and_sort(self):
        records = lead_records(self.rows())
        self.assertEqual([r["code"] for r in records], ["A", "C", "D", "B"], "Name then PES Code")
        self.assertEqual(records[3], {"code": "B", "name": "zed", "lead_source": "Agent", "sub_source": "Just Jon", "lead_status": "Applied",
                                      "consultant": "Mel", "created": "03/08/2026"})
        self.assertEqual((records[0]["consultant"], records[0]["created"]), ("Unassigned", ""), "no consultant, no usable date")
        self.assertEqual(records[1]["created"], "")
        self.assertEqual([c[1] for c in LEAD_RECORD_COLUMNS], ["code", "name", "lead_source", "sub_source", "lead_status", "consultant", "created"])
        self.assertEqual([c[0] for c in LEAD_RECORD_COLUMNS][:2], ["PES Code", "Name"])
        self.assertEqual(lead_records([]), [])

    def test_allocation_segment_rows_picks_office_name_and_stage(self):
        rows, offices, others = self.rows(), {"mel": "OXF", "raymond": "LON"}, {"raymond"}
        pick = lambda office, name, stage: [r["PES Code"] for r in allocation_segment_rows(rows, office, name, stage, offices, others)]
        self.assertEqual(pick("OXF", "Mel", "04 - Applied"), ["B"])
        self.assertEqual(pick("OXF", "Mel", "01 - New Lead"), ["D"])
        self.assertEqual(pick("LON", "Other", "04 - Applied"), ["C"], "Raymond is Group as Other: the Other row of his Office")
        self.assertEqual(pick("Unassigned", "Unassigned", "Unassigned"), ["A"], "no consultant and a blank stage: the grey piece")
        self.assertEqual(pick("OXF", "Mel", "Unassigned"), [], "Mel has no unrecognised-stage lead")
        self.assertEqual(pick("MAN", "Mel", "04 - Applied"), [], "the wrong Office")
        self.assertEqual(pick("OXF", "mel", "04 - Applied"), [])
        self.assertEqual(pick("OXF", "Mel", "09 - Non-Responsive"), [])


class LeadsChartBase(IsolatedAppTestCase):
    def setUp(self):
        super().setUp()
        self.full = self._client_logged_in_as("full")
        self.token = lambda: extract_token(self.full.get("/login").get_data(as_text=True))
        self.upload("/upload", book(APP_ROWS, lookups=APP_LOOKUPS))
        self.upload("/leads/upload", leads_book(LEADS))
        # (Mel -> MAN and Hannah -> LON come from the Consultant lookup the Applications upload seeds)
        for consultant, office, other in (("Kian", "MAN", False), ("Raymond", "LON", True)):
            data = {"csrf_token": self.token(), "source_value": consultant, "mapped_value": office}
            if other:
                data["group_as_other"] = "on"
            self.assertEqual(self.full.post("/admin/lookups/sales_office/add", data=data).status_code, 302)

    def upload(self, path, data):
        r = self.full.post(path, data={"csrf_token": self.token(), "excel_file": (io.BytesIO(data), "f.xlsx")}, content_type="multipart/form-data")
        self.assertEqual(r.status_code, 302, path)

    def page(self, query="year=2026", client=None):
        with captured() as rendered:
            r = (client or self.full).get("/dashboard/just-jon?" + query)
        self.assertEqual(r.status_code, 200, query)
        return r.get_data(as_text=True), next(c for name, c in rendered if name == "dashboard_just_jon.html")

    def records(self, office, name, stage, query="year=2026", client=None):
        return (client or self.full).get("/dashboard/just-jon/lead-records?" + query + "&" + urlencode({"office": office, "name": name, "stage": stage}))

    def pieces(self, context):
        return [(g["office"], row["name"], seg["stage"], seg["count"]) for g in context["lead_report"]["groups"] for row in g["rows"] for seg in row["segments"]]


class NumberBreakdownTests(LeadsChartBase):
    def test_the_number_breakdown_section_and_its_tables_are_gone_from_just_jon(self):
        html, _ = self.page()
        self.assertNotIn("Number Breakdown", html)
        self.assertNotIn("pipeline-table", html)
        self.assertNotIn("Application Manager Pipeline</h2>", html.replace("Application Manager Pipeline Health", ""))
        self.assertNotIn("Grand Total", html)

    def test_the_rest_of_the_page_is_still_there(self):
        html, _ = self.page()
        for text in ("Just Jon Pipeline 2026", "Application Manager Pipeline Health", "Consultant Pipeline Health", "University Pipeline Health",
                     "Just Jon - Consultant Pipeline 2026", "Just Jon - University Pipeline 2026", "Download Data"):
            self.assertIn(text, html, text)

    def test_other_pages_keep_their_number_breakdown(self):
        for path in ("/enrolled?year=2026",):
            self.assertIn("Number Breakdown", self.full.get(path).get_data(as_text=True), path)

    def test_the_new_chart_takes_its_place_at_the_bottom(self):
        html, _ = self.page()
        self.assertLess(html.index("University Pipeline Health"), html.index("<h1>Just Jon Lead Allocates</h1>"))
        self.assertLess(html.index("<h1>Just Jon Lead Allocates</h1>"), html.index("Just Jon Leads by Office and Consultant</h2>"))
        self.assertNotIn("Just Jon - Leads by Office and Consultant", html, "the section heading was renamed")


class LeadsChartTests(LeadsChartBase):
    def test_the_chart_is_the_allocation_chart_for_the_just_jon_leads_in_all_months(self):
        html, context = self.page()
        self.assertEqual(rows_of(context["lead_report"]), {
            "MAN": {"Mel": 4, "Kian": 1},              # Mel (MAN on the Consultant lookup): J1 J6 J8 J10
            "LON": {"Hannah": 2, "Other": 1},          # Hannah: J7 J9   Other: Raymond (Group as Other)
            "Other": {"Newbie": 1},
            "Unassigned": {"Unassigned": 1},
        })
        self.assertEqual(context["lead_report"]["total"], 10)
        expected = build_allocation_report(filter_just_jon_leads(self.leads_rows()), self.offices(), {"raymond"})
        self.assertEqual(context["lead_report"], expected)
        for fragment in ('class="chart-office-group"', 'class="chart-office-label"', 'class="chart-col-applications"', 'class="chart-legend"'):
            self.assertIn(fragment, html)
        self.assertIn("<h2>Just Jon Leads by Office and Consultant</h2>", html)

    def leads_rows(self):
        import json, sqlite3
        from tests.flask_test_support import db_module
        conn = sqlite3.connect(db_module.DB_PATH)
        try:
            return json.loads(conn.execute("SELECT data_json FROM active_leads_dataset ORDER BY id DESC LIMIT 1").fetchone()[0])
        finally:
            conn.close()

    def offices(self):
        return {"mel": "MAN", "hannah": "LON", "kian": "MAN", "raymond": "LON"}

    def test_only_just_jon_leads_are_counted(self):
        _, context = self.page()
        names = {r["name"] for g in context["lead_report"]["groups"] for r in g["rows"]}
        total = sum(r["count"] for g in context["lead_report"]["groups"] for r in g["rows"])
        self.assertEqual(total, 10, "the 4 other leads (J3 N1 N2 N3) are not counted")
        every = set()
        for office, name, stage, _ in self.pieces(context):
            every |= {r["code"] for r in self.records(office, name, stage).get_json()["records"]}
        self.assertEqual(every, {"J1", "J2", "J4", "J5", "J6", "J7", "J8", "J9", "J10", "J12"})
        self.assertTrue(names)

    def test_the_month_dropdown_offers_only_months_with_just_jon_leads_and_filters_the_chart(self):
        html, context = self.page()
        block = html[html.index('<select name="lead_month"'):]
        block = block[:block.index("</select>")]
        self.assertEqual(re.findall(r'<option value="([^"]*)"', block), ["", "2026-09", "2026-08"], "October has only other leads")
        self.assertEqual(re.findall(r'<option value="([^"]*)" selected', block), [""])
        self.assertIn("All months", block)
        _, sep = self.page("year=2026&lead_month=2026-09")
        self.assertEqual(rows_of(sep["lead_report"]), {"MAN": {"Mel": 1}, "LON": {"Hannah": 1}})
        html, aug = self.page("year=2026&lead_month=2026-08")
        self.assertEqual(aug["lead_report"]["total"], 8)
        self.assertIn('<option value="2026-08" selected>', html)

    def test_a_month_that_is_not_an_option_is_ignored(self):
        for month in ("2026-10", "2025-01", "garbage", "2026-13", "", "%3Cscript%3E", "2026-00", "-1"):
            _, context = self.page("year=2026&lead_month=" + month)
            self.assertEqual(context["lead_report"]["total"], 10, month)
        html, _ = self.page("year=2026&lead_month=%3Cscript%3Ealert(1)%3C/script%3E")
        self.assertNotIn("<script>alert", html)

    def test_the_month_form_keeps_the_year_and_intake_tab(self):
        html, _ = self.page("year=2027&intake=intake_01&lead_month=2026-08")
        form = html[html.index('<form method="GET" action="/dashboard/just-jon"'):]
        form = form[:form.index("</form>")]
        self.assertIn('<input type="hidden" name="year" value="2027">', form)
        self.assertIn('<input type="hidden" name="intake" value="intake_01">', form)
        self.assertIn('onchange="this.form.submit()"', form)

    def test_the_explanatory_line_under_the_heading_is_gone(self):
        html, _ = self.page()
        for text in ("Jon Daniels, Jon Daniels TT or Just Jon", "Sub Source Jon Daniels", "data as of", 'class="dataset-meta"'):
            self.assertNotIn(text, html, text)
        form = html[html.index('<form method="GET" action="/dashboard/just-jon"'):]
        form = form[:form.index("</form>")]
        self.assertIn('<label for="lead_month">Leads created in</label>', form)
        self.assertNotIn("<span", form, "just the dropdown")

    def test_the_chart_does_not_change_with_the_year_tab(self):
        _, y26 = self.page("year=2026")
        _, y27 = self.page("year=2027")
        self.assertEqual(y26["lead_report"], y27["lead_report"], "leads are by creation month, not Intake year")

    def test_with_no_leads_file_there_is_a_friendly_message_and_the_rest_of_the_page_works(self):
        import sqlite3
        from tests.flask_test_support import db_module
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute("DELETE FROM active_leads_dataset")
        conn.commit()
        conn.close()
        html, _ = self.page()
        self.assertIn("No active Leads dataset yet.", html)
        self.assertNotIn("Just Jon Leads by Office and Consultant</h2>", html)
        self.assertIn("Application Manager Pipeline Health", html)

    def test_a_month_with_no_leads_for_a_selection_says_so(self):
        import sqlite3
        from tests.flask_test_support import db_module
        self.upload("/leads/upload", leads_book([lead("X1", "Mel X", "05/10/2026", source="Paid Ad/Google")]))
        html, context = self.page()
        self.assertEqual(context["lead_report"]["groups"], [])
        self.assertIn("No Just Jon leads found.", html)
        self.assertEqual(html.count('<option value="'), 1, "only 'All months'")


class LeadRecordsTests(LeadsChartBase):
    QUERIES = ["year=2026", "year=2026&lead_month=2026-08", "year=2026&lead_month=2026-09", "year=2027", "year=2026&lead_month=bogus"]

    def test_every_piece_lists_exactly_the_number_it_shows(self):
        checked = 0
        for query in self.QUERIES:
            _, context = self.page(query)
            for office, name, stage, count in self.pieces(context):
                r = self.records(office, name, stage, query)
                self.assertEqual(r.status_code, 200, (query, office, name, stage))
                data = r.get_json()
                self.assertEqual((data["count"], len(data["records"])), (count, count), (query, office, name, stage))
                checked += 1
        self.assertGreater(checked, 12)

    def test_the_pieces_of_one_row_add_up_to_the_row(self):
        for query in self.QUERIES:
            _, context = self.page(query)
            for g in context["lead_report"]["groups"]:
                for row in g["rows"]:
                    total = sum(len(self.records(g["office"], row["name"], seg["stage"], query).get_json()["records"]) for seg in row["segments"])
                    self.assertEqual(total, row["count"], (query, g["office"], row["name"]))

    def test_known_pieces(self):
        codes = lambda office, name, stage, query="year=2026": [r["code"] for r in self.records(office, name, stage, query).get_json()["records"]]
        self.assertEqual(sorted(codes("MAN", "Mel", "01 - New Lead")), ["J1"])
        self.assertEqual(codes("MAN", "Mel", "05 - Enrolled"), ["J6"])
        self.assertEqual(codes("MAN", "Mel", "04 - Applied"), ["J10"])
        self.assertEqual(codes("MAN", "Mel", "Unassigned"), ["J8"], "the grey piece: a Lead Status the app does not know")
        self.assertEqual(codes("LON", "Other", "02 - Qualified"), ["J4"], "Raymond is Group as Other")
        self.assertEqual(codes("Unassigned", "Unassigned", "01 - New Lead"), ["J5"])
        self.assertEqual(codes("Other", "Newbie", "01 - New Lead"), ["J12"])
        self.assertEqual(codes("LON", "Hannah", "01 - New Lead"), ["J7"], "a Paid Ad lead whose Sub Source is Jon Daniels")
        self.assertEqual(codes("LON", "Hannah", "02 - Qualified"), ["J9"])
        self.assertEqual(codes("MAN", "Mel", "01 - New Lead", "year=2026&lead_month=2026-09"), [], "J1 was created in August")
        self.assertEqual(codes("MAN", "Mel", "04 - Applied", "year=2026&lead_month=2026-09"), ["J10"])

    def test_the_window_gets_lead_columns_and_says_lead(self):
        data = self.records("MAN", "Mel", "01 - New Lead").get_json()
        self.assertEqual(data["columns"], [list(c) for c in LEAD_RECORD_COLUMNS])
        self.assertEqual([c[0] for c in data["columns"]], ["PES Code", "Name", "Lead Source", "Sub Source", "Lead Status", "Consultant", "Created"])
        self.assertEqual(data["noun"], "lead")
        self.assertEqual((data["office"], data["name"], data["stage"]), ("MAN", "Mel", "01 - New Lead"))
        record = data["records"][0]
        self.assertEqual(sorted(record), ["code", "consultant", "created", "lead_source", "lead_status", "name", "sub_source"])
        self.assertEqual(record["code"], "J1")
        self.assertEqual(record["created"], "03/08/2026")
        self.assertEqual((record["lead_source"], record["sub_source"]), ("Staff Referral", "Jon Daniels TT"))
        self.assertEqual(record["lead_status"], "New Lead")
        self.assertEqual(record["consultant"], "Mel")

    def test_sorted_by_name_then_code(self):
        data = self.records("MAN", "Mel", "04 - Applied").get_json()
        keys = [(r["name"].lower(), r["code"]) for r in data["records"]]
        self.assertEqual(keys, sorted(keys))

    def test_an_unknown_stage_is_a_400_and_unknown_office_or_name_is_empty(self):
        for stage in ("", "nope", "01-New Lead", "01 - new lead", "Unassigned "):
            r = self.records("MAN", "Mel", stage)
            self.assertEqual((r.status_code, r.get_json()), (400, {"error": "Unknown chart piece."}), repr(stage))
        for office, name in (("MAN", "Nobody"), ("OXF", "Mel"), ("", ""), ("man", "Mel"), ("MAN", "mel")):
            r = self.records(office, name, "01 - New Lead")
            self.assertEqual((r.status_code, r.get_json()["count"]), (200, 0), (office, name))
        self.assertEqual(self.full.get("/dashboard/just-jon/lead-records?year=2026").status_code, 400)

    def test_no_store_json_login_and_roles(self):
        r = self.records("MAN", "Mel", "01 - New Lead")
        self.assertEqual((r.mimetype, r.headers["Cache-Control"]), ("application/json", "no-store"))
        anon = app_module.app.test_client().get("/dashboard/just-jon/lead-records?office=MAN&name=Mel&stage=01+-+New+Lead")
        self.assertEqual(anon.status_code, 302)
        self.assertIn("/login", anon.headers["Location"])
        for role in ("admissions", "consultants", "marketing"):
            self.assertEqual(self.records("MAN", "Mel", "01 - New Lead", client=self._client_logged_in_as(role)).get_json()["count"], 1, role)

    def test_with_no_leads_file_it_is_an_empty_list(self):
        import sqlite3
        from tests.flask_test_support import db_module
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute("DELETE FROM active_leads_dataset")
        conn.commit()
        conn.close()
        r = self.records("MAN", "Mel", "01 - New Lead")
        self.assertEqual((r.status_code, r.get_json()["count"]), (200, 0))


class MarkupTests(LeadsChartBase):
    def test_every_piece_of_the_leads_chart_is_a_clickable_button_that_says_what_it_opens(self):
        html, context = self.page()
        pieces = re.findall(r'<div class="chart-segment chart-segment-clickable"\s+role="button" tabindex="0"\s+data-records-url="([^"]*)" data-records-noun="([^"]*)"\s+'
                            r'data-records-title="([^"]*)"\s+data-records-params="([^"]*)"\s+data-count="(\d+)"\s+aria-label="[^"]*"\s+style="[^"]*"\s+data-tooltip="([^"]*)"', html)
        got = []
        for url, noun, title, params, count, tooltip in pieces:
            query = parse_qs(params.replace("&amp;", "&"))
            office, name, stage = query["office"][0], query["name"][0], query["stage"][0]
            self.assertEqual((url, noun), ("/dashboard/just-jon/lead-records", "lead"))
            self.assertEqual(sorted(query), ["name", "office", "stage"])
            self.assertEqual(title, f"{name} ({office}) &mdash; {stage}")
            self.assertEqual(tooltip, f"{name} - {stage}: {count}", "the hover tooltip is unchanged")
            got.append((office, name, stage, int(count)))
        self.assertEqual(got, self.pieces_of(context))
        self.assertEqual(len(got), 10)

    def pieces_of(self, context):
        return [(g["office"], row["name"], seg["stage"], seg["count"]) for g in context["lead_report"]["groups"] for row in g["rows"] for seg in row["segments"]]

    def test_the_window_is_on_the_page_once_and_both_kinds_of_piece_are_clickable(self):
        html, _ = self.page()
        self.assertEqual(html.count('<dialog id="chart-records"'), 1)
        self.assertIn('data-url="/dashboard/just-jon/records"', html)
        self.assertEqual(html.count("chart-records.js"), 1)
        self.assertEqual(html.count("Click a bar to list its applications."), 3)
        self.assertEqual(html.count("Click a bar to list its leads."), 1)
        self.assertGreater(html.count('data-records-params="chart='), 12, "the application pieces still open the application list")

    def test_the_stage_colours_and_legend_are_the_lead_ones(self):
        html, _ = self.page()
        section = html[html.index("Just Jon Leads by Office and Consultant</h2>"):]
        for stage in ("01 - New Lead", "04 - Applied", "05 - Enrolled", "10 - Disqualified"):
            self.assertIn(stage, section)
        self.assertNotIn("08-Pre-Enrolled", section, "not the application stages")

    def test_the_allocation_and_leads_pages_have_no_click_through(self):
        for path in ("/allocation?month=2026-08", "/leads-dashboard?month=2026-08", "/split?month=2026-08", "/ninety-days"):
            html = self.full.get(path).get_data(as_text=True)
            self.assertNotIn("chart-segment-clickable", html, path)
            self.assertNotIn('<dialog id="chart-records"', html, path)


if __name__ == "__main__":
    unittest.main()
