"""Consultants page: clicking a piece of the Application Manager Pipeline chart or the
University Pipeline chart lists the applications in it - the same pop-up window as the
Dashboard, University Pipeline and Just Jon pages.

The list is read off the very report the chart was drawn from, so these tests check it
against what the page itself shows (every piece, every year / Intake tab), against the
rules that make a chart's numbers differ from a plain filter (one row per student, a Lost
record dropped when the student has a live application next year, excluded managers), and
check the picked Consultant's own applications are the only ones that can ever appear."""

import io
import re
from urllib.parse import urlencode

from pipeline import STAGES
from tests.flask_test_support import IsolatedAppTestCase, extract_token
from tests.test_consultants_page import captured_context
from tests.test_role_access import AccessRouteTestCase
from tests.test_upload_atomicity import book, row

LOOKUPS = {
    "status": [("Assessment", "05-Assessment"), ("Decision", "06-Decision"), ("Enrolled", "09-Enrolled"), ("Cancelled", "10-Lost")],
    "office": [("Mo Y", "UK"), ("Nouran X", "EG"), ("Admission X", "EG")],
    "sales_office": [("Mel", "MAN"), ("Hannah", "LON")],
}


def app_row(code, intake, status, officer, consultant, university, source="Paid Ad/Google", created="", name=None):
    return row(**{"Student Code": code, "Student Name": name or f"Student {code}", "Application Status": status, "Intake": intake,
                  "Admission Officer": officer, "Counsellor": f"{consultant} Surname", "University Name": university,
                  "Lead Source": source, "Applied On": created})


ROWS = [
    app_row("M1", "August 2026", "Assessment", "Mo Y", "Mel", "Uni A", created="01/08/2026"),    # M1 applied twice: the later one is the student's row
    app_row("M1", "August 2026", "Decision", "Mo Y", "Mel", "Uni B", created="05/08/2026"),
    app_row("M2", "September 2026", "Enrolled", "Nouran X", "Mel", "Uni A"),
    app_row("M3", "September 2026", "Cancelled", "Nouran X", "Mel", "Uni A"),                   # lost in 2026 ...
    app_row("M3", "January 2027", "Assessment", "Nouran X", "Mel", "Uni A"),                    # ... but alive in 2027, so not a 2026 loss
    app_row("M4", "October 2026", "Decision", "Mo Y", "Mel", "Uni C"),
    app_row("M5", "August 2026", "Assessment", "", "Mel", "Uni A"),                             # no Application Manager
    app_row("M6", "October 2026", "Assessment", "Admission X", "Mel", "Uni A"),                 # "Admission" is not a real manager
    app_row("M7", "November 2026", "Enrolled", "Mo Y", "Mel", "", name="=SUM(1,1)"),            # no university; formula-looking name
    app_row("M8", "February 2027", "Decision", "Mo Y", "Mel", "Uni C"),
    app_row("M9", "September 2027", "Enrolled", "Nouran X", "Mel", "Uni C"),
    app_row("H1", "August 2026", "Assessment", "Mo Y", "Hannah", "Uni A"),                      # Hannah's, never Mel's
    app_row("H2", "September 2026", "Enrolled", "Nouran X", "Hannah", "Uni B"),
    app_row("H3", "February 2027", "Decision", "Mo Y", "Hannah", "Uni A"),
]
CHARTS = {"manager": "am_chart_groups", "university": "university_chart_groups"}
QUERIES = ["year=2026", "year=2027", "year=2027&intake=intake_01", "year=2027&intake=intake_03", "year=2026&intake=intake_03", "year=2099"]


class ConsultantsRecordsBase(IsolatedAppTestCase):
    def setUp(self):
        super().setUp()
        self.full = self._client_logged_in_as("full")
        token = extract_token(self.full.get("/login").get_data(as_text=True))
        data = book(ROWS, lookups=LOOKUPS)
        self.assertEqual(self.full.post("/upload", data={"csrf_token": token, "excel_file": (io.BytesIO(data), "f.xlsx")},
                                        content_type="multipart/form-data").status_code, 302)

    def page(self, query, consultant="Mel", client=None):
        with captured_context() as rendered:
            r = (client or self.full).get("/consultants?" + urlencode({"consultant": consultant}) + "&" + query)
        self.assertEqual(r.status_code, 200, query)
        return r.get_data(as_text=True), next(c for name, c in rendered if name == "dashboard_consultants.html")

    def records(self, query, chart, name, stage, consultant="Mel", client=None):
        params = {"chart": chart, "name": name, "stage": stage}
        if consultant is not None:
            params["consultant"] = consultant
        return (client or self.full).get("/consultants/records?" + query + "&" + urlencode(params))

    def codes(self, query, chart, name, stage, consultant="Mel"):
        return [r["code"] for r in self.records(query, chart, name, stage, consultant).get_json()["records"]]

    def pieces(self, context, chart):
        return [(r["name"], seg["stage"], seg["count"]) for g in context[CHARTS[chart]] for r in g["rows"] for seg in r["segments"]]


class RecordsTests(ConsultantsRecordsBase):
    def test_every_piece_of_both_charts_lists_exactly_the_number_it_shows(self):
        checked = 0
        for consultant in ("Mel", "Hannah"):
            for query in QUERIES:
                _, context = self.page(query, consultant)
                for chart in CHARTS:
                    for name, stage, count in self.pieces(context, chart):
                        r = self.records(query, chart, name, stage, consultant)
                        self.assertEqual(r.status_code, 200, (consultant, query, chart, name, stage))
                        data = r.get_json()
                        self.assertEqual((data["count"], len(data["records"])), (count, count), (consultant, query, chart, name, stage))
                        checked += 1
        self.assertGreater(checked, 15, "the data gives plenty of pieces to check")

    def test_the_pieces_of_one_bar_add_up_to_the_bar(self):
        for query in QUERIES:
            _, context = self.page(query)
            for chart, key in CHARTS.items():
                for group in context[key]:
                    for bar in group["rows"]:
                        total = sum(len(self.codes(query, chart, bar["name"], seg["stage"])) for seg in bar["segments"])
                        self.assertEqual(total, bar["total"], (query, chart, bar["name"]))

    def test_application_manager_chart_one_row_per_student_and_no_carried_forward_loss(self):
        self.assertEqual(self.codes("year=2026", "manager", "Mo", "06-Decision"), ["M1", "M4"], "M1's later Decision application represents the student")
        self.assertEqual(self.codes("year=2026", "manager", "Mo", "05-Assessment"), [], "M1's earlier Assessment row is not a second prospect")
        self.assertEqual(self.codes("year=2026", "manager", "Mo", "09-Enrolled"), ["M7"])
        self.assertEqual(self.codes("year=2026", "manager", "Nouran", "10-Lost"), [], "M3 has a live application in 2027, so it is not a 2026 loss")
        self.assertEqual(self.codes("year=2026", "manager", "Nouran", "09-Enrolled"), ["M2"])
        self.assertEqual(self.codes("year=2027", "manager", "Nouran", "05-Assessment"), ["M3"])

    def test_application_manager_chart_has_no_bar_for_a_blank_or_excluded_manager(self):
        _, context = self.page("year=2026")
        names = {bar["name"] for g in context["am_chart_groups"] for bar in g["rows"]}
        self.assertEqual(names, {"Mo", "Nouran"})
        for name in ("", "Admission", "Unassigned"):
            for stage in STAGES:
                self.assertEqual(self.codes("year=2026", "manager", name, stage), [], (name, stage))

    def test_university_chart_counts_every_row_not_one_per_student(self):
        self.assertEqual(sorted(self.codes("year=2026", "university", "Uni A", "05-Assessment")), ["M1", "M5", "M6"], "M1's Assessment row counts here")
        self.assertEqual(self.codes("year=2026", "university", "Uni B", "06-Decision"), ["M1"])
        self.assertEqual(self.codes("year=2026", "university", "Uni A", "10-Lost"), ["M3"], "the 2026 loss still counts for the university")
        self.assertEqual(self.codes("year=2026", "university", "Unassigned", "09-Enrolled"), ["M7"])

    def test_only_the_picked_consultants_applications_are_listed(self):
        mel = {c for q in QUERIES for chart in CHARTS for name, stage, _ in self.pieces(self.page(q)[1], chart) for c in self.codes(q, chart, name, stage)}
        hannah = {c for q in QUERIES for chart in CHARTS for name, stage, _ in self.pieces(self.page(q, "Hannah")[1], chart) for c in self.codes(q, chart, name, stage, "Hannah")}
        self.assertTrue(mel and all(code.startswith("M") for code in mel), mel)
        self.assertTrue(hannah and all(code.startswith("H") for code in hannah), hannah)

    def test_the_records_carry_the_usual_columns(self):
        record = self.records("year=2026", "manager", "Mo", "09-Enrolled").get_json()["records"][0]
        self.assertEqual(set(record), {"code", "student", "university", "intake", "consultant", "manager"})
        self.assertEqual((record["code"], record["consultant"], record["manager"]), ("M7", "Mel", "Mo"))

    def test_a_formula_looking_student_name_arrives_as_an_empty_cell_as_on_the_other_pages(self):
        record = self.records("year=2026", "university", "Unassigned", "09-Enrolled").get_json()["records"][0]
        self.assertEqual((record["code"], record["student"]), ("M7", ""))


class EdgeCaseTests(ConsultantsRecordsBase):
    def test_no_consultant_or_an_unknown_one_gives_an_empty_list_not_an_error(self):
        for consultant in (None, "", "Nobody", "Mel; DROP TABLE x", "<script>alert(1)</script>"):
            r = self.records("year=2026", "manager", "Mo", "09-Enrolled", consultant)
            self.assertEqual(r.status_code, 200, consultant)
            self.assertEqual((r.get_json()["count"], r.get_json()["records"]), (0, []), consultant)

    def test_a_consultant_set_to_group_as_other_cannot_be_listed(self):
        import sqlite3
        from tests.flask_test_support import db_module
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute("UPDATE lookup_tables SET group_as_other = 1 WHERE table_name='sales_office' AND lower(source_value)='hannah'")
        conn.commit()
        conn.close()
        self.assertEqual(self.records("year=2026", "manager", "Mo", "05-Assessment", "Hannah").get_json()["records"], [])
        self.assertTrue(self.records("year=2026", "manager", "Mo", "06-Decision", "Mel").get_json()["records"])

    def test_the_consultant_is_matched_ignoring_case(self):
        self.assertEqual(self.codes("year=2026", "manager", "Mo", "09-Enrolled", "mel"), ["M7"])

    def test_an_unknown_chart_or_stage_is_refused(self):
        for chart, stage in (("consultant", "05-Assessment"), ("source", "05-Assessment"), ("", "05-Assessment"), ("manager", "99-Nope"), ("manager", ""), ("am_report", "05-Assessment")):
            r = self.records("year=2026", chart, "Mo", stage)
            self.assertEqual(r.status_code, 400, (chart, stage))
            self.assertEqual(r.get_json(), {"error": "Unknown chart piece."})

    def test_a_name_that_is_not_on_the_chart_gives_an_empty_list(self):
        for name in ("", "Nobody", "mo", "Mo' OR '1'='1"):
            r = self.records("year=2026", "manager", name, "09-Enrolled")
            self.assertEqual(r.get_json()["records"], [], name)

    def test_an_intake_with_no_applications_gives_an_empty_list(self):
        for chart, name in (("university", "Uni A"), ("manager", "Mo")):
            self.assertEqual(self.records("year=2027&intake=intake_02", chart, name, "05-Assessment").get_json()["records"], [], chart)

    def test_an_unknown_year_is_read_as_the_default_year_exactly_as_the_page_does(self):
        self.assertEqual(self.codes("year=2099", "manager", "Mo", "06-Decision"), self.codes("year=2026", "manager", "Mo", "06-Decision"))

    def test_the_answer_is_never_cached(self):
        self.assertEqual(self.records("year=2026", "manager", "Mo", "09-Enrolled").headers["Cache-Control"], "no-store")

    def test_login_is_required(self):
        r = self.client.get("/consultants/records?consultant=Mel&chart=manager&name=Mo&stage=09-Enrolled")
        self.assertEqual(r.status_code, 302)
        self.assertIn("/login", r.headers["Location"])


class NoDataTests(IsolatedAppTestCase):
    def test_no_dataset_gives_an_empty_list_not_an_error(self):
        full = self._client_logged_in_as("full")
        r = full.get("/consultants/records?consultant=Mel&chart=manager&name=Mo&stage=09-Enrolled")
        self.assertEqual((r.status_code, r.get_json()["records"]), (200, []))


class PageTests(ConsultantsRecordsBase):
    def pieces_in(self, html, title):
        """The clickable pieces inside the chart panel called `title`."""
        panel = html[html.index(f"<h2>{title}</h2>"):]
        panel = panel[:panel.index("</section>")]
        return re.findall(r'<div class="chart-segment chart-segment-clickable"[^>]*>', panel), panel

    def test_the_manager_and_university_charts_are_clickable_and_the_others_are_not(self):
        html, context = self.page("year=2026")
        manager, panel = self.pieces_in(html, "Application Manager Pipeline Health")
        self.assertEqual(len(manager), len(self.pieces(context, "manager")))
        self.assertIn("Click a bar to list its applications.", panel)
        university, panel = self.pieces_in(html, "University Pipeline Health")
        self.assertEqual(len(university), len(self.pieces(context, "university")))
        self.assertIn("Click a bar to list its applications.", panel)
        for title in ("Consultant Pipeline Health", "Source Pipeline Health"):
            clickable, panel = self.pieces_in(html, title)
            self.assertEqual(clickable, [], title)
            self.assertNotIn("data-records", panel, title)
            self.assertNotIn("Click a bar", panel, title)

    def test_each_piece_names_its_chart_bar_and_stage_and_the_count_it_shows(self):
        html, context = self.page("year=2026")
        for chart, title in (("manager", "Application Manager Pipeline Health"), ("university", "University Pipeline Health")):
            pieces, _ = self.pieces_in(html, title)
            expected = self.pieces(context, chart)
            self.assertEqual(len(pieces), len(expected))
            for tag, (name, stage, count) in zip(pieces, expected):
                self.assertIn(f'data-count="{count}"', tag)
                params = re.search(r'data-records-params="([^"]*)"', tag).group(1)
                self.assertEqual(params, urlencode({"chart": chart, "name": name, "stage": stage}).replace("&", "&amp;"), tag)

    def test_the_page_has_one_pop_up_window_that_asks_the_consultants_records_route(self):
        html, _ = self.page("year=2026")
        self.assertEqual(html.count('id="chart-records"'), 1)
        self.assertIn('data-url="/consultants/records"', html)
        self.assertIn("chart-records.js", html)
        self.assertNotIn("chart-records-wide", html.split('id="chart-records"')[1].split(">")[0])

    def test_the_picker_alone_has_no_pop_up(self):
        r = self.full.get("/consultants")
        self.assertNotIn('id="chart-records"', r.get_data(as_text=True))


class PermissionTests(AccessRouteTestCase):
    URL = "/consultants/records?consultant=Mel&chart=manager&name=Mo&stage=09-Enrolled"

    def test_the_pop_up_follows_the_consultants_page_switch(self):
        from role_access import CONFIGURABLE_ROLES
        for role in CONFIGURABLE_ROLES:
            with self.subTest(role=role):
                client = self._client_logged_in_as(role)
                self.assertEqual(client.get(self.URL).status_code, 200, "on by default")
                self.save(self.grid_with(**{role: ((), ("consultants",))}))
                self.assertEqual(client.get("/consultants").status_code, 403)
                self.assertEqual(client.get(self.URL).status_code, 403, "off with the page")
                self.assertEqual(self.full.get(self.URL).status_code, 200, "Full Access is never affected")
                self.save(self.defaults())
                self.assertEqual(client.get(self.URL).status_code, 200)

    def test_other_switches_do_not_open_it(self):
        from role_access import CONFIGURABLE_ROLES, PERMISSION_KEYS
        role = CONFIGURABLE_ROLES[0]
        self.save({role: set(PERMISSION_KEYS) - {"consultants"}})
        self.assertEqual(self._client_logged_in_as(role).get(self.URL).status_code, 403)
