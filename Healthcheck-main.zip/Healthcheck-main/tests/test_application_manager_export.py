"""No full test suite existed for this module before Finding 11 - this
file is deliberately scoped to the formula-injection wiring check
(Finding 11) plus confirming the Finding 14 shared-helper extraction
didn't change this module's date-formatting/column-width output, not
general coverage of application_manager_export.py."""

import unittest
from datetime import date

import openpyxl

from application_manager_export import EXPORT_COLUMNS, build_application_manager_pipeline_export

TODAY = date(2026, 8, 13)


def _row(**overrides):
    row = {
        "Application": "Mo",
        "Status": "04-Onboarding",
        "Submitted To Uni": "2026-01-01",
        "Student Code": "PES-001",
        "Student Name": "Nina",
    }
    row.update(overrides)
    return row


class FormulaInjectionProtectionTests(unittest.TestCase):
    def test_formula_looking_student_name_is_not_stored_as_a_formula(self):
        buffer = build_application_manager_pipeline_export([_row(**{"Student Name": "=SUM(1,1)"})], TODAY)
        wb = openpyxl.load_workbook(buffer)
        ws = wb["Mo"]
        # Row 1 is the title row, row 2 is the header, data starts row 3.
        cell = ws.cell(row=3, column=EXPORT_COLUMNS.index("Student Name") + 1)
        self.assertEqual(cell.value, "=SUM(1,1)")
        self.assertNotEqual(cell.data_type, "f")


class WorkbookFormatTests(unittest.TestCase):
    """Confirms _finalize_columns()'s Finding 14 extraction (apply_date_format/
    apply_column_widths) produces byte-identical formatting to the inline
    loops it replaced - the title-row offset (header on row 2, not row 1)
    is this module's one genuinely distinct shape."""

    def setUp(self):
        self.buffer = build_application_manager_pipeline_export([_row()], TODAY)
        self.ws = openpyxl.load_workbook(self.buffer)["Mo"]

    def test_date_column_is_formatted_starting_below_the_header_row(self):
        date_col = EXPORT_COLUMNS.index("Date Submitted to University") + 1
        # Row 2 is the header itself - must not be formatted.
        self.assertNotEqual(self.ws.cell(row=2, column=date_col).number_format, "DD/MM/YYYY")
        self.assertEqual(self.ws.cell(row=3, column=date_col).number_format, "DD/MM/YYYY")

    def test_non_date_columns_are_not_formatted_as_dates(self):
        name_col = EXPORT_COLUMNS.index("Student Name") + 1
        self.assertNotEqual(self.ws.cell(row=3, column=name_col).number_format, "DD/MM/YYYY")

    def test_column_widths_match_the_established_heuristic(self):
        from openpyxl.utils import get_column_letter

        for i, column_name in enumerate(EXPORT_COLUMNS, start=1):
            expected = max(12, min(40, len(column_name) + 4))
            self.assertEqual(self.ws.column_dimensions[get_column_letter(i)].width, expected)


if __name__ == "__main__":
    unittest.main()
