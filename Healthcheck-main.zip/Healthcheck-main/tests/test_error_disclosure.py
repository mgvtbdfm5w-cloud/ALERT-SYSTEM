"""Upload / reprocess error messages must not disclose internals.

Before: a failure while opening or processing a workbook was shown to the
user as `Upload failed: <raw exception text>` - which could contain full
server filesystem paths, SQL and table names, Python exception text and
library/zip internals - and nothing was logged, so the real cause was lost.

Now:
- a USER-CAUSED bad file (corrupt, not a zip, parts missing) -> the literal
  message WORKBOOK_UNREADABLE_MESSAGE; the real exception is logged at
  WARNING with its traceback;
- a TECHNICAL failure (filesystem/OSError while opening, database or code
  error while processing rows) -> the existing generic route message
  ("... failed due to an unexpected error ..."); the real exception is
  logged at ERROR with its traceback by the route; nothing is persisted;
- the genuinely helpful validation messages (missing columns, no sheet
  found, no data rows) are unchanged - except that "no data rows" now names
  the sheet that was actually read instead of a hard-coded 'Import' - and
  user-supplied sheet names stay HTML-escaped.

Fault injection uses sentinel strings (paths, SQL wording, class names, a
"secret" filename) so any leak into a response is caught. Temp databases,
and uploads folders only.
"""

import ast
import html
import inspect
import io
import logging
import re
import sqlite3
import traceback
import unittest
import zipfile
from unittest import mock

import leads
import processing
from leads import REQUIRED_LEADS_SOURCE_COLUMNS
from processing import REQUIRED_IMPORT_COLUMNS, WORKBOOK_UNREADABLE_MESSAGE
from tests.connection_tracking import ConnectionTracker
from tests.flask_test_support import (
    ROLE_PASSWORDS,
    IsolatedAppTestCase,
    app_module,
    db_module,
    extract_token,
    make_xlsx,
)

import openpyxl

SAFE_OPEN_UPLOAD = f"Upload failed: {WORKBOOK_UNREADABLE_MESSAGE}"
SAFE_OPEN_REPROCESS = f"Reprocessing failed: {WORKBOOK_UNREADABLE_MESSAGE}"
GENERIC_UPLOAD = "Upload failed due to an unexpected error. Please try again or contact support."
GENERIC_REPROCESS = "Reprocessing failed due to an unexpected error. Please try again or contact support."

SECRET_FILENAME = "SecretNamedFile123.xlsx"
SECRET_DETAIL = "TopSecretDetail-9z"

# Words that must never reach a user in an upload/reprocess error message.
FORBIDDEN_IN_MESSAGES = (
    "Traceback", "Errno", "sqlite", "OperationalError", "no such table", "database is locked", "lookup_tables",
    "KeyError", "TypeError", "ValueError", "RuntimeError", "PermissionError", "FileNotFoundError", "OSError",
    "BadZipFile", "zip", "archive", "Content_Types", "workbook part", "Exception",
    "processing.py", "leads.py", "app.py", ".py", "/Users", "/var/folders", "/tmp", SECRET_FILENAME,
    "SecretColumnName", SECRET_DETAIL, "Permission denied", "No such file",
)


def zip_of(files):
    buf = io.BytesIO()
    archive = zipfile.ZipFile(buf, "w")
    for name, data in files.items():
        archive.writestr(name, data)
    archive.close()
    return buf.getvalue()


def workbook_bytes(sheets):
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    for name, rows in sheets.items():
        ws = wb.create_sheet(name)
        for row in rows:
            ws.append(row)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


class _Capture(logging.Handler):
    def __init__(self):
        super().__init__(logging.DEBUG)
        self.records = []

    def emit(self, record):
        self.records.append(record)

    def by(self, logger_name=None, level=None):
        return [
            r for r in self.records
            if (logger_name is None or r.name == logger_name) and (level is None or r.levelno == level)
        ]

    def text(self):
        parts = []
        for r in self.records:
            parts.append(r.getMessage())
            if r.exc_info:
                parts.append("".join(traceback.format_exception(*r.exc_info)))
        return "\n".join(parts)


class DisclosureTestCase(IsolatedAppTestCase):
    def setUp(self):
        super().setUp()
        self.tracker = ConnectionTracker(db_module)
        self.tracker.install()
        self.addCleanup(self.tracker.uninstall)
        self.addCleanup(self.tracker.force_close_leaks)
        self.client = self._client_logged_in_as("full")
        self.capture = _Capture()
        root = logging.getLogger()
        self._old_level = root.level
        root.addHandler(self.capture)
        root.setLevel(logging.DEBUG)
        self.addCleanup(root.removeHandler, self.capture)
        self.addCleanup(root.setLevel, self._old_level)

    # ------------------------------------------------------------ helpers
    def token(self):
        return extract_token(self.client.get("/login").get_data(as_text=True))

    def good_apps(self, code="PES-1"):
        row = {c: "" for c in REQUIRED_IMPORT_COLUMNS}
        row.update({"Student Code": code, "Student Name": "N", "Intake": "2026", "University Name": "U", "Course Name": "C"})
        return make_xlsx(REQUIRED_IMPORT_COLUMNS, [row]).getvalue()

    def good_leads(self):
        row = {c: "" for c in REQUIRED_LEADS_SOURCE_COLUMNS}
        row.update({"Student Id": "L1", "Name": "N"})
        return make_xlsx(REQUIRED_LEADS_SOURCE_COLUMNS, [row]).getvalue()

    def upload(self, path, data, name=SECRET_FILENAME):
        return self.client.post(
            path, data={"csrf_token": self.token(), "excel_file": (io.BytesIO(data), name)},
            content_type="multipart/form-data",
        )

    def reprocess(self):
        return self.client.post("/admin/reprocess", data={"csrf_token": self.token()})

    def landing(self, response):
        self.assertEqual(response.status_code, 302)
        return self.client.get(response.headers["Location"])

    def flashes(self, response):
        page = self.landing(response).get_data(as_text=True)
        return [(k, html.unescape(v)) for k, v in re.findall(r'class="flash (\w+)">([^<]+)<', page)]

    def seed_dataset(self):
        """A real, successful upload - leaves a dataset row and the stored
        workbook that Reprocess needs."""
        response = self.upload("/upload", self.good_apps(), name="seed.xlsx")
        self.assertIn("Upload succeeded", self.flashes(response)[0][1])
        self.stored = next(p for p in self.tmp_uploads_dir.iterdir() if p.name.endswith("seed.xlsx"))
        self.capture.records.clear()

    def snapshot(self):
        conn = sqlite3.connect(db_module.DB_PATH)
        try:
            return {
                "datasets": conn.execute("SELECT id, stored_filename FROM active_dataset ORDER BY id").fetchall(),
                "leads": conn.execute("SELECT id FROM active_leads_dataset ORDER BY id").fetchall(),
                "lookups": conn.execute("SELECT id, table_name, source_value FROM lookup_tables ORDER BY id").fetchall(),
                "unmapped": conn.execute("SELECT table_name, value, occurrence_count FROM unmapped_lookup_values ORDER BY id").fetchall(),
            }
        finally:
            conn.close()

    def assert_no_disclosure(self, response):
        """Nothing a user can see in the failure response contains internals."""
        messages = " ".join(text for _, text in self.flashes(response))
        for word in FORBIDDEN_IN_MESSAGES:
            self.assertNotIn(word, messages, f"{word!r} leaked into: {messages!r}")
        page = self.client.get(response.headers["Location"]).get_data(as_text=True)
        for pattern in (str(self.tmp_uploads_dir), str(self.tmp_db_dir), r"/Users/", r"/var/folders", "Traceback", "Errno"):
            self.assertNotIn(pattern, page)
        self.assertIsNone(re.search(r"\d{14}_", messages), "a stored filename leaked")
        self.assertNotIn(SECRET_FILENAME, response.get_data(as_text=True))

    def assert_logged_with_traceback(self, logger_name, level, exc_type=None, contains=None):
        records = self.capture.by(logger_name, level)
        self.assertTrue(records, f"no {logging.getLevelName(level)} record from {logger_name!r}: {[(r.name, r.levelname, r.getMessage()) for r in self.capture.records]}")
        record = records[-1]
        self.assertIsNotNone(record.exc_info, "the traceback must be preserved in the log")
        if exc_type is not None:
            self.assertTrue(
                issubclass(record.exc_info[0], exc_type) or exc_type in [type(c) for c in self._chain(record.exc_info[1])],
                f"logged {record.exc_info[0]} not {exc_type}",
            )
        if contains is not None:
            self.assertIn(contains, "".join(traceback.format_exception(*record.exc_info)))
        return record

    @staticmethod
    def _chain(exc):
        while exc is not None:
            yield exc
            exc = exc.__context__


# =========================================================================
# 1. Bad (user-caused) workbook files
# =========================================================================
class CorruptWorkbookTests(DisclosureTestCase):
    CORRUPT = {
        "text file named .xlsx": (b"this is not a workbook", "File is not a zip file"),
        "empty file": (b"", "File is not a zip file"),
        "zip that is not a workbook": (zip_of({"hello.txt": "x"}), "[Content_Types].xml"),
        "zip with no workbook part": (zip_of({"[Content_Types].xml": "<Types/>"}), "no valid workbook part"),
        "old .xls / OLE bytes": (b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1" + b"\0" * 600, "File is not a zip file"),
    }

    def test_corrupt_applications_workbook_gets_the_safe_excel_message(self):
        for label, (data, _) in self.CORRUPT.items():
            with self.subTest(file=label):
                before = self.snapshot()
                response = self.upload("/upload", data)
                self.assertEqual(self.flashes(response), [("error", SAFE_OPEN_UPLOAD)])
                self.assert_no_disclosure(response)
                self.assertEqual(self.snapshot(), before, "nothing persisted")

    def test_corrupt_leads_workbook_gets_the_same_safe_message(self):
        for label, (data, _) in self.CORRUPT.items():
            with self.subTest(file=label):
                before = self.snapshot()
                response = self.upload("/leads/upload", data)
                self.assertEqual(self.flashes(response), [("error", SAFE_OPEN_UPLOAD)])
                self.assert_no_disclosure(response)
                self.assertEqual(self.snapshot(), before)

    def test_a_truncated_real_workbook_is_handled_the_same_way(self):
        for path, data in (("/upload", self.good_apps()[:600]), ("/leads/upload", self.good_leads()[:600])):
            with self.subTest(path=path):
                response = self.upload(path, data)
                self.assertEqual(self.flashes(response), [("error", SAFE_OPEN_UPLOAD)])
                self.assert_no_disclosure(response)

    def test_library_and_zip_internals_never_reach_the_response(self):
        for label, (data, library_wording) in self.CORRUPT.items():
            with self.subTest(file=label):
                response = self.upload("/upload", data)
                body = " ".join(t for _, t in self.flashes(response)) + response.get_data(as_text=True)
                self.assertNotIn(library_wording, body)
                for word in ("openpyxl", "zipfile", "BadZipFile", "KeyError", "InvalidFileException"):
                    self.assertNotIn(word, body)

    def test_a_corrupt_stored_workbook_on_reprocess_gets_the_safe_message(self):
        self.seed_dataset()
        self.stored.write_bytes(b"corrupt on disk")
        before = self.snapshot()
        response = self.reprocess()
        self.assertEqual(self.flashes(response), [("error", SAFE_OPEN_REPROCESS)])
        self.assert_no_disclosure(response)
        self.assertEqual(self.snapshot(), before)

    def test_the_real_exception_is_logged_at_warning_with_its_traceback(self):
        for label, (data, library_wording) in self.CORRUPT.items():
            with self.subTest(file=label):
                self.capture.records.clear()
                self.upload("/upload", data)
                record = self.assert_logged_with_traceback("processing", logging.WARNING, contains=library_wording)
                self.assertIn("could not be opened", record.getMessage())
                self.assertEqual(self.capture.by("app", logging.ERROR), [], "a bad file is the user's problem, not an application error")

    def test_the_leads_open_failure_is_logged_at_warning_with_its_traceback(self):
        self.upload("/leads/upload", b"not a workbook")
        self.assert_logged_with_traceback("leads", logging.WARNING, contains="File is not a zip file")

    def test_reprocess_open_failure_is_logged_at_warning_with_its_traceback(self):
        self.seed_dataset()
        self.stored.write_bytes(b"corrupt on disk")
        self.reprocess()
        self.assert_logged_with_traceback("processing", logging.WARNING, contains="File is not a zip file")


# =========================================================================
# 2. Filesystem (OSError) failures while opening
# =========================================================================
class FilesystemFailureTests(DisclosureTestCase):
    def errors(self):
        path = str(self.tmp_uploads_dir / f"20260101000000_{SECRET_FILENAME}")
        return {
            "FileNotFoundError": FileNotFoundError(2, "No such file or directory", path),
            "PermissionError": PermissionError(13, "Permission denied", path),
            "disk I/O error": OSError(5, "Input/output error", path),
            "IsADirectoryError": IsADirectoryError(21, "Is a directory", path),
        }

    def test_applications_upload_shows_only_the_generic_message(self):
        for label, error in self.errors().items():
            with self.subTest(error=label):
                before = self.snapshot()
                with mock.patch("processing.openpyxl.load_workbook", side_effect=error):
                    response = self.upload("/upload", self.good_apps())
                self.assertEqual(self.flashes(response), [("error", GENERIC_UPLOAD)])
                self.assert_no_disclosure(response)
                self.assertEqual(self.snapshot(), before)

    def test_leads_upload_shows_only_the_generic_message(self):
        for label, error in self.errors().items():
            with self.subTest(error=label):
                with mock.patch("leads.openpyxl.load_workbook", side_effect=error):
                    response = self.upload("/leads/upload", self.good_leads())
                self.assertEqual(self.flashes(response), [("error", GENERIC_UPLOAD)])
                self.assert_no_disclosure(response)

    def test_reprocess_shows_only_the_generic_message(self):
        self.seed_dataset()
        for label, error in self.errors().items():
            with self.subTest(error=label):
                before = self.snapshot()
                with mock.patch("processing.openpyxl.load_workbook", side_effect=error):
                    response = self.reprocess()
                self.assertEqual(self.flashes(response), [("error", GENERIC_REPROCESS)])
                self.assert_no_disclosure(response)
                self.assertEqual(self.snapshot(), before)

    def test_the_real_error_with_its_path_is_logged_at_error_with_a_traceback(self):
        """The path is fine - and useful - in the SERVER log; it must only
        be absent from what the user sees."""
        for label, error in self.errors().items():
            with self.subTest(error=label):
                self.capture.records.clear()
                with mock.patch("processing.openpyxl.load_workbook", side_effect=error):
                    self.upload("/upload", self.good_apps())
                record = self.assert_logged_with_traceback("app", logging.ERROR, exc_type=type(error))
                self.assertIn(SECRET_FILENAME, "".join(traceback.format_exception(*record.exc_info)))
                self.assertEqual(self.capture.by("processing", logging.WARNING), [], "not mistaken for a bad file")

    def test_leads_filesystem_error_is_logged_at_error_with_a_traceback(self):
        error = PermissionError(13, "Permission denied", str(self.tmp_uploads_dir / "x.xlsx"))
        with mock.patch("leads.openpyxl.load_workbook", side_effect=error):
            self.upload("/leads/upload", self.good_leads())
        self.assert_logged_with_traceback("app", logging.ERROR, exc_type=PermissionError)


# =========================================================================
# 3. Technical failures while processing rows / saving
# =========================================================================
class TechnicalFailureTests(DisclosureTestCase):
    def failures(self):
        return {
            "KeyError": KeyError("SecretColumnName"),
            "TypeError with a source path": TypeError(f"unsupported operand in /Users/someone/gsp/processing.py {SECRET_DETAIL}"),
            "sqlite no such table": sqlite3.OperationalError("no such table: lookup_tables"),
            "sqlite locked": sqlite3.OperationalError("database is locked"),
            "RuntimeError": RuntimeError(SECRET_DETAIL),
        }

    def test_applications_upload_row_failures_show_the_generic_message_only(self):
        for label, error in self.failures().items():
            with self.subTest(error=label):
                before = self.snapshot()
                with mock.patch("processing._lookup", side_effect=error):
                    response = self.upload("/upload", self.good_apps())
                self.assertEqual(self.flashes(response), [("error", GENERIC_UPLOAD)])
                self.assert_no_disclosure(response)
                self.assertEqual(self.snapshot(), before, "no partial dataset or bookkeeping persisted")

    def test_reprocess_row_failures_show_the_generic_message_only(self):
        self.seed_dataset()
        for label, error in self.failures().items():
            with self.subTest(error=label):
                before = self.snapshot()
                with mock.patch("processing._lookup", side_effect=error):
                    response = self.reprocess()
                self.assertEqual(self.flashes(response), [("error", GENERIC_REPROCESS)])
                self.assert_no_disclosure(response)
                self.assertEqual(self.snapshot(), before)

    def test_leads_row_failures_show_the_generic_message_only(self):
        for label, error in self.failures().items():
            with self.subTest(error=label):
                before = self.snapshot()
                with mock.patch("leads.lookup_stage", side_effect=error):
                    response = self.upload("/leads/upload", self.good_leads())
                self.assertEqual(self.flashes(response), [("error", GENERIC_UPLOAD)])
                self.assert_no_disclosure(response)
                self.assertEqual(self.snapshot(), before)

    def test_the_real_exception_is_logged_at_error_with_its_traceback(self):
        for label, error in self.failures().items():
            with self.subTest(error=label):
                self.capture.records.clear()
                with mock.patch("processing._lookup", side_effect=error):
                    self.upload("/upload", self.good_apps())
                record = self.assert_logged_with_traceback("app", logging.ERROR, exc_type=type(error))
                self.assertIn(str(error.args[0]) if error.args else "", "".join(traceback.format_exception(*record.exc_info)))
                self.assertEqual(self.capture.by("processing", logging.WARNING), [])

    def test_reprocess_real_exception_is_logged_at_error_with_its_traceback(self):
        self.seed_dataset()
        with mock.patch("processing._lookup", side_effect=sqlite3.OperationalError("no such table: lookup_tables")):
            self.reprocess()
        self.assert_logged_with_traceback("app", logging.ERROR, exc_type=sqlite3.OperationalError, contains="no such table")

    def test_real_database_faults_during_upload_and_reprocess_do_not_leak(self):
        self.seed_dataset()
        for what in ("execute", "commit"):
            for label, call, generic in (
                ("upload", lambda: self.upload("/upload", self.good_apps()), GENERIC_UPLOAD),
                ("leads upload", lambda: self.upload("/leads/upload", self.good_leads()), GENERIC_UPLOAD),
            ):
                with self.subTest(fault=what, route=label):
                    before = self.snapshot()
                    with self.tracker.failing(what):
                        response = call()
                    self.assertEqual(self.flashes(response), [("error", generic)])
                    self.assert_no_disclosure(response)
                    self.assertEqual(self.snapshot(), before)
                    self.assertEqual(self.tracker.leaked(), [])
        with self.subTest(fault="commit", route="reprocess"):
            with self.tracker.failing("commit"):
                response = self.reprocess()
            self.assertEqual(self.flashes(response), [("error", GENERIC_REPROCESS)])
            self.assert_no_disclosure(response)

    def test_a_failure_inside_process_workbook_rolls_back_before_re_raising(self):
        conn = db_module.get_connection()
        try:
            path = self.tmp_uploads_dir / "direct.xlsx"
            path.write_bytes(self.good_apps())
            with mock.patch("processing._lookup", side_effect=RuntimeError(SECRET_DETAIL)):
                with self.assertRaises(RuntimeError) as caught:
                    processing.process_workbook(path, conn, "2026-01-01T00:00:00")
            self.assertEqual(str(caught.exception), SECRET_DETAIL, "the ORIGINAL exception propagates, not a wrapper")
            self.assertFalse(conn.in_transaction)
        finally:
            conn.close()


# =========================================================================
# 4. Helpful validation messages are unchanged
# =========================================================================
class ValidationMessagesUnchangedTests(DisclosureTestCase):
    def test_applications_missing_columns(self):
        data = workbook_bytes({"Sheet1": [["A", "B"], [1, 2]]})
        expected = f"Upload failed: The 'Sheet1' sheet is missing required column(s): {', '.join(REQUIRED_IMPORT_COLUMNS)}"
        self.assertEqual(self.flashes(self.upload("/upload", data)), [("error", expected)])

    def test_applications_no_usable_sheet_names_the_users_own_sheets(self):
        data = workbook_bytes({"Alpha": [["A"]], "Beta": [["B"]]})
        expected = "Upload failed: Could not find a sheet containing the required source columns. Sheets found in the workbook: Alpha, Beta"
        self.assertEqual(self.flashes(self.upload("/upload", data)), [("error", expected)])

    def test_leads_missing_columns(self):
        data = workbook_bytes({"S": [["A"], [1]]})
        expected = f"Upload failed: The 'S' sheet is missing required column(s): {', '.join(REQUIRED_LEADS_SOURCE_COLUMNS)}"
        self.assertEqual(self.flashes(self.upload("/leads/upload", data)), [("error", expected)])

    def test_leads_no_data_rows(self):
        data = workbook_bytes({"Leads": [REQUIRED_LEADS_SOURCE_COLUMNS]})
        self.assertEqual(self.flashes(self.upload("/leads/upload", data)), [("error", "Upload failed: No data rows were found in the 'Leads' sheet.")])

    def test_other_validation_messages_are_untouched(self):
        token = self.token()
        post = lambda path, **d: self.flashes(self.client.post(path, data={"csrf_token": token, **d}))
        self.assertEqual(post("/admin/kpi-targets/__COMPANY__", month_key="2026-08", target_value="abc"), [("error", "Target must be a whole number.")])
        self.assertEqual(post("/admin/forecast-settings/02-PendingQA", forecast_percent="500"), [("error", "Forecast % must be between 0 and 100.")])
        self.assertEqual(post("/admin/lookups/status/add", source_value=""), [("error", "Source / Lookup Value is required.")])


# =========================================================================
# 5. The 'no data rows' wording names the sheet that was actually read
# =========================================================================
class NoDataRowsWordingTests(DisclosureTestCase):
    def headers_only(self, **sheets):
        return workbook_bytes({name: [REQUIRED_IMPORT_COLUMNS] for name in sheets})

    def message_for(self, data):
        return self.flashes(self.upload("/upload", data))

    def test_a_sheet_not_called_import_is_named_correctly(self):
        self.assertEqual(self.message_for(workbook_bytes({"Sheet1": [REQUIRED_IMPORT_COLUMNS]})),
                         [("error", "Upload failed: No data rows were found in the 'Sheet1' sheet.")])

    def test_a_sheet_called_import_still_says_import(self):
        self.assertEqual(self.message_for(workbook_bytes({"Import": [REQUIRED_IMPORT_COLUMNS]})),
                         [("error", "Upload failed: No data rows were found in the 'Import' sheet.")])

    def test_in_a_multi_sheet_workbook_the_selected_sheet_is_named(self):
        data = workbook_bytes({"Cover": [["Notes"]], "Applications": [REQUIRED_IMPORT_COLUMNS]})
        self.assertEqual(self.message_for(data), [("error", "Upload failed: No data rows were found in the 'Applications' sheet.")])

    def test_the_hard_coded_wording_is_gone_from_the_code(self):
        self.assertNotIn("'Import' sheet.\"", inspect.getsource(processing))
        self.assertNotIn("Could not open the workbook", inspect.getsource(processing))
        self.assertNotIn("Unexpected error while processing rows", inspect.getsource(processing))
        self.assertNotIn("Could not open the workbook", inspect.getsource(leads))


class SheetNamesStayEscapedTests(DisclosureTestCase):
    NAME = "R&D <x>"

    def raw_page(self, response):
        return self.client.get(response.headers["Location"]).get_data(as_text=True)

    def test_a_sheet_name_in_the_no_data_rows_message_is_escaped(self):
        page = self.raw_page(self.upload("/upload", workbook_bytes({self.NAME: [REQUIRED_IMPORT_COLUMNS]})))
        self.assertIn("R&amp;D &lt;x&gt;", page)
        self.assertNotIn("<x>", page)

    def test_sheet_names_in_the_no_usable_sheet_message_are_escaped(self):
        page = self.raw_page(self.upload("/upload", workbook_bytes({self.NAME: [["A"]], "Other": [["B"]]})))
        self.assertIn("R&amp;D &lt;x&gt;", page)
        self.assertNotIn("<x>", page)

    def test_leads_sheet_names_are_escaped_too(self):
        page = self.raw_page(self.upload("/leads/upload", workbook_bytes({self.NAME: [REQUIRED_LEADS_SOURCE_COLUMNS]})))
        self.assertIn("R&amp;D &lt;x&gt;", page)
        self.assertNotIn("<x>", page)

    def test_the_flash_template_does_not_mark_messages_safe(self):
        for template in ("templates/layout.html", "templates/login.html"):
            self.assertNotIn("|safe", open(template).read())


# =========================================================================
# 6. Success paths are unchanged
# =========================================================================
class SuccessUnchangedTests(DisclosureTestCase):
    def test_applications_upload_succeeds_exactly_as_before(self):
        response = self.upload("/upload", self.good_apps())
        self.assertEqual(self.flashes(response), [("success", "Upload succeeded. 1 rows processed, 0 unmapped lookup value(s) found.")])
        self.assertEqual(len(self.snapshot()["datasets"]), 1)
        self.assertEqual(self.capture.by(None, logging.WARNING) + self.capture.by(None, logging.ERROR), [])

    def test_leads_upload_succeeds_exactly_as_before(self):
        response = self.upload("/leads/upload", self.good_leads())
        self.assertEqual(self.flashes(response), [("success", "Upload succeeded. 1 row(s) processed, 13 column(s) found.")])
        self.assertEqual(len(self.snapshot()["leads"]), 1)

    def test_reprocess_succeeds_exactly_as_before(self):
        self.seed_dataset()
        response = self.reprocess()
        self.assertEqual(self.flashes(response), [("success", "Reprocessing succeeded. 1 rows processed, 0 unmapped lookup value(s) found.")])
        self.assertEqual(len(self.snapshot()["datasets"]), 2)

    def test_unmapped_values_are_still_counted_on_a_successful_upload(self):
        row = {c: "" for c in REQUIRED_IMPORT_COLUMNS}
        row.update({"Student Code": "P", "Student Name": "N", "Application Status": "Brand New Status"})
        response = self.upload("/upload", make_xlsx(REQUIRED_IMPORT_COLUMNS, [row]).getvalue())
        self.assertEqual(self.flashes(response), [("success", "Upload succeeded. 1 rows processed, 1 unmapped lookup value(s) found.")])


# =========================================================================
# 7. Log hygiene and the structural guard
# =========================================================================
class FilesystemErrorClassificationTests(DisclosureTestCase):
    """OS failures vs bad files. openpyxl raises a bare IOError (an OSError
    WITHOUT an errno) for a zip with no workbook part - that is a bad file."""

    def test_is_filesystem_error_distinguishes_by_errno_not_by_text(self):
        for error in (FileNotFoundError(2, "x", "/p"), PermissionError(13, "x"), OSError(5, "Input/output error"),
                      IsADirectoryError(21, "x"), NotADirectoryError(20, "x"), OSError(28, "No space left")):
            self.assertTrue(processing.is_filesystem_error(error), repr(error))
        for error in (IOError("File contains no valid workbook part"), OSError("a message only"), zipfile.BadZipFile("x"),
                      KeyError("x"), ValueError("x"), RuntimeError("x"), EOFError(), sqlite3.OperationalError("locked")):
            self.assertFalse(processing.is_filesystem_error(error), repr(error))

    def test_openpyxls_bare_ioerror_is_a_bad_file_not_a_server_problem(self):
        data = zip_of({"[Content_Types].xml": "<Types/>"})
        for path in ("/upload", "/leads/upload"):
            with self.subTest(path=path):
                self.capture.records.clear()
                response = self.upload(path, data)
                self.assertEqual(self.flashes(response), [("error", SAFE_OPEN_UPLOAD)])
                self.assert_no_disclosure(response)
                self.assert_logged_with_traceback("processing" if path == "/upload" else "leads", logging.WARNING, contains="no valid workbook part")
                self.assertEqual(self.capture.by("app", logging.ERROR), [])

    def test_a_bare_oserror_without_errno_is_not_shown_to_the_user_either(self):
        with mock.patch("processing.openpyxl.load_workbook", side_effect=OSError(f"boom {SECRET_DETAIL} /Users/x")):
            response = self.upload("/upload", self.good_apps())
        self.assertEqual(self.flashes(response), [("error", SAFE_OPEN_UPLOAD)])
        self.assert_no_disclosure(response)


class LogHygieneTests(DisclosureTestCase):
    def test_logs_never_contain_file_contents_cookies_tokens_or_request_bodies(self):
        marker = b"UPLOADED-CONTENT-MARKER-5521"
        token = self.token()
        cookie = self.client.get_cookie("session").value
        self.client.post(
            "/upload",
            data={"csrf_token": token, "excel_file": (io.BytesIO(marker + b" not a workbook"), "x.xlsx")},
            content_type="multipart/form-data",
        )
        with mock.patch("processing._lookup", side_effect=RuntimeError(SECRET_DETAIL)):
            self.upload("/upload", self.good_apps())
        text = self.capture.text()
        for secret in (marker.decode(), token, cookie, ROLE_PASSWORDS["full"], "csrf_token", "excel_file"):
            self.assertNotIn(secret, text)
        self.assertIn(SECRET_DETAIL, text, "technical detail is allowed - and expected - in the server log")


class StructuralGuardTests(unittest.TestCase):
    """No caught exception may ever be interpolated into a user-facing
    ProcessingError / LeadsProcessingError message, and the unsafe paths
    keep the shapes that make that true."""

    USER_FACING = {"ProcessingError", "LeadsProcessingError"}

    def tree(self, module):
        return ast.parse(inspect.getsource(module))

    def functions(self, module):
        return [n for n in ast.walk(self.tree(module)) if isinstance(n, ast.FunctionDef)]

    @staticmethod
    def bound_exception_names(func):
        return {h.name for h in ast.walk(func) if isinstance(h, ast.ExceptHandler) and h.name}

    def test_no_caught_exception_is_interpolated_into_a_user_facing_error(self):
        for module in (processing, leads):
            for func in self.functions(module):
                caught = self.bound_exception_names(func)
                for node in ast.walk(func):
                    if (isinstance(node, ast.Raise) and isinstance(node.exc, ast.Call)
                            and getattr(node.exc.func, "id", "") in self.USER_FACING):
                        used = {n.id for arg in node.exc.args for n in ast.walk(arg) if isinstance(n, ast.Name)}
                        self.assertFalse(used & caught, f"{module.__name__}.{func.name} line {node.lineno} interpolates {used & caught}")

    def test_user_facing_errors_are_only_ever_built_from_literals_and_safe_names(self):
        allowed_names = {"ws", "missing", "workbook", "WORKBOOK_UNREADABLE_MESSAGE", "title"}
        for module in (processing, leads):
            for node in ast.walk(self.tree(module)):
                if (isinstance(node, ast.Raise) and isinstance(node.exc, ast.Call)
                        and getattr(node.exc.func, "id", "") in self.USER_FACING):
                    names = {n.id for arg in node.exc.args for n in ast.walk(arg) if isinstance(n, ast.Name)}
                    self.assertTrue(names <= allowed_names, f"{module.__name__} line {node.lineno}: unexpected names {names - allowed_names}")

    def test_the_open_failure_shapes(self):
        for module, func_name, error_class in ((processing, "process_workbook", "ProcessingError"), (leads, "process_leads_workbook", "LeadsProcessingError")):
            func = next(f for f in self.functions(module) if f.name == func_name)
            first_try = next(n for n in ast.walk(func) if isinstance(n, ast.Try))
            self.assertEqual([ast.unparse(h.type) for h in first_try.handlers], ["Exception"])
            handler = first_try.handlers[0]
            # 1. a genuine filesystem error is re-raised UNCHANGED...
            guard = next(s for s in handler.body if isinstance(s, ast.If))
            self.assertIn("is_filesystem_error", ast.unparse(guard.test))
            self.assertEqual([type(s) for s in guard.body], [ast.Raise])
            self.assertIsNone(guard.body[0].exc, "bare `raise`")
            # 2. ...anything else is logged at WARNING (with the traceback) and becomes a LITERAL user message.
            warnings = [c for c in ast.walk(handler) if isinstance(c, ast.Call) and getattr(c.func, "attr", "") == "warning"]
            self.assertEqual(len(warnings), 1)
            self.assertTrue(any(k.arg == "exc_info" and getattr(k.value, "value", None) is True for k in warnings[0].keywords))
            final = handler.body[-1]
            self.assertIsInstance(final, ast.Raise)
            self.assertEqual(getattr(final.exc.func, "id", None), error_class)
            self.assertEqual([ast.unparse(a) for a in final.exc.args], ["WORKBOOK_UNREADABLE_MESSAGE"])

    def test_the_row_loop_handler_reraises_the_original_exception(self):
        func = next(f for f in self.functions(processing) if f.name == "process_workbook")
        handlers = [h for t in ast.walk(func) if isinstance(t, ast.Try) for h in t.handlers if ast.unparse(h.type) == "Exception" and any(
            isinstance(c, ast.Call) and getattr(c.func, "attr", "") == "rollback" for c in ast.walk(h))]
        self.assertEqual(len(handlers), 1)
        self.assertIsNone(handlers[0].name)
        self.assertIsInstance(handlers[0].body[-1], ast.Raise)
        self.assertIsNone(handlers[0].body[-1].exc, "bare `raise`: the original exception, not a wrapper")


if __name__ == "__main__":
    unittest.main()
