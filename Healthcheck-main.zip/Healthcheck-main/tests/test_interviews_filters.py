"""The Interviews page: five business days (Today, Tomorrow and the three after)
and the Application Manager / QA Officer / Consultant filters."""

import io
import re
import unittest
from datetime import date
from unittest import mock

import interviews as interviews_module
from flask import template_rendered
from pipeline import list_qa_officers
from tests.flask_test_support import IsolatedAppTestCase, app_module, extract_token
from tests.test_upload_atomicity import book, row

STATUS_LOOKUP = [("Assessment", "05-Assessment"), ("Ready", "07-Ready"), ("Enrolled", "09-Enrolled"), ("QA Rejected", "00-QARejected")]
DAYS = [date(2026, 11, 2), date(2026, 11, 3), date(2026, 11, 4), date(2026, 11, 5), date(2026, 11, 6)]       # Monday to Friday


def student(code, day, manager, qa, consultant, status="Assessment", name=None):
    return row(**{"Student Code": code, "Student Name": name or f"Student {code}", "Application Status": status, "Intake": "September 2026",
                  "University Name": "Test Uni", "Admission Officer": manager, "QA Officer": qa, "Counsellor": consultant,
                  "Interview Booked Date/Time": f"{day} 10:00"})


STUDENTS = [
    student("M1", "02/11/2026", "Alice A", "Quinn Q", "Gina G"),
    student("M2", "02/11/2026", "Bob B", "Rita R", "Hugh H"),
    student("T1", "03/11/2026", "Alice A", "Rita R", "Gina G"),
    student("W1", "04/11/2026", "Bob B", "Quinn Q", "Gina G"),
    student("W2", "04/11/2026", "Cara C", "", "Ivan I"),                       # no QA Officer
    student("H1", "05/11/2026", "Alice A", "Quinn Q", "Hugh H"),
    student("F1", "06/11/2026", "Bob B", "Rita R", "Ivan I"),
    student("F2", "06/11/2026", "Alice A", "Quinn Q", "Gina G", status="Enrolled"),       # excluded status
    student("X1", "09/11/2026", "Dora D", "Sam S", "Jo J"),                    # the Monday after: outside the five days
    student("X0", "30/10/2026", "Dora D", "Sam S", "Jo J"),                    # the Friday before
    student("N1", "", "Alice A", "Quinn Q", "Gina G"),                         # no interview booked
]


def captured():
    from contextlib import contextmanager

    @contextmanager
    def manager():
        rendered = []

        def record(sender, template, context, **extra):
            rendered.append((template.name, dict(context)))

        template_rendered.connect(record, app_module.app)
        try:
            yield rendered
        finally:
            template_rendered.disconnect(record, app_module.app)
    return manager()


class InterviewsBase(IsolatedAppTestCase):
    def setUp(self):
        super().setUp()
        self.client = self._client_logged_in_as("full")
        data = book(STUDENTS, lookups={"status": STATUS_LOOKUP})
        token = extract_token(self.client.get("/login").get_data(as_text=True))
        self.assertEqual(self.client.post("/upload", data={"csrf_token": token, "excel_file": (io.BytesIO(data), "t.xlsx")},
                                          content_type="multipart/form-data").status_code, 302)

    def page(self, query="", days=DAYS, client=None):
        with captured() as rendered, mock.patch.object(app_module, "get_operational_days", return_value=days):
            r = (client or self.client).get("/interviews" + query)
        self.assertEqual(r.status_code, 200, query)
        return r.get_data(as_text=True), next(c for name, c in rendered if name == "interviews.html")

    def listed(self, query="", days=DAYS):
        """{section label: [student names in the order shown]}"""
        _, context = self.page(query, days)
        return {s["label"]: [st["Student Code"] for g in s["groups"] for st in g["students"]] for s in context["sections"]}

    def options(self, html, name):
        block = html[html.index(f'<select name="{name}"'):]
        block = block[:block.index("</select>")]
        return re.findall(r'<option value="([^"]*)"', block), re.findall(r'<option value="([^"]*)" selected', block)


class FiveDaysTests(InterviewsBase):
    def test_five_sections_today_tomorrow_and_the_three_after_in_the_same_format(self):
        html, context = self.page()
        headings = re.findall(r"<h2>(Interviews [^<]*)</h2>", html)
        self.assertEqual(headings, ["Interviews Today &mdash; Monday 2 November 2026",
                                    "Interviews Tomorrow &mdash; Tuesday 3 November 2026",
                                    "Interviews Wednesday &mdash; Wednesday 4 November 2026",
                                    "Interviews Thursday &mdash; Thursday 5 November 2026",
                                    "Interviews Friday &mdash; Friday 6 November 2026"])
        self.assertEqual([s["label"] for s in context["sections"]], ["Today", "Tomorrow", "Wednesday", "Thursday", "Friday"])
        self.assertEqual(html.count('<table class="data-table interviews-table">'), 5)

    def test_each_section_lists_only_its_own_days_interviews(self):
        self.assertEqual(self.listed(), {"Today": ["M1", "M2"], "Tomorrow": ["T1"], "Wednesday": ["W1", "W2"], "Thursday": ["H1"], "Friday": ["F1"]})

    def test_nothing_from_outside_the_five_days_or_with_an_excluded_status_or_no_interview(self):
        html, _ = self.page()
        for code in ("X1", "X0", "N1", "F2"):
            self.assertNotIn(code, html, code)

    def test_the_tables_keep_their_columns_and_copy_buttons(self):
        html, _ = self.page()
        self.assertEqual(html.count("<th>QA Officer</th>"), 5)
        self.assertIn('<button type="button" class="copy-btn" data-code="W1">', html)

    def test_a_day_with_no_interviews_says_so_in_the_same_words(self):
        shifted = [date(2026, 11, 9), date(2026, 11, 10), date(2026, 11, 11), date(2026, 11, 12), date(2026, 11, 13)]
        html, _ = self.page(days=shifted)
        self.assertIn("X1", html, "the 9 November interview is Today when the days are shifted")
        self.assertIn("No interviews scheduled for tomorrow.", html)
        self.assertIn("No interviews scheduled for Wednesday.", html)
        self.assertIn("No interviews scheduled for Thursday.", html)
        self.assertIn("No interviews scheduled for Friday.", html)
        self.assertNotIn("No interviews scheduled for today.", html)

    def test_real_calendar_a_saturday_shows_monday_to_friday(self):
        with mock.patch.object(interviews_module, "today_uk", return_value=date(2026, 11, 7)):
            r = self.client.get("/interviews")
        html = r.get_data(as_text=True)
        headings = re.findall(r"<h2>(Interviews [^<]*)</h2>", html)
        self.assertEqual([h.split(" &mdash; ")[0] for h in headings], ["Interviews Today", "Interviews Tomorrow", "Interviews Wednesday", "Interviews Thursday", "Interviews Friday"])
        self.assertIn("Monday 9 November 2026", headings[0])
        self.assertIn("Friday 13 November 2026", headings[4])
        self.assertIn("X1", html)

    def test_real_calendar_a_friday_shows_friday_then_monday_to_thursday(self):
        with mock.patch.object(interviews_module, "today_uk", return_value=date(2026, 11, 6)):
            html = self.client.get("/interviews").get_data(as_text=True)
        headings = re.findall(r"<h2>(Interviews [^<]*)</h2>", html)
        self.assertEqual([h.split(" &mdash; ")[1] for h in headings],
                         ["Friday 6 November 2026", "Monday 9 November 2026", "Tuesday 10 November 2026", "Wednesday 11 November 2026", "Thursday 12 November 2026"])
        self.assertEqual([h.split(" &mdash; ")[0] for h in headings], ["Interviews Today", "Interviews Tomorrow", "Interviews Tuesday", "Interviews Wednesday", "Interviews Thursday"])

    def test_real_calendar_a_midweek_day(self):
        with mock.patch.object(interviews_module, "today_uk", return_value=date(2026, 11, 4)):
            html = self.client.get("/interviews").get_data(as_text=True)
        headings = [h.split(" &mdash; ")[1] for h in re.findall(r"<h2>(Interviews [^<]*)</h2>", html)]
        self.assertEqual(headings, ["Wednesday 4 November 2026", "Thursday 5 November 2026", "Friday 6 November 2026", "Monday 9 November 2026", "Tuesday 10 November 2026"])


class FilterTests(InterviewsBase):
    def test_three_filters_sit_above_the_days_in_this_order(self):
        html, _ = self.page()
        first_section = html.index("<h2>Interviews Today")
        bar = html[:first_section]
        self.assertLess(bar.index('name="manager"'), bar.index('name="qa"'))
        self.assertLess(bar.index('name="qa"'), bar.index('name="consultant"'))
        for label in ("Application Manager</label>", "QA Officer</label>", "Consultant</label>"):
            self.assertIn(label, bar)
        for first in ("All Application Managers", "All QA Officers", "All Consultants"):
            self.assertIn(first, bar)
        self.assertEqual(bar.count('onchange="this.form.submit()"'), 3, "each dropdown applies as soon as it is changed")

    def test_the_options_are_the_people_with_an_interview_in_the_five_days(self):
        html, _ = self.page()
        self.assertEqual(self.options(html, "manager")[0], ["", "Alice", "Bob", "Cara"], "Dora has none in these days; Alice's Enrolled F2 is excluded but she has others")
        self.assertEqual(self.options(html, "qa")[0], ["", "Quinn", "Rita", "Unassigned"], "Sam's only interviews are outside the five days")
        self.assertEqual(self.options(html, "consultant")[0], ["", "Gina", "Hugh", "Ivan"])

    def test_the_options_follow_the_days_being_shown(self):
        html, _ = self.page(days=[date(2026, 11, 9)] + DAYS[:4])
        self.assertIn("Dora", self.options(html, "manager")[0])
        self.assertIn("Sam", self.options(html, "qa")[0])
        self.assertIn("Jo", self.options(html, "consultant")[0])

    def test_the_application_manager_filter_narrows_every_day(self):
        self.assertEqual(self.listed("?manager=Alice"), {"Today": ["M1"], "Tomorrow": ["T1"], "Wednesday": [], "Thursday": ["H1"], "Friday": []})
        self.assertEqual(self.listed("?manager=Bob"), {"Today": ["M2"], "Tomorrow": [], "Wednesday": ["W1"], "Thursday": [], "Friday": ["F1"]})

    def test_the_qa_officer_filter_narrows_every_day_including_unassigned(self):
        self.assertEqual(self.listed("?qa=Quinn"), {"Today": ["M1"], "Tomorrow": [], "Wednesday": ["W1"], "Thursday": ["H1"], "Friday": []})
        self.assertEqual(self.listed("?qa=Rita"), {"Today": ["M2"], "Tomorrow": ["T1"], "Wednesday": [], "Thursday": [], "Friday": ["F1"]})
        self.assertEqual(self.listed("?qa=Unassigned"), {"Today": [], "Tomorrow": [], "Wednesday": ["W2"], "Thursday": [], "Friday": []})

    def test_the_consultant_filter_narrows_every_day(self):
        self.assertEqual(self.listed("?consultant=Gina"), {"Today": ["M1"], "Tomorrow": ["T1"], "Wednesday": ["W1"], "Thursday": [], "Friday": []})
        self.assertEqual(self.listed("?consultant=Ivan"), {"Today": [], "Tomorrow": [], "Wednesday": ["W2"], "Thursday": [], "Friday": ["F1"]})

    def test_filters_combine(self):
        self.assertEqual(self.listed("?manager=Alice&qa=Quinn"), {"Today": ["M1"], "Tomorrow": [], "Wednesday": [], "Thursday": ["H1"], "Friday": []})
        self.assertEqual(self.listed("?manager=Alice&consultant=Hugh"), {"Today": [], "Tomorrow": [], "Wednesday": [], "Thursday": ["H1"], "Friday": []})
        self.assertEqual(self.listed("?manager=Bob&qa=Quinn&consultant=Gina"), {"Today": [], "Tomorrow": [], "Wednesday": ["W1"], "Thursday": [], "Friday": []})
        self.assertEqual(sum(len(v) for v in self.listed("?manager=Alice&qa=Rita&consultant=Ivan").values()), 0)

    def test_a_value_that_is_not_an_option_is_ignored(self):
        everything = self.listed()
        for query in ("?manager=Nobody", "?manager=", "?manager=alice", "?manager=Dora", "?qa=Sam", "?qa=%3Cscript%3E", "?consultant=Jo", "?consultant=",
                      "?manager=Alice&qa=Nope"):
            got = self.listed(query)
            if query == "?manager=Alice&qa=Nope":
                self.assertEqual(got, self.listed("?manager=Alice"), query)
            else:
                self.assertEqual(got, everything, query)
        html, _ = self.page("?manager=%3Cscript%3Ealert(1)%3C/script%3E")
        self.assertNotIn("<script>alert", html)

    def test_selected_values_are_marked_and_clear_filters_appears_only_when_filtered(self):
        html, _ = self.page("?manager=Alice&qa=Rita&consultant=Hugh")
        self.assertEqual(self.options(html, "manager")[1], ["Alice"])
        self.assertEqual(self.options(html, "qa")[1], ["Rita"])
        self.assertEqual(self.options(html, "consultant")[1], ["Hugh"])
        self.assertIn('<a href="/interviews" class="uni-clear">Clear filters</a>', html)
        html, _ = self.page()
        self.assertEqual([self.options(html, n)[1] for n in ("manager", "qa", "consultant")], [[""], [""], [""]])
        self.assertNotIn("Clear filters", html)
        html, _ = self.page("?qa=Unassigned")
        self.assertIn("Clear filters", html)

    def test_a_filter_that_leaves_a_day_empty_shows_that_days_message(self):
        html, _ = self.page("?manager=Alice")
        self.assertIn("No interviews scheduled for Wednesday.", html)
        self.assertIn("No interviews scheduled for Friday.", html)
        self.assertNotIn("No interviews scheduled for today.", html)

    def test_the_filters_do_not_change_the_options(self):
        full, _ = self.page()
        filtered, _ = self.page("?manager=Alice")
        for name in ("manager", "qa", "consultant"):
            self.assertEqual(self.options(full, name)[0], self.options(filtered, name)[0])

    def test_every_role_can_use_the_page_and_the_filters(self):
        for role in ("admissions", "consultants", "marketing"):
            _, context = self.page("?manager=Alice", client=self._client_logged_in_as(role))
            self.assertEqual(sum(len(s["groups"]) for s in context["sections"]), 3, role)

    def test_with_no_dataset_there_are_no_filters(self):
        import sqlite3
        from tests.flask_test_support import db_module
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute("DELETE FROM active_dataset")
        conn.commit()
        conn.close()
        html = self.client.get("/interviews").get_data(as_text=True)
        self.assertIn("No active dataset yet.", html)
        self.assertNotIn('name="manager"', html)


class HelperTests(unittest.TestCase):
    def test_list_qa_officers_reads_the_qa_field_with_blank_as_unassigned(self):
        rows = [{"QA": v} for v in ("rita", "Quinn", "Rita", " Quinn ", "", None, "  ")]
        self.assertEqual(list_qa_officers(rows), ["Quinn", "Rita", "rita", "Unassigned"])
        self.assertEqual(list_qa_officers([{"Application": "x"}]), ["Unassigned"])
        self.assertEqual(list_qa_officers([]), [])


if __name__ == "__main__":
    unittest.main()
