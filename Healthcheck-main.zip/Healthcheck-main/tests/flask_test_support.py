"""Shared isolated Flask test-client infrastructure for route-level tests.

Used by tests/test_csrf.py and tests/test_authorization.py (and any future
route-level suite) so none of them depend on each other. Route-level tests
are the exception in this project - every other test file exercises pure
business logic - so everything that makes them safe lives here, once.

IMPORTING THIS MODULE does the isolation setup, in the one order that
works: disposable environment first, then db.DB_PATH patched, and only then
app.py imported. A test module must therefore import from here BEFORE it
(or anything it imports) imports `app`.

ISOLATION
---------
Nothing built on this module ever touches the real data/app.db or the real
uploads/ folder:

- Disposable role passwords and FLASK_SECRET_KEY are set as environment
  variables before app.py is ever imported (required by app.py's own
  fail-fast startup check - see Finding 2). They are overwritten
  unconditionally, not setdefault, so a real value accidentally present in
  the ambient shell environment is never used.
- db.DB_PATH is monkeypatched to a temporary SQLite file before app.py is
  imported, so the module-level init_db() call app.py makes at import time
  creates its schema there, never in the real database. Every test then
  gets its OWN fresh temp database file in IsolatedAppTestCase.setUp(), so
  tests can never see each other's data.
- app.UPLOAD_FOLDER is monkeypatched to a fresh temporary directory in
  setUp() for the same reason - every file-writing route call lands there,
  never in the real uploads/ folder.

One unavoidable residual, called out explicitly for transparency: app.py
has a module-level statement, `UPLOAD_FOLDER.mkdir(exist_ok=True)`, that
runs once, the first time app.py is imported, against the REAL uploads/
path (computed from app.py's own on-disk location, which can't be changed
before app.py itself is imported). Since that directory already exists,
this is a no-op existence check - nothing is created, modified, deleted,
or read there. app.UPLOAD_FOLDER is monkeypatched immediately after,
before any test method runs, so no file ever actually lands in the real
folder.

- The login throttle (app.login_throttle, in-memory) is replaced with a
  fresh instance driven by a FakeClock for every test, and restored
  afterwards. Without that, failed logins in one test would count towards
  another test's lockout, and a lockout test would need real sleeping.
  self.clock.advance(seconds) moves the throttle's time forward instantly.

Tests that hit routes with other real-world side effects must patch those
too in their own setUp.

CSRFProtect is never disabled here - tests exercise the real protection
exactly as it runs in production.
"""

import io
import os
import re
import shutil
import sqlite3
import tempfile
import unittest
from pathlib import Path

import openpyxl

# --- Disposable test-only credentials, set BEFORE importing app ---
os.environ["FULL_PASSWORD"] = "csrf-test-full-password"
os.environ["ADMISSIONS_PASSWORD"] = "csrf-test-admissions-password"
os.environ["CONSULTANTS_PASSWORD"] = "csrf-test-consultants-password"
os.environ["MARKETING_PASSWORD"] = "csrf-test-marketing-password"
os.environ["FLASK_SECRET_KEY"] = "csrf-test-secret-key"

import db as db_module  # noqa: E402

_IMPORT_TIME_DB_DIR = Path(tempfile.mkdtemp(prefix="gsp_flask_test_import_db_"))
db_module.DB_PATH = _IMPORT_TIME_DB_DIR / "import_time.db"

import app as app_module  # noqa: E402  (triggers app.py's module-level init_db() against the patched DB_PATH above)
from login_throttle import LoginThrottle  # noqa: E402

_IMPORT_TIME_LOGIN_THROTTLE = app_module.login_throttle


class FakeClock:
    """A controllable clock for LoginThrottle: tests call advance() instead
    of sleeping."""

    def __init__(self, start=1000.0):
        self.now = float(start)

    def __call__(self):
        return self.now

    def advance(self, seconds):
        self.now += seconds

ROLE_PASSWORDS = {
    "full": os.environ["FULL_PASSWORD"],
    "admissions": os.environ["ADMISSIONS_PASSWORD"],
    "consultants": os.environ["CONSULTANTS_PASSWORD"],
    "marketing": os.environ["MARKETING_PASSWORD"],
}
FULL_PASSWORD = ROLE_PASSWORDS["full"]

_TOKEN_PATTERN = re.compile(r'name="csrf_token"\s+value="([^"]+)"')


def extract_token(html):
    """The CSRF token from a rendered page's hidden form field, or None."""
    match = _TOKEN_PATTERN.search(html)
    return match.group(1) if match else None


def make_xlsx(columns, rows):
    """An in-memory .xlsx with a header row of `columns` and one row per
    dict in `rows` - for building valid upload fixtures."""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(columns)
    for row in rows:
        ws.append([row.get(c, "") for c in columns])
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf


class IsolatedAppTestCase(unittest.TestCase):
    """Fresh temporary database AND uploads directory for every single
    test method - no test can see another test's data, and nothing here
    ever touches the real data/app.db or uploads/."""

    def setUp(self):
        self.tmp_db_dir = Path(tempfile.mkdtemp(prefix="gsp_flask_test_db_"))
        self.tmp_uploads_dir = Path(tempfile.mkdtemp(prefix="gsp_flask_test_uploads_"))
        db_module.DB_PATH = self.tmp_db_dir / "test.db"
        db_module.init_db()
        app_module.UPLOAD_FOLDER = self.tmp_uploads_dir
        app_module.reload_role_access()
        self.clock = FakeClock()
        app_module.login_throttle = LoginThrottle(clock=self.clock)
        app_module.app.config["TESTING"] = True
        self.client = app_module.app.test_client()

    def tearDown(self):
        shutil.rmtree(self.tmp_db_dir, ignore_errors=True)
        shutil.rmtree(self.tmp_uploads_dir, ignore_errors=True)
        app_module.login_throttle = _IMPORT_TIME_LOGIN_THROTTLE

    def _get_login_token(self, client=None):
        client = client or self.client
        resp = client.get("/login")
        return extract_token(resp.get_data(as_text=True))

    def _login(self, client=None, password=FULL_PASSWORD):
        """Log `client` in as a real authenticated session, using a real
        token - returns the client for chaining."""
        client = client or self.client
        token = self._get_login_token(client)
        resp = client.post("/login", data={"password": password, "csrf_token": token})
        assert resp.status_code == 302, f"test setup login failed: {resp.status_code}"
        return client

    def _client_logged_in_as(self, role):
        """A NEW test client (independent cookie jar/session) logged in
        through the real login flow as `role`, using a real CSRF token."""
        client = app_module.app.test_client()
        token = self._get_login_token(client)
        resp = client.post("/login", data={"password": ROLE_PASSWORDS[role], "csrf_token": token})
        self.assertEqual(resp.status_code, 302, f"login as {role} failed")
        return client

    def _client_with_session(self, **session_values):
        """A NEW test client whose session carries exactly the given values
        on top of a real CSRF seed - used to forge session states the login
        flow never produces (unknown or missing role)."""
        client = app_module.app.test_client()
        client.get("/login")
        with client.session_transaction() as sess:
            sess.update(session_values)
        return client

    def _query(self, sql, params=()):
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.row_factory = sqlite3.Row
        rows = conn.execute(sql, params).fetchall()
        conn.close()
        return rows
