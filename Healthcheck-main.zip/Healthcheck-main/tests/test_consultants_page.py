"""The Consultants page (/consultants): pick a Consultant, see their Enrolled
figures by Intake year and their Application Manager / Consultant / Source /
University pipelines. Also the pure helpers behind it in pipeline.py.

Route tests upload a small workbook with known numbers through the real
upload route into the isolated temp database (never the live one)."""

import io
import re
import unittest
from contextlib import contextmanager

from flask import template_rendered

from pipeline import (
    DEFAULT_FORECAST_PERCENTAGES,
    PIPELINE_INTAKE_YEARS,
    build_consultant_enrolled_by_year,
    build_paid_split_cards,
    build_pipeline_report,
    list_consultant_names,
    regroup_sources,
    resolve_consultant_name,
)
from tests.flask_test_support import IsolatedAppTestCase, app_module, extract_token
from tests.test_upload_atomicity import book, row


# ------------------------------------------------------------------ helpers
class ConsultantNameHelperTests(unittest.TestCase):
    def test_distinct_sorted_case_insensitively_and_blanks_skipped(self):
        rows = [{"Consultant": n} for n in ("mel", "Mel", " Zed ", "adam", "", None, "  ", "Hannah")]
        rows.append({})
        self.assertEqual(list_consultant_names(rows), ["adam", "Hannah", "mel", "Zed"])

    def test_empty_input(self):
        self.assertEqual(list_consultant_names([]), [])

    def test_excluded_names_are_left_out_ignoring_case_and_spaces(self):
        rows = [{"Consultant": n} for n in ("Mel", "Hannah", "anum", "Tanaka")]
        self.assertEqual(list_consultant_names(rows, exclude={"ANUM", " tanaka "}), ["Hannah", "Mel"])
        self.assertEqual(list_consultant_names(rows, exclude=[]), ["anum", "Hannah", "Mel", "Tanaka"])
        self.assertEqual(list_consultant_names(rows, exclude=None), list_consultant_names(rows))
        self.assertEqual(list_consultant_names(rows, exclude={"", None, "nobody"}), ["anum", "Hannah", "Mel", "Tanaka"])

    def test_resolve_is_case_insensitive_and_trimmed_and_returns_the_canonical_spelling(self):
        names = ["Hannah", "Mel"]
        self.assertEqual(resolve_consultant_name(names, "mel"), "Mel")
        self.assertEqual(resolve_consultant_name(names, "  HANNAH "), "Hannah")

    def test_resolve_returns_none_for_blank_missing_or_unknown(self):
        names = ["Hannah", "Mel"]
        for value in (None, "", "   ", "nobody", "Mel; DROP TABLE", "<script>alert(1)</script>", "Me"):
            self.assertIsNone(resolve_consultant_name(names, value), value)
        self.assertIsNone(resolve_consultant_name([], "Mel"))


class RegroupSourcesTests(unittest.TestCase):
    def sources(self, values):
        return [r["Source"] for r in regroup_sources([{"Source": v, "Status": "x"} for v in values])]

    def test_inbound_call_website_social_media_and_employee_become_inbound(self):
        self.assertEqual(self.sources(["Inbound Call", "Website", "Social Media", "Employee"]), ["Inbound"] * 4)

    def test_matching_ignores_case_and_surrounding_spaces(self):
        self.assertEqual(self.sources(["inbound call", " WEBSITE ", "Social media", "eMPLOYEE"]), ["Inbound"] * 4)

    def test_every_other_source_is_left_exactly_as_it_was(self):
        values = ["Paid Ad", "Student Referral", "Staff Referral", "Agent", "Event", "Inbound", "Inbound Calls", "", None, "Web"]
        self.assertEqual(self.sources(values), values)

    def test_other_fields_are_kept_and_the_input_rows_are_not_modified(self):
        rows = [{"Source": "Website", "Status": "09-Enrolled", "Consultant": "Mel"}]
        out = regroup_sources(rows)
        self.assertEqual(out, [{"Source": "Inbound", "Status": "09-Enrolled", "Consultant": "Mel"}])
        self.assertEqual(rows[0]["Source"], "Website")
        self.assertIsNot(out[0], rows[0])

    def test_a_custom_mapping_can_be_given(self):
        self.assertEqual([r["Source"] for r in regroup_sources([{"Source": "Agent"}], {"agent": "Partners"})], ["Partners"])

    def test_regrouped_rows_make_one_inbound_row_in_a_source_report(self):
        rows = [{"Source": s, "Status": "05-Assessment"} for s in ("Inbound Call", "Website", "Social Media", "Employee", "Agent")]
        report = build_pipeline_report(regroup_sources(rows), DEFAULT_FORECAST_PERCENTAGES, person_field="Source",
                                       group_field=None, blank_person_label="Unassigned", rank_by_total=True)
        self.assertEqual([(m["name"], m["total"]) for m in report["office_groups"][0]["managers"]], [("Inbound", 4), ("Agent", 1)])


class PaidSplitCardsTests(unittest.TestCase):
    def cards(self, sources_and_statuses):
        rows = [{"Source": src, "Status": status} for src, status in sources_and_statuses]
        return build_paid_split_cards(rows, DEFAULT_FORECAST_PERCENTAGES)

    def by_label(self, cards):
        return {c["label"]: c for c in cards}

    def test_three_cards_in_order_paid_ads_non_paid_overall(self):
        cards = self.cards([("Paid Ad", "05-Assessment"), ("Agent", "05-Assessment")])
        self.assertEqual([c["label"] for c in cards], ["Paid Ads", "Non Paid", "Overall"])

    def test_paid_is_the_paid_ad_source_and_non_paid_is_everything_else(self):
        cards = self.by_label(self.cards(
            [("Paid Ad", "05-Assessment")] * 3
            + [(s, "05-Assessment") for s in ("Agent", "Student Referral", "Staff Referral", "Inbound", "Website", "Event", "")]))
        self.assertEqual((cards["Paid Ads"]["total"], cards["Non Paid"]["total"], cards["Overall"]["total"]), (3, 7, 10))

    def test_paid_ad_matching_ignores_case_and_spaces_and_blank_is_non_paid(self):
        cards = self.by_label(self.cards([("paid ad", "07-Ready"), (" PAID AD ", "07-Ready"), (None, "07-Ready"), ("Paid Ads", "07-Ready")]))
        self.assertEqual((cards["Paid Ads"]["total"], cards["Non Paid"]["total"]), (2, 2))   # "Paid Ads" is not the source name

    def test_paid_plus_non_paid_is_always_overall_for_total_and_forecast(self):
        cards = self.by_label(self.cards([("Paid Ad", "09-Enrolled"), ("Paid Ad", "05-Assessment"), ("Agent", "07-Ready"),
                                          ("Event", "06-Decision"), ("", "04-Onboarding")]))
        for key in ("total", "forecast"):
            self.assertEqual(cards["Paid Ads"][key] + cards["Non Paid"][key], cards["Overall"][key], key)

    def test_each_cards_numbers_come_from_the_normal_pipeline_maths(self):
        rows = [{"Source": "Paid Ad", "Status": s} for s in ("09-Enrolled", "05-Assessment", "05-Assessment", "10-Lost")]
        cards = self.by_label(build_paid_split_cards(rows, DEFAULT_FORECAST_PERCENTAGES))
        report = build_pipeline_report(rows, DEFAULT_FORECAST_PERCENTAGES, person_field="Source", group_field=None)
        person = report["office_groups"][0]["managers"][0]
        self.assertEqual((cards["Paid Ads"]["total"], cards["Paid Ads"]["forecast"], cards["Paid Ads"]["conversion"]),
                         (person["total"], person["forecast"], person["conversion"]))
        self.assertEqual(cards["Overall"]["conversion"], report["grand_total_conversion"])

    def test_a_side_with_no_applications_still_gets_a_zero_card(self):
        only_paid = self.by_label(self.cards([("Paid Ad", "05-Assessment")]))
        self.assertEqual((only_paid["Non Paid"]["total"], only_paid["Non Paid"]["forecast"], only_paid["Non Paid"]["conversion"]), (0, 0, 0))
        none_paid = self.by_label(self.cards([("Agent", "05-Assessment")]))
        self.assertEqual(none_paid["Paid Ads"]["total"], 0)
        empty = self.cards([])
        self.assertEqual([(c["label"], c["total"]) for c in empty], [("Paid Ads", 0), ("Non Paid", 0), ("Overall", 0)])

    def test_the_input_rows_are_not_modified(self):
        rows = [{"Source": "Agent", "Status": "05-Assessment"}]
        build_paid_split_cards(rows, DEFAULT_FORECAST_PERCENTAGES)
        self.assertEqual(rows, [{"Source": "Agent", "Status": "05-Assessment"}])


def r(consultant, status, intake, **extra):
    return {"Consultant": consultant, "Status": status, "Intake": intake, **extra}


class EnrolledByYearTests(unittest.TestCase):
    ROWS = [
        r("Mel", "09-Enrolled", "September 2026"),
        r("Mel", "09-Enrolled", "October 2026"),
        r("Mel", "05-Assessment", "September 2026"),      # not enrolled
        r("Mel", "10-Lost", "September 2026"),            # not enrolled
        r("Hannah", "09-Enrolled", "September 2026"),     # someone else
        r("mel", "09-Enrolled", "November 2026"),         # same person, different case
        r("Mel", "09-Enrolled", "January 2027"),          # 2027: Intake 01 (Jan-Mar)
        r("Mel", "09-Enrolled", "May 2027"),              # 2027: Intake 02 (Apr-Jun)
        r("Mel", "09-Enrolled", "September 2027"),        # 2027: Intake 03
        r("Mel", "09-Enrolled", "Whenever 2027"),         # unrecognised month: dropped, like the Enrolled page
    ]
    MANUAL = {2026: [{"consultant": "Mel", "intake_01": 5, "intake_02": 3},
                     {"consultant": "Hannah", "intake_01": 100, "intake_02": 100}]}

    def result(self, consultant="Mel", manual=None):
        return {e["year"]: e for e in build_consultant_enrolled_by_year(
            self.ROWS, consultant, PIPELINE_INTAKE_YEARS, self.MANUAL if manual is None else manual)}

    def test_one_entry_per_year_in_order(self):
        entries = build_consultant_enrolled_by_year(self.ROWS, "Mel", PIPELINE_INTAKE_YEARS, self.MANUAL)
        self.assertEqual([e["year"] for e in entries], list(PIPELINE_INTAKE_YEARS))

    def test_2026_is_manual_backfill_plus_live_enrolled_as_intake_03(self):
        e = self.result()[2026]
        self.assertEqual((e["intake_01"], e["intake_02"], e["intake_03"], e["total"]), (5, 3, 3, 11))

    def test_only_enrolled_rows_count(self):
        self.assertEqual(self.result(manual={})[2026]["total"], 3)

    def test_2027_splits_live_enrolled_by_intake_month_with_no_backfill(self):
        e = self.result()[2027]
        self.assertEqual((e["intake_01"], e["intake_02"], e["intake_03"], e["total"]), (1, 1, 1, 3))

    def test_other_consultants_figures_never_leak_in(self):
        self.assertEqual(self.result("Hannah")[2026]["total"], 1 + 100 + 100)
        self.assertEqual(self.result("Mel")[2026]["total"], 11)

    def test_spelling_case_does_not_split_a_person(self):
        self.assertEqual(self.result("MEL")[2026]["intake_03"], 3)

    def test_unknown_or_blank_consultant_is_all_zeros(self):
        for who in ("Nobody", "", None):
            for e in build_consultant_enrolled_by_year(self.ROWS, who, PIPELINE_INTAKE_YEARS, self.MANUAL):
                self.assertEqual((e["intake_01"], e["intake_02"], e["intake_03"], e["total"]), (0, 0, 0, 0), who)

    def test_manual_backfill_only_applies_to_the_year_it_is_given_for(self):
        self.assertEqual(self.result()[2027]["intake_02"], 1)     # live only; the 2026 backfill is not added


# -------------------------------------------------------------------- route
STATUS_LOOKUP = [("Enrolled", "09-Enrolled"), ("Assessment", "05-Assessment"), ("Cancelled", "10-Lost"), ("Ready", "07-Ready")]   # only "Cancelled" still counts as Lost in the pipelines


def app_row(code, name, consultant, status, source, intake="September 2026"):
    return row(**{
        "Student Code": code, "Student Name": name, "Application Status": status,
        "Counsellor": f"{consultant} Surname", "Admission Officer": "Alice Brown", "Lead Source": source,
        "University Name": "Test University", "Intake": intake,
    })


ROWS = [
    app_row("P1", "M One", "Mel", "Enrolled", "Paid Ad/Google"),
    app_row("P2", "M Two", "Mel", "Assessment", "Paid Ad/Google"),
    app_row("P3", "M Three", "Mel", "Cancelled", "Agent/Partner"),
    app_row("P4", "M Four", "Mel", "Ready", ""),
    app_row("P5", "M Five", "Mel", "Enrolled", "Student Referral/Friend", intake="January 2027"),
    app_row("H1", "H One", "Hannah", "Enrolled", "Event/Fair"),
    app_row("H2", "H Two", "Hannah", "Ready", "Inbound Call/Phone"),
    app_row("H3", "H Three", "Hannah", "Assessment", "Website/Organic"),
    app_row("H4", "H Four", "Hannah", "Assessment", "social media/Facebook"),    # case differs
    app_row("H5", "H Five", "Hannah", "Ready", "Employee/Referral"),
    app_row("H6", "H Six", "Hannah", "Ready", "Staff Referral/Colleague"),      # NOT part of Inbound
    app_row("A1", "A One", "Anum", "Ready", "Website/Organic"),     # Anum is normally hidden on the team pages
]


@contextmanager
def captured_context():
    rendered = []

    def record(sender, template, context, **extra):
        rendered.append((template.name, dict(context)))

    template_rendered.connect(record, app_module.app)
    try:
        yield rendered
    finally:
        template_rendered.disconnect(record, app_module.app)


def report_total(report):
    return report["grand_total_records"]


def report_people(report):
    return {m["name"]: m["total"] for g in report["office_groups"] for m in g["managers"]}


class ConsultantsPageTests(IsolatedAppTestCase):
    def setUp(self):
        super().setUp()
        self.client = self._client_logged_in_as("full")
        self.load(ROWS)

    def load(self, rows, client=None):
        client = client or self.client
        token = extract_token(client.get("/login").get_data(as_text=True))
        response = client.post(
            "/upload", data={"csrf_token": token, "excel_file": (io.BytesIO(book(rows, lookups={"status": STATUS_LOOKUP, "office": [("Alice Brown", "UK")]})), "t.xlsx")},
            content_type="multipart/form-data")
        self.assertEqual(response.status_code, 302)

    def page(self, query="", client=None):
        with captured_context() as rendered:
            response = (client or self.client).get("/consultants" + query)
        self.assertEqual(response.status_code, 200)
        context = next((c for name, c in rendered if name == "dashboard_consultants.html"), None)
        return response.get_data(as_text=True), context

    # -------------------------------------------------------- the picker
    def test_without_a_consultant_only_the_picker_is_shown(self):
        html, context = self.page()
        self.assertIn("Select a consultant...", html)
        for name in ("Anum", "Hannah", "Mel"):
            self.assertIn(f'<option value="{name}"', html)
        self.assertNotIn("Enrolled by Year", html)
        self.assertNotIn("Pipeline Health", html)
        self.assertIsNone(context["selected_consultant"])

    def test_unknown_or_hostile_values_show_the_picker_and_never_error_or_echo(self):
        for value in ("Nobody", "", "%27%20OR%201%3D1", "%3Cscript%3Ealert(1)%3C%2Fscript%3E", "Mel%00"):
            html, context = self.page(f"?consultant={value}")
            self.assertIsNone(context["selected_consultant"], value)
            self.assertNotIn("<script>alert(1)</script>", html)
            self.assertNotIn("Pipeline Health", html)

    def test_the_picker_keeps_the_selected_year_and_intake(self):
        html, _ = self.page("?consultant=Mel&year=2027&intake=intake_01")
        self.assertIn('name="year" value="2027"', html)
        self.assertIn('name="intake" value="intake_01"', html)
        self.assertRegex(html, r'<option value="Mel" selected>')

    def test_the_consultant_is_matched_case_insensitively(self):
        _, context = self.page("?consultant=mEL")
        self.assertEqual(context["selected_consultant"], "Mel")

    def test_no_dataset_shows_the_no_data_message(self):
        import sqlite3
        from tests.flask_test_support import db_module
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute("DELETE FROM active_dataset")
        conn.commit()
        conn.close()
        html, _ = self.page("?consultant=Mel")
        self.assertIn("No active dataset yet.", html)

    # ---------------------------------------------------- the selected page
    def test_selected_consultant_sections_appear_in_the_requested_order(self):
        html, _ = self.page("?consultant=Mel&year=2026")
        order = [html.index(t) for t in (
            "Enrolled by Year", "Mel - Application Manager Pipeline 2026", "Mel - Consultant Pipeline 2026",
            "Mel - Source Pipeline 2026", "Mel - University Pipeline 2026")]
        self.assertEqual(order, sorted(order), "Enrolled by Year first, then the pipelines")

    def test_there_is_no_number_breakdown_section_or_table(self):
        for query in ("?consultant=Mel&year=2026", "?consultant=Mel&year=2027", "?consultant=Hannah"):
            html, _ = self.page(query)
            self.assertNotIn("Number Breakdown", html)
            self.assertNotIn("pipeline-table", html)
            self.assertNotIn("<table class=\"pipeline-table", html)
            self.assertEqual(html.count("<table"), 1, "only the Enrolled by Year table remains")

    def test_the_source_pipeline_has_three_cards_paid_ads_non_paid_and_overall(self):
        html, context = self.page("?consultant=Mel&year=2026")
        self.assertEqual([(c["label"], c["total"]) for c in context["source_summary_cards"]],
                         [("Paid Ads", 2), ("Non Paid", 2), ("Overall", 4)])
        section = html[html.index("Mel - Source Pipeline 2026"):html.index("Mel - University Pipeline 2026")]
        self.assertEqual(section.count('<div class="summary-card">'), 2, "Paid Ads and Non Paid")
        self.assertEqual(section.count('<div class="summary-card summary-card-overall">'), 1, "and the total")
        self.assertLess(section.index("summary-cards"), section.index("Source Pipeline Health"), "cards sit above the chart")
        titles = re.findall(r'<div class="summary-card-title">([^<]+)</div>', section)
        self.assertEqual(titles, ["Paid Ads", "Non Paid", "Overall"])
        for text in ("Apps", "Forecast", "Conversion"):
            self.assertIn(f"<span>{text}</span>", section)

    def test_non_paid_is_everything_that_is_not_a_paid_ad_including_inbound_and_blank(self):
        _, mel = self.page("?consultant=Mel&year=2026")          # Paid Ad x2, Agent, blank
        self.assertEqual({c["label"]: c["total"] for c in mel["source_summary_cards"]}, {"Paid Ads": 2, "Non Paid": 2, "Overall": 4})
        _, hannah = self.page("?consultant=Hannah&year=2026")    # Event, 4 inbound-type, Staff Referral: no paid at all
        self.assertEqual({c["label"]: c["total"] for c in hannah["source_summary_cards"]}, {"Paid Ads": 0, "Non Paid": 6, "Overall": 6})

    def test_the_cards_always_add_up_to_the_pipelines_grand_total(self):
        for who in ("Mel", "Hannah", "Anum"):
            _, context = self.page(f"?consultant={who}&year=2026")
            cards = {c["label"]: c for c in context["source_summary_cards"]}
            self.assertEqual(cards["Paid Ads"]["total"] + cards["Non Paid"]["total"], cards["Overall"]["total"], who)
            self.assertEqual(cards["Overall"]["total"], report_total(context["am_report"]), who)

    def test_the_old_per_source_cards_are_gone_but_the_chart_still_groups_inbound(self):
        html, context = self.page("?consultant=Hannah&year=2026")
        section = html[html.index("Hannah - Source Pipeline 2026"):html.index("Hannah - University Pipeline 2026")]
        cards_part = section[:section.index("Source Pipeline Health")]
        for gone in ("Inbound", "Event", "Staff Referral", "Website", "Social Media", "Employee"):
            self.assertNotIn(f'<div class="summary-card-title">{gone}</div>', cards_part, gone)
        chart = [r["name"] for g in context["source_chart_groups"] for r in g["rows"]]
        self.assertEqual(chart[0], "Inbound", "chart rows are still by source, with the Inbound grouping")
        self.assertEqual(sorted(chart), ["Event", "Inbound", "Staff Referral"])
        for gone in ("Inbound Call", "Website", "Social Media", "Employee"):
            self.assertNotIn(gone, section, gone)

    def test_inbound_grouping_changes_only_the_source_pipeline(self):
        _, context = self.page("?consultant=Hannah&year=2026")
        self.assertEqual({report_total(context[k]) for k in ("am_report", "consultant_report", "source_report")}, {6})
        self.assertEqual(report_people(context["consultant_report"]), {"Hannah": 6})

    def test_a_single_inbound_style_source_is_also_shown_as_inbound(self):
        _, context = self.page("?consultant=Anum&year=2026")      # Anum's one application is Website
        self.assertEqual(report_people(context["source_report"]), {"Inbound": 1})

    def test_the_other_sources_keep_their_names_for_a_consultant_without_inbound(self):
        _, context = self.page("?consultant=Mel&year=2026")
        self.assertEqual(report_people(context["source_report"]), {"Paid Ad": 2, "Agent": 1, "Unassigned": 1})

    def test_a_year_with_no_applications_shows_zero_cards_and_no_error(self):
        html, context = self.page("?consultant=Mel&year=2027&intake=intake_02")
        self.assertEqual([(c["label"], c["total"]) for c in context["source_summary_cards"]],
                         [("Paid Ads", 0), ("Non Paid", 0), ("Overall", 0)])
        self.assertNotIn("Traceback", html)

    def test_the_enrolled_by_year_explanatory_note_is_gone(self):
        for query in ("?consultant=Mel", "?consultant=Hannah&year=2027"):
            html, _ = self.page(query)
            self.assertIn("Enrolled by Year", html)
            self.assertNotIn("Same figures as the Enrolled page", html)
            self.assertNotIn("manual pre-CRM backfill", html)
            self.assertNotIn("everything else is live 09-Enrolled applications", html)

    def test_the_source_pipeline_is_this_consultants_own_by_source(self):
        _, context = self.page("?consultant=Mel&year=2026")
        sources = report_people(context["source_report"])
        self.assertEqual(sources, {"Paid Ad": 2, "Agent": 1, "Unassigned": 1})
        for other in ("Event", "Inbound Call", "Website", "Student Referral"):
            self.assertNotIn(other, sources)

    def test_the_source_pipeline_agrees_with_the_application_manager_and_consultant_pipelines(self):
        _, context = self.page("?consultant=Mel&year=2026")
        totals = {report_total(context[k]) for k in ("am_report", "consultant_report", "source_report")}
        self.assertEqual(totals, {4})

    def test_every_pipeline_is_scoped_to_the_selected_consultant(self):
        _, context = self.page("?consultant=Mel&year=2026")
        self.assertEqual(set(report_people(context["consultant_report"])), {"Mel"})
        _, hannah = self.page("?consultant=Hannah&year=2026")
        self.assertEqual(report_total(hannah["am_report"]), 6)
        self.assertEqual(report_people(hannah["source_report"]), {"Event": 1, "Inbound": 4, "Staff Referral": 1})

    def test_a_normally_hidden_consultant_still_gets_their_own_consultant_pipeline(self):
        _, context = self.page("?consultant=Anum&year=2026")
        self.assertEqual(report_people(context["consultant_report"]), {"Anum": 1})
        self.assertEqual(report_total(context["source_report"]), 1)

    def test_the_year_selects_the_pipeline_data(self):
        _, y2026 = self.page("?consultant=Mel&year=2026")
        _, y2027 = self.page("?consultant=Mel&year=2027")
        self.assertEqual(report_total(y2026["source_report"]), 4)
        self.assertEqual(report_people(y2027["source_report"]), {"Student Referral": 1})

    def test_intake_tabs_apply_from_2027(self):
        _, context = self.page("?consultant=Mel&year=2027&intake=intake_01")
        self.assertEqual(report_total(context["source_report"]), 1)
        _, context = self.page("?consultant=Mel&year=2027&intake=intake_02")
        self.assertEqual(report_total(context["source_report"]), 0)

    def test_tab_links_carry_the_consultant(self):
        html, _ = self.page("?consultant=Mel&year=2027")
        self.assertIn("consultant=Mel&amp;year=2026", html)
        self.assertIn("consultant=Mel&amp;year=2027", html)
        self.assertRegex(html, r'href="/consultants\?year=2027&amp;intake=intake_01&amp;consultant=Mel"|href="/consultants\?consultant=Mel&amp;year=2027&amp;intake=intake_01"')

    # ------------------------------------------------- Enrolled by year
    def test_enrolled_by_year_shows_every_year_for_the_consultant(self):
        html, context = self.page("?consultant=Mel&year=2026")
        by_year = {e["year"]: e for e in context["enrolled_by_year"]}
        self.assertEqual((by_year[2026]["intake_03"], by_year[2026]["total"]), (1, 1))
        self.assertEqual((by_year[2027]["intake_01"], by_year[2027]["total"]), (1, 1))
        self.assertIn('class="active-year-row"', html)

    def test_enrolled_by_year_includes_the_manual_2026_backfill(self):
        token = extract_token(self.client.get("/login").get_data(as_text=True))
        response = self.client.post("/admin/lookups/sales_office/add", data={
            "csrf_token": token, "source_value": "Mel", "mapped_value": "OXF",
            "intake_01_count": "5", "intake_02_count": "3"})
        self.assertEqual(response.status_code, 302)
        _, context = self.page("?consultant=Mel")
        e = {x["year"]: x for x in context["enrolled_by_year"]}[2026]
        self.assertEqual((e["intake_01"], e["intake_02"], e["intake_03"], e["total"]), (5, 3, 1, 9))

    def test_enrolled_by_year_matches_the_enrolled_page(self):
        """The Enrolled page's own per-consultant chart row and this table must agree."""
        _, context = self.page("?consultant=Hannah&year=2026")
        with captured_context() as rendered:
            self.client.get("/enrolled?year=2026")
        chart = next(c for name, c in rendered if name == "enrolled.html")["consultant_chart_rows"]
        hannah = next(x for x in chart if x["name"] == "Hannah")
        mine = {e["year"]: e for e in context["enrolled_by_year"]}[2026]
        self.assertEqual((mine["intake_01"], mine["intake_02"], mine["intake_03"], mine["total"]),
                         (hannah["intake_01"], hannah["intake_02"], hannah["intake_03"], hannah["total"]))

    # ------------------------------------- "Group as Other" availability
    def set_lookup(self, consultant, group_as_other, sales_office="OXF"):
        """Add (or edit) the consultant's row in the Consultant lookup table through the real
        Admin routes, with the Group as Other checkbox on or off."""
        import sqlite3
        from tests.flask_test_support import db_module
        conn = sqlite3.connect(db_module.DB_PATH)
        existing = conn.execute("SELECT id FROM lookup_tables WHERE table_name='sales_office' AND lower(source_value)=lower(?)",
                                (consultant,)).fetchone()
        conn.close()
        token = extract_token(self.client.get("/login").get_data(as_text=True))
        data = {"csrf_token": token, "source_value": consultant, "mapped_value": sales_office}
        if group_as_other:
            data["group_as_other"] = "on"
        url = (f"/admin/lookups/sales_office/{existing[0]}/edit" if existing else "/admin/lookups/sales_office/add")
        self.assertEqual(self.client.post(url, data=data).status_code, 302)

    def names(self, query=""):
        _, context = self.page(query)
        return context["consultant_names"]

    def test_everyone_is_available_when_nobody_is_grouped_as_other(self):
        self.assertEqual(self.names(), ["Anum", "Hannah", "Mel"])

    def test_a_consultant_set_to_group_as_other_is_not_available(self):
        self.set_lookup("Hannah", True)
        self.assertEqual(self.names(), ["Anum", "Mel"])
        html, _ = self.page()
        self.assertNotIn('<option value="Hannah"', html)

    def test_a_consultant_set_to_no_stays_available(self):
        self.set_lookup("Hannah", True)
        self.set_lookup("Mel", False)
        self.assertEqual(self.names(), ["Anum", "Mel"])

    def test_a_consultant_with_no_lookup_row_counts_as_no(self):
        self.set_lookup("Hannah", True)
        self.assertIn("Anum", self.names())      # Anum has no Consultant lookup row at all

    def test_the_flag_matches_the_name_ignoring_case(self):
        self.set_lookup("MEL", True)
        self.assertNotIn("Mel", self.names())

    def test_a_flagged_consultant_typed_into_the_url_is_not_analysed(self):
        self.set_lookup("Hannah", True)
        for query in ("?consultant=Hannah", "?consultant=hannah&year=2026", "?consultant=Hannah&year=2027&intake=intake_01"):
            html, context = self.page(query)
            self.assertIsNone(context["selected_consultant"], query)
            self.assertNotIn("Pipeline Health", html)
            self.assertNotIn("Enrolled by Year", html)
            self.assertNotIn("Hannah", html, "a flagged name is not even echoed back")
        self.assertNotIn("H One", html)

    def test_switching_the_flag_back_to_no_makes_them_available_again(self):
        self.set_lookup("Hannah", True)
        self.assertNotIn("Hannah", self.names())
        self.set_lookup("Hannah", False)
        self.assertIn("Hannah", self.names())
        _, context = self.page("?consultant=Hannah")
        self.assertEqual(context["selected_consultant"], "Hannah")

    def test_unflagged_consultants_still_get_their_full_report(self):
        self.set_lookup("Hannah", True)
        _, context = self.page("?consultant=Mel&year=2026")
        self.assertEqual(report_total(context["source_report"]), 4)

    def test_the_page_carries_no_explanatory_note_about_group_as_other(self):
        for query in ("", "?consultant=Mel"):
            html, _ = self.page(query)
            self.assertNotIn("not listed here", html)
            self.assertNotIn("Group as Other", html)

    def test_everyone_flagged_leaves_an_empty_picker_and_no_error(self):
        for name in ("Anum", "Hannah", "Mel"):
            self.set_lookup(name, True)
        html, context = self.page("?consultant=Mel")
        self.assertEqual(context["consultant_names"], [])
        self.assertIsNone(context["selected_consultant"])
        self.assertIn("No consultants found in the current data.", html)

    # --------------------------------------------- navigation / old URL
    def test_the_toolbar_links_to_consultants_on_every_page_for_every_role(self):
        for role in ("full", "admissions", "consultants", "marketing"):
            client = self._client_logged_in_as(role)
            for path in ("/company-dashboard", "/admin", "/todo", "/consultants"):
                html = client.get(path).get_data(as_text=True)
                self.assertRegex(html, re.compile(r'<nav class="nav">.*?href="/consultants"[^>]*>Consultants</a>', re.S), role + path)

    def test_every_role_can_open_the_page(self):
        for role in ("full", "admissions", "consultants", "marketing"):
            client = self._client_logged_in_as(role)
            self.assertEqual(client.get("/consultants?consultant=Mel").status_code, 200, role)

    def test_the_admin_pages_list_links_to_consultants_not_faheem(self):
        html = self.client.get("/admin").get_data(as_text=True)
        self.assertIn('class="page-link" href="/consultants">Consultants</a>', html)
        self.assertNotIn('href="/dashboard/faheem"', html)

    def test_the_old_faheem_bookmark_redirects_to_that_consultant(self):
        response = self.client.get("/dashboard/faheem")
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.headers["Location"], "/consultants?consultant=Faheem")

    def test_login_is_required(self):
        anonymous = app_module.app.test_client()
        for path in ("/consultants", "/consultants?consultant=Mel", "/dashboard/faheem"):
            response = anonymous.get(path)
            self.assertEqual(response.status_code, 302, path)
            self.assertIn("/login", response.headers["Location"])


if __name__ == "__main__":
    unittest.main()
