"""Incentives page: Incentive 1 - LSC November 2026 applications whose QA was
approved on or after 9 October 2026, and Incentive 2 - QA Limited November 2026
applications (any QA Passed date) and Incentive 3 - ULAW applications for any 2026
intake, each by Consultant - Incentive 1 triggered at 5 enrolments, Incentive 2 at 5, 10
and 20, Incentive 3 at 2 and 5 (with its enrolled applications listed underneath); and
Incentive 4 - TSD, QA approved on or after 24 July 2026, 2026 intakes: no chart, just the
list of enrolled applications; with the click-through window."""

import io
import re
import unittest
from contextlib import contextmanager
from dataclasses import replace
from datetime import date
from unittest import mock
from urllib.parse import parse_qs, urlencode

from flask import template_rendered

from incentives import INCENTIVES, INCENTIVES_BY_KEY, INCENTIVE_TABS, Incentive, build_incentive, incentive_records, qualifying_rows
from pipeline import PIPELINE_HEALTH_STAGE_GROUPS
from tests.flask_test_support import IsolatedAppTestCase, app_module, extract_token
from tests.test_upload_atomicity import book, row

INC = INCENTIVES_BY_KEY["incentive_1"]
INC2 = INCENTIVES_BY_KEY["incentive_2"]
INC3 = INCENTIVES_BY_KEY["incentive_3"]
INC4 = INCENTIVES_BY_KEY["incentive_4"]
INC4_ALL = replace(INC4, list_min_enrolled=0)         # the same rules, with every Consultant listed (to test the rest of the list on a little data)
GROUPS = [g["key"] for g in PIPELINE_HEALTH_STAGE_GROUPS]
FORECAST = {"04-Onboarding": 10, "05-Assessment": 20, "06-Decision": 40, "07-Ready": 70, "08-Pre-Enrolled": 90, "09-Enrolled": 100}


def app(code, consultant, status="09-Enrolled", qa="2026-10-15", university="LSC", intake="November 2026", **extra):
    return {"Student Code": code, "Student Name": f"Student {code}", "Consultant": consultant, "Status": status, "QA Passed": qa,
            "University Name": university, "Intake": intake, "Application": "Mo", **extra}


class ConfigTests(unittest.TestCase):
    def test_incentive_1_is_lsc_november_2026_qa_from_9_october_triggered_at_5(self):
        self.assertEqual([i.key for i in INCENTIVES if i.tab == "2026"], ["incentive_1", "incentive_2", "incentive_3", "incentive_4"])
        self.assertEqual((INC.title, INC.university, INC.intake_month, INC.intake_year, INC.qa_approved_from, INC.triggers),
                         ("Incentive 1", "LSC", 11, 2026, date(2026, 10, 9), (5,)))
        self.assertEqual(INC.intake_label, "November 2026")
        self.assertEqual(INC.description, "LSC November 2026 intake applications whose QA was approved on or after 9 October 2026. Triggered at 5 enrolments.")


    def test_incentive_2_is_qa_limited_november_2026_with_no_qa_start_date_triggered_at_5_10_and_20(self):
        self.assertEqual((INC2.title, INC2.university, INC2.intake_month, INC2.intake_year, INC2.qa_approved_from, INC2.triggers),
                         ("Incentive 2", "QA Limited", 11, 2026, None, (5, 10, 20)))
        self.assertEqual(INC2.intake_label, "November 2026")
        self.assertEqual(INC2.description, "QA Limited November 2026 intake applications whose QA has been approved. Triggers at 5, 10 and 20 enrolments.")
        self.assertEqual(INC2.triggers_text, "Triggers at 5, 10 and 20 enrolments")
        self.assertEqual(INC.triggers_text, "Triggered at 5 enrolments")
        self.assertEqual(Incentive("y", "Y", "TSD", 9, 2026, None, (3, 6)).triggers_text, "Triggers at 3 and 6 enrolments")


    def test_incentive_3_is_ulaw_any_2026_intake_with_no_qa_start_date_triggered_at_2_and_5(self):
        self.assertEqual((INC3.title, INC3.university, INC3.intake_month, INC3.intake_year, INC3.qa_approved_from, INC3.triggers, INC3.show_enrolled_list),
                         ("Incentive 3", "ULAW", None, 2026, None, (2, 5), True))
        self.assertEqual(INC3.intake_label, "2026")
        self.assertEqual(INC3.description, "ULAW 2026 intake applications whose QA has been approved. Triggers at 2 and 5 enrolments.")
        self.assertEqual([i.key for i in INCENTIVES if i.show_enrolled_list], ["incentive_3", "incentive_4"], "only these two list their enrolled applications")


class Incentive3QualifyingTests(unittest.TestCase):
    def codes(self, rows):
        return [r["Student Code"] for r in qualifying_rows(rows, INC3)]

    def test_any_month_of_2026_counts_and_no_other_year(self):
        rows = [app(c, "Mel", university="ULAW", intake=v) for c, v in (("a", "January 2026"), ("b", "September 2026"), ("c", "December 2026"), ("d", "Nov 2026"), ("e", "2026"),
                                                                       ("f", "January 2027"), ("g", "December 2025"), ("h", ""), ("i", None), ("j", "garbage"))]
        self.assertEqual(self.codes(rows), ["a", "b", "c", "d", "e"])

    def test_only_ulaw_matched_whole_ignoring_case_and_spaces(self):
        rows = [app("a", "Mel", university="ULAW"), app("b", "Mel", university=" ulaw "), app("c", "Mel", university="ULAW Ltd"), app("d", "Mel", university="LSC"),
                app("e", "Mel", university=""), app("f", "Mel", university=None), app("g", "Mel", university="The University of Law")]
        self.assertEqual(self.codes(rows), ["a", "b"])

    def test_any_qa_passed_date_counts_but_there_must_be_one(self):
        rows = [app(c, "Mel", university="ULAW", qa=v) for c, v in (("a", "2026-01-01"), ("b", "2027-03-01"), ("c", ""), ("d", None), ("e", "garbage"))]
        self.assertEqual(self.codes(rows), ["a", "b"])

    def test_an_incentive_with_a_month_still_needs_that_month(self):
        rows = [app("a", "Mel", university="LSC", intake="November 2026"), app("b", "Mel", university="LSC", intake="September 2026"), app("c", "Mel", university="LSC", intake="2026")]
        self.assertEqual([r["Student Code"] for r in qualifying_rows(rows, INC)], ["a"])

    def test_triggers_at_exactly_2_and_5(self):
        expected = {0: (0, False, 2), 1: (0, False, 2), 2: (1, True, 5), 4: (1, True, 5), 5: (2, True, None), 8: (2, True, None)}
        for enrolled, (level, triggered, upcoming) in expected.items():
            built = build_incentive([app(f"E{i}", "Zed", university="ULAW") for i in range(enrolled)] + [app("A", "Zed", "05-Assessment", university="ULAW")], INC3, FORECAST)
            c = built["consultants"][0]
            self.assertEqual((c["level"], c["triggered"], c["next"]), (level, triggered, upcoming), enrolled)


class Incentive4QualifyingTests(unittest.TestCase):
    def codes(self, rows):
        return [r["Student Code"] for r in qualifying_rows(rows, INC4)]

    def test_config(self):
        self.assertEqual((INC4.title, INC4.university, INC4.intake_month, INC4.intake_year, INC4.qa_approved_from, INC4.triggers, INC4.show_enrolled_list, INC4.has_chart),
                         ("Incentive 4", "TSD", None, 2026, date(2026, 7, 24), (), True, False))
        self.assertEqual(INC4.intake_label, "2026")
        self.assertEqual(INC4.description, "TSD 2026 intake applications whose QA was approved on or after 24 July 2026 and are enrolled. Only Consultants with 10 or more enrolled are listed.")
        self.assertEqual(INC4.list_min_enrolled, 10)
        self.assertEqual(INC4_ALL.description, "TSD 2026 intake applications whose QA was approved on or after 24 July 2026 and are enrolled.")
        self.assertEqual([i.list_min_enrolled for i in INCENTIVES], [0, 0, 0, 10, 0], "only Incentive 4 limits its list by consultant")
        self.assertEqual(INC4.list_columns, ("consultant", "manager", "code", "student", "university", "course"))
        self.assertTrue(INC.has_chart and INC2.has_chart and INC3.has_chart)

    def test_qa_passed_on_the_start_day_counts_the_day_before_does_not(self):
        rows = [app(c, "Mel", university="TSD", intake="September 2026", qa=v) for c, v in (("a", "2026-07-23"), ("b", "2026-07-24"), ("c", "2026-07-25"), ("d", "2026-12-01"), ("e", "2024-07-24"),
                                                                                          ("f", ""), ("g", None), ("h", "garbage"))]
        self.assertEqual(self.codes(rows), ["b", "c", "d"])

    def test_only_tsd_matched_whole_ignoring_case_and_spaces(self):
        rows = [app(c, "Mel", university=u, intake="September 2026", qa="2026-08-01") for c, u in (("a", "TSD"), ("b", " tsd "), ("c", "TSD Group"), ("d", "LSC"), ("e", ""), ("f", None), ("g", "XTSD"))]
        self.assertEqual(self.codes(rows), ["a", "b"])

    def test_any_month_of_the_2026_intake_and_no_other_year(self):
        rows = [app(c, "Mel", university="TSD", qa="2026-08-01", intake=v) for c, v in (("a", "January 2026"), ("b", "September 2026"), ("c", "December 2026"), ("d", "2026"),
                                                                                      ("e", "September 2025"), ("f", "January 2027"), ("g", ""), ("h", None))]
        self.assertEqual(self.codes(rows), ["a", "b", "c", "d"])

    def test_no_chart_just_the_enrolled_list_and_counts(self):
        rows = [dict(app(c, "Mel", s, university="TSD", intake="September 2026", qa="2026-08-01"), **{"Application": "Mo", "Course Name": "LLB"})
                for c, s in (("a", "09-Enrolled"), ("b", "05-Assessment"), ("c", "09-Enrolled"), ("d", "10-Lost"))]
        built = build_incentive(rows, INC4_ALL, FORECAST)
        self.assertEqual((built["report"], built["chart_groups"], built["consultants"], built["summary"]), (None, [], [], {"total": 4, "enrolled": 2, "team": None}))
        self.assertEqual([(r["code"], r["manager"], r["university"], r["course"], r["consultant"]) for r in built["enrolled_list"]],
                         [("a", "Mo", "TSD", "LLB", "Mel"), ("c", "Mo", "TSD", "LLB", "Mel")])

    def test_a_blank_application_manager_is_unassigned(self):
        rows = [dict(app("a", "Mel", university="TSD", intake="September 2026", qa="2026-08-01"), **{"Application": ""}), app("b", "Mel", university="TSD", intake="September 2026", qa="2026-08-01", **{"Application": None})]
        self.assertEqual([r["manager"] for r in build_incentive(rows, INC4_ALL, FORECAST)["enrolled_list"]], ["Unassigned", "Unassigned"])


class Incentive4MinimumTests(unittest.TestCase):
    """Only Consultants with 10 or more enrolled applications (under the rules) are listed."""

    def listed(self, rows):
        return build_incentive(rows, INC4, FORECAST)["enrolled_list"]

    def group(self, consultant, n, prefix=None, **extra):
        return [tsd(f"{prefix or consultant}{i}", consultant, **extra) for i in range(n)]

    def test_nine_is_not_listed_ten_and_eleven_are_with_all_their_applications(self):
        rows = self.group("Nine", 9) + self.group("Ten", 10) + self.group("Eleven", 11)
        listed = self.listed(rows)
        self.assertEqual({r["consultant"] for r in listed}, {"Ten", "Eleven"})
        self.assertEqual((len([r for r in listed if r["consultant"] == "Ten"]), len([r for r in listed if r["consultant"] == "Eleven"])), (10, 11))

    def test_only_applications_under_the_rules_count_towards_the_ten(self):
        nine = self.group("Nine", 9)
        not_counted = ([tsd(f"p{i}", "Nine", status="05-Assessment") for i in range(3)] + [tsd(f"q{i}", "Nine", qa="2026-07-23") for i in range(3)] +
                       [tsd(f"n{i}", "Nine", qa="") for i in range(2)] + [app(f"l{i}", "Nine", university="LSC", intake="September 2026") for i in range(2)] +
                       [app(f"y{i}", "Nine", university="TSD", intake="September 2027") for i in range(2)] + [tsd(f"x{i}", "Nine", status="08-Pre-Enrolled") for i in range(2)])
        self.assertEqual(self.listed(nine + not_counted), [])
        self.assertEqual(len(self.listed(nine + [tsd("ten", "Nine", qa="2026-07-24")])), 10, "the QA start day counts")

    def test_consultants_are_counted_separately_and_by_exact_name(self):
        rows = self.group("Ann", 6, "a") + self.group("Bob", 6, "b")
        self.assertEqual(self.listed(rows), [], "12 between them is not 10 each")
        rows = [tsd(f"s{i}", "Ann" if i < 5 else "ann") for i in range(10)]
        self.assertEqual(self.listed(rows), [], "Ann and ann are different names, as on the chart")

    def test_unassigned_is_not_a_consultant_so_it_is_never_listed(self):
        rows = [tsd(f"u{i}", "") for i in range(12)] + [tsd(f"v{i}", None) for i in range(3)]
        self.assertEqual(self.listed(rows), [])
        self.assertEqual(len(build_incentive(rows, INC4_ALL, FORECAST)["enrolled_list"]), 15, "(without the minimum they are listed)")

    def test_the_summary_still_counts_everything(self):
        built = build_incentive(self.group("Nine", 9) + self.group("Ten", 10), INC4, FORECAST)
        self.assertEqual(built["summary"], {"total": 19, "enrolled": 19, "team": None})
        self.assertEqual(len(built["enrolled_list"]), 10)

    def test_the_other_incentives_list_everyone(self):
        rows = [app("a", "Ann", university="ULAW", intake="September 2026")]
        self.assertEqual(len(build_incentive(rows, INC3, FORECAST)["enrolled_list"]), 1)


class UnassignedListTests(unittest.TestCase):
    """What Incentive 4's Consultant minimum leaves out for want of a Consultant, to check by hand."""

    def test_the_qualifying_enrolled_applications_with_no_consultant(self):
        rows = [tsd("u2", "", "Pat", course="LLM"), tsd("u1", None, "Mo", course="MBA"), tsd("u3", "  ", ""),
                tsd("p", "", status="05-Assessment"), tsd("q", "", qa="2026-07-23"), tsd("n", "", qa=""), app("l", "", university="LSC", intake="September 2026"),
                app("y", "", university="TSD", intake="September 2027"), tsd("named", "Ann")]
        listed = build_incentive(rows, INC4, FORECAST)["unassigned_list"]
        self.assertEqual([(r["code"], r["manager"], r["course"], r["university"], r["consultant"]) for r in listed],
                         [("u1", "Mo", "MBA", "TSD", "Unassigned"), ("u2", "Pat", "LLM", "TSD", "Unassigned"), ("u3", "Unassigned", "MBA", "TSD", "Unassigned")])

    def test_it_is_empty_without_a_minimum_and_for_the_other_incentives(self):
        rows = [tsd("u1", ""), app("u2", "", university="ULAW", intake="September 2026")]
        self.assertEqual(build_incentive(rows, INC4_ALL, FORECAST)["unassigned_list"], [])
        for incentive in (INC, INC2, INC3):
            self.assertEqual(build_incentive(rows, incentive, FORECAST)["unassigned_list"], [], incentive.key)

    def test_it_does_not_depend_on_how_many_there_are(self):
        self.assertEqual(len(build_incentive([tsd(f"u{i}", "") for i in range(12)], INC4, FORECAST)["unassigned_list"]), 12)


class EnrolledListTests(unittest.TestCase):
    def test_only_enrolled_applications_with_the_four_fields_sorted_by_consultant(self):
        rows = [app("U3", "Zed", university="ULAW", **{"Course Name": "LLM Law"}), app("U1", "Ann", university="ULAW", **{"Course Name": "LPC"}),
                app("U2", "Ann", university="ULAW", **{"Course Name": "GDL"}, ), app("U4", "", university="ULAW", **{"Course Name": "BA"}), app("U5", "bob", university="ULAW"),
                app("N1", "Ann", "05-Assessment", university="ULAW"), app("N2", "Ann", "08-Pre-Enrolled", university="ULAW"), app("N3", "Ann", "10-Lost", university="ULAW")]
        rows[1]["Student Name"], rows[2]["Student Name"] = "Zoe", "Amy"
        listed = build_incentive(rows, INC3, FORECAST)["enrolled_list"]
        self.assertEqual([(r["consultant"], r["course"], r["code"], r["student"]) for r in listed],
                         [("Ann", "GDL", "U2", "Amy"), ("Ann", "LPC", "U1", "Zoe"), ("bob", "", "U5", "Student U5"), ("Zed", "LLM Law", "U3", "Student U3"), ("Unassigned", "BA", "U4", "Student U4")])
        self.assertEqual(sorted(listed[0]), ["code", "consultant", "course", "manager", "student", "university"])

    def test_only_qualifying_applications_are_listed(self):
        rows = [app("A", "Ann", university="ULAW"), app("B", "Ann", university="LSC"), app("C", "Ann", university="ULAW", intake="January 2027"), app("D", "Ann", university="ULAW", qa="")]
        self.assertEqual([r["code"] for r in build_incentive(rows, INC3, FORECAST)["enrolled_list"]], ["A"])

    def test_the_other_incentives_do_not_list(self):
        rows = [app("A", "Ann", university="LSC"), app("B", "Ann", university="QA Limited")]
        self.assertEqual(build_incentive(rows, INC, FORECAST)["enrolled_list"], [])
        self.assertEqual(build_incentive(rows, INC2, FORECAST)["enrolled_list"], [])

    def test_students_listed_by_name_ignoring_case_and_ties_by_code(self):
        rows = [dict(app(c, "Ann", university="ULAW"), **{"Student Name": n}) for c, n in (("2", "bea"), ("1", "Bea"), ("3", "al"))]
        self.assertEqual([r["code"] for r in build_incentive(rows, INC3, FORECAST)["enrolled_list"]], ["3", "1", "2"])

    def test_the_input_is_not_modified(self):
        rows = [app("A", "Ann", university="ULAW")]
        before = [dict(r) for r in rows]
        build_incentive(rows, INC3, FORECAST)
        self.assertEqual(rows, before)


class Incentive2QualifyingTests(unittest.TestCase):
    def codes(self, rows):
        return [r["Student Code"] for r in qualifying_rows(rows, INC2)]

    def test_any_qa_passed_date_counts_but_there_must_be_one(self):
        rows = [app(c, "Mel", university="QA Limited", qa=v) for c, v in (("a", "2026-01-01"), ("b", "2026-10-08"), ("c", "2026-10-09"), ("d", "2027-03-01"),
                                                                         ("e", ""), ("f", None), ("g", "garbage"))]
        self.assertEqual(self.codes(rows), ["a", "b", "c", "d"])

    def test_only_qa_limited_matched_whole_ignoring_case_and_spaces(self):
        rows = [app("a", "Mel", university="QA Limited"), app("b", "Mel", university=" qa limited "), app("c", "Mel", university="QA"), app("d", "Mel", university="QA Limited Group"),
                app("e", "Mel", university="LSC"), app("f", "Mel", university=""), app("g", "Mel", university=None), app("h", "Mel", university="XQA Limited")]
        self.assertEqual(self.codes(rows), ["a", "b"])

    def test_only_the_november_2026_intake(self):
        rows = [app("a", "Mel", university="QA Limited", intake="November 2026"), app("b", "Mel", university="QA Limited", intake="Nov 2026"),
                app("c", "Mel", university="QA Limited", intake="November 2027"), app("d", "Mel", university="QA Limited", intake="October 2026"),
                app("e", "Mel", university="QA Limited", intake=""), app("f", "Mel", university="QA Limited", intake=None)]
        self.assertEqual(self.codes(rows), ["a", "b"])

    def test_the_two_incentives_never_share_an_application(self):
        rows = [app("a", "Mel", university="LSC"), app("b", "Mel", university="QA Limited")]
        self.assertEqual(self.codes(rows), ["b"])
        self.assertEqual([r["Student Code"] for r in qualifying_rows(rows, INC)], ["a"])

    def built(self, enrolled):
        return build_incentive([app(f"E{i}", "Zed", university="QA Limited", qa="2026-06-01") for i in range(enrolled)] + [app("A", "Zed", "05-Assessment", university="QA Limited")], INC2, FORECAST)

    def test_each_level_is_reached_at_exactly_its_number(self):
        expected = {0: (0, False, 5, 5, 5), 4: (0, False, 5, 1, 5), 5: (1, True, 10, 5, 10), 9: (1, True, 10, 1, 10), 10: (2, True, 20, 10, 20),
                    19: (2, True, 20, 1, 20), 20: (3, True, None, 0, 20), 25: (3, True, None, 0, 20)}
        for enrolled, (level, triggered, upcoming, remaining, target) in expected.items():
            c = self.built(enrolled)["consultants"][0]
            self.assertEqual((c["level"], c["triggered"], c["next"], c["remaining"], c["target"]), (level, triggered, upcoming, remaining, target), enrolled)

    def test_the_summary_counts_the_consultants_at_each_level(self):
        rows = []
        for name, n in (("A", 3), ("B", 5), ("C", 9), ("D", 10), ("E", 20), ("F", 31)):
            rows += [app(f"{name}{i}", name, university="QA Limited") for i in range(n)]
        summary = build_incentive(rows, INC2, FORECAST)["summary"]
        self.assertEqual(summary["tiers"], [{"enrolments": 5, "consultants": 5}, {"enrolments": 10, "consultants": 3}, {"enrolments": 20, "consultants": 2}])
        self.assertEqual((summary["triggered"], summary["consultants"]), (5, 6), "A, with 3, has reached nothing")

    def test_a_single_trigger_incentive_has_one_tier(self):
        summary = build_incentive([app(f"E{i}", "Zed") for i in range(6)], INC, FORECAST)["summary"]
        self.assertEqual(summary["tiers"], [{"enrolments": 5, "consultants": 1}])


class QualifyingTests(unittest.TestCase):
    def codes(self, rows, incentive=INC):
        return [r["Student Code"] for r in qualifying_rows(rows, incentive)]

    def test_qa_approved_on_the_start_day_counts_the_day_before_does_not(self):
        rows = [app("a", "Mel", qa="2026-10-08"), app("b", "Mel", qa="2026-10-09"), app("c", "Mel", qa="2026-10-10"), app("d", "Mel", qa="2027-01-01")]
        self.assertEqual(self.codes(rows), ["b", "c", "d"])

    def test_no_usable_qa_date_never_qualifies(self):
        rows = [app(c, "Mel", qa=v) for c, v in (("a", ""), ("b", None), ("c", "garbage"), ("d", "09/10/2026"))]
        rows.append({k: v for k, v in app("e", "Mel").items() if k != "QA Passed"})
        self.assertEqual(self.codes(rows), [])

    def test_only_the_university_matched_whole_ignoring_case_and_spaces(self):
        rows = [app("a", "Mel", university="LSC"), app("b", "Mel", university=" lsc "), app("c", "Mel", university="LSC Group"), app("d", "Mel", university="TSD"),
                app("e", "Mel", university=""), app("f", "Mel", university=None), app("g", "Mel", university="XLSC")]
        self.assertEqual(self.codes(rows), ["a", "b"])

    def test_only_the_intake_month_and_year(self):
        rows = [app("a", "Mel", intake="November 2026"), app("b", "Mel", intake="Nov 2026"), app("c", "Mel", intake="november 2026"), app("d", "Mel", intake="November 2027"),
                app("e", "Mel", intake="October 2026"), app("f", "Mel", intake="January 2027"), app("g", "Mel", intake=""), app("h", "Mel", intake=None), app("i", "Mel", intake="2026")]
        self.assertEqual(self.codes(rows), ["a", "b", "c"])

    def test_another_incentive_can_have_other_rules(self):
        other = Incentive("x", "Incentive X", "TSD", 9, 2026, date(2026, 8, 1), (3,))
        rows = [app("a", "Mel", university="TSD", intake="September 2026", qa="2026-08-01"), app("b", "Mel"), app("c", "Mel", university="TSD", intake="September 2026", qa="2026-07-31")]
        self.assertEqual(self.codes(rows, other), ["a"])
        self.assertEqual(other.description, "TSD September 2026 intake applications whose QA was approved on or after 1 August 2026. Triggered at 3 enrolments.")

    def test_the_input_is_not_modified(self):
        rows = [app("a", "Mel")]
        qualifying_rows(rows, INC)
        self.assertEqual(rows, [app("a", "Mel")])


def sample():
    rows = []
    rows += [app(f"M{i}", "Mel", qa=f"2026-10-{9 + i:02d}") for i in range(5)]                                  # 5 enrolled (the first on the start day)
    rows += [app("M6", "Mel", "05-Assessment"), app("M7", "Mel", "06-Decision"), app("M8", "Mel", "08-Pre-Enrolled")]      # pre-enrolled is not an enrolment yet
    rows += [app(f"H{i}", "Hannah") for i in range(4)] + [app("H5", "Hannah", "10-Lost"), app("H6", "Hannah", "10-Lost"), app("H7", "Hannah", "07-Ready")]   # 4 enrolled
    rows += [app(f"K{i}", "Kian") for i in range(6)]                                                              # 6 enrolled
    rows += [app("U1", "", "05-Assessment"), app("U2", None, "04-Onboarding")]                                    # nobody allocated
    rows += [app("P1", "Kian", "03-PendingSubmission"), app("R1", "Kian", "00-QARejected")]                       # not on the chart / not a pipeline stage
    # none of these qualify:
    rows += [app("X1", "Mel", qa="2026-10-08"), app("X2", "Mel", qa=""), app("X3", "Mel", university="TSD"), app("X4", "Mel", intake="October 2026"),
             app("X5", "Mel", intake="November 2027"), app("X6", "Mel", university="LSC Group")]
    return rows


class BuildTests(unittest.TestCase):
    def setUp(self):
        self.built = build_incentive(sample(), INC, FORECAST)

    def test_a_row_per_consultant_most_applications_first_blank_as_unassigned(self):
        # ranked by all of a Consultant's qualifying applications: Mel 8, then Hannah and Kian on 7 (Kian also has one at 03-PendingSubmission) A-Z
        self.assertEqual([c["name"] for c in self.built["consultants"]], ["Mel", "Hannah", "Kian", "Unassigned"])
        totals = {r["name"]: r["total"] for g in self.built["chart_groups"] for r in g["rows"]}
        self.assertEqual(totals, {"Kian": 6, "Mel": 8, "Hannah": 7, "Unassigned": 2}, "the chart counts the stages it draws (04 to 10)")

    def test_enrolled_triggered_and_remaining_per_consultant(self):
        by = {c["name"]: c for c in self.built["consultants"]}
        self.assertEqual((by["Kian"]["enrolled"], by["Kian"]["triggered"], by["Kian"]["remaining"]), (6, True, 0))
        self.assertEqual((by["Mel"]["enrolled"], by["Mel"]["triggered"], by["Mel"]["remaining"]), (5, True, 0))
        self.assertEqual((by["Hannah"]["enrolled"], by["Hannah"]["triggered"], by["Hannah"]["remaining"]), (4, False, 1))
        self.assertEqual((by["Unassigned"]["enrolled"], by["Unassigned"]["triggered"], by["Unassigned"]["remaining"]), (0, False, 5))

    def test_it_triggers_at_exactly_the_target(self):
        for enrolled, expected in ((0, False), (4, False), (5, True), (6, True), (9, True)):
            built = build_incentive([app(f"E{i}", "Zed") for i in range(enrolled)] + [app("A", "Zed", "05-Assessment")], INC, FORECAST)
            self.assertEqual(built["consultants"][0]["triggered"], expected, enrolled)
            self.assertEqual(built["consultants"][0]["remaining"], max(5 - enrolled, 0), enrolled)

    def test_the_summary(self):
        summary = self.built["summary"]
        self.assertEqual(summary["total"], 24, "every pipeline stage 03 to 10, including the 03 the chart does not draw; not the QA-rejected one")
        self.assertEqual(summary["enrolled"], 15, "Mel's pre-enrolled application is not an enrolment")
        self.assertEqual((summary["triggered"], summary["consultants"]), (2, 4))

    def test_non_qualifying_applications_are_nowhere(self):
        shown = {r["code"] for c in self.built["consultants"] for g in GROUPS for r in incentive_records(self.built["report"], c["name"], g)}
        self.assertTrue(shown)
        self.assertFalse(shown & {"X1", "X2", "X3", "X4", "X5", "X6", "R1", "P1"})

    def test_every_piece_lists_exactly_its_count_and_the_pieces_add_up_to_the_bar(self):
        checked = 0
        for group in self.built["chart_groups"]:
            for row_ in group["rows"]:
                total = 0
                for seg in row_["segments"]:
                    records = incentive_records(self.built["report"], row_["name"], seg["key"])
                    self.assertEqual(len(records), seg["count"], (row_["name"], seg["key"]))
                    total += len(records)
                    checked += 1
                self.assertEqual(total, row_["total"], row_["name"])
        self.assertGreater(checked, 5)

    def test_an_unknown_group_gives_none_and_an_unknown_consultant_gives_nothing(self):
        self.assertIsNone(incentive_records(self.built["report"], "Mel", "nope"))
        self.assertEqual(incentive_records(self.built["report"], "Nobody", "enrolled_this_intake"), [])
        self.assertEqual(incentive_records(self.built["report"], "mel", "enrolled_this_intake"), [])

    def test_nothing_qualifying_gives_an_empty_page_model(self):
        built = build_incentive([app("X", "Mel", university="TSD")], INC, FORECAST)
        self.assertEqual((built["consultants"], built["chart_groups"][0]["rows"] if built["chart_groups"] else []), ([], []))
        self.assertEqual(built["summary"], {"total": 0, "enrolled": 0, "forecast": 0, "conversion": 0, "triggered": 0, "tiers": [{"enrolments": 5, "consultants": 0}], "consultants": 0, "team": None})


# ----------------------------------------------------------------- the page
STATUS_LOOKUP = [("Enrolled", "09-Enrolled"), ("Assessment", "05-Assessment"), ("Decision", "06-Decision"), ("Ready", "07-Ready"), ("Lost", "10-Lost"),
                 ("Onboarding", "04-Onboarding"), ("Pending Submission", "03-PendingSubmission"), ("QA Rejected", "00-QARejected"),
                 ("Pre Enrolled", "08-Pre-Enrolled")]
RAW = {"08-Pre-Enrolled": "Pre Enrolled", "09-Enrolled": "Enrolled", "05-Assessment": "Assessment", "06-Decision": "Decision", "07-Ready": "Ready", "10-Lost": "Lost", "04-Onboarding": "Onboarding",
       "03-PendingSubmission": "Pending Submission", "00-QARejected": "QA Rejected"}


def uk(iso):
    return f"{iso[8:10]}/{iso[5:7]}/{iso[:4]}" if iso else ""


def workbook_rows(rows=None):
    return [row(**{"Student Code": r["Student Code"], "Student Name": r["Student Name"], "Application Status": RAW[r["Status"]], "Counsellor": (r["Consultant"] or ""),
                   "University Name": r["University Name"] or "", "Intake": r["Intake"] or "", "QA Signed Off": uk(r["QA Passed"]), "Admission Officer": f'{r["Application"]} Y' if r.get("Application") else "", "Course Name": r.get("Course Name", ""),
                   "Lead Source": r.get("Source", "")})
            for r in (sample() if rows is None else rows)]


def qa_sample():
    rows = [app(f"Q{i}", "Zed", university="QA Limited", qa=f"2026-0{i + 1}-15") for i in range(5)]                  # 5 enrolled, QA passed long before October
    rows += [app("Q6", "Zed", "05-Assessment", university="QA Limited"), app("Q7", "Ann", university="QA Limited", qa="2026-11-20"), app("Q8", "Ann", "10-Lost", university=" qa limited ")]
    # none of these qualify:
    rows += [app("Y1", "Zed", university="QA Limited", intake="October 2026"), app("Y2", "Zed", university="QA Limited", qa=""), app("Y3", "Zed", university="QA"),
             app("Y4", "Zed", university="QA Limited Group"), app("Y5", "Zed", university="QA Limited", intake="November 2027")]
    return rows


@contextmanager
def captured():
    rendered = []

    def record(sender, template, context, **extra):
        rendered.append((template.name, dict(context)))

    template_rendered.connect(record, app_module.app)
    try:
        yield rendered
    finally:
        template_rendered.disconnect(record, app_module.app)


class PageBase(IsolatedAppTestCase):
    ROWS = None

    def setUp(self):
        super().setUp()
        self.full = self._client_logged_in_as("full")
        token = extract_token(self.full.get("/login").get_data(as_text=True))
        data = book(self.ROWS if self.ROWS is not None else workbook_rows(), lookups={"status": STATUS_LOOKUP})
        self.assertEqual(self.full.post("/upload", data={"csrf_token": token, "excel_file": (io.BytesIO(data), "f.xlsx")}, content_type="multipart/form-data").status_code, 302)

    def page(self, client=None, query=""):
        with captured() as rendered:
            r = (client or self.full).get("/incentives" + query)
        self.assertEqual(r.status_code, 200)
        return r.get_data(as_text=True), next(c for name, c in rendered if name == "incentives.html")

    def records(self, consultant, group, incentive="incentive_1", client=None):
        return (client or self.full).get("/incentives/records?" + urlencode({"incentive": incentive, "consultant": consultant, "group": group}))


class PageTests(PageBase):
    def test_the_heading_rules_and_cards(self):
        html, context = self.page()
        self.assertIn("<h1>Incentives</h1>", html)
        self.assertIn("Incentive 1 &mdash; LSC November 2026", html)
        self.assertIn("LSC November 2026 intake applications whose QA was approved on or after 9 October 2026. Triggered at 5 enrolments.", html)
        summary = context["incentives"][0]["summary"]
        self.assertEqual((summary["total"], summary["enrolled"], summary["triggered"], summary["consultants"]), (24, 15, 2, 4))
        card = html[html.index('<div class="summary-card summary-card-overall">'):]
        card = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", card[:card.index("</section>")]))
        self.assertIn("Apps 24 Enrolled 15 Forecast", card)
        self.assertIn("Triggered at 5 enrolments Consultants triggered 2 of 4", card)

    def test_the_chart_is_a_row_per_consultant_in_the_university_pipeline_style(self):
        html, context = self.page()
        self.assertIn("<h2>Incentive 1 Pipeline by Consultant</h2>", html)
        self.assertIn('<div class="chart-manager-name">Consultant</div>', html)
        names = re.findall(r'<div class="chart-row">\s*<div class="chart-manager-name">([^<]+)</div>', html)
        self.assertEqual(names, ["Mel", "Hannah", "Kian", "Unassigned"])
        for fragment in ('class="chart-bar-track"', 'class="chart-col-total"', 'class="chart-col-forecast"', 'class="chart-col-conversion"', 'class="chart-legend"'):
            self.assertIn(fragment, html)
        legend = html[html.index('class="chart-legend"'):]
        for label in ("Pending Assessment", "Pending Offer", "Pending Enrolment", "Enrolled This Intake", "Lost"):
            self.assertIn(label, legend)

    def test_the_enrolled_column_shows_progress_to_the_trigger(self):
        from html import unescape
        html, _ = self.page()
        pills = re.findall(r'<span class="incentive-pill( incentive-pill-triggered)?" title="([^"]*)">\s*([^<]+?)\s*</span>', html)
        self.assertEqual([(t.strip(), unescape(text)) for t, _, text in pills],
                         [("incentive-pill-triggered", "5 / 5 \u2713"), ("", "4 / 5"), ("incentive-pill-triggered", "6 / 5 \u2713"), ("", "0 / 5")], "Mel, Hannah, Kian, Unassigned")
        self.assertEqual([title for _, title, _ in pills], ["Incentive triggered", "1 more to trigger the incentive", "Incentive triggered", "5 more to trigger the incentive"])
        self.assertIn('<span class="chart-col-incentive">Enrolled</span>', html)

    def test_every_piece_is_a_clickable_button_and_the_tooltip_is_unchanged(self):
        html, context = self.page()
        pieces = re.findall(r'<div class="chart-segment chart-segment-clickable" role="button" tabindex="0"\s+style="[^"]*"\s+data-tooltip="([^"]*)"\s+'
                            r'data-records-title="([^"]*)"\s+data-records-params="([^"]*)"\s+data-count="(\d+)"', html)
        got = []
        for tooltip, title, params, count in pieces:
            query = parse_qs(params.replace("&amp;", "&"))
            self.assertEqual(sorted(query), ["consultant", "group", "incentive"])
            name, group = query["consultant"][0], query["group"][0]
            label = title.split(" &mdash; ")[1]
            self.assertEqual((query["incentive"][0], tooltip), ("incentive_1", f"{name} - {label}: {count}"))
            got.append((name, group, int(count)))
        expected = [(r["name"], s["key"], s["count"]) for g in context["incentives"][0]["chart_groups"] for r in g["rows"] for s in r["segments"]]
        self.assertEqual(got, expected)
        self.assertGreater(len(got), 5)

    def test_the_window_is_on_the_page_once_with_its_own_endpoint(self):
        html, _ = self.page()
        self.assertEqual(html.count('<dialog id="chart-records"'), 1)
        self.assertIn('data-url="/incentives/records"', html)
        self.assertEqual(html.count("chart-records.js"), 1)
        self.assertIn("Click a bar to list its applications.", html)

    def test_it_is_in_the_toolbar_and_highlighted_on_its_page(self):
        html, _ = self.page()
        nav = html[html.index('<nav class="nav">'):html.index("</nav>")]
        self.assertRegex(nav, r'<a href="/incentives" class="active">Incentives</a>')
        self.assertLess(nav.index("University Pipeline"), nav.index("Incentives"))
        self.assertLess(nav.index("Incentives"), nav.index("Interviews"))

    def test_every_role_can_open_it_and_login_is_required(self):
        for role in ("admissions", "consultants", "marketing"):
            _, context = self.page(client=self._client_logged_in_as(role))
            self.assertEqual(context["incentives"][0]["summary"]["total"], 24, role)
        anon = app_module.app.test_client().get("/incentives")
        self.assertEqual(anon.status_code, 302)
        self.assertIn("/login", anon.headers["Location"])

    def test_other_pages_do_not_have_it(self):
        for path in ("/university-pipeline?year=2026", "/dashboard?year=2026"):
            self.assertNotIn("incentive-pill", self.full.get(path).get_data(as_text=True), path)


class RecordsRouteTests(PageBase):
    def test_every_piece_lists_exactly_the_number_it_shows(self):
        _, context = self.page()
        checked = 0
        for group in context["incentives"][0]["chart_groups"]:
            for row_ in group["rows"]:
                for seg in row_["segments"]:
                    r = self.records(row_["name"], seg["key"])
                    self.assertEqual(r.status_code, 200)
                    data = r.get_json()
                    self.assertEqual((data["count"], len(data["records"])), (seg["count"], seg["count"]), (row_["name"], seg["key"]))
                    checked += 1
        self.assertGreater(checked, 5)

    def test_known_pieces_and_the_six_fields(self):
        codes = lambda consultant, group: [r["code"] for r in self.records(consultant, group).get_json()["records"]]
        self.assertEqual(sorted(codes("Mel", "enrolled_this_intake")), ["M0", "M1", "M2", "M3", "M4"], "M0 is the one whose QA was approved on 9 October")
        self.assertEqual(codes("Mel", "pending_assessment"), ["M6"])
        self.assertEqual(codes("Mel", "pending_offer"), ["M7"])
        self.assertEqual(codes("Mel", "pending_enrolment"), ["M8"], "pre-enrolled is listed in the pipeline but is not counted as an enrolment")
        self.assertEqual(sorted(codes("Hannah", "lost")), ["H5", "H6"])
        self.assertEqual(codes("Unassigned", "pending_assessment"), ["U1", "U2"])
        self.assertEqual(len(codes("Kian", "enrolled_this_intake")), 6)
        data = self.records("Hannah", "pending_enrolment").get_json()
        self.assertEqual(data["records"], [{"code": "H7", "student": "Student H7", "university": "LSC", "intake": "November 2026", "consultant": "Hannah", "manager": "Mo"}])
        self.assertEqual((data["incentive"], data["consultant"], data["group"]), ("incentive_1", "Hannah", "pending_enrolment"))

    def test_sorted_by_student_then_code(self):
        data = self.records("Kian", "enrolled_this_intake").get_json()
        keys = [(r["student"].lower(), r["code"]) for r in data["records"]]
        self.assertEqual(keys, sorted(keys))

    def test_an_unknown_incentive_or_group_is_a_400_and_an_unknown_consultant_is_empty(self):
        for params in ({"incentive": "nope", "consultant": "Mel", "group": "lost"}, {"incentive": "", "consultant": "Mel", "group": "lost"},
                       {"consultant": "Mel", "group": "lost"}, {"incentive": "incentive_1", "consultant": "Mel", "group": "nope"},
                       {"incentive": "incentive_1", "consultant": "Mel"}, {"incentive": "INCENTIVE_1", "consultant": "Mel", "group": "lost"}):
            r = self.full.get("/incentives/records?" + urlencode(params))
            self.assertEqual((r.status_code, r.get_json()), (400, {"error": "Unknown chart piece."}), params)
        for consultant in ("Nobody", "mel", "Mel ", ""):
            r = self.records(consultant, "enrolled_this_intake")
            self.assertEqual((r.status_code, r.get_json()["count"]), (200, 0), repr(consultant))

    def test_json_no_store_login_and_roles(self):
        r = self.records("Mel", "enrolled_this_intake")
        self.assertEqual((r.mimetype, r.headers["Cache-Control"]), ("application/json", "no-store"))
        anon = app_module.app.test_client().get("/incentives/records?incentive=incentive_1&consultant=Mel&group=lost")
        self.assertEqual(anon.status_code, 302)
        for role in ("admissions", "consultants", "marketing"):
            self.assertEqual(self.records("Mel", "enrolled_this_intake", client=self._client_logged_in_as(role)).get_json()["count"], 5, role)


class Incentive2PageTests(PageBase):
    ROWS = workbook_rows(sample() + qa_sample())

    def second(self, html):
        return html[html.index("Incentive 2 &mdash;"):html.index("Incentive 3 &mdash;")]

    def test_both_incentives_are_on_the_page_in_order_each_with_its_rule(self):
        html, context = self.page()
        self.assertEqual([b["incentive"].key for b in context["incentives"]], ["incentive_1", "incentive_2", "incentive_3", "incentive_4"])
        self.assertLess(html.index("Incentive 1 &mdash; LSC November 2026"), html.index("Incentive 2 &mdash; QA Limited November 2026"))
        self.assertIn("QA Limited November 2026 intake applications whose QA has been approved. Triggers at 5, 10 and 20 enrolments.", html)
        self.assertIn("<h2>Incentive 2 Pipeline by Consultant</h2>", html)

    def test_incentive_1_is_unchanged_by_the_qa_limited_applications(self):
        _, context = self.page()
        summary = context["incentives"][0]["summary"]
        self.assertEqual((summary["total"], summary["enrolled"], summary["triggered"], summary["consultants"]), (24, 15, 2, 4))

    def test_incentive_2_counts_only_qa_limited_applications(self):
        _, context = self.page()
        built = context["incentives"][1]
        self.assertEqual([c["name"] for c in built["consultants"]], ["Zed", "Ann"], "Zed has 6, Ann 2")
        by = {c["name"]: c for c in built["consultants"]}
        self.assertEqual((by["Zed"]["enrolled"], by["Zed"]["triggered"], by["Zed"]["remaining"]), (5, True, 5), "5 enrolled: the first level reached, 5 more to the next")
        self.assertEqual((by["Ann"]["enrolled"], by["Ann"]["triggered"], by["Ann"]["remaining"]), (1, False, 4))
        self.assertEqual((built["summary"]["total"], built["summary"]["enrolled"], built["summary"]["triggered"], built["summary"]["consultants"]), (8, 6, 1, 2))

    def test_the_incentive_box_lists_each_level_with_how_many_consultants_reached_it(self):
        html, _ = self.page()
        box = self.second(html)
        box = box[box.index('<div class="summary-card-title">Consultant Incentive</div>'):]
        box = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", box[:box.index("</section>")]))
        self.assertIn("Incentive 5 enrolments 1 of 2 10 enrolments 0 of 2 20 enrolments 0 of 2", box)
        self.assertNotIn("Consultants triggered", box.split("Incentive Pipeline")[0])
        first = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html[html.index('<div class="summary-card-title">Consultant Incentive</div>'):html.index("Incentive 2 &mdash;")]))
        self.assertIn("Triggered at 5 enrolments Consultants triggered 2 of 4", first, "Incentive 1's box is as before")

    def test_the_second_chart_shows_the_pills_for_its_own_consultants(self):
        from html import unescape
        html, _ = self.page()
        pills = re.findall(r'<span class="incentive-pill( incentive-pill-triggered)?" title="[^"]*">\s*([^<]+?)\s*</span>', self.second(html))
        self.assertEqual([(t.strip(), unescape(text)) for t, text in pills], [("incentive-pill-triggered", "5 / 10 \u2713"), ("", "1 / 5")])

    def test_each_piece_asks_for_its_own_incentive(self):
        html, _ = self.page()
        params = [parse_qs(p.replace("&amp;", "&")) for p in re.findall(r'data-records-params="([^"]*)"', self.second(html))]
        self.assertTrue(params)
        self.assertEqual({q["incentive"][0] for q in params}, {"incentive_2"})
        first = html[:html.index("Incentive 2 &mdash;")]
        self.assertEqual({parse_qs(p.replace("&amp;", "&"))["incentive"][0] for p in re.findall(r'data-records-params="([^"]*)"', first)}, {"incentive_1"})

    def test_the_window_is_still_on_the_page_once(self):
        html, _ = self.page()
        self.assertEqual(html.count('<dialog id="chart-records"'), 1)
        self.assertEqual(html.count("chart-records.js"), 1)

    def test_the_pieces_list_their_applications_from_the_right_incentive(self):
        codes = lambda consultant, group, incentive: sorted(r["code"] for r in self.records(consultant, group, incentive).get_json()["records"])
        self.assertEqual(codes("Zed", "enrolled_this_intake", "incentive_2"), ["Q0", "Q1", "Q2", "Q3", "Q4"])
        self.assertEqual(codes("Zed", "pending_assessment", "incentive_2"), ["Q6"])
        self.assertEqual(codes("Ann", "enrolled_this_intake", "incentive_2"), ["Q7"])
        self.assertEqual(codes("Ann", "lost", "incentive_2"), ["Q8"])
        self.assertEqual(codes("Zed", "enrolled_this_intake", "incentive_1"), [], "Zed has no LSC applications")
        self.assertEqual(codes("Mel", "enrolled_this_intake", "incentive_2"), [], "Mel has no QA Limited applications")
        data = self.records("Ann", "enrolled_this_intake", "incentive_2").get_json()
        self.assertEqual((data["incentive"], data["records"][0]["university"], data["records"][0]["intake"]), ("incentive_2", "QA Limited", "November 2026"))

    def test_every_piece_lists_exactly_the_number_it_shows(self):
        _, context = self.page()
        checked = 0
        for group in context["incentives"][1]["chart_groups"]:
            for row_ in group["rows"]:
                for seg in row_["segments"]:
                    data = self.records(row_["name"], seg["key"], "incentive_2").get_json()
                    self.assertEqual((data["count"], len(data["records"])), (seg["count"], seg["count"]), (row_["name"], seg["key"]))
                    checked += 1
        self.assertGreater(checked, 2)


class LevelsOnThePageTests(PageBase):
    """Consultants at every level of Incentive 2 - the pill, its tooltip and the box."""

    ROWS = workbook_rows([app(f"{name}{i}", name, university="QA Limited") for name, n in (("Ana", 3), ("Bea", 5), ("Cat", 12), ("Dee", 20), ("Eve", 26)) for i in range(n)])

    def pills(self):
        from html import unescape
        html, _ = self.page()
        found = re.findall(r'<span class="incentive-pill( incentive-pill-triggered)?" title="([^"]*)">\s*([^<]+?)\s*</span>', html[html.index("Incentive 2 &mdash;"):])
        return [(bool(t.strip()), unescape(text), unescape(title)) for t, title, text in found]

    def test_the_pill_shows_enrolments_against_the_next_level_and_a_tick_once_one_is_reached(self):
        by_name = dict(zip(["Eve", "Dee", "Cat", "Bea", "Ana"], self.pills()))     # most applications first
        self.assertEqual(by_name["Ana"], (False, "3 / 5", "2 more to trigger the incentive"))
        self.assertEqual(by_name["Bea"], (True, "5 / 10 \u2713", "Reached 5 - 5 more to reach 10"))
        self.assertEqual(by_name["Cat"], (True, "12 / 20 \u2713", "Reached 10 - 8 more to reach 20"))
        self.assertEqual(by_name["Dee"], (True, "20 / 20 \u2713", "All 3 triggers reached"))
        self.assertEqual(by_name["Eve"], (True, "26 / 20 \u2713", "All 3 triggers reached"))

    def test_the_box_counts_the_consultants_who_reached_each_level(self):
        html, _ = self.page()
        box = html[html.index("Incentive 2 &mdash;"):]
        box = box[box.index('<div class="summary-card-title">Consultant Incentive</div>'):]
        box = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", box[:box.index("</section>")]))
        self.assertIn("5 enrolments 4 of 5 10 enrolments 3 of 5 20 enrolments 2 of 5", box)

    def test_the_hint_names_the_levels(self):
        html, _ = self.page()
        self.assertIn("against the next trigger up (5, 10 or 20)", html)


def ulaw(code, consultant, status="09-Enrolled", course="LLM Law", **extra):
    return app(code, consultant, status, university="ULAW", intake="September 2026", **{"Course Name": course}, **extra)


class Incentive3PageTests(PageBase):
    ROWS = workbook_rows(
        [ulaw("U1", "Ann", course="LPC"), ulaw("U2", "Ann", course="GDL"), ulaw("U3", "Bob"), ulaw("U4", "Cat", course="BA Law"), ulaw("U5", "Cat", course="LLB"), ulaw("U6", "Cat", course="LLM"),
         ulaw("U7", "Cat", course="LPC"), ulaw("U8", "Cat", course="GDL"), ulaw("P1", "Bob", "05-Assessment", course="MA"), ulaw("L1", "Bob", "10-Lost", course="MBA"),
         ulaw("Z1", "", course="BSc")]
        + [app("X1", "Ann", university="LSC", intake="November 2026"), app("X2", "Ann", university="ULAW", intake="September 2027"), app("X3", "Ann", university="ULAW", intake="September 2026", qa="")])

    def third(self, html):
        return html[html.index("Incentive 3 &mdash;"):html.index("Incentive 4 &mdash;")]

    def test_the_heading_rule_and_box(self):
        html, context = self.page()
        third = self.third(html)
        self.assertIn("Incentive 3 &mdash; ULAW 2026", html)
        self.assertIn("ULAW 2026 intake applications whose QA has been approved. Triggers at 2 and 5 enrolments.", third)
        box = third[third.index('<div class="summary-card-title">Consultant Incentive</div>'):]
        box = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", box[:box.index("</section>")]))
        self.assertIn("2 enrolments 2 of 4 5 enrolments 1 of 4", box, "Cat 5, Ann 2, Bob 1 (his pending and lost ones are not enrolments), Unassigned 1")
        self.assertIn("<h2>Incentive 3 Pipeline by Consultant</h2>", html)

    def test_the_pills(self):
        from html import unescape
        html, _ = self.page()
        pills = re.findall(r'<span class="incentive-pill( incentive-pill-triggered)?" title="([^"]*)">\s*([^<]+?)\s*</span>', self.third(html))
        self.assertEqual([(bool(t.strip()), unescape(text), unescape(title)) for t, title, text in pills],
                         [(True, "5 / 5 \u2713", "All 2 triggers reached"), (False, "1 / 2", "1 more to trigger the incentive"), (True, "2 / 5 \u2713", "Reached 2 - 3 more to reach 5"),
                          (False, "1 / 2", "1 more to trigger the incentive")], "Cat, Bob (3 applications), Ann, Unassigned")

    def test_the_enrolled_applications_are_listed_underneath_the_chart(self):
        html, context = self.page()
        third = self.third(html)
        self.assertLess(third.index("Incentive 3 Pipeline by Consultant"), third.index("Incentive 3 Enrolled Applications (9)"))
        table = third[third.index('<table class="data-table incentive-enrolled-table">'):third.index("</table>")]
        self.assertEqual(re.findall(r"<th>([^<]*)</th>", table), ["Consultant", "Course", "PES Code", "Student Name"])
        rows = [[re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", cell)).strip() for cell in re.findall(r"<td>(.*?)</td>", tr, re.S)] for tr in re.findall(r"<tr>(.*?)</tr>", table, re.S)[1:]]
        self.assertEqual(rows, [["Ann", "LPC", "U1", "Student U1"], ["Ann", "GDL", "U2", "Student U2"], ["Bob", "LLM Law", "U3", "Student U3"], ["Cat", "BA Law", "U4", "Student U4"],
                                ["Cat", "LLB", "U5", "Student U5"], ["Cat", "LLM", "U6", "Student U6"], ["Cat", "LPC", "U7", "Student U7"], ["Cat", "GDL", "U8", "Student U8"],
                                ["Unassigned", "BSc", "Z1", "Student Z1"]])
        self.assertNotIn("P1", table)
        self.assertNotIn("L1", table)
        self.assertEqual([r["code"] for r in context["incentives"][2]["enrolled_list"]], ["U1", "U2", "U3", "U4", "U5", "U6", "U7", "U8", "Z1"])

    def test_each_pes_code_is_a_copy_button(self):
        html, _ = self.page()
        table = self.third(html)
        self.assertEqual(re.findall(r'<button type="button" class="copy-btn" data-code="([^"]*)">', table), ["U1", "U2", "U3", "U4", "U5", "U6", "U7", "U8", "Z1"])

    def test_only_incentives_3_and_4_have_a_list(self):
        html, _ = self.page()
        self.assertEqual(html.count("incentive-enrolled-table"), 1, "Incentive 4 has no applications here, so no table")
        self.assertEqual(html.count("Enrolled Applications ("), 2)
        self.assertLess(html.index("Incentive 3 &mdash;"), html.index("Incentive 3 Enrolled Applications ("))
        self.assertNotIn("Incentive 1 Enrolled", html)
        self.assertNotIn("Incentive 2 Enrolled", html)

    def test_text_in_a_name_is_shown_as_text(self):
        evil = "<img src=x onerror=alert(1)>"
        rows = workbook_rows([dict(ulaw("E1", "Ann"), **{"Student Name": evil, "Course Name": evil})])
        html = self.third(self.page_for(rows))
        self.assertNotIn(evil, html)
        self.assertIn("&lt;img src=x onerror=alert(1)&gt;", html)

    def page_for(self, rows):
        import io as _io
        token = extract_token(self.full.get("/login").get_data(as_text=True))
        data = book(rows, lookups={"status": STATUS_LOOKUP})
        self.assertEqual(self.full.post("/upload", data={"csrf_token": token, "excel_file": (_io.BytesIO(data), "g.xlsx")}, content_type="multipart/form-data").status_code, 302)
        return self.page()[0]

    def test_the_pieces_of_incentive_3_list_their_applications(self):
        _, context = self.page()
        data = self.records("Cat", "enrolled_this_intake", "incentive_3").get_json()
        self.assertEqual(sorted(r["code"] for r in data["records"]), ["U4", "U5", "U6", "U7", "U8"])
        self.assertEqual(data["incentive"], "incentive_3")
        self.assertEqual(self.records("Bob", "lost", "incentive_3").get_json()["count"], 1)
        for group in context["incentives"][2]["chart_groups"]:
            for row_ in group["rows"]:
                for seg in row_["segments"]:
                    self.assertEqual(self.records(row_["name"], seg["key"], "incentive_3").get_json()["count"], seg["count"], (row_["name"], seg["key"]))


def tsd(code, consultant, manager="Mo", status="09-Enrolled", course="MBA", qa="2026-08-01", **extra):
    return app(code, consultant, status, university="TSD", intake="September 2026", qa=qa, **{"Course Name": course, "Application": manager}, **extra)


class Incentive4PageTests(PageBase):
    ROWS = workbook_rows(
        # Ann: 9 under the rules + one QA-passed on the start day = 10 (listed). Cat: exactly 10 (listed).
        [tsd(f"A{i}", "Ann", "Mo" if i % 2 else "Pat", course=f"Course {i}") for i in range(9)] + [tsd("A9", "Ann", "Mo", course="Day one", qa="2026-07-24")]
        + [tsd(f"C{i}", "Cat", "Mo") for i in range(10)]
        # Bob: 9 under the rules; the rest of his applications are not (so he has 9, and is not listed).
        + [tsd(f"B{i}", "Bob") for i in range(9)] + [tsd("BQ1", "Bob", qa="2026-07-23"), tsd("BQ2", "Bob", qa="2026-07-23"), tsd("BP", "Bob", status="05-Assessment"), tsd("BL", "Bob", status="10-Lost")]
        + [app("BX", "Bob", university="TSD", intake="September 2027"), app("BY", "Bob", university="LSC", intake="November 2026"), tsd("BN", "Bob", qa="")]
        # nobody allocated: 12 enrolled, but that is not a Consultant
        + [tsd(f"U{i}", "", "") for i in range(12)])

    def fourth(self, html):
        return html[html.index("Incentive 4 &mdash;"):html.index("</main>")]

    def rows_of(self, html):
        fourth = self.fourth(html)
        table = fourth[fourth.index('<table class="data-table incentive-enrolled-table">'):fourth.index("</table>")]
        return [[re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", cell)).strip() for cell in re.findall(r"<td>(.*?)</td>", tr, re.S)] for tr in re.findall(r"<tr>(.*?)</tr>", table, re.S)[1:]]

    def test_the_heading_and_rule(self):
        html, _ = self.page()
        self.assertIn("Incentive 4 &mdash; TSD 2026", html)
        self.assertIn("TSD 2026 intake applications whose QA was approved on or after 24 July 2026 and are enrolled. Only Consultants with 10 or more enrolled are listed.", self.fourth(html))

    def test_no_cards_no_chart_no_pills_for_it(self):
        html, _ = self.page()
        fourth = self.fourth(html)
        for text in ("summary-card", "chart-row", "chart-segment", "incentive-pill", "Pipeline by Consultant", "chart-legend", "Triggered at", "Triggers at", "Consultants triggered"):
            self.assertNotIn(text, fourth, text)

    def test_only_consultants_with_ten_or_more_enrolled_are_listed(self):
        html, context = self.page()
        self.assertIn("Incentive 4 Enrolled Applications (20)", self.fourth(html))
        rows = self.rows_of(html)
        self.assertEqual(sorted({r[0] for r in rows}), ["Ann", "Cat"], "not Bob (9) or the unallocated 12")
        self.assertEqual(len(rows), 20)
        self.assertEqual(len(context["incentives"][3]["enrolled_list"]), 20)

    def test_the_list_has_the_six_columns_in_the_order_asked_for(self):
        html, _ = self.page()
        fourth = self.fourth(html)
        table = fourth[fourth.index('<table class="data-table incentive-enrolled-table">'):fourth.index("</table>")]
        self.assertEqual(re.findall(r"<th>([^<]*)</th>", table), ["Consultant", "Application Manager", "PES Code", "Student Name", "University", "Course"])
        rows = self.rows_of(html)
        self.assertEqual(rows[0][0], "Ann")
        by_code = {r[2]: r for r in rows}
        self.assertEqual(by_code["A9"], ["Ann", "Mo", "A9", "Student A9", "TSD", "Day one"])
        self.assertEqual(by_code["A2"], ["Ann", "Pat", "A2", "Student A2", "TSD", "Course 2"])
        self.assertEqual(by_code["C3"], ["Cat", "Mo", "C3", "Student C3", "TSD", "MBA"])

    def test_sorted_by_consultant_then_student(self):
        rows = self.rows_of(self.page()[0])
        keys = [(r[0], r[3].lower()) for r in rows]
        self.assertEqual(keys, sorted(keys))
        self.assertEqual([r[0] for r in rows], ["Ann"] * 10 + ["Cat"] * 10)

    def test_each_pes_code_is_a_copy_button(self):
        html, _ = self.page()
        fourth = self.fourth(html)
        codes = re.findall(r'<button type="button" class="copy-btn" data-code="([^"]*)">', fourth[:fourth.index("No Consultant, Not Counted")])
        self.assertEqual(sorted(codes), sorted([f"A{i}" for i in range(10)] + [f"C{i}" for i in range(10)]))

    def test_the_applications_with_no_consultant_are_listed_for_checking(self):
        html, _ = self.page()
        fourth = self.fourth(html)
        self.assertIn("Incentive 4 &mdash; No Consultant, Not Counted (12)", fourth)
        self.assertIn("so they cannot count towards any Consultant's 10. Check these.", fourth)
        block = fourth[fourth.index("No Consultant, Not Counted"):]
        table = block[block.index('<table class="data-table incentive-unassigned-table">'):block.index("</table>")]
        self.assertEqual(re.findall(r"<th>([^<]*)</th>", table), ["Application Manager", "PES Code", "Student Name", "University", "Course"], "no Consultant column: there is none")
        rows = [[re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", cell)).strip() for cell in re.findall(r"<td>(.*?)</td>", tr, re.S)] for tr in re.findall(r"<tr>(.*?)</tr>", table, re.S)[1:]]
        self.assertEqual(sorted(r[1] for r in rows), sorted(f"U{i}" for i in range(12)))
        self.assertEqual(rows[0][0], "Unassigned")
        self.assertEqual(len(re.findall(r'data-code="([^"]*)"', table)), 12, "each PES Code can be copied")
        self.assertTrue({r[1] for r in rows}.isdisjoint({f"A{i}" for i in range(10)} | {f"C{i}" for i in range(10)} | {f"B{i}" for i in range(9)}), "only the unallocated ones")

    def test_only_incentive_4_has_that_list(self):
        html, _ = self.page()
        self.assertEqual(html.count("Not Counted ("), 1)
        self.assertEqual(html.count("incentive-unassigned-table"), 1)

    def test_it_has_no_pieces_to_click_so_the_records_endpoint_says_no(self):
        for group in ("enrolled_this_intake", "lost"):
            r = self.records("Ann", group, "incentive_4")
            self.assertEqual((r.status_code, r.get_json()), (400, {"error": "Unknown chart piece."}), group)
        self.assertEqual(self.records("Ann", "enrolled_this_intake", "incentive_1").status_code, 200)

    def test_the_other_incentives_still_have_their_charts(self):
        html, context = self.page()
        self.assertEqual([b["incentive"].has_chart for b in context["incentives"]], [True, True, True, False])
        self.assertEqual(html.count("summary-card-overall"), 3)


class NobodyHasTenTests(PageBase):
    ROWS = workbook_rows([tsd(f"B{i}", "Bob") for i in range(9)])

    def test_the_list_says_no_consultant_has_ten_yet(self):
        html, _ = self.page()
        self.assertIn("Incentive 4 Enrolled Applications (0)", html)
        self.assertIn("No Consultant has 10 or more enrolled applications yet.", html)
        self.assertIn("No Consultant, Not Counted (0)", html)
        self.assertIn('<p class="placeholder">None.</p>', html[html.index("No Consultant, Not Counted (0)"):])


class NoEnrolledYetTests(PageBase):
    ROWS = workbook_rows([ulaw("P1", "Bob", "05-Assessment")])

    def test_the_list_says_so(self):
        html, _ = self.page()
        self.assertIn("Incentive 3 Enrolled Applications (0)", html)
        self.assertIn("No enrolled applications yet.", html, "Incentive 3's list")
        self.assertNotIn("incentive-enrolled-table", html)


class NothingQualifiesTests(PageBase):
    ROWS = [row(**{"Student Code": "X1", "Student Name": "X", "Application Status": "Enrolled", "Counsellor": "Mel Z", "University Name": "TSD",
                   "Intake": "November 2026", "QA Signed Off": "15/10/2026", "Admission Officer": "Mo Y"})]

    def test_the_page_says_so_and_has_no_chart(self):
        html, context = self.page()
        self.assertIn("No applications qualify yet.", html)
        self.assertNotIn('class="chart-row"', html)
        self.assertEqual(context["incentives"][0]["summary"]["total"], 0)
        self.assertIn("Triggered at 5 enrolments", html)


INC5 = INCENTIVES_BY_KEY["incentive_2027_1"]
PAID = {"Source": "Paid Ad"}


def a2027(code, consultant, status="09-Enrolled", university="UCLAN", intake="January 2027", source="Paid Ad", **extra):
    return app(code, consultant, status, university=university, intake=intake, **({"Source": source} if source is not None else {}), **extra)


def incentive_5_sample():
    rows = [a2027("P1", "Zed", university="UCLAN", intake="January 2027"), a2027("P2", "Zed", university="ARU", intake="February 2027"),
            a2027("P3", "Zed", university="UOGM", intake="March 2027"), a2027("P4", "Zed", university=" uclan ", intake="March 2027", source=" paid ad "),
            a2027("P5", "Zed", "05-Assessment", university="ARU", intake="February 2027"),
            a2027("P6", "Amy", university="UCLAN"), a2027("P7", "Amy", university="ARU"), a2027("P8", "Amy", "10-Lost", university="UOGM"),
            a2027("P9", "Amy", "08-Pre-Enrolled", university="UOGM"),
            a2027("P10", "Amy"), a2027("P11", "", university="ARU")]
    rows += [a2027("T1", "Amy", source="Agent"), a2027("T2", "Zed", university="ARU", intake="March 2027", source=""),         # enrolled, not Paid Ad: only in the team total
             a2027("T3", "Bea", "05-Assessment", source="Agent")]                                                             # not Paid Ad and not enrolled: nowhere
    rows += [a2027("N1", "Zed", intake="April 2027"), a2027("N2", "Zed", university="ARU", intake="December 2026"),            # not in these months
             a2027("N3", "Zed", university="Anglia"), a2027("N4", "Zed", university="UOGM", intake="February 2028"),          # not these Universities or this year
             a2027("N5", "Zed", qa=""), a2027("N6", "Zed", university="ARU Group"), a2027("N7", "Zed", intake="2027"),
             a2027("N8", "Zed", university="Callum and Matthews")]                                                            # the group's name is not a University
    return rows


class Incentive2027ConfigTests(unittest.TestCase):
    def test_the_rules(self):
        self.assertEqual((INC5.key, INC5.title, INC5.tab), ("incentive_2027_1", "Incentive 1", "2027-intake-01"))
        self.assertEqual((INC5.university, INC5.universities), ("Callum and Matthews", ("UCLAN", "ARU", "UOGM")))
        self.assertEqual((INC5.intake_year, INC5.months, INC5.qa_approved_from, INC5.triggers, INC5.source), (2027, (1, 2, 3), None, (4,), "Paid Ad"))
        self.assertEqual((INC5.team_target, INC5.rate, INC5.raised_rate), (50, 250, 500))
        self.assertTrue(INC5.has_chart)
        self.assertFalse(INC5.show_enrolled_list)

    def test_the_wording(self):
        self.assertEqual(INC5.intake_label, "January to March 2027")
        self.assertEqual(INC5.subject, "Callum and Matthews (UCLAN, ARU and UOGM)")
        self.assertEqual(INC5.description, "For ARU, UCLAN and UOGM, 4 Enrolled from Paid Ad lead sources only = \u00a3250 per student bonus. "
                                           "If 50 are enrolled into all 3 universities as a team from any source, the Paid Ad qualifying enrolments doubles to \u00a3500 per student.")

    def test_without_its_own_wording_the_rule_line_is_worked_out_from_the_rules(self):
        worked_out = replace(INC5, rule_text="")
        self.assertEqual(worked_out.description, "Callum and Matthews (UCLAN, ARU and UOGM) January to March 2027 intake Paid Ad applications whose QA has been approved. Triggered at 4 enrolments.")
        self.assertEqual(replace(INC4, rule_text="Say this.").description, "Say this.")

    def test_the_other_incentives_have_none_of_it_and_read_as_before(self):
        for inc in (INC, INC2, INC3, INC4):
            self.assertEqual((inc.universities, inc.intake_months, inc.source, inc.team_target, inc.rate, inc.rule_text), ((), (), None, 0, 0, ""), inc.key)
            self.assertEqual(inc.covered_universities, (inc.university,))
            self.assertNotIn("\u00a3", inc.description)
        self.assertEqual(INC.subject, "LSC")

    def test_the_intake_months_read_as_a_range_or_a_list(self):
        label = lambda months: Incentive("k", "T", "X", None, 2027, None, (1,), intake_months=months).intake_label
        self.assertEqual(label((1, 2, 3)), "January to March 2027")
        self.assertEqual(label((3, 1, 2)), "January to March 2027")
        self.assertEqual(label((1, 3)), "January and March 2027")
        self.assertEqual(label((1, 3, 5)), "January, March and May 2027")
        self.assertEqual(label((3,)), "March 2027")
        self.assertEqual(label(()), "2027")
        self.assertEqual(INC.intake_label, "November 2026")

    def test_two_universities_read_properly(self):
        self.assertEqual(Incentive("k", "T", "Group", 1, 2027, None, (2,), universities=("AAA", "BBB")).subject, "Group (AAA and BBB)")
        self.assertEqual(Incentive("k", "T", "Group", 1, 2027, None, (2,), universities=("AAA",)).subject, "Group (AAA)")


class Incentive2027QualifyingTests(unittest.TestCase):
    def codes(self, **kw):
        return {r["Student Code"] for r in qualifying_rows(incentive_5_sample(), INC5, **kw)}

    def test_paid_ad_applications_for_the_three_universities_in_january_to_march_2027(self):
        self.assertEqual(self.codes(), {"P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8", "P9", "P10", "P11"})

    def test_every_source_when_asked_for_the_team_count(self):
        self.assertEqual(self.codes(any_source=True), {"P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8", "P9", "P10", "P11", "T1", "T2", "T3"})

    def test_what_does_not_qualify_for_either(self):
        for any_source in (False, True):
            self.assertFalse(self.codes(any_source=any_source) & {"N1", "N2", "N3", "N4", "N5", "N6", "N7", "N8"}, any_source)

    def test_each_rule_on_its_own(self):
        base = a2027("B", "Zed")
        self.assertEqual(len(qualifying_rows([base], INC5)), 1)
        for change in ({"university": "UCL"}, {"intake": "April 2027"}, {"intake": "January 2026"}, {"qa": ""}, {"source": "Agent"}, {"source": None}):
            self.assertEqual(qualifying_rows([a2027("B", "Zed", **change)], INC5), [], change)
        for university in ("UCLAN", "ARU", "UOGM", "uclan", " Aru "):
            self.assertEqual(len(qualifying_rows([a2027("B", "Zed", university=university)], INC5)), 1, university)
        for intake in ("January 2027", "February 2027", "March 2027", "Jan 2027", "Mar 2027"):
            self.assertEqual(len(qualifying_rows([a2027("B", "Zed", intake=intake)], INC5)), 1, intake)


class Incentive2027BuildTests(unittest.TestCase):
    def setUp(self):
        self.built = build_incentive(incentive_5_sample(), INC5, FORECAST)

    def test_the_consultants_have_only_their_paid_applications_and_a_goal_of_4(self):
        by = {c["name"]: c for c in self.built["consultants"]}
        self.assertEqual(set(by), {"Zed", "Amy", "Unassigned"}, "Bea has no Paid Ad application")
        self.assertEqual((by["Zed"]["enrolled"], by["Zed"]["triggered"], by["Zed"]["target"], by["Zed"]["remaining"]), (4, True, 4, 0))
        self.assertEqual((by["Amy"]["enrolled"], by["Amy"]["triggered"], by["Amy"]["target"], by["Amy"]["remaining"]), (3, False, 4, 1))
        self.assertEqual((by["Unassigned"]["enrolled"], by["Unassigned"]["triggered"]), (1, False))

    def test_the_summary_counts_the_paid_applications_and_the_team_total_counts_everyones(self):
        summary = self.built["summary"]
        self.assertEqual((summary["enrolled"], summary["triggered"], summary["consultants"]), (8, 1, 3))
        self.assertEqual(summary["tiers"], [{"enrolments": 4, "consultants": 1}])
        self.assertEqual(summary["team"], {"enrolled": 10, "target": 50, "reached": False, "rate": 250})     # 8 Paid Ad, and T1 and T2 from other sources

    def test_the_team_total_is_the_same_whoever_is_in_the_chart(self):
        rows = [a2027(f"E{i}", f"C{i % 7}", source=("Paid Ad", "Agent", "", "Student Referral")[i % 4]) for i in range(49)]
        self.assertEqual(build_incentive(rows, INC5, FORECAST)["summary"]["team"], {"enrolled": 49, "target": 50, "reached": False, "rate": 250})
        built = build_incentive(rows + [a2027("E49", "Bea", source="Agent")], INC5, FORECAST)
        self.assertEqual(built["summary"]["team"], {"enrolled": 50, "target": 50, "reached": True, "rate": 500})
        self.assertEqual(built["summary"]["enrolled"], 13, "the 500 rate does not change who is in the Paid Ad chart")
        built = build_incentive(rows + [a2027("E49", "Bea", source="Agent")] * 5, INC5, FORECAST)
        self.assertEqual((built["summary"]["team"]["enrolled"], built["summary"]["team"]["rate"]), (54, 500))

    def test_only_enrolled_applications_count_towards_the_team_total(self):
        rows = [a2027(f"E{i}", "Zed") for i in range(40)] + [a2027(f"L{i}", "Zed", status) for i, status in enumerate(["10-Lost", "05-Assessment", "08-Pre-Enrolled"] * 5)]
        self.assertEqual(build_incentive(rows, INC5, FORECAST)["summary"]["team"]["enrolled"], 40)

    def test_what_is_outside_the_universities_months_or_qa_does_not_count_towards_the_team_total(self):
        rows = [a2027(f"E{i}", "Zed", **change) for i, change in enumerate([{"university": "UCL"}, {"intake": "April 2027"}, {"intake": "March 2026"}, {"qa": ""}] * 15)]
        self.assertEqual(build_incentive(rows, INC5, FORECAST)["summary"]["team"]["enrolled"], 0)

    def test_a_triggered_consultant_at_exactly_4(self):
        for enrolled, expected in ((0, False), (3, False), (4, True), (5, True)):
            built = build_incentive([a2027(f"E{i}", "Zed") for i in range(enrolled)] + [a2027("A", "Zed", "05-Assessment")], INC5, FORECAST)
            self.assertEqual(built["consultants"][0]["triggered"], expected, enrolled)
            self.assertEqual(built["consultants"][0]["remaining"], max(4 - enrolled, 0), enrolled)

    def test_the_other_incentives_have_no_team_total(self):
        for inc in (INC, INC2, INC3, INC4):
            self.assertIsNone(build_incentive([app("X", "Mel")], inc, FORECAST)["summary"]["team"], inc.key)

    def test_nothing_in_the_chart_for_a_consultant_with_only_other_sources(self):
        built = build_incentive([a2027("T", "Bea", source="Agent")] * 3, INC5, FORECAST)
        self.assertEqual((built["consultants"], built["summary"]["team"]["enrolled"]), ([], 3))


class Incentive2027PageTests(PageBase):
    ROWS = [row(**{"Student Code": r["Student Code"], "Student Name": r["Student Name"], "Application Status": RAW[r["Status"]], "Counsellor": r["Consultant"] or "",
                   "University Name": r["University Name"], "Intake": r["Intake"], "QA Signed Off": uk(r["QA Passed"]), "Admission Officer": "Mo Y",
                   "Lead Source": r.get("Source", "")}) for r in incentive_5_sample()]

    def html(self, query="?tab=2027-intake-01", client=None):
        return self.page(client, query)

    def test_the_heading_rule_and_cards(self):
        html, context = self.html()
        self.assertIn("Incentive 1 &mdash; Callum and Matthews January to March 2027", html)
        self.assertIn("For ARU, UCLAN and UOGM, 4 Enrolled from Paid Ad lead sources only = \u00a3250 per student bonus. "
                      "If 50 are enrolled into all 3 universities as a team from any source, the Paid Ad qualifying enrolments doubles to \u00a3500 per student.", html)
        self.assertNotIn("everyone, any lead source", html)
        built = context["incentives"][0]
        self.assertEqual(built["incentive"].key, "incentive_2027_1")
        self.assertIn("Triggered at", html)
        self.assertIn("<strong>4 enrolments</strong>", html)
        self.assertIn("<span>Consultants triggered</span>\n                                <strong>1 of 3</strong>", html)

    def test_the_team_total_card_shows_progress_and_the_current_rate(self):
        html, _ = self.html()
        card = html[html.index("Team Total"):]
        card = card[:card.index("</section>")]
        self.assertIn("<span>Enrolled, any lead source</span>\n                                <strong>10 of 50</strong>", card)
        self.assertIn("<span>Rate per enrolled Paid Ad student</span>\n                                <strong>&pound;250</strong>", card)
        self.assertNotIn("&pound;500", card)

    def test_the_chart_is_the_paid_ad_applications_by_consultant(self):
        html, context = self.html()
        totals = {r["name"]: r["total"] for g in context["incentives"][0]["chart_groups"] for r in g["rows"]}
        self.assertEqual(totals, {"Zed": 5, "Amy": 5, "Unassigned": 1}, "Amy's Lost and Pre-Enrolled ones are drawn; T1 to T3 are not Paid Ad")
        self.assertIn("incentive-pill", html)
        self.assertIn("4 / 4", html)
        self.assertIn("3 / 4", html)
        self.assertIn("1 / 4", html)
        self.assertIn("Enrolled shows each Consultant's enrolments against the 4 needed.", html)

    def test_it_is_only_on_its_own_tab(self):
        html, context = self.html("")
        self.assertNotIn("Callum and Matthews", html)
        self.assertNotIn("Team Total", html)
        self.assertNotIn("incentive_2027_1", html)

    def test_no_pay_totals_are_worked_out(self):
        html, _ = self.html()
        self.assertEqual(sorted(set(re.findall(r"&pound;[\d,]+", html))), ["&pound;250"])
        for word in ("payout", "Payout", "owed", "earned"):
            self.assertNotIn(word, html)


class Incentive2027TeamTargetPageTests(PageBase):
    ROWS = [row(**{"Student Code": f"E{i}", "Student Name": f"Student E{i}", "Application Status": "Enrolled", "Counsellor": f"C{i % 5}", "University Name": "UCLAN",
                   "Intake": "February 2027", "QA Signed Off": uk("2026-10-15"), "Admission Officer": "Mo Y", "Lead Source": ("Paid Ad", "Agent")[i % 2]}) for i in range(50)]

    def test_at_50_everyone_the_rate_is_500(self):
        html, context = self.page(query="?tab=2027-intake-01")
        self.assertEqual(context["incentives"][0]["summary"]["team"], {"enrolled": 50, "target": 50, "reached": True, "rate": 500})
        self.assertIn("<strong>50 of 50</strong>", html)
        self.assertIn("<strong>&pound;500</strong>", html)
        card = html[html.index("Team Total"):]
        self.assertNotIn("<strong>&pound;250</strong>", card[:card.index("</section>")])
        self.assertEqual(context["incentives"][0]["summary"]["enrolled"], 25, "the chart is still the Paid Ad ones")


class Incentive2027RecordsTests(PageBase):
    ROWS = Incentive2027PageTests.ROWS

    def codes(self, consultant, group):
        r = self.records(consultant, group, "incentive_2027_1")
        self.assertEqual(r.status_code, 200)
        return sorted(x["code"] for x in r.get_json()["records"])

    def test_a_piece_lists_the_paid_ad_applications_it_counts_and_no_others(self):
        self.assertEqual(self.codes("Zed", "enrolled_this_intake"), ["P1", "P2", "P3", "P4"])
        self.assertEqual(self.codes("Zed", "pending_assessment"), ["P5"])
        self.assertEqual(self.codes("Amy", "enrolled_this_intake"), ["P10", "P6", "P7"])
        self.assertEqual(self.codes("Amy", "pending_enrolment"), ["P9"])
        self.assertEqual(self.codes("Amy", "lost"), ["P8"])
        self.assertEqual(self.codes("Bea", "pending_assessment"), [], "T3 is not Paid Ad")

    def test_every_piece_lists_exactly_the_number_it_shows(self):
        _, context = self.page(query="?tab=2027-intake-01")
        built = context["incentives"][0]
        for group in built["chart_groups"]:
            for row_ in group["rows"]:
                for seg in row_["segments"]:
                    self.assertEqual(len(self.codes(row_["name"], seg["key"])), seg["count"], (row_["name"], seg["key"]))

    def test_the_page_tab_in_the_address_is_harmless_to_the_window(self):
        r = self.full.get("/incentives/records?" + urlencode({"incentive": "incentive_2027_1", "consultant": "Zed", "group": "enrolled_this_intake", "tab": "2027-intake-01"}))
        self.assertEqual(len(r.get_json()["records"]), 4)


class IncentiveCardTitleTests(PageBase):
    def test_the_box_is_called_consultant_incentive_on_every_incentive_that_has_one(self):
        for query, count in (("", 3), ("?tab=2027-intake-01", 1)):          # Incentive 4 has no chart, so no box
            html, _ = self.page(query=query)
            self.assertEqual(html.count('<div class="summary-card-title">Consultant Incentive</div>'), count, query)
            self.assertNotIn('<div class="summary-card-title">Incentive</div>', html, query)
            self.assertEqual(html.count('<div class="summary-card-title">Overall</div>'), count, query)


class TabsTests(PageBase):
    def tab_links(self, html):
        row = html[html.index('<div class="tabs">'):]
        row = row[:row.index("</div>")]
        return re.findall(r'<a href="([^"]*)"\s+class="tab-link( active)?">([^<]*)</a>', row)

    def test_the_tabs_are_2026_and_2027_intake_01_and_the_2026_incentives_are_on_the_first(self):
        self.assertEqual(INCENTIVE_TABS, (("2026", "2026"), ("2027-intake-01", "2027 Intake 01")))
        self.assertEqual([i.key for i in INCENTIVES if i.tab == "2026"], ["incentive_1", "incentive_2", "incentive_3", "incentive_4"])
        self.assertEqual([i.key for i in INCENTIVES if i.tab == "2027-intake-01"], ["incentive_2027_1"])
        self.assertTrue(all(i.tab in dict(INCENTIVE_TABS) for i in INCENTIVES))

    def test_the_page_opens_on_2026_with_all_four_incentives(self):
        html, context = self.page()
        self.assertEqual(context["selected_tab"], "2026")
        self.assertEqual([b["incentive"].key for b in context["incentives"]], ["incentive_1", "incentive_2", "incentive_3", "incentive_4"])
        self.assertEqual(self.tab_links(html), [("/incentives", " active", "2026"), ("/incentives?tab=2027-intake-01", "", "2027 Intake 01")])
        self.assertIn("Incentive 1 &mdash;", html)
        self.assertNotIn("No incentives have been added", html)

    def test_the_2027_intake_01_tab_has_its_own_incentive_and_none_of_the_2026_ones(self):
        html, context = self.page(query="?tab=2027-intake-01")
        self.assertEqual(context["selected_tab"], "2027-intake-01")
        self.assertEqual([b["incentive"].key for b in context["incentives"]], ["incentive_2027_1"])
        self.assertEqual(self.tab_links(html), [("/incentives", "", "2026"), ("/incentives?tab=2027-intake-01", " active", "2027 Intake 01")])
        self.assertIn("Incentive 1 &mdash; Callum and Matthews January to March 2027", html)
        for text in ("Incentive 2 &mdash;", "Incentive 4 &mdash;", "No incentives have been added", "LSC November 2026"):
            self.assertNotIn(text, html, text)

    def test_a_tab_with_no_incentives_says_so(self):
        with mock.patch.object(app_module, "INCENTIVES", tuple(i for i in INCENTIVES if i.tab == "2026")):
            html, context = self.page(query="?tab=2027-intake-01")
        self.assertEqual((context["selected_tab"], context["incentives"]), ("2027-intake-01", []))
        self.assertIn("No incentives have been added for 2027 Intake 01 yet.", html)
        for text in ("Incentive 1 &mdash;", "Incentive 4 &mdash;", "summary-card", "incentive-rule"):
            self.assertNotIn(text, html, text)

    def test_the_2026_tab_says_nothing_about_missing_incentives(self):
        html, _ = self.page(query="?tab=2026")
        self.assertNotIn("No incentives have been added", html)
        self.assertIn("Incentive 4 &mdash;", html)

    def test_a_tab_that_is_not_there_falls_back_to_2026(self):
        for query in ("?tab=2028", "?tab=", "?tab=2027-intake-02", "?tab=%3Cb%3E", "?tab=2026&tab=x"):
            html, context = self.page(query=query)
            self.assertEqual(context["selected_tab"], "2026", query)
            self.assertEqual(len(context["incentives"]), 4, query)
            self.assertEqual(self.tab_links(html)[0][1], " active", query)

    def test_a_new_incentive_shows_on_its_own_tab_and_nowhere_else(self):
        new = replace(INC, key="incentive_5", title="Incentive 5", university="LSC", intake_year=2027, tab="2027-intake-01")
        with mock.patch.object(app_module, "INCENTIVES", (*INCENTIVES, new)):
            html, context = self.page(query="?tab=2027-intake-01")
            self.assertEqual([b["incentive"].key for b in context["incentives"]], ["incentive_2027_1", "incentive_5"])
            self.assertIn("Incentive 5 &mdash; LSC November 2027", html)
            self.assertNotIn("Incentive 4 &mdash;", html)
            self.assertNotIn("No incentives have been added", html)
            html, context = self.page()
            self.assertEqual([b["incentive"].key for b in context["incentives"]], ["incentive_1", "incentive_2", "incentive_3", "incentive_4"])
            self.assertNotIn("Incentive 5", html)

    def test_the_tabs_are_open_to_every_role_as_the_page_is(self):
        for role in ("full", "admissions", "consultants", "marketing"):
            client = self._client_logged_in_as(role)
            html, context = self.page(client, "?tab=2027-intake-01")
            self.assertEqual([b["incentive"].key for b in context["incentives"]], ["incentive_2027_1"], role)
            self.assertIn("Callum and Matthews", html, role)


class NoDatasetTests(IsolatedAppTestCase):
    def test_the_page_says_there_is_no_dataset(self):
        full = self._client_logged_in_as("full")
        html = full.get("/incentives").get_data(as_text=True)
        self.assertIn("No active dataset yet.", html)
        self.assertNotIn("tab-link", html)
        self.assertNotIn("Incentive 1 &mdash;", html)


if __name__ == "__main__":
    unittest.main()
