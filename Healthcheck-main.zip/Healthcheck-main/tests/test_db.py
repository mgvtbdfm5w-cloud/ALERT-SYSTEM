import json
import os
import shutil
import sqlite3
import tempfile
import time
import unittest
from pathlib import Path

from db import (
    ACTIVE_DATASET_RETENTION_LIMIT,
    cleanup_orphaned_uploads,
    get_active_dataset_row,
    load_active_dataset,
    prune_active_dataset_table,
    _resolve_within_uploads_dir,
)


class ActiveDatasetHelperTests(unittest.TestCase):
    """Uses an isolated in-memory SQLite connection - never touches the
    real application database."""

    def setUp(self):
        self.conn = sqlite3.connect(":memory:")
        self.conn.row_factory = sqlite3.Row
        self.conn.execute(
            """
            CREATE TABLE active_dataset (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                original_filename TEXT NOT NULL,
                stored_filename TEXT NOT NULL,
                uploaded_at TEXT NOT NULL,
                row_count INTEGER,
                data_json TEXT
            )
            """
        )
        self.conn.commit()

    def tearDown(self):
        self.conn.close()

    def _insert(self, data_json, uploaded_at="2026-08-01T10:00:00"):
        self.conn.execute(
            "INSERT INTO active_dataset (original_filename, stored_filename, uploaded_at, "
            "row_count, data_json) VALUES (?, ?, ?, ?, ?)",
            ("file.xlsx", "stored.xlsx", uploaded_at, 1, data_json),
        )
        self.conn.commit()

    def test_no_dataset_returns_none_and_empty_list(self):
        dataset, rows = load_active_dataset(self.conn)
        self.assertIsNone(dataset)
        self.assertEqual(rows, [])

    def test_get_active_dataset_row_returns_none_when_empty(self):
        self.assertIsNone(get_active_dataset_row(self.conn))

    def test_valid_dataset_returns_row_and_parsed_rows(self):
        self._insert(json.dumps([{"Student Code": "S001"}]))
        dataset, rows = load_active_dataset(self.conn)
        self.assertIsNotNone(dataset)
        self.assertEqual(rows, [{"Student Code": "S001"}])

    def test_returns_the_most_recently_inserted_row(self):
        self._insert(json.dumps([{"Student Code": "OLD"}]), uploaded_at="2026-08-01T10:00:00")
        self._insert(json.dumps([{"Student Code": "NEW"}]), uploaded_at="2026-08-02T10:00:00")
        dataset, rows = load_active_dataset(self.conn)
        self.assertEqual(rows, [{"Student Code": "NEW"}])

    def test_corrupted_json_does_not_raise_and_returns_empty_rows(self):
        self._insert("{not valid json")
        with self.assertLogs("db", level="ERROR"):
            dataset, rows = load_active_dataset(self.conn)
        # Metadata is still returned even though the rows couldn't be parsed.
        self.assertIsNotNone(dataset)
        self.assertEqual(rows, [])

    def test_get_active_dataset_row_never_parses_json(self):
        # Confirms the metadata-only helper doesn't do unnecessary work -
        # even badly malformed JSON must not raise here, since it's never
        # touched.
        self._insert("{not valid json")
        dataset = get_active_dataset_row(self.conn)
        self.assertIsNotNone(dataset)
        self.assertEqual(dataset["data_json"], "{not valid json")


class PruneActiveDatasetTableTests(unittest.TestCase):
    """prune_active_dataset_table() - the keep-latest-N retention rule
    behind save_active_dataset()/save_active_leads_dataset() (Finding 6's
    automatic-pruning fix). Exercised directly via raw inserts against
    both real table shapes it supports, rather than through the full
    upload pipeline, so these tests stay fast and focused on the pruning
    rule itself - processing.py's/leads.py's own tests cover it wired
    into the real save functions end-to-end."""

    def setUp(self):
        self.conn = None
        self._fresh_tables()

    def tearDown(self):
        self.conn.close()

    def _fresh_tables(self):
        """(Re)create both tables on a brand new in-memory connection,
        closing whichever connection this test was previously using - each
        retention scenario below needs to start from a clean, empty table
        rather than accumulating rows across scenarios in the same test."""
        if self.conn is not None:
            self.conn.close()
        self.conn = sqlite3.connect(":memory:")
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(
            """
            CREATE TABLE active_dataset (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                original_filename TEXT NOT NULL,
                stored_filename TEXT NOT NULL,
                uploaded_at TEXT NOT NULL,
                row_count INTEGER,
                data_json TEXT
            );
            CREATE TABLE active_leads_dataset (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                original_filename TEXT NOT NULL,
                stored_filename TEXT NOT NULL,
                uploaded_at TEXT NOT NULL,
                row_count INTEGER,
                columns_json TEXT,
                data_json TEXT
            );
            """
        )
        self.conn.commit()

    def _insert(self, table_name, n=1):
        """Insert n new rows into table_name, returning the new ids in
        insertion order (oldest first)."""
        ids = []
        for _ in range(n):
            if table_name == "active_leads_dataset":
                cur = self.conn.execute(
                    "INSERT INTO active_leads_dataset "
                    "(original_filename, stored_filename, uploaded_at, row_count, columns_json, data_json) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    ("file.xlsx", "stored.xlsx", "2026-08-01T10:00:00", 1, "[]", "[]"),
                )
            else:
                cur = self.conn.execute(
                    "INSERT INTO active_dataset "
                    "(original_filename, stored_filename, uploaded_at, row_count, data_json) "
                    "VALUES (?, ?, ?, ?, ?)",
                    ("file.xlsx", "stored.xlsx", "2026-08-01T10:00:00", 1, "[]"),
                )
            ids.append(cur.lastrowid)
        self.conn.commit()
        return ids

    def _ids(self, table_name):
        return [row["id"] for row in self.conn.execute(f"SELECT id FROM {table_name} ORDER BY id")]

    def test_one_to_four_rows_all_retained(self):
        for table in ("active_dataset", "active_leads_dataset"):
            with self.subTest(table=table):
                for n in range(1, ACTIVE_DATASET_RETENTION_LIMIT):
                    self._fresh_tables()
                    ids = self._insert(table, n)
                    prune_active_dataset_table(self.conn, table)
                    self.conn.commit()
                    self.assertEqual(self._ids(table), ids)

    def test_exactly_the_limit_all_retained(self):
        for table in ("active_dataset", "active_leads_dataset"):
            with self.subTest(table=table):
                self._fresh_tables()
                ids = self._insert(table, ACTIVE_DATASET_RETENTION_LIMIT)
                prune_active_dataset_table(self.conn, table)
                self.conn.commit()
                self.assertEqual(self._ids(table), ids)

    def test_one_over_the_limit_removes_only_the_oldest(self):
        for table in ("active_dataset", "active_leads_dataset"):
            with self.subTest(table=table):
                self._fresh_tables()
                ids = self._insert(table, ACTIVE_DATASET_RETENTION_LIMIT + 1)
                prune_active_dataset_table(self.conn, table)
                self.conn.commit()
                self.assertEqual(self._ids(table), ids[1:])

    def test_repeated_pruning_never_exceeds_the_limit_and_newest_always_survives(self):
        for table in ("active_dataset", "active_leads_dataset"):
            with self.subTest(table=table):
                self._fresh_tables()
                last_id = None
                for _ in range(ACTIVE_DATASET_RETENTION_LIMIT * 3):
                    last_id = self._insert(table, 1)[0]
                    prune_active_dataset_table(self.conn, table)
                    self.conn.commit()
                    self.assertLessEqual(len(self._ids(table)), ACTIVE_DATASET_RETENTION_LIMIT)
                self.assertIn(last_id, self._ids(table))

    def test_unsupported_table_name_raises(self):
        with self.assertRaises(ValueError):
            prune_active_dataset_table(self.conn, "some_other_table")


class CleanupOrphanedUploadsTests(unittest.TestCase):
    """cleanup_orphaned_uploads() - the filesystem half of Finding 6/7's
    retention policy: delete a managed upload file once it's no longer
    referenced by any row retained in active_dataset or
    active_leads_dataset. Uses a real temporary directory (never the real
    uploads/ folder) alongside an isolated in-memory SQLite connection."""

    def setUp(self):
        self.tmp_dir = Path(tempfile.mkdtemp(prefix="gsp_uploads_test_"))
        self.conn = sqlite3.connect(":memory:")
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(
            """
            CREATE TABLE active_dataset (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                original_filename TEXT NOT NULL,
                stored_filename TEXT NOT NULL,
                uploaded_at TEXT NOT NULL,
                row_count INTEGER,
                data_json TEXT
            );
            CREATE TABLE active_leads_dataset (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                original_filename TEXT NOT NULL,
                stored_filename TEXT NOT NULL,
                uploaded_at TEXT NOT NULL,
                row_count INTEGER,
                columns_json TEXT,
                data_json TEXT
            );
            """
        )
        self.conn.commit()

    def tearDown(self):
        self.conn.close()
        shutil.rmtree(self.tmp_dir, ignore_errors=True)

    def _touch(self, name, age_seconds=24 * 60 * 60):
        """Create `name`, last modified `age_seconds` ago. Old by default:
        these tests are about WHICH files count as orphans; the minimum-age
        guard for recent files is covered in test_upload_cleanup_age.py."""
        path = self.tmp_dir / name
        path.write_text("")
        modified = time.time() - age_seconds
        os.utime(path, (modified, modified))

    def _insert(self, table, stored_filename):
        if table == "active_leads_dataset":
            self.conn.execute(
                "INSERT INTO active_leads_dataset "
                "(original_filename, stored_filename, uploaded_at, row_count, columns_json, data_json) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                ("x.xlsx", stored_filename, "2026-09-01T09:00:00", 0, "[]", "[]"),
            )
        else:
            self.conn.execute(
                "INSERT INTO active_dataset "
                "(original_filename, stored_filename, uploaded_at, row_count, data_json) "
                "VALUES (?, ?, ?, ?, ?)",
                ("x.xlsx", stored_filename, "2026-09-01T09:00:00", 0, "[]"),
            )
        self.conn.commit()

    def _remaining(self):
        return {p.name for p in self.tmp_dir.iterdir()}

    def test_files_referenced_by_retained_applications_rows_are_preserved(self):
        self._insert("active_dataset", "20260901090000_a.xlsx")
        self._touch("20260901090000_a.xlsx")

        cleanup_orphaned_uploads(self.conn, self.tmp_dir)

        self.assertIn("20260901090000_a.xlsx", self._remaining())

    def test_files_referenced_by_retained_leads_rows_are_preserved(self):
        self._insert("active_leads_dataset", "leads_20260901090000_a.xlsx")
        self._touch("leads_20260901090000_a.xlsx")

        cleanup_orphaned_uploads(self.conn, self.tmp_dir)

        self.assertIn("leads_20260901090000_a.xlsx", self._remaining())

    def test_current_active_applications_file_is_preserved(self):
        # The "current" row is simply the highest-id retained row - no
        # special-casing needed beyond the general allow-list, since it's
        # always one of the rows the DB itself still has.
        self._insert("active_dataset", "20260901090000_old.xlsx")
        self._insert("active_dataset", "20260901100000_current.xlsx")
        self._touch("20260901090000_old.xlsx")
        self._touch("20260901100000_current.xlsx")

        cleanup_orphaned_uploads(self.conn, self.tmp_dir)

        self.assertIn("20260901100000_current.xlsx", self._remaining())

    def test_orphaned_managed_applications_uploads_are_deleted(self):
        self._insert("active_dataset", "20260901100000_current.xlsx")
        self._touch("20260901100000_current.xlsx")
        self._touch("20260801090000_orphan.xlsx")  # not referenced by any row

        deleted = cleanup_orphaned_uploads(self.conn, self.tmp_dir)

        self.assertEqual(deleted, ["20260801090000_orphan.xlsx"])
        self.assertNotIn("20260801090000_orphan.xlsx", self._remaining())
        self.assertIn("20260901100000_current.xlsx", self._remaining())

    def test_orphaned_managed_leads_uploads_are_deleted(self):
        self._insert("active_leads_dataset", "leads_20260901100000_current.xlsx")
        self._touch("leads_20260901100000_current.xlsx")
        self._touch("leads_20260801090000_orphan.xlsx")

        deleted = cleanup_orphaned_uploads(self.conn, self.tmp_dir)

        self.assertEqual(deleted, ["leads_20260801090000_orphan.xlsx"])
        self.assertNotIn("leads_20260801090000_orphan.xlsx", self._remaining())

    def test_gitkeep_is_preserved(self):
        self._touch(".gitkeep")

        cleanup_orphaned_uploads(self.conn, self.tmp_dir)

        self.assertIn(".gitkeep", self._remaining())

    def test_unknown_unexpected_files_are_preserved(self):
        for name in ("readme.txt", "notes.xlsx", "20260801_missing_seconds.xlsx", "random_file"):
            self._touch(name)

        cleanup_orphaned_uploads(self.conn, self.tmp_dir)

        remaining = self._remaining()
        for name in ("readme.txt", "notes.xlsx", "20260801_missing_seconds.xlsx", "random_file"):
            self.assertIn(name, remaining)

    def test_directories_inside_uploads_are_preserved(self):
        # Give the directory a name that would otherwise match the managed
        # upload pattern, to confirm it's the is_file() check (not just the
        # regex) protecting it.
        (self.tmp_dir / "20260801090000_a_directory.xlsx").mkdir()

        cleanup_orphaned_uploads(self.conn, self.tmp_dir)

        self.assertTrue((self.tmp_dir / "20260801090000_a_directory.xlsx").is_dir())

    def test_path_traversal_style_filename_cannot_resolve_outside_uploads_dir(self):
        outside_dir = Path(tempfile.mkdtemp(prefix="gsp_outside_test_"))
        try:
            traversal_name = f"../{outside_dir.name}/20260801090000_evil.xlsx"
            self.assertIsNone(_resolve_within_uploads_dir(self.tmp_dir, traversal_name))
            self.assertIsNone(_resolve_within_uploads_dir(self.tmp_dir, "../../../etc/passwd"))
        finally:
            shutil.rmtree(outside_dir, ignore_errors=True)

    def test_cleanup_never_raises_even_if_the_uploads_dir_is_missing(self):
        missing_dir = self.tmp_dir / "does_not_exist"
        # Must not raise - a cleanup problem must never surface as (or
        # cause) a failed upload.
        deleted = cleanup_orphaned_uploads(self.conn, missing_dir)
        self.assertEqual(deleted, [])


if __name__ == "__main__":
    unittest.main()
