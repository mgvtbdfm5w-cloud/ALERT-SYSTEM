"""The Weekly Report (and its PDF) has been removed completely: no page, no
route, no code, and no PDF library among the app's dependencies."""

import ast
import importlib
import re
import unittest
from pathlib import Path

from authorization import ENDPOINT_ROLES
from tests.flask_test_support import IsolatedAppTestCase, app_module, extract_token

ROOT = Path(__file__).resolve().parent.parent


class NoWeeklyReportTests(IsolatedAppTestCase):
    def setUp(self):
        super().setUp()
        self.full = self._client_logged_in_as("full")

    def test_the_route_and_its_policy_entry_are_gone(self):
        self.assertNotIn("weekly_report", {rule.endpoint for rule in app_module.app.url_map.iter_rules()})
        self.assertNotIn("weekly_report", ENDPOINT_ROLES)
        for role in ("full", "admissions", "consultants", "marketing"):
            self.assertEqual(self._client_logged_in_as(role).get("/admin/weekly-report").status_code, 404, role)

    def test_the_report_code_is_gone_from_the_app(self):
        for name in ("build_weekly_report_pdf", "weekly_report_export_filename", "_build_weekly_report_context", "weekly_report"):
            self.assertFalse(hasattr(app_module, name), name)
        with self.assertRaises(ImportError):
            importlib.import_module("weekly_report")
        self.assertFalse((ROOT / "weekly_report.py").exists())

    def test_no_page_links_to_or_mentions_the_weekly_report(self):
        for role in ("full", "admissions", "consultants", "marketing"):
            client = self._client_logged_in_as(role)
            for path in ("/admin", "/company-dashboard", "/leads-dashboard", "/consultants", "/allocation"):
                html = client.get(path).get_data(as_text=True)
                for text in ("Weekly Report", "weekly-report", "Weekly Management Report"):
                    self.assertNotIn(text, html, (role, path, text))

    def test_the_rest_of_the_admin_page_still_works(self):
        html = self.full.get("/admin").get_data(as_text=True)
        for text in ('action="/upload"', 'action="/leads/upload"', "Enrolled - Current Intake Export", "Lookup Tables"):
            self.assertIn(text, html)


class NoPdfLibraryTests(unittest.TestCase):
    PDF_PACKAGES = ("reportlab", "pillow", "charset-normalizer")

    def test_the_pdf_libraries_are_no_longer_dependencies(self):
        for name in ("requirements.txt", "requirements-dev.txt"):
            pinned = {re.split(r"[=<>~! ]", line.strip(), 1)[0].lower().replace("_", "-")
                      for line in (ROOT / name).read_text().splitlines()
                      if line.strip() and not line.startswith(("#", "-r"))}
            for package in self.PDF_PACKAGES:
                self.assertNotIn(package, pinned, (name, package))

    def test_no_app_code_imports_reportlab_or_pil(self):
        offenders = []
        for path in ROOT.glob("*.py"):
            for node in ast.walk(ast.parse(path.read_text())):
                modules = [a.name for a in node.names] if isinstance(node, ast.Import) else [node.module or ""] if isinstance(node, ast.ImportFrom) else []
                offenders += [f"{path.name}: {m}" for m in modules if m.split(".")[0] in ("reportlab", "PIL")]
        self.assertEqual(offenders, [])

    def test_the_runtime_pins_still_cover_what_the_app_needs(self):
        text = (ROOT / "requirements.txt").read_text().lower()
        for package in ("flask==", "flask-wtf==", "gunicorn==", "openpyxl==", "werkzeug==", "wtforms=="):
            self.assertIn(package, text, package)


if __name__ == "__main__":
    unittest.main()
