"""Phone Number on the two Enrolled downloads, straight before Email.

The number comes from the Applications workbook's "Mobile No" column; it is
kept on the stored row but deliberately NOT added to the Current Data / full
Applications download columns."""

import io
import unittest

import openpyxl

import enrolled_export
import enrolled_intake_export
import processing
from tests.flask_test_support import IsolatedAppTestCase, extract_token
from tests.test_upload_atomicity import REQUIRED_IMPORT_COLUMNS, row as app_row


def workbook(rows, mobile_column=True):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Import"
    extra = ["Email ID"] + (["Mobile No"] if mobile_column else []) + ["Enrolment Confirmed Date"]
    ws.append(REQUIRED_IMPORT_COLUMNS + extra)
    for r in rows:
        ws.append([r.get(c, "") for c in REQUIRED_IMPORT_COLUMNS] + [r.get(c, "") for c in extra])
    sheet = wb.create_sheet("Lookups")
    sheet.append(["Status", "Mapped", None, "Office", "Mapped", None, "SalesOffice", "Mapped"])
    sheet.cell(2, 1, "Enrolled")
    sheet.cell(2, 2, "09-Enrolled")
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def student(code, **fields):
    base = {"Student Code": code, "Student Name": f"Name {code}", "Application Status": "Enrolled", "Intake": "September 2026",
            "University Name": "Uni One", "Course Name": "Course A", "Counsellor": "Mel X", "Email ID": f"{code.lower()}@example.com",
            "Enrolment Confirmed Date": "01/09/2026"}
    base.update(fields)
    return app_row(**base)


ROWS = [
    student("E1", **{"Mobile No": "07476923185"}),             # leading zero must survive
    student("E2", **{"Mobile No": "+447990188166"}),           # leading + must survive
    student("E3", **{"Mobile No": 447930207241}),              # a numeric cell, written without ".0"
    student("E4", **{"Mobile No": 447930207242.0}),
    student("E5", **{"Mobile No": "  07700 900123  "}),        # trimmed, inner spacing kept
    student("E6", **{"Mobile No": ""}),                        # none given
]
EXPECTED = {"E1": "07476923185", "E2": "+447990188166", "E3": "447930207241", "E4": "447930207242", "E5": "07700 900123"}


class PhoneNumberTests(unittest.TestCase):
    def test_phone_text(self):
        self.assertEqual([processing._phone_text(v) for v in (None, "", "  ", "0747", 447.0, 447, " +44 7 ", 4.5)],
                         ["", "", "", "0747", "447", "447", "+44 7", "4.5"])

    def test_it_is_not_a_current_data_or_full_download_column(self):
        self.assertNotIn("Phone Number", processing.COLUMNS)

    def test_phone_number_sits_straight_before_email_in_both_downloads(self):
        for columns in (enrolled_export.EXPORT_COLUMNS, enrolled_intake_export.EXPORT_COLUMNS):
            self.assertEqual(columns.index("Phone Number") + 1, columns.index("Email"))
        self.assertEqual(enrolled_export.EXPORT_COLUMNS,
                         ["Consultant Name", "PES Code", "Student Name", "Student Number", "Location", "Sub Source", "Phone Number", "Email", "Course", "Enrolled Date"])
        self.assertEqual(enrolled_intake_export.EXPORT_COLUMNS[:5], ["Student Code", "Student Name", "Student Number", "Phone Number", "Email"])

    def test_a_row_without_a_phone_number_key_still_exports_with_a_blank_cell(self):
        row = {"Student Code": "X", "Student Name": "N", "University Name": "U", "Consultant": "C", "Email": "x@e.com"}
        for build, sheet in ((enrolled_export.build_enrolled_export, "U"), (enrolled_intake_export.build_enrolled_current_intake_export, enrolled_intake_export.SHEET_TITLE)):
            ws = openpyxl.load_workbook(build([row]))[sheet]
            header = [c.value for c in ws[1]]
            values = [c.value for c in ws[2]]
            self.assertIsNone(values[header.index("Phone Number")])
            self.assertEqual(values[header.index("Email")], "x@e.com")


class EndToEndTests(IsolatedAppTestCase):
    def setUp(self):
        super().setUp()
        self.full = self._client_logged_in_as("full")

    def token(self):
        return extract_token(self.full.get("/login").get_data(as_text=True))

    def upload(self, data):
        r = self.full.post("/upload", data={"csrf_token": self.token(), "excel_file": (io.BytesIO(data), "f.xlsx")}, content_type="multipart/form-data")
        self.assertEqual(r.status_code, 302)

    def sheet_rows(self, path, sheet=None):
        r = self.full.get(path)
        self.assertEqual(r.status_code, 200, path)
        wb = openpyxl.load_workbook(io.BytesIO(r.data))
        sheets = [wb[sheet]] if sheet else [wb[name] for name in wb.sheetnames]
        out = {}
        for ws in sheets:
            header = [c.value for c in ws[1]]
            for values in ws.iter_rows(min_row=2, values_only=True):
                rec = dict(zip(header, values))
                out[rec.get("PES Code") or rec.get("Student Code")] = rec
        return header, out

    def check(self, path, sheet=None):
        header, rows = self.sheet_rows(path, sheet)
        self.assertEqual(header.index("Phone Number") + 1, header.index("Email"), path)
        self.assertEqual({code: rec["Phone Number"] for code, rec in rows.items() if code != "E6"}, EXPECTED, path)
        self.assertFalse(rows["E6"]["Phone Number"])
        self.assertEqual({code: rec["Email"] for code, rec in rows.items()}, {f"E{i}": f"e{i}@example.com" for i in range(1, 7)}, path)

    def test_both_downloads_carry_the_phone_numbers_from_the_upload(self):
        self.upload(workbook(ROWS))
        self.check("/enrolled/export/intake-03?year=2026")
        self.check("/enrolled/export/current-intake", enrolled_intake_export.SHEET_TITLE)

    def test_reprocess_current_data_fills_them_in_too(self):
        self.upload(workbook(ROWS))
        r = self.full.post("/admin/reprocess", data={"csrf_token": self.token()})
        self.assertEqual(r.status_code, 302)
        self.check("/enrolled/export/intake-03?year=2026")

    def test_a_workbook_with_no_mobile_column_uploads_and_downloads_with_blank_phones(self):
        self.upload(workbook(ROWS, mobile_column=False))
        header, rows = self.sheet_rows("/enrolled/export/intake-03?year=2026")
        self.assertEqual(len(rows), 6)
        self.assertFalse(any(rec["Phone Number"] for rec in rows.values()))

    def test_phone_numbers_do_not_appear_on_the_current_data_page_or_full_download(self):
        self.upload(workbook(ROWS))
        self.assertNotIn("07476923185", self.full.get("/admin").get_data(as_text=True))
        r = self.full.get("/download")
        self.assertEqual(r.status_code, 200)
        wb = openpyxl.load_workbook(io.BytesIO(r.data))
        cells = {str(c.value) for ws in wb for row in ws.iter_rows() for c in row if c.value is not None}
        self.assertNotIn("07476923185", cells)
        self.assertNotIn("Phone Number", cells)


if __name__ == "__main__":
    unittest.main()
