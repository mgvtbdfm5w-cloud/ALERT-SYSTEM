"""The 90 Days page: leads created 90 or more days ago, in the Allocation
page's Office / Consultant chart.

Pure filter tests, then route tests through the real upload/lookups routes
with "today" pinned so the 90-day boundary is exact."""

import io
import re
import unittest
from datetime import date
from unittest import mock

from leads_dashboard import MIN_AGE_DAYS, filter_by_min_age_days
from tests.flask_test_support import IsolatedAppTestCase, app_module, extract_token
from tests.test_allocation import captured, lead, leads_book, rows_of

TODAY = date(2026, 10, 6)          # 90 days earlier is 2026-07-08


class FilterTests(unittest.TestCase):
    def created(self, *values):
        return [{"Creation Date": v, "n": i} for i, v in enumerate(values)]

    def test_exactly_ninety_days_old_counts_and_eighty_nine_does_not(self):
        rows = self.created("2026-07-08", "2026-07-09", "2026-07-07", "2026-10-06", "2026-01-01")
        self.assertEqual([r["n"] for r in filter_by_min_age_days(rows, TODAY)], [0, 2, 4])

    def test_the_threshold_is_ninety_days(self):
        self.assertEqual(MIN_AGE_DAYS, 90)

    def test_blank_missing_future_and_unreadable_dates_are_left_out(self):
        rows = self.created("", None, "garbage", "2026-10-20", "2099-01-01", date(2026, 7, 8))
        self.assertEqual([r["n"] for r in filter_by_min_age_days(rows, TODAY)], [5])

    def test_a_different_threshold_and_today_move_the_cut_off(self):
        rows = self.created("2026-09-06", "2026-09-07")
        self.assertEqual([r["n"] for r in filter_by_min_age_days(rows, TODAY, days=30)], [0])
        self.assertEqual([r["n"] for r in filter_by_min_age_days(rows, date(2026, 12, 6))], [0, 1])

    def test_the_input_is_not_modified_and_empty_is_fine(self):
        rows = self.created("2026-01-01")
        filter_by_min_age_days(rows, TODAY)
        self.assertEqual(rows, self.created("2026-01-01"))
        self.assertEqual(filter_by_min_age_days([], TODAY), [])


LEADS = [
    lead("A1", "Mel X", "08/07/2026"),                                    # exactly 90 days: shown
    lead("A2", "Mel X", "09/07/2026", source="Agent/Z"),                  # 89 days: not shown
    lead("A3", "Hannah Y", "07/07/2026", "Applied"),                      # 91 days: shown
    lead("A4", "Kian Q", "15/03/2026", "Enrolled Student", "Agent/Z"),    # old: shown
    lead("A5", "Raymond P", "01/01/2026", source="Inbound Call/Phone"),   # old, Group as Other: shown
    lead("A6", "", "10/04/2026"),                                         # old, nobody allocated: shown
    lead("A7", "Mel X", "06/10/2026"),                                    # today: not shown
    lead("A8", "Mel X", "20/10/2026"),                                    # future: not shown
    lead("A9", "Mel X", ""),                                              # no date: not shown
]


class NinetyDaysRouteTests(IsolatedAppTestCase):
    def setUp(self):
        super().setUp()
        self.full = self._client_logged_in_as("full")
        token = lambda: extract_token(self.full.get("/login").get_data(as_text=True))
        self.assertEqual(self.full.post("/leads/upload", data={"csrf_token": token(), "excel_file": (io.BytesIO(leads_book(LEADS)), "l.xlsx")},
                                        content_type="multipart/form-data").status_code, 302)
        for consultant, office, other in (("Mel", "OXF", False), ("Hannah", "OXF", False), ("Kian", "MAN", False), ("Raymond", "LON", True)):
            data = {"csrf_token": token(), "source_value": consultant, "mapped_value": office}
            if other:
                data["group_as_other"] = "on"
            self.assertEqual(self.full.post("/admin/lookups/sales_office/add", data=data).status_code, 302)
        patcher = mock.patch.object(app_module, "today_uk", return_value=TODAY)
        patcher.start()
        self.addCleanup(patcher.stop)

    def page(self, client=None):
        with captured() as rendered:
            r = (client or self.full).get("/ninety-days")
        self.assertEqual(r.status_code, 200)
        context = next(c for name, c in rendered if name == "ninety_days.html")
        return r.get_data(as_text=True), context

    def test_only_leads_ninety_days_or_older_are_shown_grouped_by_office_and_consultant(self):
        _, context = self.page()
        report = context["report"]
        self.assertEqual(rows_of(report), {"OXF": {"Mel": 1, "Hannah": 1}, "MAN": {"Kian": 1}, "LON": {"Other": 1}, "Unassigned": {"Unassigned": 1}})
        self.assertEqual(report["total"], 5)

    def test_every_stage_is_included_and_shown_in_the_bars(self):
        html, context = self.page()
        stages = {seg["stage"] for g in context["report"]["groups"] for r in g["rows"] for seg in r["segments"]}
        self.assertEqual(stages, {"01 - New Lead", "04 - Applied", "05 - Enrolled"})

    def test_the_page_draws_the_chart_in_the_allocation_style(self):
        html, _ = self.page()
        self.assertIn("<h2>Leads 90 Days or Older by Office and Consultant</h2>", html)
        for fragment in ('class="chart-office-group"', 'class="chart-office-label"', 'class="chart-segment"', 'class="chart-legend"'):
            self.assertIn(fragment, html)
        self.assertIn('<div class="chart-manager-name">Consultant</div>', html)
        drawn = {}
        for group in html.split('<div class="chart-office-group">')[1:]:
            label = re.search(r'chart-office-label">([^<]+)<', group).group(1)
            drawn[label] = {m.group(1): int(m.group(2)) for m in re.finditer(
                r'chart-manager-name">([^<]+)</div>.*?chart-col-total">(\d+)<', group, re.S)}
        self.assertEqual(drawn, {"OXF (2)": {"Mel": 1, "Hannah": 1}, "MAN (1)": {"Kian": 1}, "LON (1)": {"Other": 1}, "Unassigned (1)": {"Unassigned": 1}})

    def test_it_says_which_creation_date_is_the_cut_off(self):
        html, context = self.page()
        self.assertEqual(context["cutoff_label"], "08/07/2026")
        self.assertIn("Created on or before 08/07/2026", html)

    def test_there_is_no_month_picker(self):
        html, _ = self.page()
        self.assertNotIn('name="month"', html)

    def test_the_cut_off_moves_with_today(self):
        with mock.patch.object(app_module, "today_uk", return_value=date(2026, 7, 8)):
            _, context = self.page()
        self.assertEqual(rows_of(context["report"]), {"MAN": {"Kian": 1}, "LON": {"Other": 1}}, "10/04/2026 is only 89 days old on 08/07")

    def test_when_nothing_is_old_enough_it_says_so(self):
        with mock.patch.object(app_module, "today_uk", return_value=date(2026, 1, 2)):
            html, context = self.page()
        self.assertEqual(context["report"]["groups"], [])
        self.assertIn("No leads are 90 days or older.", html)

    def test_the_button_sits_next_to_split_on_the_leads_dashboard(self):
        html = self.full.get("/leads-dashboard?month=2026-07").get_data(as_text=True)
        split, ninety = html.index('href="/split"'), html.index('href="/ninety-days"')
        self.assertLess(split, ninety)
        self.assertLess(ninety - split, 200, "the two buttons are adjacent")
        self.assertIn(">90 Days</a>", html)

    def test_every_role_sees_the_button_and_can_open_the_page(self):
        for role in ("full", "admissions", "consultants", "marketing"):
            client = self._client_logged_in_as(role)
            self.assertIn('href="/ninety-days"', client.get("/leads-dashboard?month=2026-07").get_data(as_text=True), role)
            self.assertEqual(client.get("/ninety-days").status_code, 200, role)

    def test_login_is_required(self):
        r = app_module.app.test_client().get("/ninety-days")
        self.assertEqual(r.status_code, 302)
        self.assertIn("/login", r.headers["Location"])

    def test_with_no_leads_file_there_is_a_friendly_message(self):
        import sqlite3
        from tests.flask_test_support import db_module
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute("DELETE FROM active_leads_dataset")
        conn.commit()
        conn.close()
        r = self.full.get("/ninety-days")
        self.assertEqual(r.status_code, 200)
        self.assertIn("No active Leads dataset yet.", r.get_data(as_text=True))


if __name__ == "__main__":
    unittest.main()
