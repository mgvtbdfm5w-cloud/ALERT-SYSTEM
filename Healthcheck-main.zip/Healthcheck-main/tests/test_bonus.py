"""The 30 Days page: the Bonus Eligibility chart (by Application Manager, with the
click-through window and a "Submitted to uni in" month filter) for the 2027 Intake
applications submitted to a university from 1 October 2026.

Day one is Submitted To Uni. Eligible = offer accepted within 30 days of it; Open = no
offer yet and within 30 days; Missed = anything else."""

import io
import re
import unittest
from contextlib import contextmanager
from datetime import date, timedelta
from html import unescape
from unittest import mock
from urllib.parse import parse_qs, urlencode

import openpyxl
from flask import template_rendered

import bonus
from bonus import (
    BONUS_DAYS,
    BONUS_RECORD_COLUMNS,
    ELIGIBLE,
    MISSED,
    NOT_ELIGIBLE,
    OPEN,
    bonus_records,
    build_bonus_chart,
    classify,
    in_scope,
    submitted_months,
)
from tests.flask_test_support import IsolatedAppTestCase, app_module, extract_token
from tests.test_upload_atomicity import REQUIRED_IMPORT_COLUMNS, book, row

TODAY = date(2027, 1, 15)


def d(offset):
    """TODAY minus `offset` days as an ISO string (the stored date format)."""
    return (TODAY - timedelta(days=offset)).isoformat()


def app(code="1", sub=None, accepted=None, status="05-Assessment", manager="Alice", office="EG", **extra):
    return {"Student Code": code, "Student Name": f"Student {code}", "Status": status, "Application": manager, "Office": office, "University Name": "Uni A",
            "Intake": "September 2026", "Consultant": "Gina", "Submitted To Uni": sub, "Offer Accepted Date": accepted, **extra}


class ClassifyTests(unittest.TestCase):
    def test_the_thirty_day_rule_when_there_is_an_offer(self):
        sub = d(100)
        for days, expected in ((0, ELIGIBLE), (1, ELIGIBLE), (29, ELIGIBLE), (30, ELIGIBLE), (31, MISSED), (60, MISSED), (144, MISSED)):
            accepted = (date.fromisoformat(sub) + timedelta(days=days)).isoformat()
            self.assertEqual(classify(app(sub=sub, accepted=accepted), TODAY), expected, days)

    def test_the_thirty_day_rule_when_there_is_no_offer_yet(self):
        for waited, expected in ((0, OPEN), (1, OPEN), (29, OPEN), (30, OPEN), (31, MISSED), (45, MISSED), (400, MISSED)):
            self.assertEqual(classify(app(sub=d(waited)), TODAY), expected, waited)

    def test_a_submission_dated_in_the_future_is_open(self):
        self.assertEqual(classify(app(sub=(TODAY + timedelta(days=5)).isoformat()), TODAY), OPEN)

    def test_an_offer_accepted_before_the_submission_date_is_a_deferral_and_not_eligible(self):
        self.assertEqual(classify(app(sub=d(20), accepted=d(30)), TODAY), NOT_ELIGIBLE)
        self.assertEqual(classify(app(sub=d(20), accepted=d(21)), TODAY), NOT_ELIGIBLE, "even one day before")
        self.assertEqual(classify(app(sub=d(20), accepted=d(20)), TODAY), ELIGIBLE, "the same day is zero days, which counts")
        self.assertEqual(classify(app(sub=d(20), accepted=d(19)), TODAY), ELIGIBLE)

    def test_a_deferral_stays_not_eligible_whatever_the_status(self):
        for status in ("05-Assessment", "09-Enrolled", "10-Lost"):
            self.assertEqual(classify(app(sub=d(20), accepted=d(30), status=status), TODAY), NOT_ELIGIBLE, status)

    def test_a_lost_application_with_no_accepted_offer_is_missed_straight_away(self):
        self.assertEqual(classify(app(sub=d(3), status="10-Lost"), TODAY), MISSED)
        self.assertEqual(classify(app(sub=d(40), status="10-Lost"), TODAY), MISSED)

    def test_a_lost_application_that_did_get_an_offer_is_judged_on_the_offer_date(self):
        self.assertEqual(classify(app(sub=d(50), accepted=d(30), status="10-Lost"), TODAY), ELIGIBLE)
        self.assertEqual(classify(app(sub=d(80), accepted=d(30), status="10-Lost"), TODAY), MISSED)

    def test_other_statuses_are_judged_by_the_dates_alone(self):
        for status in ("04-Onboarding", "05-Assessment", "06-Decision", "07-Ready", "08-Pre-Enrolled", "09-Enrolled"):
            self.assertEqual(classify(app(sub=d(10), status=status), TODAY), OPEN, status)
            self.assertEqual(classify(app(sub=d(50), status=status), TODAY), MISSED, status)

    def test_no_usable_submitted_date_is_none(self):
        for sub in (None, "", "garbage", "2026-13-45"):
            self.assertIsNone(classify(app(sub=sub, accepted=d(1)), TODAY), repr(sub))

    def test_an_unreadable_offer_date_counts_as_no_offer(self):
        self.assertEqual(classify(app(sub=d(5), accepted="garbage"), TODAY), OPEN)
        self.assertEqual(classify(app(sub=d(50), accepted=""), TODAY), MISSED)

    def test_the_window_is_thirty_days(self):
        self.assertEqual(BONUS_DAYS, 30)


def in_2027(code, **kwargs):
    return app(code, Intake="September 2027", **kwargs)


class ScopeTests(unittest.TestCase):
    def test_only_pipeline_statuses_with_a_submitted_date(self):
        rows = [in_2027("a", sub=d(5)), in_2027("b", sub=None), in_2027("c", sub=d(5), status="00-QARejected"), in_2027("d", sub=d(5), status="11-Deferred"), in_2027("e", sub=d(5), status=""),
                in_2027("f", sub=d(5), status="10-Lost"), in_2027("g", sub="junk"), in_2027("h", sub=d(5), status="03-PendingSubmission")]
        self.assertEqual([r["Student Code"] for r in in_scope(rows)], ["a", "f", "h"])

    def test_only_the_2027_intake(self):
        rows = [app("a", sub=d(5), Intake="September 2026"), app("b", sub=d(5), Intake="January 2027"), app("c", sub=d(5), Intake="December 2027"), app("d", sub=d(5), Intake="2027"),
                app("e", sub=d(5), Intake="March 2028"), app("f", sub=d(5), Intake=""), app("g", sub=d(5), Intake=None), app("h", sub=d(5), Intake="junk")]
        self.assertEqual([r["Student Code"] for r in in_scope(rows)], ["b", "c", "d"])
        self.assertEqual(bonus.BONUS_INTAKE_YEAR, 2027)

    def test_only_applications_submitted_from_1_october_2026(self):
        rows = [in_2027("a", sub="2026-09-30"), in_2027("b", sub="2026-10-01"), in_2027("c", sub="2026-10-02"), in_2027("d", sub="2025-12-01"), in_2027("e", sub="2027-03-01")]
        self.assertEqual([r["Student Code"] for r in in_scope(rows)], ["b", "c", "e"])
        self.assertEqual(bonus.BONUS_SUBMITTED_FROM, date(2026, 10, 1))

    def test_the_month_options_run_oldest_first_from_october_2026_to_the_current_month(self):
        self.assertEqual(submitted_months([], date(2027, 1, 15)), [(2026, 10), (2026, 11), (2026, 12), (2027, 1)])
        self.assertEqual(submitted_months([], date(2026, 10, 1)), [(2026, 10)])
        self.assertEqual(submitted_months([], date(2026, 9, 20)), [], "nothing is in scope before October 2026")

    def test_a_month_with_later_submissions_extends_the_options_and_only_in_scope_ones_count(self):
        rows = [in_2027("a", sub="2027-03-03"), in_2027("b", sub="2027-06-30", status="00-QARejected"), app("c", sub="2027-05-05", Intake="September 2026"), in_2027("d", sub=None)]
        self.assertEqual(submitted_months(rows, date(2027, 1, 15)), [(2026, 10), (2026, 11), (2026, 12), (2027, 1), (2027, 2), (2027, 3)])


def sample():
    return [{**r, "Intake": "September 2027"} for r in raw_sample()]


def raw_sample():
    return [
        app("A1", sub=d(17), accepted=d(2)),                      # Alice: eligible (15 days)
        app("A2", sub=d(31), accepted=d(0)),                      # missed (31 days)
        app("A3", sub=d(12)),                                     # open
        app("A4", sub=d(42)),                                     # missed (no offer, 42 days)
        app("A5", sub=d(27), status="10-Lost"),                   # missed (lost, no offer)
        app("A6", sub=d(52), accepted=d(22)),                     # eligible (30 days exactly)
        app("A7", sub=d(10), accepted=d(14)),                     # not eligible: accepted 4 days BEFORE it was submitted (a deferral)
        app("B1", sub=d(30), manager="Bob", office="UK"),         # Bob: open (30 days exactly)
        app("B2", sub=d(31), manager="Bob", office="UK"),         # missed
        app("B3", sub=d(88), accepted=d(73), manager="Bob", office="UK"),    # eligible
        app("C1", sub=d(7), manager="", office=""),               # nobody: open
        app("X1", sub=d(7), manager="Admission"),                 # an excluded placeholder manager
        app("N1", sub=None),                                      # no day one
        app("Q1", sub=d(7), status="00-QARejected"),              # not a pipeline status
    ]


class ChartTests(unittest.TestCase):
    def setUp(self):
        self.chart = build_bonus_chart(sample(), TODAY)

    def rows(self):
        return {r["name"]: r for g in self.chart["groups"] for r in g["rows"]}

    def test_offices_eg_then_uk_managers_alphabetical_and_nobody_as_unassigned(self):
        self.assertEqual([(g["office"], [r["name"] for r in g["rows"]]) for g in self.chart["groups"]],
                         [("EG", ["Alice"]), ("UK", ["Bob"]), ("Unassigned", ["Unassigned"])])

    def test_counts_per_manager(self):
        rows = self.rows()
        self.assertEqual((rows["Alice"]["total"], rows["Alice"]["eligible"], rows["Alice"]["open"], rows["Alice"]["missed"], rows["Alice"]["not_eligible"]), (6, 2, 1, 3, 1))
        self.assertEqual((rows["Bob"]["total"], rows["Bob"]["eligible"], rows["Bob"]["open"], rows["Bob"]["missed"], rows["Bob"]["not_eligible"]), (3, 1, 1, 1, 0))
        self.assertEqual((rows["Unassigned"]["total"], rows["Unassigned"]["open"]), (1, 1))
        self.assertEqual(self.chart["totals"], {"total": 10, "eligible": 3, "open": 3, "missed": 4, "not_eligible": 1}, "Not Eligible is not in the total")

    def test_excluded_managers_and_out_of_scope_applications_are_not_there(self):
        every = {r["Student Code"] for per in self.chart["managers"].values() for rows in per.values() for r in rows}
        self.assertEqual(every, {"A1", "A2", "A3", "A4", "A5", "A6", "A7", "B1", "B2", "B3", "C1"})
        self.assertNotIn("Admission", self.chart["managers"])

    def test_the_eligible_percentage_is_the_eligible_share_rounded_half_up(self):
        rows = self.rows()
        self.assertEqual((rows["Alice"]["eligible_pct"], rows["Bob"]["eligible_pct"], rows["Unassigned"]["eligible_pct"]), (33, 33, 0))
        one_of_eight = build_bonus_chart([in_2027("1", sub=d(40), accepted=d(30), manager="Zed")] + [in_2027(str(i), sub=d(40), manager="Zed") for i in range(2, 9)], TODAY)
        self.assertEqual(one_of_eight["groups"][0]["rows"][0]["eligible_pct"], 13, "12.5 rounds up")

    def test_segments_are_eligible_open_missed_in_that_order_with_their_colours_and_zero_ones_left_out(self):
        alice = self.rows()["Alice"]
        self.assertEqual([(s["label"], s["count"], s["color"]) for s in alice["segments"]],
                         [("Eligible", 2, "#16a34a"), ("Open", 1, "#e0a526"), ("Missed", 3, "#c0605a"), ("Not Eligible", 1, "#9aa4b2")])
        self.assertEqual([s["key"] for s in alice["segments"]], ["eligible", "open", "missed", "not_eligible"])
        self.assertEqual([s["label"] for s in self.rows()["Unassigned"]["segments"]], ["Open"])

    def test_bars_are_scaled_to_the_biggest_manager(self):
        alice, bob = self.rows()["Alice"], self.rows()["Bob"]
        self.assertAlmostEqual(sum(s["width_pct"] for s in alice["segments"]), 100.0, msg="Alice has 7 applications including the Not Eligible one, the most")
        self.assertAlmostEqual(sum(s["width_pct"] for s in bob["segments"]), 300 / 7)

    def test_an_office_comes_from_the_first_row_that_has_one_and_none_means_unassigned(self):
        rows = [in_2027("1", sub=d(5), manager="Mo", office=""), in_2027("2", sub=d(5), manager="Mo", office="UK"), in_2027("3", sub=d(5), manager="Mo", office="EG")]
        self.assertEqual([(g["office"], g["rows"][0]["total"]) for g in build_bonus_chart(rows, TODAY)["groups"]], [("UK", 3)])
        self.assertEqual(build_bonus_chart([in_2027("1", sub=d(5), manager="Mo", office="")], TODAY)["groups"][0]["office"], "Unassigned")

    def test_nothing_in_scope_is_an_empty_chart(self):
        chart = build_bonus_chart([in_2027("1", sub=None)], TODAY)
        self.assertEqual((chart["groups"], chart["totals"]), ([], {"total": 0, "eligible": 0, "open": 0, "missed": 0, "not_eligible": 0}))
        self.assertEqual(build_bonus_chart([], TODAY)["groups"], [])

    def test_a_piece_lists_exactly_the_number_it_shows(self):
        for group in self.chart["groups"]:
            for r in group["rows"]:
                total = 0
                for seg in r["segments"]:
                    records = bonus_records(self.chart, r["name"], seg["key"], TODAY)
                    self.assertEqual(len(records), seg["count"], (r["name"], seg["key"]))
                    total += len(records)
                self.assertEqual(total, r["total"] + r["not_eligible"], r["name"])

    def test_the_input_is_not_modified(self):
        rows = sample()
        before = [dict(r) for r in rows]
        build_bonus_chart(rows, TODAY)
        self.assertEqual(rows, before)


class RecordsTests(unittest.TestCase):
    def setUp(self):
        self.chart = build_bonus_chart(sample(), TODAY)

    def test_fields_dates_and_days(self):
        eligible = {r["code"]: r for r in bonus_records(self.chart, "Alice", "eligible", TODAY)}
        a1 = eligible["A1"]
        self.assertEqual((a1["submitted"], a1["accepted"], a1["days_to_offer"], a1["days_waiting"]), (date.fromisoformat(d(17)).strftime("%d/%m/%Y"), date.fromisoformat(d(2)).strftime("%d/%m/%Y"), "15", ""))
        self.assertEqual(eligible["A6"]["days_to_offer"], "30")
        opened = bonus_records(self.chart, "Alice", "open", TODAY)[0]
        self.assertEqual((opened["code"], opened["accepted"], opened["days_to_offer"], opened["days_waiting"]), ("A3", "", "", "12"))
        missed = {r["code"]: r for r in bonus_records(self.chart, "Alice", "missed", TODAY)}
        self.assertEqual((missed["A2"]["days_to_offer"], missed["A2"]["days_waiting"]), ("31", ""))
        self.assertEqual((missed["A4"]["days_to_offer"], missed["A4"]["days_waiting"]), ("", "42"))
        self.assertEqual((missed["A5"]["days_to_offer"], missed["A5"]["days_waiting"]), ("", "27"), "a lost application is missed but still shows how long it waited")
        self.assertEqual(sorted(a1), sorted(k for _, k in BONUS_RECORD_COLUMNS))
        self.assertEqual(a1["university"], "Uni A")
        self.assertEqual(a1["consultant"], "Gina")

    def test_sorted_by_student_then_code(self):
        keys = [(r["student"].lower(), r["code"]) for r in bonus_records(self.chart, "Alice", "missed", TODAY)]
        self.assertEqual(keys, sorted(keys))

    def test_students_are_listed_alphabetically_whatever_their_codes_and_ties_fall_back_to_the_code(self):
        rows = [dict(in_2027("1", sub=d(5)), **{"Student Name": "zed"}), dict(in_2027("2", sub=d(5)), **{"Student Name": "Amy"}),
                dict(in_2027("3", sub=d(5)), **{"Student Name": "amy"}), dict(in_2027("0", sub=d(5)), **{"Student Name": "Bea"})]
        listed = bonus_records(build_bonus_chart(rows, TODAY), "Alice", "open", TODAY)
        self.assertEqual([(r["student"], r["code"]) for r in listed], [("Amy", "2"), ("amy", "3"), ("Bea", "0"), ("zed", "1")])

    def test_unknown_status_none_unknown_manager_empty(self):
        self.assertIsNone(bonus_records(self.chart, "Alice", "nope", TODAY))
        self.assertIsNone(bonus_records(self.chart, "Alice", "Eligible", TODAY))
        self.assertEqual(bonus_records(self.chart, "Nobody", "open", TODAY), [])
        self.assertEqual(bonus_records(self.chart, "alice", "open", TODAY), [])

    def test_the_columns(self):
        self.assertEqual([c[0] for c in BONUS_RECORD_COLUMNS], ["PES Code", "Student", "University", "Intake", "Consultant", "Submitted To Uni", "Offer Accepted", "Days to Offer", "Days Waiting"])


# ----------------------------------------------------------------- the page
STATUS_LOOKUP = [("Assessment", "05-Assessment"), ("Lost", "10-Lost"), ("QA Rejected", "00-QARejected"), ("Enrolled", "09-Enrolled")]
RAW = {"05-Assessment": "Assessment", "10-Lost": "Lost", "00-QARejected": "QA Rejected", "09-Enrolled": "Enrolled"}
OFFICES = [("Alice Brown", "EG"), ("Bob Green", "UK"), ("Admission Desk", "EG")]
EXTRA = ["Offer Accepted Date"]


def uk(iso):
    return f"{iso[8:10]}/{iso[5:7]}/{iso[:4]}" if iso else ""


def officer(manager):
    return {"Alice": "Alice Brown", "Bob": "Bob Green", "Admission": "Admission Desk", "": ""}[manager]


def workbook_rows(rows=None):
    out = []
    for r in rows if rows is not None else sample():
        out.append(row(**{"Student Code": r["Student Code"], "Student Name": r["Student Name"], "Application Status": RAW[r["Status"]] if r["Status"] in RAW else "Assessment",
                          "Admission Officer": officer(r["Application"]), "University Name": r["University Name"], "Intake": r["Intake"], "Counsellor": "Gina G",
                          "Uni Submission Done": uk(r["Submitted To Uni"]), "Offer Accepted Date": uk(r["Offer Accepted Date"]), "QA Officer": r.get("QA", "")}))
    return out


LOOKUPS = {"status": STATUS_LOOKUP, "office": OFFICES}


@contextmanager
def captured():
    rendered = []

    def record(sender, template, context, **extra):
        rendered.append((template.name, dict(context)))

    template_rendered.connect(record, app_module.app)
    try:
        yield rendered
    finally:
        template_rendered.disconnect(record, app_module.app)


class PageBase(IsolatedAppTestCase):
    ROWS = None

    def setUp(self):
        super().setUp()
        self.full = self._client_logged_in_as("full")
        token = extract_token(self.full.get("/login").get_data(as_text=True))
        data = book(self.ROWS if self.ROWS is not None else workbook_rows(), lookups=LOOKUPS, extra_columns=EXTRA)
        self.assertEqual(self.full.post("/upload", data={"csrf_token": token, "excel_file": (io.BytesIO(data), "f.xlsx")}, content_type="multipart/form-data").status_code, 302)
        patcher = mock.patch.object(app_module, "today_uk", return_value=TODAY)
        patcher.start()
        self.addCleanup(patcher.stop)

    def page(self, query="", client=None):
        """The 30 Days page."""
        return self._render("/thirty-days", "thirty_days.html", query, client)

    def dashboard_page(self, query="year=2026", client=None):
        """The Application Manager Pipeline page."""
        return self._render("/dashboard", "dashboard.html", query, client)

    def _render(self, path, template, query, client):
        with captured() as rendered:
            r = (client or self.full).get(f"{path}?{query}")
        self.assertEqual(r.status_code, 200, query)
        return r.get_data(as_text=True), next(c for name, c in rendered if name == template)

    def records(self, manager, status, query="", client=None):
        return (client or self.full).get("/thirty-days/records?" + query + "&" + urlencode({"manager": manager, "status": status}))

    def section(self, html):
        start = html.index("<h2>Bonus Eligibility by Application Manager</h2>")
        return html[start:html.index("</section>", start)]

    def pieces(self, context):
        return [(r["name"], s["key"], s["count"]) for g in context["bonus_chart"]["groups"] for r in g["rows"] for s in r["segments"]]


class PageTests(PageBase):
    def test_the_chart_has_its_own_30_days_page(self):
        html, _ = self.page()
        self.assertIn("<title>30 Day Offers Accepted - GSP Health Check Manager</title>", html)
        self.assertIn("<h1>30 Day Offers Accepted</h1>", html)
        self.assertIn("Bonus Eligibility by Application Manager", html)
        self.assertIn('class="back-link">&larr; Application Manager Pipeline</a>', html)
        for text in ("Application Manager Pipeline Health", "Offer Days", "Download Spreadsheet", "summary-card"):
            self.assertNotIn(text, html, text)

    def test_the_chart_is_off_the_application_manager_pipeline_page_which_links_to_30_days(self):
        html, context = self.dashboard_page("year=2027")
        for text in ("Bonus Eligibility", "sub_month", "Submitted to uni in", "bonus_chart"):
            self.assertNotIn(text, html, text)
        self.assertNotIn("bonus_chart", context)
        self.assertRegex(html, r'<a class="btn-primary btn-link" href="/thirty-days">30 Days</a>')
        for text in ("Application Manager Pipeline 2027", "Application Manager Pipeline Health", "Download Spreadsheet", "Offer Days"):
            self.assertIn(text, html, text)

    def test_the_page_has_no_year_or_intake_tabs_and_ignores_them_in_the_address(self):
        html, context = self.page()
        for text in ('class="tabs"', "tab-link", "tabs-months", "Intake 01", "Intake 02", "Intake 03", 'name="year"', 'name="intake"', 'name="intake_month"'):
            self.assertNotIn(text, html, text)
        self.assertIn('href="/dashboard" class="back-link"', html)
        for query in ("year=2026", "year=2027&intake=intake_01", "year=2027&intake_month=3"):
            self.assertEqual(self.page(query)[1]["bonus_chart"]["totals"], context["bonus_chart"]["totals"], query)

    def test_the_number_breakdown_section_and_table_stay_gone_from_the_pipeline_page(self):
        for html in (self.dashboard_page()[0], self.page()[0]):
            for text in ("Number Breakdown", "pipeline-table", "Grand Total"):
                self.assertNotIn(text, html, text)

    def test_rows_columns_and_figures(self):
        html, context = self.page()
        section = self.section(html)
        names = re.findall(r'<div class="chart-row">\s*<div class="chart-manager-name">([^<]+)</div>', section)
        self.assertEqual(names, ["Alice", "Bob", "Unassigned"])
        header = section[section.index('<div class="chart-columns-header">'):section.index('<div class="chart-office-group">')]
        text = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", header)).strip()
        self.assertEqual(text, "Manager Total Eligible Open Missed Not Eligible %")
        rows = [re.findall(r'<span class="chart-col-[a-z -]+">\s*([^<]*?)\s*</span>', tr) for tr in re.findall(r'<div class="chart-row">.*?<div class="chart-summary">(.*?)</div>\s*</div>', section, re.S)]
        self.assertEqual(rows, [["6", "2", "1", "3", "1", "33%"], ["3", "1", "1", "1", "0", "33%"], ["1", "0", "1", "0", "0", "0%"]])
        self.assertEqual(context["bonus_chart"]["totals"], {"total": 10, "eligible": 3, "open": 3, "missed": 4, "not_eligible": 1})

    def test_the_legend_is_there_and_the_explanation_under_the_chart_is_not(self):
        html, _ = self.page()
        section = self.section(html)
        legend = section[section.index('class="chart-legend"'):]
        for label in ("Eligible", "Open", "Missed", "Not Eligible"):
            self.assertIn(label, legend)
        self.assertIn("background-color: #9aa4b2", legend)
        for text in ("Day one is", "Submitted To Uni date", "% is the share", "are counted", "Click a bar", 'class="hint"'):
            self.assertNotIn(text, html, text)

    def test_every_piece_is_a_clickable_button_and_has_the_tooltip(self):
        html, context = self.page()
        section = self.section(html)
        pieces = re.findall(r'<div class="chart-segment chart-segment-clickable" role="button" tabindex="0"\s+style="[^"]*"\s+data-tooltip="([^"]*)"\s+'
                            r'data-records-title="([^"]*)"\s+data-records-params="([^"]*)"\s+data-count="(\d+)"', section)
        got = []
        for tooltip, title, params, count in pieces:
            query = parse_qs(params.replace("&amp;", "&"))
            manager, status = query["manager"][0], query["status"][0]
            self.assertEqual(sorted(query), ["manager", "status"])
            label = status.replace("_", " ").title()
            self.assertEqual(title, f"{manager} &mdash; {label}")
            self.assertEqual(tooltip, f"{manager} - {label}: {count}")
            got.append((manager, status, int(count)))
        self.assertEqual(got, self.pieces(context))
        self.assertEqual(len(got), 8, "Alice 4 (with Not Eligible), Bob 3, Unassigned 1")
        self.assertIn(("Alice", "not_eligible", 1), got)

    def test_each_page_has_one_window_that_asks_its_own_endpoint(self):
        html, _ = self.page()
        self.assertEqual(html.count('<dialog id="chart-records"'), 1)
        self.assertIn('data-url="/thirty-days/records"', html)
        self.assertEqual(html.count("chart-records.js"), 1)
        html, _ = self.dashboard_page()
        self.assertEqual(html.count('<dialog id="chart-records"'), 1)
        self.assertIn('data-url="/dashboard/records"', html)
        self.assertNotIn("chart-records-wide", html, "only the 30 Days window is the wide one")
        self.assertIn('class="chart-records chart-records-wide"', self.page()[0])

    def test_the_month_dropdown_runs_oldest_first_from_october_2026(self):
        html, _ = self.page()
        block = html[html.index('<select name="sub_month"'):]
        block = block[:block.index("</select>")]
        keys = re.findall(r'<option value="([^"]*)"', block)
        self.assertEqual(keys[0], "")
        self.assertEqual(keys[1:], sorted(keys[1:]), "oldest month first")
        self.assertEqual(keys[1:], ["2026-10", "2026-11", "2026-12", "2027-01"], "October 2026 up to the current month")
        self.assertEqual(re.findall(r'<option value="\d{4}-\d{2}"[^>]*>\s*([^<]*?)\s*</option>', block), ["October 2026", "November 2026", "December 2026", "January 2027"])
        self.assertIn("All months", block)
        self.assertEqual(re.findall(r'<option value="([^"]*)" selected', block), [""])
        self.assertIn("Submitted to uni in</label>", html)

    def test_picking_a_month_narrows_the_chart_to_applications_submitted_in_that_month(self):
        _, all_context = self.page()
        month = date.fromisoformat(d(12))
        key = f"{month.year}-{month.month:02d}"
        _, context = self.page(f"sub_month={key}")
        total = context["bonus_chart"]["totals"]["total"]
        self.assertLess(total, all_context["bonus_chart"]["totals"]["total"])
        in_month = [r for r in sample() if r["Submitted To Uni"] and r["Submitted To Uni"][:7] == key and r["Status"] != "00-QARejected" and r["Application"] != "Admission"]
        self.assertEqual(total + context["bonus_chart"]["totals"]["not_eligible"], len(in_month))

    def test_a_month_that_is_not_an_option_is_ignored(self):
        _, everything = self.page()
        for month in ("2020-01", "garbage", "2026-13", "", "%3Cscript%3E", "2026-1x"):
            _, context = self.page("sub_month=" + month)
            self.assertEqual(context["bonus_chart"]["totals"], everything["bonus_chart"]["totals"], month)
        html, _ = self.page("sub_month=%3Cscript%3Ealert(1)%3C/script%3E")
        self.assertNotIn("<script>alert", html)

    def test_the_selected_month_is_marked(self):
        html, _ = self.page()
        first_month = re.findall(r'<option value="(\d{4}-\d{2})"', html)[0]
        html, _ = self.page(f"sub_month={first_month}")
        form = html[html.index('<form method="GET" action="/thirty-days"'):]
        form = form[:form.index("</form>")]
        self.assertIn(f'<option value="{first_month}" selected>', form)
        self.assertIn('onchange="this.form.submit()"', form)

    def test_one_month_has_only_its_own_applications(self):
        _, context = self.page("sub_month=2026-10")
        self.assertEqual(context["bonus_chart"]["totals"]["total"], 1, "only B3 was submitted in October 2026")

    def test_every_role_can_see_it_and_other_pages_do_not_have_it(self):
        for role in ("admissions", "consultants", "marketing"):
            _, context = self.page(client=self._client_logged_in_as(role))
            self.assertEqual(context["bonus_chart"]["totals"]["total"], 10, role)
        for path in ("/dashboard?year=2026", "/university-pipeline?year=2026", "/dashboard/just-jon?year=2026", "/enrolled?year=2026"):
            self.assertNotIn("Bonus Eligibility", self.full.get(path).get_data(as_text=True), path)



class RecordsRouteTests(PageBase):
    QUERIES = ["", "sub_month=2026-10", "sub_month=2026-11", "sub_month=2026-12", "sub_month=2027-01", "sub_month=bogus", "year=2026&intake=intake_01"]

    def test_every_piece_lists_exactly_the_number_it_shows(self):
        checked = 0
        for query in self.QUERIES:
            _, context = self.page(query)
            for manager, status, count in self.pieces(context):
                r = self.records(manager, status, query)
                self.assertEqual(r.status_code, 200, (query, manager, status))
                data = r.get_json()
                self.assertEqual((data["count"], len(data["records"])), (count, count), (query, manager, status))
                checked += 1
        self.assertGreater(checked, 12)

    def test_the_pieces_of_one_bar_add_up_to_the_bar(self):
        _, context = self.page()
        for g in context["bonus_chart"]["groups"]:
            for r in g["rows"]:
                total = sum(len(self.records(r["name"], s["key"]).get_json()["records"]) for s in r["segments"])
                self.assertEqual(total, r["total"] + r["not_eligible"], r["name"])

    def test_known_pieces_and_columns(self):
        codes = lambda m, s, q="": sorted(r["code"] for r in self.records(m, s, q).get_json()["records"])
        self.assertEqual(codes("Alice", "eligible"), ["A1", "A6"])
        self.assertEqual(codes("Alice", "open"), ["A3"])
        self.assertEqual(codes("Alice", "missed"), ["A2", "A4", "A5"])
        self.assertEqual(codes("Bob", "open"), ["B1"], "exactly 30 days is still open")
        self.assertEqual(codes("Bob", "missed"), ["B2"], "31 days is missed")
        self.assertEqual(codes("Unassigned", "open"), ["C1"])
        self.assertEqual(codes("Alice", "not_eligible"), ["A7"], "a deferral: accepted before it was submitted")
        self.assertEqual(codes("Bob", "not_eligible"), [])
        a7 = self.records("Alice", "not_eligible").get_json()["records"][0]
        self.assertEqual((a7["days_to_offer"], a7["days_waiting"]), ("-4", ""))
        data = self.records("Alice", "eligible").get_json()
        self.assertEqual(data["columns"], [list(c) for c in BONUS_RECORD_COLUMNS])
        self.assertEqual((data["noun"], data["manager"], data["status"]), ("application", "Alice", "eligible"))
        a1 = next(r for r in data["records"] if r["code"] == "A1")
        self.assertEqual((a1["days_to_offer"], a1["days_waiting"]), ("15", ""))
        open_a3 = self.records("Alice", "open").get_json()["records"][0]
        self.assertEqual((open_a3["days_to_offer"], open_a3["days_waiting"]), ("", "12"))

    def test_the_month_filter_applies_to_the_list_as_it_does_to_the_chart(self):
        dec_codes = sorted(r["code"] for r in self.records("Alice", "missed", "sub_month=2026-12").get_json()["records"])
        all_codes = sorted(r["code"] for r in self.records("Alice", "missed").get_json()["records"])
        self.assertEqual(dec_codes, ["A2", "A4", "A5"])
        self.assertEqual(all_codes, ["A2", "A4", "A5"])
        self.assertEqual(sorted(r["code"] for r in self.records("Alice", "eligible", "sub_month=2026-12").get_json()["records"]), ["A1"])
        self.assertEqual(sorted(r["code"] for r in self.records("Alice", "eligible").get_json()["records"]), ["A1", "A6"])

    def test_an_unknown_status_is_a_400_and_an_unknown_manager_is_empty(self):
        for status in ("", "nope", "Eligible", "ELIGIBLE", "lost", "not eligible", "Not_Eligible", "not-eligible"):
            r = self.records("Alice", status)
            self.assertEqual((r.status_code, r.get_json()), (400, {"error": "Unknown chart piece."}), status)
        self.assertEqual(self.full.get("/thirty-days/records?manager=Alice").status_code, 400)
        for manager in ("Nobody", "alice", "Alice ", "", "Admission"):
            r = self.records(manager, "eligible")
            self.assertEqual((r.status_code, r.get_json()["count"]), (200, 0), repr(manager))

    def test_json_no_store_login_and_roles(self):
        r = self.records("Alice", "eligible")
        self.assertEqual((r.mimetype, r.headers["Cache-Control"]), ("application/json", "no-store"))
        anon = app_module.app.test_client().get("/thirty-days/records?manager=Alice&status=eligible")
        self.assertEqual(anon.status_code, 302)
        for role in ("admissions", "consultants", "marketing"):
            self.assertEqual(self.records("Alice", "eligible", client=self._client_logged_in_as(role)).get_json()["count"], 2, role)

    def test_with_no_dataset_it_is_an_empty_list(self):
        import sqlite3
        from tests.flask_test_support import db_module
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute("DELETE FROM active_dataset")
        conn.commit()
        conn.close()
        r = self.records("Alice", "eligible")
        self.assertEqual((r.status_code, r.get_json()["count"]), (200, 0))


class OnlyDeferralsTests(PageBase):
    """A manager whose only applications are deferrals still has a row - with nothing counted."""

    ROWS = workbook_rows([in_2027("D1", sub=d(10), accepted=d(14), manager="Bob", office="UK"), in_2027("D2", sub=d(10), accepted=d(12), manager="Bob", office="UK"),
                          in_2027("E1", sub=d(10), accepted=d(5))])

    def test_the_row_shows_the_deferrals_but_counts_nothing(self):
        html, context = self.page()
        bob = next(r for g in context["bonus_chart"]["groups"] for r in g["rows"] if r["name"] == "Bob")
        self.assertEqual((bob["total"], bob["eligible"], bob["not_eligible"], bob["eligible_pct"]), (0, 0, 2, 0))
        self.assertEqual([(s["label"], s["count"]) for s in bob["segments"]], [("Not Eligible", 2)])
        self.assertEqual(context["bonus_chart"]["totals"], {"total": 1, "eligible": 1, "open": 0, "missed": 0, "not_eligible": 2})
        self.assertEqual(sorted(r["code"] for r in self.records("Bob", "not_eligible").get_json()["records"]), ["D1", "D2"])

    def test_the_month_filter_covers_deferrals_too(self):
        _, context = self.page("sub_month=2027-01")
        self.assertEqual(context["bonus_chart"]["totals"]["not_eligible"], 2)

    def test_the_download_leaves_them_out(self):
        import openpyxl
        response = self.full.get("/thirty-days/export")
        codes = [r[2] for r in openpyxl.load_workbook(io.BytesIO(response.data)).active.iter_rows(min_row=3, values_only=True)]
        self.assertEqual(codes, ["E1"])


class OnlyDeferralsInTheDatasetTests(PageBase):
    ROWS = workbook_rows([in_2027("D1", sub=d(10), accepted=d(14))])

    def test_the_chart_is_shown_not_the_empty_message(self):
        html, context = self.page()
        self.assertEqual(context["bonus_chart"]["totals"], {"total": 0, "eligible": 0, "open": 0, "missed": 0, "not_eligible": 1})
        self.assertNotIn("No applications have been submitted", html)
        self.assertIn("chart-segment-clickable", html)


def qa_app(code, qa, **kwargs):
    return {**in_2027(code, **kwargs), "QA": qa}


QA_ROWS = [
    qa_app("Q1", "Quinn", sub=d(20), accepted=d(10)),                           # Alice, Quinn: eligible (10 days)
    qa_app("Q2", "Quinn", sub=d(60), accepted=d(10)),                           # Alice, Quinn: missed (50 days)
    qa_app("Q3", "Quinn", sub=d(5), manager="Bob", office="UK"),                # Bob, Quinn: open
    qa_app("Q4", "Rita", sub=d(20), accepted=d(10), manager="Bob", office="UK"),    # Bob, Rita: eligible
    qa_app("Q5", "Rita", sub=d(10), accepted=d(14)),                           # Alice, Rita: not eligible (a deferral)
    qa_app("Q6", "", sub=d(5)),                                                    # Alice, no QA Officer: open
    qa_app("Q7", "Quinn", sub=d(5), manager="Admission"),                       # a placeholder manager: on neither chart
    qa_app("Q8", "Abe", sub=d(5), manager=""),                                 # no manager, Abe: open
]


class QAOfficerChartTests(unittest.TestCase):
    def setUp(self):
        self.chart = build_bonus_chart(QA_ROWS, TODAY, person_field="QA")
        self.manager_chart = build_bonus_chart(QA_ROWS, TODAY)

    def rows(self, chart=None):
        return {r["name"]: r for g in (chart or self.chart)["groups"] for r in g["rows"]}

    def test_one_row_per_qa_officer_in_a_single_group_with_no_office_unassigned_last(self):
        self.assertEqual([(g["office"], [r["name"] for r in g["rows"]]) for g in self.chart["groups"]], [("", ["Abe"[:3] if False else "Abe", "Quinn", "Rita", "Unassigned"])])

    def test_counts_per_qa_officer(self):
        rows = self.rows()
        self.assertEqual((rows["Quinn"]["total"], rows["Quinn"]["eligible"], rows["Quinn"]["open"], rows["Quinn"]["missed"], rows["Quinn"]["not_eligible"]), (3, 1, 1, 1, 0))
        self.assertEqual((rows["Rita"]["total"], rows["Rita"]["eligible"], rows["Rita"]["not_eligible"], rows["Rita"]["eligible_pct"]), (1, 1, 1, 100))
        self.assertEqual((rows["Unassigned"]["total"], rows["Unassigned"]["open"]), (1, 1))
        self.assertEqual((rows["Abe"]["total"], rows["Abe"]["open"]), (1, 1))

    def test_both_charts_count_the_same_applications(self):
        self.assertEqual(self.chart["totals"], self.manager_chart["totals"])
        self.assertEqual(self.chart["totals"], {"total": 6, "eligible": 2, "open": 3, "missed": 1, "not_eligible": 1})
        codes = lambda chart: {r["Student Code"] for per in chart["managers"].values() for rs in per.values() for r in rs}
        self.assertEqual(codes(self.chart), codes(self.manager_chart))
        self.assertNotIn("Q7", codes(self.chart), "a placeholder manager's application is on neither chart")

    def test_the_application_manager_chart_is_still_by_manager_and_office(self):
        self.assertEqual([(g["office"], [r["name"] for r in g["rows"]]) for g in self.manager_chart["groups"]],
                         [("EG", ["Alice", "Unassigned"]), ("UK", ["Bob"])], "Q8 has no manager and takes the Office of its row")

    def test_unassigned_comes_last_even_when_it_would_sort_early(self):
        rows = [qa_app("1", "Zed", sub=d(5)), qa_app("2", "", sub=d(5)), qa_app("3", "Al", sub=d(5))]
        self.assertEqual([r["name"] for r in build_bonus_chart(rows, TODAY, person_field="QA")["groups"][0]["rows"]], ["Al", "Zed", "Unassigned"])

    def test_names_sort_ignoring_case(self):
        rows = [qa_app("1", "zed", sub=d(5)), qa_app("2", "Bea", sub=d(5)), qa_app("3", "alan", sub=d(5))]
        self.assertEqual([r["name"] for r in build_bonus_chart(rows, TODAY, person_field="QA")["groups"][0]["rows"]], ["alan", "Bea", "zed"])

    def test_a_piece_lists_exactly_the_number_it_shows(self):
        for row_ in self.chart["groups"][0]["rows"]:
            for seg in row_["segments"]:
                self.assertEqual(len(bonus_records(self.chart, row_["name"], seg["key"], TODAY)), seg["count"], (row_["name"], seg["key"]))

    def test_the_records_come_from_the_right_qa_officer(self):
        self.assertEqual([r["code"] for r in bonus_records(self.chart, "Quinn", "eligible", TODAY)], ["Q1"])
        self.assertEqual([r["code"] for r in bonus_records(self.chart, "Rita", "not_eligible", TODAY)], ["Q5"])
        self.assertEqual(bonus_records(self.chart, "Alice", "eligible", TODAY), [], "Alice is an Application Manager, not a QA Officer")

    def test_a_missing_qa_field_is_unassigned(self):
        rows = [in_2027("1", sub=d(5))]
        self.assertEqual([r["name"] for r in build_bonus_chart(rows, TODAY, person_field="QA")["groups"][0]["rows"]], ["Unassigned"])


class QAOfficerChartPageTests(PageBase):
    ROWS = workbook_rows(QA_ROWS)

    def panel(self, html, title):
        start = html.index(f"<h2>{title}</h2>")
        return html[start:html.index("</section>", start)]

    def names(self, panel):
        return re.findall(r'<div class="chart-row">\s*<div class="chart-manager-name">([^<]+)</div>', panel)

    def test_the_page_has_both_charts_the_manager_one_first(self):
        html, context = self.page()
        self.assertLess(html.index("<h2>Bonus Eligibility by Application Manager</h2>"), html.index("<h2>Bonus Eligibility by QA Officer</h2>"))
        self.assertEqual(self.names(self.panel(html, "Bonus Eligibility by Application Manager")), ["Alice", "Bob", "Unassigned"])
        self.assertEqual(self.names(self.panel(html, "Bonus Eligibility by QA Officer")), ["Abe", "Quinn", "Rita", "Unassigned"])
        self.assertEqual(context["bonus_chart"]["totals"], context["bonus_qa_chart"]["totals"])

    def test_the_qa_chart_has_the_same_columns_but_names_its_first_one_qa_officer_and_has_no_office_labels(self):
        html, _ = self.page()
        panel = self.panel(html, "Bonus Eligibility by QA Officer")
        header = panel[panel.index('<div class="chart-columns-header">'):panel.index('<div class="chart-office-group">')]
        self.assertEqual(re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", header)).strip(), "QA Officer Total Eligible Open Missed Not Eligible %")
        self.assertNotIn("chart-office-label", panel)
        self.assertIn("chart-office-label", self.panel(html, "Bonus Eligibility by Application Manager"))
        rows = [re.findall(r'<span class="chart-col-[a-z -]+">\s*([^<]*?)\s*</span>', tr) for tr in re.findall(r'<div class="chart-row">.*?<div class="chart-summary">(.*?)</div>\s*</div>', panel, re.S)]
        self.assertEqual(rows, [["1", "0", "1", "0", "0", "0%"], ["3", "1", "1", "1", "0", "33%"], ["1", "1", "0", "0", "1", "100%"], ["1", "0", "1", "0", "0", "0%"]])

    def test_each_chart_has_its_own_legend(self):
        html, _ = self.page()
        for title in ("Bonus Eligibility by Application Manager", "Bonus Eligibility by QA Officer"):
            self.assertIn('class="chart-legend"', self.panel(html, title))
            self.assertIn("Not Eligible", self.panel(html, title))

    def test_the_qa_pieces_ask_for_by_qa_and_the_manager_pieces_do_not(self):
        html, context = self.page()
        qa = re.findall(r'data-records-params="([^"]*)"', self.panel(html, "Bonus Eligibility by QA Officer"))
        am = re.findall(r'data-records-params="([^"]*)"', self.panel(html, "Bonus Eligibility by Application Manager"))
        self.assertTrue(qa and am)
        self.assertTrue(all(sorted(parse_qs(p.replace("&amp;", "&"))) == ["by", "manager", "status"] and parse_qs(p.replace("&amp;", "&"))["by"] == ["qa"] for p in qa))
        self.assertTrue(all(sorted(parse_qs(p.replace("&amp;", "&"))) == ["manager", "status"] for p in am))
        self.assertEqual(len(qa), sum(len(r["segments"]) for g in context["bonus_qa_chart"]["groups"] for r in g["rows"]))

    def test_one_month_filter_one_window_one_script(self):
        html, _ = self.page()
        self.assertEqual(html.count('<select name="sub_month"'), 1)
        self.assertEqual(html.count('<dialog id="chart-records"'), 1)
        self.assertEqual(html.count("chart-records.js"), 1)

    def test_the_month_filter_narrows_both_charts(self):
        key = f"{date.fromisoformat(d(5)).year}-{date.fromisoformat(d(5)).month:02d}"
        _, everything = self.page()
        _, context = self.page(f"sub_month={key}")
        for name in ("bonus_chart", "bonus_qa_chart"):
            self.assertEqual(context[name]["totals"]["total"], context["bonus_chart"]["totals"]["total"])
        self.assertLess(context["bonus_qa_chart"]["totals"]["total"], everything["bonus_qa_chart"]["totals"]["total"])

    def test_the_records_by_qa_officer(self):
        codes = lambda who, status, by="qa": sorted(r["code"] for r in self.full.get("/thirty-days/records?" + urlencode({"manager": who, "status": status, "by": by})).get_json()["records"])
        self.assertEqual(codes("Quinn", "eligible"), ["Q1"])
        self.assertEqual(codes("Quinn", "open"), ["Q3"])
        self.assertEqual(codes("Rita", "not_eligible"), ["Q5"])
        self.assertEqual(codes("Unassigned", "open"), ["Q6"])
        self.assertEqual(codes("Abe", "open"), ["Q8"])
        self.assertEqual(codes("Alice", "eligible"), [], "an Application Manager's name is not a QA Officer")
        self.assertEqual(codes("Alice", "eligible", "manager"), ["Q1"])
        self.assertEqual(codes("Quinn", "eligible", "manager"), [], "and a QA Officer's name is not an Application Manager")

    def test_every_qa_piece_lists_exactly_the_number_it_shows(self):
        _, context = self.page()
        checked = 0
        for g in context["bonus_qa_chart"]["groups"]:
            for r in g["rows"]:
                for s in r["segments"]:
                    data = self.full.get("/thirty-days/records?" + urlencode({"manager": r["name"], "status": s["key"], "by": "qa"})).get_json()
                    self.assertEqual((data["count"], len(data["records"])), (s["count"], s["count"]), (r["name"], s["key"]))
                    checked += 1
        self.assertGreater(checked, 5)

    def test_an_unknown_by_is_a_400_and_by_manager_is_the_default(self):
        for by in ("nope", "QA", "Manager", "application", " qa"):
            r = self.full.get("/thirty-days/records?" + urlencode({"manager": "Quinn", "status": "eligible", "by": by}))
            self.assertEqual((r.status_code, r.get_json()), (400, {"error": "Unknown chart piece."}), by)
        plain = self.full.get("/thirty-days/records?manager=Alice&status=eligible").get_json()
        explicit = self.full.get("/thirty-days/records?manager=Alice&status=eligible&by=manager").get_json()
        self.assertEqual(plain, explicit)

    def test_the_download_is_still_the_eligible_applications_by_application_manager(self):
        import openpyxl
        response = self.full.get("/thirty-days/export")
        rows = list(openpyxl.load_workbook(io.BytesIO(response.data)).active.iter_rows(min_row=3, values_only=True))
        self.assertEqual([(r[0], r[2]) for r in rows], [("Alice", "Q1"), ("Bob", "Q4")])


class EmptyMonthTests(PageBase):
    ROWS = workbook_rows([in_2027("J1", sub="2027-01-05")])

    def test_a_month_with_nothing_says_so_and_has_no_chart(self):
        html, context = self.page("sub_month=2026-11")
        self.assertEqual(context["selected_bonus_month"], "2026-11")
        self.assertEqual(context["bonus_chart"]["totals"]["total"], 0)
        self.assertIn("No applications have been submitted to a university in this month.", html)
        self.assertNotIn("chart-segment-clickable", html)

    def test_all_months_has_the_chart(self):
        html, context = self.page()
        self.assertEqual(context["bonus_chart"]["totals"]["total"], 1)
        self.assertIn("chart-segment-clickable", html)


class NoSubmissionsTests(PageBase):
    ROWS = workbook_rows([in_2027("N1", sub=None)])

    def test_a_dataset_with_no_submissions_says_so(self):
        html, _ = self.page()
        self.assertIn("No applications have been submitted to a university.", html)
        self.assertNotIn("chart-segment-clickable", html)


class WhichApplicationsAreInTests(PageBase):
    """Only the 2027 Intake, submitted from 1 October 2026 - whatever year / Intake tab the address names."""

    ROWS = workbook_rows([
        {**app("OLD26", sub="2026-11-10"), "Intake": "September 2026"},
        {**app("Y27a", sub="2026-10-01", accepted="2026-10-11"), "Intake": "January 2027"},
        {**app("Y27b", sub="2026-09-30"), "Intake": "September 2027"},
        {**app("Y27c", sub="2026-12-05", manager="Bob", office="UK"), "Intake": "April 2027"},
        {**app("Y27d", sub="2027-01-10"), "Intake": "2027"},
        {**app("NOINT", sub="2026-11-10"), "Intake": ""},
        {**app("Y28", sub="2026-11-10"), "Intake": "March 2028"},
    ])

    def codes(self, query=""):
        _, context = self.page(query)
        return sorted(r["Student Code"] for per in context["bonus_chart"]["managers"].values() for rows in per.values() for r in rows)

    def test_only_the_2027_intake_submitted_from_1_october_2026(self):
        self.assertEqual(self.codes(), ["Y27a", "Y27c", "Y27d"])

    def test_the_year_and_intake_tabs_make_no_difference(self):
        for query in ("year=2026", "year=2027&intake=intake_03", "year=2027&intake_month=3", "year=2027&intake=intake_02&intake_month=3"):
            self.assertEqual(self.codes(query), ["Y27a", "Y27c", "Y27d"], query)

    def test_the_month_filter_picks_the_submitted_month(self):
        self.assertEqual(self.codes("sub_month=2026-10"), ["Y27a"])
        self.assertEqual(self.codes("sub_month=2026-12"), ["Y27c"])
        self.assertEqual(self.codes("sub_month=2027-01"), ["Y27d"])
        self.assertEqual(self.codes("sub_month=2026-09"), ["Y27a", "Y27c", "Y27d"], "September 2026 is not an option, so it is ignored")

    def test_the_pieces_list_their_applications(self):
        for query in ("", "sub_month=2026-10", "sub_month=2026-12"):
            _, context = self.page(query)
            for manager, status, count in self.pieces(context):
                self.assertEqual(self.records(manager, status, query).get_json()["count"], count, (query, manager, status))


if __name__ == "__main__":
    unittest.main()
