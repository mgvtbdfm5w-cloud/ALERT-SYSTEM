"""SharePoint publishing has been removed (the app now runs on Railway): no
Republish buttons or routes, nothing is written anywhere after a data change,
no SharePoint warnings - and the plain browser downloads still work."""

import io
import os
import re
import unittest

from authorization import ENDPOINT_ROLES
from tests.flask_test_support import IsolatedAppTestCase, app_module, extract_token
from tests.test_upload_atomicity import book, row


class NoSharePointTests(IsolatedAppTestCase):
    def setUp(self):
        super().setUp()
        self.full = self._client_logged_in_as("full")

    def token(self, client=None):
        return extract_token((client or self.full).get("/login").get_data(as_text=True))

    def upload(self, name="a.xlsx"):
        rows = [row(**{"Student Code": "P1", "Student Name": "A", "Application Status": "x"})]
        return self.full.post("/upload", data={"csrf_token": self.token(), "excel_file": (io.BytesIO(book(rows)), name)},
                              content_type="multipart/form-data")

    def flashes(self, response):
        page = self.full.get(response.headers["Location"]).get_data(as_text=True)
        return re.findall(r'class="flash (\w+)">([^<]+)<', page)

    # ---------------------------------------------------------------- gone
    def test_the_republish_routes_and_policy_entries_are_gone(self):
        endpoints = {rule.endpoint for rule in app_module.app.url_map.iter_rules()}
        for name in ("republish_applications", "republish_leads"):
            self.assertNotIn(name, endpoints)
            self.assertNotIn(name, ENDPOINT_ROLES)
        for path in ("/admin/republish/applications", "/admin/republish/leads"):
            self.assertEqual(self.full.post(path, data={"csrf_token": self.token()}).status_code, 404, path)

    def test_the_sharepoint_code_and_settings_are_gone_from_the_app(self):
        for name in ("SHAREPOINT_REPORTING_FOLDER", "SHAREPOINT_REFRESH_WARNING", "_atomic_write_bytes",
                     "_publish_buffer", "_refresh_sharepoint_after_data_change", "_republish"):
            self.assertFalse(hasattr(app_module, name), name)

    def test_no_page_mentions_sharepoint_or_republishing_for_any_role(self):
        for role in ("full", "admissions", "consultants", "marketing"):
            client = self._client_logged_in_as(role)
            for path in ("/admin", "/company-dashboard", "/leads-dashboard", "/consultants"):
                html = client.get(path).get_data(as_text=True)
                for text in ("SharePoint", "Republish", "republish"):
                    self.assertNotIn(text, html, (role, path, text))

    # -------------------------------------------------- data changes are quiet
    def test_an_upload_succeeds_with_only_the_success_message_and_writes_nothing_else(self):
        before = set(os.listdir(self.tmp_uploads_dir))
        response = self.upload()
        self.assertEqual(response.status_code, 302)
        self.assertEqual([kind for kind, _ in self.flashes(response)], ["success"], "no warning follows the success")
        new_files = set(os.listdir(self.tmp_uploads_dir)) - before
        self.assertEqual(len(new_files), 1, "only the uploaded workbook is stored")
        self.assertNotIn("Applications.xlsx", os.listdir(self.tmp_uploads_dir))

    def test_reprocess_succeeds_quietly(self):
        self.upload()
        response = self.full.post("/admin/reprocess", data={"csrf_token": self.token()})
        self.assertEqual([kind for kind, _ in self.flashes(response)], ["success"])

    def test_nothing_is_created_next_to_the_app_or_in_the_home_folders(self):
        """The removed feature wrote into a configured folder; point the old env var at a temp dir and prove it is ignored."""
        import tempfile
        folder = tempfile.mkdtemp(prefix="gsp_old_sharepoint_")
        os.environ["SHAREPOINT_REPORTING_FOLDER"] = folder
        self.addCleanup(os.environ.pop, "SHAREPOINT_REPORTING_FOLDER", None)
        self.upload()
        self.assertEqual(os.listdir(folder), [])
        os.rmdir(folder)

    # ------------------------------------------------ downloads still work
    def test_the_browser_downloads_still_work_and_are_unchanged(self):
        self.upload()
        r = self.full.get("/download")
        self.assertEqual(r.status_code, 200)
        self.assertIn("Applications.xlsx", r.headers["Content-Disposition"])
        self.assertTrue(r.get_data().startswith(b"PK"), "a real .xlsx file")
        html = self.full.get("/admin").get_data(as_text=True)
        self.assertIn('href="/download"', html)
        self.assertIn("Download Spreadsheet", html)

    def test_the_admin_upload_and_reprocess_controls_are_still_there(self):
        html = self.full.get("/admin").get_data(as_text=True)
        for text in ('action="/upload"', 'action="/leads/upload"', 'action="/admin/reprocess"'):
            self.assertIn(text, html)


if __name__ == "__main__":
    unittest.main()
