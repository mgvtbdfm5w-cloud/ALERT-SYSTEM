import logging
import unittest
from datetime import date, timedelta
from unittest import mock

import healthcheck
from healthcheck import (
    ApplicationManagerStillAdmissionsRule,
    ApprovedButPendingSubmissionRule,
    ApprovedMissingSubmittedToUniRule,
    DATE_COMPLETENESS_CUTOFF,
    DuplicateStudentCodeOpenApplicationsRule,
    HealthcheckDatasetRule,
    HealthcheckRule,
    InvalidConsultantMappingRule,
    MultipleAdmissionOfficersRule,
    NewAppStuckRule,
    QAPassedMissingDocsApprovedRule,
    QAStuckRule,
    SubmittedToUniNotApprovedRule,
    UnassignedApplicationManagerPreOfferRule,
    UnassignedSupportSubmittedRule,
    _business_days_since,
    run_healthcheck,
)


class InvalidConsultantMappingRuleTests(unittest.TestCase):
    def setUp(self):
        self.rule = InvalidConsultantMappingRule()

    def test_triggers_when_consultant_has_no_sales_office(self):
        message = self.rule.evaluate({"Consultant": "Raneen", "Sales Office": ""})
        self.assertIsNotNone(message)
        self.assertIn("Raneen", message)

    def test_does_not_trigger_when_sales_office_present(self):
        self.assertIsNone(self.rule.evaluate({"Consultant": "Raneen", "Sales Office": "OXF"}))

    def test_does_not_trigger_when_consultant_blank(self):
        self.assertIsNone(self.rule.evaluate({"Consultant": "", "Sales Office": ""}))


class ApplicationManagerStillAdmissionsRuleTests(unittest.TestCase):
    def setUp(self):
        self.rule = ApplicationManagerStillAdmissionsRule()

    def test_triggers_for_flagged_status(self):
        self.assertIsNotNone(
            self.rule.evaluate({"Application": "Admissions", "Status": "05-Assessment"})
        )

    def test_triggers_case_insensitive_and_trimmed(self):
        self.assertIsNotNone(
            self.rule.evaluate({"Application": "  admissions  ", "Status": "09-Enrolled"})
        )

    def test_does_not_trigger_for_10_lost(self):
        self.assertIsNone(
            self.rule.evaluate({"Application": "Admissions", "Status": "10-Lost"})
        )

    def test_does_not_trigger_for_status_outside_flagged_set(self):
        self.assertIsNone(
            self.rule.evaluate({"Application": "Admissions", "Status": "01-NewApp"})
        )

    def test_does_not_trigger_for_a_real_manager(self):
        self.assertIsNone(
            self.rule.evaluate({"Application": "Mo", "Status": "05-Assessment"})
        )

    def test_does_not_trigger_for_blank_application(self):
        self.assertIsNone(
            self.rule.evaluate({"Application": "", "Status": "05-Assessment"})
        )

    def test_boundary_08_pre_enrolled_is_flagged(self):
        # Current Data's real value for this stage - see the rule's own
        # comment on why this counts as the "09-PreEnrolled" stage.
        self.assertIsNotNone(
            self.rule.evaluate({"Application": "Admissions", "Status": "08-Pre-Enrolled"})
        )

    def test_flagged_statuses_are_derived_from_pipeline_stages_not_a_hardcoded_copy(self):
        # Regression: _FLAGGED_STATUSES used to be a hand-typed copy of
        # pipeline.STAGES minus "10-Lost" - if a new stage were ever added
        # to pipeline.STAGES, this rule wouldn't know about it. Deriving it
        # directly means every stage except 10-Lost is always covered.
        from pipeline import STAGES
        self.assertEqual(self.rule._FLAGGED_STATUSES, set(STAGES) - {"10-Lost"})

    def test_every_pipeline_stage_except_lost_is_flagged(self):
        from pipeline import STAGES
        for status in STAGES:
            result = self.rule.evaluate({"Application": "Admissions", "Status": status})
            if status == "10-Lost":
                self.assertIsNone(result, f"{status} should not be flagged")
            else:
                self.assertIsNotNone(result, f"{status} should be flagged")


class MultipleAdmissionOfficersRuleTests(unittest.TestCase):
    def setUp(self):
        self.rule = MultipleAdmissionOfficersRule()

    def test_triggers_on_comma(self):
        message = self.rule.evaluate({"_raw": {"Admission Officer": "Sam, Alex"}})
        self.assertIsNotNone(message)

    def test_triggers_on_the_word_and(self):
        self.assertIsNotNone(
            self.rule.evaluate({"_raw": {"Admission Officer": "Sam and Alex"}})
        )

    def test_does_not_trigger_for_single_name(self):
        self.assertIsNone(self.rule.evaluate({"_raw": {"Admission Officer": "Sam"}}))

    def test_does_not_trigger_for_blank(self):
        self.assertIsNone(self.rule.evaluate({"_raw": {"Admission Officer": ""}}))

    def test_does_not_trigger_when_raw_missing_entirely(self):
        self.assertIsNone(self.rule.evaluate({}))


class ApprovedMissingSubmittedToUniRuleTests(unittest.TestCase):
    def setUp(self):
        self.rule = ApprovedMissingSubmittedToUniRule()

    def test_triggers_when_approved_and_no_submitted_date(self):
        self.assertIsNotNone(
            self.rule.evaluate({"Sub Status": "Approved", "Submitted To Uni": None})
        )

    def test_triggers_case_insensitive_and_trimmed(self):
        self.assertIsNotNone(
            self.rule.evaluate({"Sub Status": "approved ", "Submitted To Uni": None})
        )

    def test_triggers_regardless_of_created_date(self):
        # This rule was deliberately broadened to have NO Created-date
        # cutoff, unlike QAPassedMissingDocsApprovedRule - it must catch
        # legacy/migrated records too.
        self.assertIsNotNone(
            self.rule.evaluate(
                {"Sub Status": "Approved", "Submitted To Uni": None, "Created": "2020-01-01"}
            )
        )

    def test_does_not_trigger_when_submitted_date_present(self):
        self.assertIsNone(
            self.rule.evaluate({"Sub Status": "Approved", "Submitted To Uni": "2026-01-01"})
        )

    def test_does_not_trigger_for_other_sub_status(self):
        self.assertIsNone(
            self.rule.evaluate({"Sub Status": "Pending", "Submitted To Uni": None})
        )


class SubmittedToUniNotApprovedRuleTests(unittest.TestCase):
    def setUp(self):
        self.rule = SubmittedToUniNotApprovedRule()

    def test_triggers_for_blank_sub_status(self):
        self.assertIsNotNone(
            self.rule.evaluate({"Submitted To Uni": "2026-01-01", "Sub Status": ""})
        )

    def test_triggers_for_non_approved_sub_status(self):
        self.assertIsNotNone(
            self.rule.evaluate({"Submitted To Uni": "2026-01-01", "Sub Status": "Pending"})
        )

    def test_does_not_trigger_for_approved(self):
        self.assertIsNone(
            self.rule.evaluate({"Submitted To Uni": "2026-01-01", "Sub Status": "Approved"})
        )

    def test_does_not_trigger_for_approved_case_insensitive(self):
        self.assertIsNone(
            self.rule.evaluate({"Submitted To Uni": "2026-01-01", "Sub Status": "approved"})
        )

    def test_does_not_trigger_for_blank_submitted_date(self):
        self.assertIsNone(
            self.rule.evaluate({"Submitted To Uni": None, "Sub Status": "Pending"})
        )

    def test_malformed_submitted_date_does_not_crash_or_trigger(self):
        self.assertIsNone(
            self.rule.evaluate({"Submitted To Uni": "not-a-date", "Sub Status": "Pending"})
        )


class UnassignedApplicationManagerPreOfferRuleTests(unittest.TestCase):
    def setUp(self):
        self.rule = UnassignedApplicationManagerPreOfferRule()

    def test_triggers_for_blank_application_pre_offer(self):
        self.assertIsNotNone(
            self.rule.evaluate(
                {"Status": "05-Assessment", "Submitted To Uni": "2026-08-01", "Application": ""}
            )
        )

    def test_does_not_trigger_when_manager_assigned(self):
        self.assertIsNone(
            self.rule.evaluate(
                {"Status": "05-Assessment", "Submitted To Uni": "2026-08-01", "Application": "Mo"}
            )
        )

    def test_does_not_trigger_outside_qualifying_statuses(self):
        self.assertIsNone(
            self.rule.evaluate(
                {"Status": "07-Ready", "Submitted To Uni": "2026-08-01", "Application": ""}
            )
        )

    def test_does_not_trigger_without_a_submitted_date(self):
        self.assertIsNone(
            self.rule.evaluate(
                {"Status": "05-Assessment", "Submitted To Uni": None, "Application": ""}
            )
        )


class UnassignedSupportSubmittedRuleTests(unittest.TestCase):
    """Scoped to the most recent month with Submitted To Uni data, matching
    the Submissions page's default chart view exactly."""

    def setUp(self):
        self.rule = UnassignedSupportSubmittedRule()

    def test_flags_blank_support_in_the_most_recent_month(self):
        rows = [
            {"Student Code": "PES1", "Submitted To Uni": "2026-08-05", "Support": ""},
            {"Student Code": "PES2", "Submitted To Uni": "2026-08-10", "Support": "Yara"},
        ]
        issues = self.rule.evaluate(rows)
        self.assertEqual(issues, [("PES1", "Submitted To Uni date is recorded but no Support person is assigned.")])

    def test_does_not_flag_blank_support_in_an_older_month(self):
        rows = [
            {"Student Code": "PES1", "Submitted To Uni": "2026-07-05", "Support": ""},
            {"Student Code": "PES2", "Submitted To Uni": "2026-08-10", "Support": "Yara"},
        ]
        # August (the more recent month) has no unassigned rows, so the
        # July row - even though it's blank - is outside the scope of
        # "this month's" chart and must not be flagged.
        self.assertEqual(self.rule.evaluate(rows), [])

    def test_whitespace_only_support_still_counts_as_blank(self):
        rows = [{"Student Code": "PES1", "Submitted To Uni": "2026-08-05", "Support": "   "}]
        self.assertEqual(len(self.rule.evaluate(rows)), 1)

    def test_rows_without_a_submitted_date_are_ignored(self):
        rows = [
            {"Student Code": "PES1", "Submitted To Uni": None, "Support": ""},
            {"Student Code": "PES2", "Submitted To Uni": "2026-08-10", "Support": "Yara"},
        ]
        self.assertEqual(self.rule.evaluate(rows), [])

    def test_no_submission_data_at_all_returns_no_issues(self):
        self.assertEqual(self.rule.evaluate([]), [])


class QAPassedMissingDocsApprovedRuleTests(unittest.TestCase):
    def setUp(self):
        self.rule = QAPassedMissingDocsApprovedRule()

    def test_triggers_after_cutoff_with_missing_docs_approved(self):
        message = self.rule.evaluate(
            {"Created": "2026-08-01", "QA Passed": "2026-08-05", "Docs Approved": None}
        )
        self.assertIsNotNone(message)

    def test_does_not_trigger_on_cutoff_date_itself(self):
        # DATE_COMPLETENESS_CUTOFF is exclusive - "Created <= cutoff" is
        # excluded, so a record created exactly on the cutoff date must not
        # be flagged (it's treated as a legacy/migrated record).
        self.assertIsNone(
            self.rule.evaluate(
                {
                    "Created": DATE_COMPLETENESS_CUTOFF.isoformat(),
                    "QA Passed": "2026-08-05",
                    "Docs Approved": None,
                }
            )
        )

    def test_triggers_one_day_after_cutoff(self):
        self.assertIsNotNone(
            self.rule.evaluate(
                {"Created": "2026-08-01", "QA Passed": "2026-08-05", "Docs Approved": None}
            )
        )

    def test_does_not_trigger_when_docs_approved_present(self):
        self.assertIsNone(
            self.rule.evaluate(
                {
                    "Created": "2026-08-01",
                    "QA Passed": "2026-08-05",
                    "Docs Approved": "2026-08-06",
                }
            )
        )

    def test_does_not_trigger_without_qa_passed(self):
        self.assertIsNone(
            self.rule.evaluate({"Created": "2026-08-01", "QA Passed": None, "Docs Approved": None})
        )

    def test_does_not_trigger_before_cutoff(self):
        self.assertIsNone(
            self.rule.evaluate(
                {"Created": "2020-01-01", "QA Passed": "2026-08-05", "Docs Approved": None}
            )
        )


class ApprovedButPendingSubmissionRuleTests(unittest.TestCase):
    def setUp(self):
        self.rule = ApprovedButPendingSubmissionRule()

    def test_triggers_for_approved_and_pending_submission(self):
        message = self.rule.evaluate({"Sub Status": "Approved", "Status": "03-PendingSubmission"})
        self.assertEqual(
            message, "Sub Status is Approved but application is still at 03-PendingSubmission."
        )

    def test_triggers_case_insensitive_and_trimmed(self):
        self.assertIsNotNone(
            self.rule.evaluate({"Sub Status": " approved ", "Status": " 03-pendingsubmission "})
        )

    def test_does_not_trigger_for_04_onboarding(self):
        self.assertIsNone(
            self.rule.evaluate({"Sub Status": "Approved", "Status": "04-Onboarding"})
        )

    def test_does_not_trigger_for_05_assessment(self):
        self.assertIsNone(
            self.rule.evaluate({"Sub Status": "Approved", "Status": "05-Assessment"})
        )

    def test_does_not_trigger_for_non_approved_sub_status(self):
        self.assertIsNone(
            self.rule.evaluate({"Sub Status": "Pending", "Status": "03-PendingSubmission"})
        )

    def test_does_not_trigger_for_blank_sub_status(self):
        self.assertIsNone(
            self.rule.evaluate({"Sub Status": "", "Status": "03-PendingSubmission"})
        )

    def test_does_not_trigger_for_blank_status(self):
        self.assertIsNone(
            self.rule.evaluate({"Sub Status": "Approved", "Status": ""})
        )

    def test_does_not_use_submitted_to_uni_at_all(self):
        # This is a current-state contradiction only - Submitted To Uni must
        # play no part, positive or negative, in this rule's decision.
        with_date = self.rule.evaluate(
            {"Sub Status": "Approved", "Status": "03-PendingSubmission", "Submitted To Uni": "2026-01-01"}
        )
        without_date = self.rule.evaluate(
            {"Sub Status": "Approved", "Status": "03-PendingSubmission", "Submitted To Uni": None}
        )
        self.assertEqual(with_date, without_date)
        self.assertIsNotNone(with_date)


class BusinessDaysSinceTests(unittest.TestCase):
    """Weekends within the span don't count - a stretch that includes a
    Saturday/Sunday takes more calendar days to reach a given business-day
    total than one that doesn't."""

    def test_no_weekend_in_range_matches_calendar_days(self):
        # Thursday 2026-09-10 -> reference Monday 2026-09-14 is 4 calendar
        # days, spanning one weekend (Sat 12, Sun 13) - 2 business days
        # (Fri 11, Mon 14).
        reference = date(2026, 9, 14)  # Monday
        self.assertEqual(_business_days_since(4, reference), 2)

    def test_pure_weekday_span_counts_every_day(self):
        # Monday 2026-09-14 -> Wednesday 2026-09-16: 2 calendar days, no
        # weekend crossed, so 2 business days too.
        reference = date(2026, 9, 16)  # Wednesday
        self.assertEqual(_business_days_since(2, reference), 2)

    def test_zero_days_ago_is_zero_business_days(self):
        reference = date(2026, 9, 16)
        self.assertEqual(_business_days_since(0, reference), 0)

    def test_defaults_to_today_uk_when_no_reference_given(self):
        with mock.patch("healthcheck._today_uk", return_value=date(2026, 9, 16)):
            self.assertEqual(_business_days_since(2), 2)


class _StageStuckRuleTestsMixin:
    """Shared test bodies for NewAppStuckRule/QAStuckRule - each subclass
    sets rule_cls/matching_status/other_status."""

    rule_cls = None
    matching_status = None
    other_status = None

    def setUp(self):
        self.rule = self.rule_cls()

    def _reference(self):
        return date(2026, 9, 18)  # Friday - the last 4 calendar days (Mon-Fri) contain no weekend

    def test_does_not_trigger_below_threshold(self):
        with mock.patch("healthcheck._today_uk", return_value=self._reference()):
            self.assertIsNone(
                self.rule.evaluate({"Status": self.matching_status, "Stage Length": "3 Days ago"})
            )

    def test_triggers_at_threshold(self):
        with mock.patch("healthcheck._today_uk", return_value=self._reference()):
            message = self.rule.evaluate({"Status": self.matching_status, "Stage Length": "4 Days ago"})
            self.assertIsNotNone(message)
            self.assertIn(self.rule.stage_name, message)

    def test_triggers_above_threshold(self):
        with mock.patch("healthcheck._today_uk", return_value=self._reference()):
            self.assertIsNotNone(
                self.rule.evaluate({"Status": self.matching_status, "Stage Length": "32 Days ago"})
            )

    def test_does_not_trigger_for_a_different_status(self):
        with mock.patch("healthcheck._today_uk", return_value=self._reference()):
            self.assertIsNone(
                self.rule.evaluate({"Status": self.other_status, "Stage Length": "32 Days ago"})
            )

    def test_does_not_trigger_when_stage_length_missing(self):
        self.assertIsNone(self.rule.evaluate({"Status": self.matching_status, "Stage Length": ""}))

    def test_does_not_trigger_when_stage_length_unparseable(self):
        self.assertIsNone(
            self.rule.evaluate({"Status": self.matching_status, "Stage Length": "unknown"})
        )

    def test_weekend_span_needs_more_calendar_days_to_trigger(self):
        # Monday reference: "4 Days ago" lands on Thursday, spanning last
        # weekend - only 2 business days, so must NOT trigger yet even
        # though the same 4-calendar-day count triggers on a weekday-only
        # reference (see test_triggers_at_threshold).
        monday = date(2026, 9, 14)
        with mock.patch("healthcheck._today_uk", return_value=monday):
            self.assertIsNone(
                self.rule.evaluate({"Status": self.matching_status, "Stage Length": "4 Days ago"})
            )
            # 6 calendar days ago from Monday crosses the same weekend and
            # reaches exactly 4 business days (Thu, Fri, Mon... need one
            # more): verify by asserting the business-day math directly
            # rather than guessing further calendar offsets.
            message = self.rule.evaluate({"Status": self.matching_status, "Stage Length": "6 Days ago"})
            self.assertIsNotNone(message)


class NewAppStuckRuleTests(_StageStuckRuleTestsMixin, unittest.TestCase):
    rule_cls = NewAppStuckRule
    matching_status = "01-NewApp"
    other_status = "02-PendingQA"


class QAStuckRuleTests(_StageStuckRuleTestsMixin, unittest.TestCase):
    rule_cls = QAStuckRule
    matching_status = "02-PendingQA"
    other_status = "01-NewApp"


class DuplicateStudentCodeOpenApplicationsRuleTests(unittest.TestCase):
    def setUp(self):
        self.rule = DuplicateStudentCodeOpenApplicationsRule()

    def _row(self, student_code, status):
        return {"Student Code": student_code, "Status": status}

    def test_two_open_records_same_code_triggers_one_issue(self):
        rows = [
            self._row("PES123456", "05-Assessment"),
            self._row("PES123456", "06-Decision"),
        ]
        issues = self.rule.evaluate(rows)
        self.assertEqual(issues, [("PES123456", "Two Open Applications")])

    def test_three_open_records_same_code_still_only_one_issue(self):
        rows = [
            self._row("PES123456", "05-Assessment"),
            self._row("PES123456", "06-Decision"),
            self._row("PES123456", "07-Ready"),
        ]
        issues = self.rule.evaluate(rows)
        self.assertEqual(issues, [("PES123456", "Two Open Applications")])

    def test_one_open_one_lost_does_not_trigger(self):
        rows = [
            self._row("PES123456", "05-Assessment"),
            self._row("PES123456", "10-Lost"),
        ]
        self.assertEqual(self.rule.evaluate(rows), [])

    def test_two_lost_records_does_not_trigger(self):
        rows = [
            self._row("PES123456", "10-Lost"),
            self._row("PES123456", "10-Lost"),
        ]
        self.assertEqual(self.rule.evaluate(rows), [])

    def test_different_student_codes_do_not_trigger(self):
        rows = [
            self._row("PES111111", "05-Assessment"),
            self._row("PES222222", "05-Assessment"),
        ]
        self.assertEqual(self.rule.evaluate(rows), [])

    def test_lost_comparison_is_safe_against_spacing_and_case(self):
        rows = [
            self._row("PES123456", "05-Assessment"),
            self._row("PES123456", "  10-lost  "),
        ]
        self.assertEqual(self.rule.evaluate(rows), [])

    def test_only_the_specific_closed_statuses_are_excluded(self):
        # Two different genuinely-active statuses (neither Lost,
        # QA-Rejected, nor Deferred) must still both count as open.
        rows = [
            self._row("PES123456", "07-Ready"),
            self._row("PES123456", "08-Pre-Enrolled"),
        ]
        self.assertEqual(self.rule.evaluate(rows), [("PES123456", "Two Open Applications")])

    def test_one_open_one_qa_rejected_does_not_trigger(self):
        # Regression: a real open application plus a QA-Rejected attempt is
        # only one open application, not two - this was the actual bug
        # (e.g. Student Code PES1924058: 01-NewApp + 00-QARejected).
        rows = [
            self._row("PES123456", "01-NewApp"),
            self._row("PES123456", "00-QARejected"),
        ]
        self.assertEqual(self.rule.evaluate(rows), [])

    def test_two_qa_rejected_records_does_not_trigger(self):
        # Two rejected attempts and nothing else means zero open
        # applications, not two.
        rows = [
            self._row("PES123456", "00-QARejected"),
            self._row("PES123456", "00-QARejected"),
        ]
        self.assertEqual(self.rule.evaluate(rows), [])

    def test_qa_rejected_comparison_is_safe_against_spacing_and_case(self):
        rows = [
            self._row("PES123456", "05-Assessment"),
            self._row("PES123456", "  00-qarejected  "),
        ]
        self.assertEqual(self.rule.evaluate(rows), [])

    def test_multiple_qa_rejected_resubmissions_plus_one_open_does_not_trigger(self):
        # Real-world pattern: a student can be QA-rejected and resubmit
        # several times - none of those rejected attempts should ever push
        # the count to "open" >= 2.
        rows = [
            self._row("PES123456", "03-PendingSubmission"),
            self._row("PES123456", "00-QARejected"),
            self._row("PES123456", "00-QARejected"),
            self._row("PES123456", "00-QARejected"),
        ]
        self.assertEqual(self.rule.evaluate(rows), [])

    def test_one_open_one_deferred_does_not_trigger(self):
        rows = [
            self._row("PES123456", "01-NewApp"),
            self._row("PES123456", "11-Deferred"),
        ]
        self.assertEqual(self.rule.evaluate(rows), [])

    def test_two_deferred_records_does_not_trigger(self):
        rows = [
            self._row("PES123456", "11-Deferred"),
            self._row("PES123456", "11-Deferred"),
        ]
        self.assertEqual(self.rule.evaluate(rows), [])

    def test_lost_qa_rejected_and_deferred_together_with_one_open_does_not_trigger(self):
        rows = [
            self._row("PES123456", "05-Assessment"),
            self._row("PES123456", "10-Lost"),
            self._row("PES123456", "00-QARejected"),
            self._row("PES123456", "11-Deferred"),
        ]
        self.assertEqual(self.rule.evaluate(rows), [])

    def test_two_genuinely_open_records_still_triggers_alongside_a_qa_rejected_one(self):
        # Confirms the fix only stops closed statuses from being miscounted
        # as open - it must not also start under-counting genuinely
        # duplicate open applications.
        rows = [
            self._row("PES123456", "05-Assessment"),
            self._row("PES123456", "06-Decision"),
            self._row("PES123456", "00-QARejected"),
        ]
        self.assertEqual(self.rule.evaluate(rows), [("PES123456", "Two Open Applications")])

    def test_unexpected_blank_student_code_is_never_grouped_into_a_duplicate(self):
        rows = [
            self._row("", "05-Assessment"),
            self._row(None, "06-Decision"),
            self._row("   ", "07-Ready"),
        ]
        self.assertEqual(self.rule.evaluate(rows), [])

    def test_empty_dataset_returns_no_issues(self):
        self.assertEqual(self.rule.evaluate([]), [])


class RunHealthcheckEngineTests(unittest.TestCase):
    def test_one_student_can_generate_multiple_issues(self):
        # Deliberately breaks three independent rules at once.
        row = {
            "Student Code": "S001",
            "Consultant": "Raneen",
            "Sales Office": "",
            "Application": "Admissions",
            "Status": "05-Assessment",
            "Submitted To Uni": None,
            "Sub Status": "Approved",
            "Created": "2026-08-01",
            "QA Passed": "2026-08-05",
            "Docs Approved": None,
            "_raw": {},
        }
        issues = run_healthcheck([row])
        rule_ids = {issue["rule_id"] for issue in issues}
        self.assertGreaterEqual(len(issues), 3)
        self.assertTrue(all(issue["student_code"] == "S001" for issue in issues))
        self.assertIn("invalid_consultant_mapping", rule_ids)
        self.assertIn("application_manager_still_admissions", rule_ids)
        self.assertIn("approved_missing_submitted_to_uni", rule_ids)

    def test_a_broken_rule_does_not_stop_the_rest_of_the_engine(self):
        class BrokenRule(HealthcheckRule):
            id = "broken_rule"
            name = "Deliberately Broken Rule"

            def evaluate(self, row):
                raise RuntimeError("boom")

        good_row = {"Student Code": "S002", "Consultant": "Raneen", "Sales Office": ""}

        with mock.patch.object(
            healthcheck,
            "RULES",
            [BrokenRule(), InvalidConsultantMappingRule()],
        ):
            with self.assertLogs("healthcheck", level="ERROR") as captured:
                issues = run_healthcheck([good_row])

        # The good rule after the broken one must still have run and fired.
        self.assertEqual(len(issues), 1)
        self.assertEqual(issues[0]["rule_id"], "invalid_consultant_mapping")
        # The failure must be logged, not silently dropped.
        self.assertTrue(
            any("broken_rule" in message or "Broken Rule" in message for message in captured.output)
        )

    def test_empty_dataset_produces_no_issues_and_does_not_raise(self):
        self.assertEqual(run_healthcheck([]), [])

    def test_existing_row_level_rules_are_unaffected_by_the_dataset_rule(self):
        # A single row, no duplicate Student Code involved at all - the
        # dataset-level rule must contribute nothing here, and the row-level
        # result must be identical to before dataset rules existed.
        row = {
            "Student Code": "S010",
            "Status": "05-Assessment",
            "Consultant": "Raneen",
            "Sales Office": "",
        }
        issues = run_healthcheck([row])
        self.assertEqual(len(issues), 1)
        self.assertEqual(issues[0]["rule_id"], "invalid_consultant_mapping")

    def test_duplicate_student_code_issue_appears_alongside_unrelated_row_issues(self):
        # Same student appears twice (both open -> triggers the dataset
        # rule) and also breaks an unrelated row-level rule on one of the
        # two rows - both issue types must appear for this student.
        rows = [
            {
                "Student Code": "S020",
                "Status": "05-Assessment",
                "Consultant": "Raneen",
                "Sales Office": "",
            },
            {
                "Student Code": "S020",
                "Status": "06-Decision",
                "Consultant": "",
                "Sales Office": "",
            },
        ]
        issues = run_healthcheck(rows)
        rule_ids = [issue["rule_id"] for issue in issues]
        self.assertIn("invalid_consultant_mapping", rule_ids)
        self.assertIn("duplicate_student_code_open_applications", rule_ids)
        self.assertEqual(rule_ids.count("duplicate_student_code_open_applications"), 1)

        duplicate_issue = next(
            i for i in issues if i["rule_id"] == "duplicate_student_code_open_applications"
        )
        self.assertEqual(duplicate_issue["student_code"], "S020")
        self.assertEqual(duplicate_issue["message"], "Two Open Applications")

    def test_a_broken_dataset_rule_does_not_stop_the_rest_of_the_engine(self):
        class BrokenDatasetRule(HealthcheckDatasetRule):
            id = "broken_dataset_rule"
            name = "Deliberately Broken Dataset Rule"

            def evaluate(self, rows):
                raise RuntimeError("boom")

        rows = [
            {"Student Code": "S030", "Consultant": "Raneen", "Sales Office": ""},
        ]

        with mock.patch.object(healthcheck, "DATASET_RULES", [BrokenDatasetRule()]):
            with self.assertLogs("healthcheck", level="ERROR") as captured:
                issues = run_healthcheck(rows)

        # Row-level rules must still have run normally.
        self.assertEqual(len(issues), 1)
        self.assertEqual(issues[0]["rule_id"], "invalid_consultant_mapping")
        self.assertTrue(
            any(
                "broken_dataset_rule" in message or "Broken Dataset Rule" in message
                for message in captured.output
            )
        )


if __name__ == "__main__":
    unittest.main()
