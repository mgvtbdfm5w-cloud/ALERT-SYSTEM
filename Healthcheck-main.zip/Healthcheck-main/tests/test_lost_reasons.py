import unittest

from lost_reasons import build_lost_reason_report, filter_by_field, list_distinct_values


def _row(status="10-Lost", reason=None, sub_reason=None, **extra):
    row = {"Status": status, "Lost Reason": reason, "Lost Sub Reason": sub_reason}
    row.update(extra)
    return row


class OnlyLostStatusCountsTests(unittest.TestCase):
    def test_non_lost_rows_are_excluded_even_with_a_reason_set(self):
        rows = [
            _row(status="05-Assessment", reason="InternalDecision", sub_reason="LossOfInterest"),
            _row(status="10-Lost", reason="InternalDecision", sub_reason="LossOfInterest"),
        ]
        report = build_lost_reason_report(rows)
        self.assertEqual(report["total"], 1)

    def test_empty_rows_produces_an_empty_report_not_a_crash(self):
        report = build_lost_reason_report([])
        self.assertEqual(report["total"], 0)
        self.assertEqual(report["reason_groups"], [])


class GroupingTests(unittest.TestCase):
    def setUp(self):
        self.rows = [
            _row(reason="InternalDecision", sub_reason="LossOfInterest"),
            _row(reason="InternalDecision", sub_reason="LossOfInterest"),
            _row(reason="InternalDecision", sub_reason="UniversityIssue"),
            _row(reason="StudentWithdrew", sub_reason="ChangedMind"),
        ]
        self.report = build_lost_reason_report(self.rows)

    def test_total_counts_every_lost_row(self):
        self.assertEqual(self.report["total"], 4)

    def test_reason_group_totals(self):
        totals = {g["reason"]: g["total"] for g in self.report["reason_groups"]}
        self.assertEqual(totals, {"InternalDecision": 3, "StudentWithdrew": 1})

    def test_reason_total_equals_sum_of_its_sub_reason_rows(self):
        for group in self.report["reason_groups"]:
            self.assertEqual(group["total"], sum(r["count"] for r in group["rows"]))

    def test_reason_groups_ranked_by_total_descending(self):
        names = [g["reason"] for g in self.report["reason_groups"]]
        self.assertEqual(names, ["InternalDecision", "StudentWithdrew"])

    def test_sub_reason_rows_within_a_group_ranked_by_count_descending(self):
        internal = next(g for g in self.report["reason_groups"] if g["reason"] == "InternalDecision")
        sub_reasons = [r["name"] for r in internal["rows"]]
        self.assertEqual(sub_reasons, ["LossOfInterest", "UniversityIssue"])


class TieBreakTests(unittest.TestCase):
    def test_reason_tie_breaks_alphabetically(self):
        rows = [
            _row(reason="Zed Reason", sub_reason="X"),
            _row(reason="Amy Reason", sub_reason="Y"),
        ]
        report = build_lost_reason_report(rows)
        names = [g["reason"] for g in report["reason_groups"]]
        self.assertEqual(names, ["Amy Reason", "Zed Reason"])

    def test_sub_reason_tie_breaks_alphabetically(self):
        rows = [
            _row(reason="Reason", sub_reason="Zed Sub"),
            _row(reason="Reason", sub_reason="Amy Sub"),
        ]
        report = build_lost_reason_report(rows)
        sub_reasons = [r["name"] for r in report["reason_groups"][0]["rows"]]
        self.assertEqual(sub_reasons, ["Amy Sub", "Zed Sub"])


class BlankReasonAndSubReasonTests(unittest.TestCase):
    def test_blank_reason_folds_into_unassigned(self):
        rows = [_row(reason="", sub_reason="whatever"), _row(reason=None, sub_reason="whatever")]
        report = build_lost_reason_report(rows)
        names = [g["reason"] for g in report["reason_groups"]]
        self.assertEqual(names, ["Unassigned"])
        self.assertEqual(report["reason_groups"][0]["total"], 2)

    def test_blank_sub_reason_folds_into_unassigned(self):
        rows = [_row(reason="InternalDecision", sub_reason=""), _row(reason="InternalDecision", sub_reason=None)]
        report = build_lost_reason_report(rows)
        sub_reasons = [r["name"] for r in report["reason_groups"][0]["rows"]]
        self.assertEqual(sub_reasons, ["Unassigned"])
        self.assertEqual(report["reason_groups"][0]["rows"][0]["count"], 2)


class BarWidthTests(unittest.TestCase):
    def test_row_width_scales_against_the_busiest_row_on_the_whole_page_not_just_its_group(self):
        # "Big" reason has a sub-reason with count 10 (the page-wide max).
        # "Small" reason's own sub-reason (count 2) must scale against that
        # same page-wide max (2/10=20%), not against its own group's max
        # (which would wrongly show 100%, since it's the only row there).
        rows = (
            [_row(reason="Big", sub_reason="A")] * 10
            + [_row(reason="Small", sub_reason="B")] * 2
        )
        report = build_lost_reason_report(rows)
        by_reason = {g["reason"]: g for g in report["reason_groups"]}

        big_row = by_reason["Big"]["rows"][0]
        self.assertAlmostEqual(big_row["width_pct"], 100.0)

        small_row = by_reason["Small"]["rows"][0]
        self.assertAlmostEqual(small_row["width_pct"], 20.0)  # 2/10 * 100, NOT 2/2=100

    def test_zero_rows_does_not_divide_by_zero(self):
        report = build_lost_reason_report([])
        self.assertEqual(report["reason_groups"], [])


class ListDistinctValuesTests(unittest.TestCase):
    def test_lists_distinct_values_alphabetically(self):
        rows = [
            _row(Consultant="Zed"),
            _row(Consultant="Amy"),
            _row(Consultant="Amy"),
        ]
        self.assertEqual(list_distinct_values(rows, "Consultant"), ["Amy", "Zed"])

    def test_blank_folds_into_unassigned(self):
        rows = [_row(Consultant=""), _row(Consultant=None)]
        self.assertEqual(list_distinct_values(rows, "Consultant"), ["Unassigned"])

    def test_only_lost_rows_contribute_options(self):
        rows = [
            _row(status="05-Assessment", Consultant="NotLostPerson"),
            _row(status="10-Lost", Consultant="LostPerson"),
        ]
        self.assertEqual(list_distinct_values(rows, "Consultant"), ["LostPerson"])

    def test_works_for_application_manager_field_too(self):
        rows = [_row(Application="Nouran"), _row(Application="Anum")]
        self.assertEqual(list_distinct_values(rows, "Application"), ["Anum", "Nouran"])

    def test_empty_rows_returns_empty_list(self):
        self.assertEqual(list_distinct_values([], "Consultant"), [])


class FilterByFieldTests(unittest.TestCase):
    def test_matches_exact_value(self):
        rows = [_row(Consultant="Mo"), _row(Consultant="Raneen")]
        filtered = filter_by_field(rows, "Consultant", "Mo")
        self.assertEqual(len(filtered), 1)
        self.assertEqual(filtered[0]["Consultant"], "Mo")

    def test_matches_unassigned_for_blank_values(self):
        rows = [_row(Consultant=""), _row(Consultant="Mo")]
        filtered = filter_by_field(rows, "Consultant", "Unassigned")
        self.assertEqual(len(filtered), 1)

    def test_no_match_returns_empty_list(self):
        rows = [_row(Consultant="Mo")]
        self.assertEqual(filter_by_field(rows, "Consultant", "Raneen"), [])

    def test_works_for_application_manager_field_too(self):
        rows = [_row(Application="Nouran"), _row(Application="Anum")]
        filtered = filter_by_field(rows, "Application", "Nouran")
        self.assertEqual(len(filtered), 1)
        self.assertEqual(filtered[0]["Application"], "Nouran")


if __name__ == "__main__":
    unittest.main()
