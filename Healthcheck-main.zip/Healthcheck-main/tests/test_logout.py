"""Logout is POST-only and CSRF-protected.

Pins the design: `POST /logout` with a valid CSRF token clears the session
and redirects to /login; GET and HEAD are refused (405) and never touch the
session, so a cross-site link, prefetch or crawler cannot log anyone out;
a missing / invalid / other-session token is the normal 400 and the session
survives; logout stays OUTSIDE role authorization (authorization
.PUBLIC_ENDPOINTS) so even a session with an unknown or tampered role can
clear itself; the nav renders a small POST form (not an anchor); and one
deliberate friendly case - a still-logged-in user whose Logout button has
EXPIRED - is redirected with a message instead of a bare 400, without ever
clearing the session or loosening CSRF.

Uses the shared isolated Flask test infrastructure (temp database, uploads
folders; CSRFProtect never disabled).
"""

import ast
import inspect
import re
import time
import unittest
from contextlib import contextmanager
from unittest import mock

from authorization import ENDPOINT_ROLES, KNOWN_ROLES, PUBLIC_ENDPOINTS
from tests.flask_test_support import ROLE_PASSWORDS, IsolatedAppTestCase, app_module, extract_token

LOGOUT_FORM = re.compile(
    r'<form method="post" action="/logout"[^>]*>\s*'
    r'<input type="hidden" name="csrf_token" value="([^"]+)">\s*'
    r'<button type="submit" class="logout">Logout</button>\s*</form>'
)
PROTECTED_PAGES = ("/company-dashboard", "/admin", "/kpi", "/todo")
BAD_SESSIONS = (
    {"logged_in": True, "role": "unknown-role"},
    {"logged_in": True, "role": "FULL"},
    {"logged_in": True, "role": ""},
    {"logged_in": True},
)


@contextmanager
def clock_advanced(seconds):
    """Make itsdangerous (which signs and ages Flask-WTF's CSRF tokens) see
    a clock `seconds` ahead, so a token minted now looks that old - with the
    app's REAL 3600 s limit untouched and no sleeping."""
    real_time = time.time
    with mock.patch("itsdangerous.timed.time", mock.Mock(time=lambda: real_time() + seconds)):
        yield


class LogoutTestCase(IsolatedAppTestCase):
    def is_logged_in(self, client):
        with client.session_transaction() as sess:
            return bool(sess.get("logged_in"))

    def nav_token(self, client, path="/company-dashboard"):
        """The CSRF token inside the nav's Logout form on `path`."""
        match = LOGOUT_FORM.search(client.get(path).get_data(as_text=True))
        self.assertIsNotNone(match, f"no logout form on {path}")
        return match.group(1)

    def logout(self, client, token):
        return client.post("/logout", data={"csrf_token": token})


class ValidLogoutTests(LogoutTestCase):
    def test_every_role_can_post_logout_with_a_valid_token(self):
        for role in KNOWN_ROLES:
            with self.subTest(role=role):
                client = self._client_logged_in_as(role)
                self.assertTrue(self.is_logged_in(client))
                resp = self.logout(client, self.nav_token(client))
                self.assertEqual(resp.status_code, 302)
                self.assertTrue(resp.headers["Location"].endswith("/login"))
                self.assertFalse(self.is_logged_in(client))

    def test_the_session_is_really_empty_afterwards(self):
        client = self._client_logged_in_as("full")
        self.logout(client, self.nav_token(client))
        with client.session_transaction() as sess:
            self.assertNotIn("role", sess)
            self.assertNotIn("logged_in", sess)

    def test_protected_pages_redirect_to_login_afterwards(self):
        for role in KNOWN_ROLES:
            client = self._client_logged_in_as(role)
            for path in PROTECTED_PAGES:
                self.assertEqual(client.get(path).status_code, 200, (role, path))
            self.logout(client, self.nav_token(client))
            for path in PROTECTED_PAGES:
                with self.subTest(role=role, path=path):
                    resp = client.get(path)
                    self.assertEqual(resp.status_code, 302)
                    self.assertTrue(resp.headers["Location"].endswith("/login"))

    def test_logging_in_again_after_logout_works(self):
        client = self._client_logged_in_as("admissions")
        self.logout(client, self.nav_token(client))
        self._login(client, password=ROLE_PASSWORDS["admissions"])
        self.assertEqual(client.get("/company-dashboard").status_code, 200)


class GetAndHeadAreRefusedTests(LogoutTestCase):
    def test_get_returns_405_and_the_session_survives(self):
        for role in KNOWN_ROLES:
            with self.subTest(role=role):
                client = self._client_logged_in_as(role)
                resp = client.get("/logout")
                self.assertEqual(resp.status_code, 405)
                self.assertEqual({m.strip() for m in resp.headers["Allow"].split(",")}, {"OPTIONS", "POST"})
                self.assertTrue(self.is_logged_in(client))
                self.assertEqual(client.get("/company-dashboard").status_code, 200)

    def test_head_returns_405_and_the_session_survives(self):
        for role in KNOWN_ROLES:
            with self.subTest(role=role):
                client = self._client_logged_in_as(role)
                self.assertEqual(client.head("/logout").status_code, 405)
                self.assertTrue(self.is_logged_in(client))

    def test_a_cross_site_style_get_cannot_log_the_user_out(self):
        client = self._client_logged_in_as("full")
        resp = client.get(
            "/logout",
            headers={
                "Sec-Fetch-Site": "cross-site",
                "Sec-Fetch-Mode": "navigate",
                "Sec-Fetch-Dest": "document",
                "Referer": "https://evil.example/page-with-a-link",
            },
        )
        self.assertEqual(resp.status_code, 405)
        self.assertTrue(self.is_logged_in(client))

    def test_unauthenticated_get_and_head_are_also_405_not_a_redirect(self):
        client = app_module.app.test_client()
        self.assertEqual(client.get("/logout").status_code, 405)
        self.assertEqual(client.head("/logout").status_code, 405)

    def test_the_route_is_post_only(self):
        rule = next(r for r in app_module.app.url_map.iter_rules() if r.endpoint == "logout")
        self.assertEqual(rule.methods - {"OPTIONS"}, {"POST"})


class CsrfProtectionTests(LogoutTestCase):
    def test_missing_token_is_400_and_the_session_survives(self):
        client = self._client_logged_in_as("full")
        resp = client.post("/logout", data={})
        self.assertEqual(resp.status_code, 400)
        self.assertIn("The CSRF token is missing.", resp.get_data(as_text=True))
        self.assertTrue(self.is_logged_in(client))

    def test_invalid_token_is_400_and_the_session_survives(self):
        client = self._client_logged_in_as("full")
        for bad in ("garbage", "x" * 80, ""):
            with self.subTest(token=bad[:10]):
                resp = client.post("/logout", data={"csrf_token": bad})
                self.assertEqual(resp.status_code, 400)
                self.assertTrue(self.is_logged_in(client))

    def test_a_token_from_another_session_is_400_and_the_session_survives(self):
        victim = self._client_logged_in_as("full")
        attacker = self._client_logged_in_as("consultants")
        resp = self.logout(victim, self.nav_token(attacker))
        self.assertEqual(resp.status_code, 400)
        self.assertIn("The CSRF tokens do not match.", resp.get_data(as_text=True))
        self.assertTrue(self.is_logged_in(victim))

    def test_a_forged_form_post_without_a_token_cannot_log_the_user_out(self):
        client = self._client_logged_in_as("admissions")
        resp = client.post(
            "/logout",
            data={},
            headers={"Origin": "https://evil.example", "Referer": "https://evil.example/", "Sec-Fetch-Site": "cross-site"},
        )
        self.assertEqual(resp.status_code, 400)
        self.assertTrue(self.is_logged_in(client))

    def test_logout_is_not_csrf_exempt_and_keeps_the_default_400_body(self):
        client = self._client_logged_in_as("full")
        logout_body = client.post("/logout", data={}).get_data(as_text=True)
        other_body = client.post("/admin/reprocess", data={}).get_data(as_text=True)
        self.assertEqual(logout_body, other_body)  # same default Flask-WTF 400 page as any other POST

    def test_no_csrf_failure_type_other_than_expiry_is_softened(self):
        # (expiry itself is covered in ExpiredLogoutButtonTests)
        client = self._client_logged_in_as("full")
        for data in ({}, {"csrf_token": "garbage"}):
            resp = client.post("/logout", data=data)
            self.assertEqual(resp.status_code, 400)
            self.assertNotIn("expired", resp.get_data(as_text=True).lower())


class UnknownTamperedAndUnauthenticatedTests(LogoutTestCase):
    def test_logout_is_public_and_not_in_the_role_policy(self):
        self.assertIn("logout", PUBLIC_ENDPOINTS)
        self.assertNotIn("logout", ENDPOINT_ROLES)

    def test_unknown_or_tampered_role_sessions_can_still_log_out(self):
        for session_values in BAD_SESSIONS:
            with self.subTest(session=session_values):
                client = self._client_with_session(**session_values)
                self.assertEqual(client.get("/admin").status_code, 403)  # locked out of everything...
                token = extract_token(client.get("/login").get_data(as_text=True))  # its own session's token
                resp = self.logout(client, token)  # ...but can always clear itself
                self.assertEqual(resp.status_code, 302)
                self.assertFalse(self.is_logged_in(client))
                self.assertEqual(client.get("/admin").status_code, 302)  # now just logged out

    def test_the_403_pages_own_logout_form_works_for_a_tampered_role(self):
        client = self._client_with_session(logged_in=True, role="unknown-role")
        resp = client.get("/admin")
        self.assertEqual(resp.status_code, 403)
        match = LOGOUT_FORM.search(resp.get_data(as_text=True))
        self.assertIsNotNone(match, "the 403 page must offer a way out")
        self.assertEqual(self.logout(client, match.group(1)).status_code, 302)
        self.assertFalse(self.is_logged_in(client))

    def test_unauthenticated_valid_token_post_just_redirects_to_login(self):
        client = app_module.app.test_client()
        token = self._get_login_token(client)
        resp = self.logout(client, token)
        self.assertEqual(resp.status_code, 302)
        self.assertTrue(resp.headers["Location"].endswith("/login"))

    def test_unauthenticated_post_without_a_token_is_400(self):
        self.assertEqual(app_module.app.test_client().post("/logout", data={}).status_code, 400)

    def test_a_stale_page_after_the_session_is_gone_is_a_plain_400(self):
        """e.g. logged out in another tab / cookie cleared / secret rotated:
        no session token to match, so the normal 400 (not the friendly case,
        which is only for a still-logged-in session)."""
        client = self._client_logged_in_as("full")
        token = self.nav_token(client)
        fresh = app_module.app.test_client()  # no cookie at all
        resp = self.logout(fresh, token)
        self.assertEqual(resp.status_code, 400)


class NavigationFormTests(LogoutTestCase):
    def test_every_role_gets_a_post_logout_form_with_a_csrf_token(self):
        for role in KNOWN_ROLES:
            client = self._client_logged_in_as(role)
            for path in ("/company-dashboard", "/admin", "/kpi"):
                with self.subTest(role=role, path=path):
                    html = client.get(path).get_data(as_text=True)
                    matches = LOGOUT_FORM.findall(html)
                    self.assertEqual(len(matches), 1)
                    self.assertGreater(len(matches[0]), 20)  # a real token
                    self.assertIn('<form method="post" action="/logout"', html)
                    self.assertIn('name="csrf_token"', html)
                    self.assertIn(">Logout</button>", html)

    def test_there_is_no_logout_anchor_anywhere(self):
        for role in KNOWN_ROLES:
            client = self._client_logged_in_as(role)
            for path in ("/company-dashboard", "/admin", "/todo", "/leads-dashboard"):
                with self.subTest(role=role, path=path):
                    html = client.get(path).get_data(as_text=True)
                    self.assertNotIn('href="/logout"', html)
                    self.assertNotRegex(html, r"<a[^>]*logout")

    def test_the_form_token_is_the_one_that_actually_works(self):
        for role in KNOWN_ROLES:
            with self.subTest(role=role):
                client = self._client_logged_in_as(role)
                self.assertEqual(self.logout(client, self.nav_token(client)).status_code, 302)

    def test_the_login_page_has_no_logout_control(self):
        html = app_module.app.test_client().get("/login").get_data(as_text=True)
        self.assertNotIn("/logout", html)

    def test_the_nav_markup_is_otherwise_unchanged(self):
        html = self._client_logged_in_as("full").get("/company-dashboard").get_data(as_text=True)
        for link in ("/company-dashboard", "/admin", "/todo"):
            self.assertIn(f'href="{link}"', html)
        self.assertIn('class="nav-role-label"', html)
        # Logout stays the last item in the nav, after the role label.
        self.assertLess(html.index('class="nav-role-label"'), html.index('action="/logout"'))


class ExpiredLogoutButtonTests(LogoutTestCase):
    """The ONE softened CSRF failure: a still-logged-in user's own token that
    is genuine but too old (>3600 s, simulated by advancing the clock that
    signs/ages the tokens - the app's limit itself is never touched)."""

    EXPIRED_BY = 2 * 60 * 60

    def test_expired_logout_token_is_friendly_for_a_logged_in_session_only(self):
        owner = self._client_logged_in_as("full")
        owner_token = self.nav_token(owner)
        other = self._client_logged_in_as("consultants")
        other_token = self.nav_token(other)
        anon = app_module.app.test_client()
        anon_token = self._get_login_token(anon)

        with clock_advanced(self.EXPIRED_BY):
            # --- the friendly case ---------------------------------------
            resp = self.logout(owner, owner_token)
            self.assertEqual(resp.status_code, 302)
            self.assertTrue(resp.headers["Location"].endswith("/company-dashboard"))
            self.assertTrue(self.is_logged_in(owner), "an expired token must NOT clear the session")

            # --- everything else stays the normal 400 --------------------
            self.assertEqual(self.logout(owner, other_token).status_code, 400)   # another session's (expired) token
            self.assertTrue(self.is_logged_in(owner))
            self.assertEqual(self.logout(other, "garbage").status_code, 400)      # invalid
            self.assertEqual(other.post("/logout", data={}).status_code, 400)     # missing
            self.assertTrue(self.is_logged_in(other))
            self.assertEqual(self.logout(anon, anon_token).status_code, 400)      # expired but NOT logged in

            # --- other endpoints are never softened ----------------------
            resp = owner.post("/admin/reprocess", data={"csrf_token": owner_token})
            self.assertEqual(resp.status_code, 400)
            self.assertIn("expired", resp.get_data(as_text=True).lower())
            self.assertTrue(self.is_logged_in(owner))

    def test_an_expired_token_of_a_tampered_role_session_is_still_just_a_friendly_redirect(self):
        client = self._client_with_session(logged_in=True, role="unknown-role")
        token = extract_token(client.get("/login").get_data(as_text=True))
        with clock_advanced(self.EXPIRED_BY):
            # (the whole flow runs under the advanced clock: the session cookie is re-signed
            # with that clock on every response, so mixing clocks would invalidate it)
            resp = self.logout(client, token)
            self.assertEqual(resp.status_code, 302)       # still logged in -> friendly case, session untouched
            self.assertTrue(self.is_logged_in(client))
            # ...and the page it lands on (a 403 for this role) carries a fresh, working logout form.
            landing = client.get(resp.headers["Location"])
            self.assertEqual(landing.status_code, 403)
            fresh = LOGOUT_FORM.search(landing.get_data(as_text=True)).group(1)
            self.assertEqual(self.logout(client, fresh).status_code, 302)
            self.assertFalse(self.is_logged_in(client))

    def test_message_shown_once_then_a_fresh_token_logs_out(self):
        client = self._client_logged_in_as("admissions")
        old_token = self.nav_token(client)
        with clock_advanced(self.EXPIRED_BY):
            resp = self.logout(client, old_token)
            self.assertEqual(resp.status_code, 302)
            self.assertTrue(self.is_logged_in(client))

            landing = client.get(resp.headers["Location"])      # the redirect target renders a fresh token
            html = landing.get_data(as_text=True)
            self.assertEqual(landing.status_code, 200)
            self.assertIn("Your Logout button expired. Please try again.", html)
            self.assertIn('class="flash warning"', html)
            fresh = LOGOUT_FORM.search(html).group(1)
            self.assertNotEqual(fresh, old_token)

            again = client.get("/company-dashboard").get_data(as_text=True)
            self.assertNotIn("Your Logout button expired", again)  # shown once
            self.assertEqual(self.logout(client, fresh).status_code, 302)  # the fresh token works
            self.assertFalse(self.is_logged_in(client))

    def test_a_token_still_inside_the_limit_is_not_treated_as_expired(self):
        client = self._client_logged_in_as("full")
        token = self.nav_token(client)
        with clock_advanced(3500):                              # < 3600: still valid
            resp = self.logout(client, token)
        self.assertEqual(resp.status_code, 302)
        self.assertTrue(resp.headers["Location"].endswith("/login"))
        self.assertFalse(self.is_logged_in(client))

    def test_the_global_time_limit_is_untouched(self):
        self.assertEqual(app_module.app.config["WTF_CSRF_TIME_LIMIT"], 3600)

    def test_the_expiry_check_does_not_depend_on_flask_wtfs_message_text(self):
        """Structural guard: the code (docstrings excluded) must not read the
        CSRFError's message/description or compare against Flask-WTF's
        wording."""
        for func in (app_module._csrf_token_is_genuine_but_expired, app_module._csrf_failed):
            tree = ast.parse(inspect.getsource(func).strip())
            body = tree.body[0]
            if ast.get_docstring(body) is not None:
                body.body = body.body[1:]
            attrs = {n.attr for n in ast.walk(body) if isinstance(n, ast.Attribute)}
            strings = [n.value for n in ast.walk(body) if isinstance(n, ast.Constant) and isinstance(n.value, str)]
            self.assertFalse({"description", "args", "get_description"} & attrs, func.__name__)
            self.assertFalse([t for t in strings if "CSRF token" in t or "has expired" in t], func.__name__)
            self.assertNotIn("str", {n.func.id for n in ast.walk(body) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name)})
            # nothing is ever read off the caught exceptions/errors (no e.args[0], no str(e), no error.description)
            self.assertFalse([n for n in ast.walk(body) if isinstance(n, ast.Subscript) and isinstance(n.value, ast.Attribute) and n.value.attr == "args"], func.__name__)
            self.assertFalse([h for h in ast.walk(body) if isinstance(h, ast.ExceptHandler) and h.name], f"{func.__name__}: exception objects must not be inspected")


class ExpiryIsOnlyClassifiedWhenAgeIsTheCauseTests(LogoutTestCase):
    """Two-step classification: friendly handling needs BOTH "fails under the
    normal time limit" AND "passes with age ignored". A current, valid token
    that was rejected for some OTHER reason (Flask-WTF's HTTPS same-origin /
    referrer check) must keep the ordinary 400."""

    HTTPS = "https://localhost"

    def post_https(self, client, token, referer=None):
        headers = {"Referer": referer} if referer else {}
        return client.post("/logout", data={"csrf_token": token}, base_url=self.HTTPS, headers=headers)

    # --- the helper's call pattern, with validate_csrf stubbed ------------
    def classify(self, side_effects):
        from wtforms.validators import ValidationError

        calls = []

        def fake(token, **kwargs):
            calls.append(kwargs)
            outcome = side_effects[len(calls) - 1]
            if outcome == "fail":
                raise ValidationError("whatever the wording is")

        with app_module.app.test_request_context("/logout", method="POST", data={"csrf_token": "t"}):
            with mock.patch.object(app_module, "validate_csrf", side_effect=fake):
                result = app_module._csrf_token_is_genuine_but_expired()
        return result, calls

    def test_fails_normally_and_passes_with_age_ignored_is_expired(self):
        result, calls = self.classify(["fail", "ok"])
        self.assertTrue(result)
        self.assertEqual(len(calls), 2)
        self.assertEqual(calls[0], {})                                   # step 1: the app's NORMAL limit (no override)
        self.assertGreater(calls[1]["time_limit"], 10 * 365 * 24 * 3600 - 1)  # step 2: age ignored

    def test_a_token_that_validates_normally_is_never_expired(self):
        result, calls = self.classify(["ok"])
        self.assertFalse(result)
        self.assertEqual(len(calls), 1, "no second check once the normal one passes")

    def test_a_token_that_fails_even_with_age_ignored_is_not_expired(self):
        result, calls = self.classify(["fail", "fail"])
        self.assertFalse(result)
        self.assertEqual(len(calls), 2)

    # --- the real HTTPS referrer / same-origin failure -------------------
    def test_https_without_a_referrer_is_the_ordinary_400_even_with_a_current_valid_token(self):
        client = self._client_logged_in_as("full")
        token = self.nav_token(client)
        resp = self.post_https(client, token)                           # token is fresh & valid; Referer missing
        self.assertEqual(resp.status_code, 400)
        self.assertTrue(self.is_logged_in(client))
        self.assertNotIn(b"Your Logout button expired", client.get("/company-dashboard").data)

    def test_https_with_a_foreign_referrer_is_the_ordinary_400(self):
        client = self._client_logged_in_as("admissions")
        token = self.nav_token(client)
        resp = self.post_https(client, token, referer="https://evil.example/anything")
        self.assertEqual(resp.status_code, 400)
        self.assertTrue(self.is_logged_in(client))
        self.assertNotIn(b"Your Logout button expired", client.get("/company-dashboard").data)

    def test_the_same_https_request_with_the_right_referrer_logs_out_proving_the_token_was_good(self):
        client = self._client_logged_in_as("full")
        token = self.nav_token(client)
        resp = self.post_https(client, token, referer=self.HTTPS + "/company-dashboard")
        self.assertEqual(resp.status_code, 302)
        self.assertTrue(resp.headers["Location"].endswith("/login"))
        self.assertFalse(self.is_logged_in(client))

    def test_https_referrer_failure_is_not_friendly_for_any_role(self):
        for role in KNOWN_ROLES:
            with self.subTest(role=role):
                client = self._client_logged_in_as(role)
                self.assertEqual(self.post_https(client, self.nav_token(client)).status_code, 400)
                self.assertTrue(self.is_logged_in(client))

    # --- genuinely expired still gets the friendly path, also over https --
    def test_a_genuinely_expired_token_is_still_friendly(self):
        client = self._client_logged_in_as("full")
        token = self.nav_token(client)
        with clock_advanced(2 * 60 * 60):
            resp = self.logout(client, token)
            self.assertEqual(resp.status_code, 302)
            self.assertTrue(resp.headers["Location"].endswith("/company-dashboard"))
            self.assertTrue(self.is_logged_in(client))
            html = client.get(resp.headers["Location"]).get_data(as_text=True)
            self.assertIn("Your Logout button expired. Please try again.", html)
            fresh = LOGOUT_FORM.search(html).group(1)
            self.assertNotEqual(fresh, token)
            self.assertEqual(self.logout(client, fresh).status_code, 302)
            self.assertFalse(self.is_logged_in(client))

    def test_other_failures_stay_the_ordinary_400_and_keep_the_session(self):
        owner = self._client_logged_in_as("full")
        stranger = self._client_logged_in_as("consultants")
        for label, data in (
            ("missing", {}),
            ("invalid", {"csrf_token": "garbage"}),
            ("another session's", {"csrf_token": self.nav_token(stranger)}),
            ("forged signature", {"csrf_token": "x" * 40 + "." + "y" * 20 + "." + "z" * 27}),
        ):
            with self.subTest(token=label):
                self.assertEqual(owner.post("/logout", data=data).status_code, 400)
                self.assertTrue(self.is_logged_in(owner))
        with clock_advanced(2 * 60 * 60):                                # ...and also once everything is "old"
            for label, data in (("missing", {}), ("invalid", {"csrf_token": "garbage"}),
                                ("another session's", {"csrf_token": self.nav_token(stranger)})):
                with self.subTest(token=label, aged=True):
                    self.assertEqual(owner.post("/logout", data=data).status_code, 400)
                    self.assertTrue(self.is_logged_in(owner))


if __name__ == "__main__":
    unittest.main()
