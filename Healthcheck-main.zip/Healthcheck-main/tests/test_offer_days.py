import unittest
from datetime import date, timedelta

import openpyxl

from offer_days import (
    BUCKETS,
    EXPORT_COLUMNS,
    QUALIFYING_STATUSES,
    TOTAL_EXPORT_SLUG,
    average_age_days,
    build_offer_days_export,
    build_offer_days_report,
    build_offer_days_total_export,
    classify_bucket,
    export_filename,
    list_qualifying_records,
    resolve_export_bucket,
)

TODAY = date(2026, 8, 13)


def _ago(n):
    return (TODAY - timedelta(days=n)).isoformat()


def _future(n):
    return (TODAY + timedelta(days=n)).isoformat()


def _row(status, submitted, application="Mo", **extra):
    row = {"Status": status, "Submitted To Uni": submitted, "Application": application}
    row.update(extra)
    return row


class QualifyingStatusTests(unittest.TestCase):
    def test_only_the_three_pre_offer_statuses_qualify(self):
        self.assertEqual(QUALIFYING_STATUSES, {"04-Onboarding", "05-Assessment", "06-Decision"})

    def test_each_qualifying_status_is_included(self):
        for status in QUALIFYING_STATUSES:
            report = build_offer_days_report([_row(status, _ago(1))], TODAY)
            self.assertEqual(report["total"], 1, msg=status)

    def test_non_qualifying_statuses_are_excluded(self):
        for status in ["01-NewApp", "02-PendingQA", "03-PendingSubmission", "07-Ready",
                        "08-Pre-Enrolled", "09-Enrolled", "10-Lost"]:
            report = build_offer_days_report([_row(status, _ago(1))], TODAY)
            self.assertEqual(report["total"], 0, msg=status)


class BucketBoundaryTests(unittest.TestCase):
    def test_age_0_is_0_10(self):
        self.assertEqual(classify_bucket(0), "0-10 Days")

    def test_age_10_is_0_10(self):
        self.assertEqual(classify_bucket(10), "0-10 Days")

    def test_age_11_is_11_20(self):
        self.assertEqual(classify_bucket(11), "11-20 Days")

    def test_age_20_is_11_20(self):
        self.assertEqual(classify_bucket(20), "11-20 Days")

    def test_age_21_is_21_30(self):
        self.assertEqual(classify_bucket(21), "21-30 Days")

    def test_age_30_is_21_30(self):
        self.assertEqual(classify_bucket(30), "21-30 Days")

    def test_age_31_is_31_plus(self):
        self.assertEqual(classify_bucket(31), "31+ Days")

    def test_very_old_age_still_31_plus(self):
        self.assertEqual(classify_bucket(365), "31+ Days")

    def test_negative_age_is_none(self):
        self.assertIsNone(classify_bucket(-1))

    def test_submitted_to_uni_is_day_zero(self):
        # Submitted today -> age 0 -> 0-10 Days, not excluded/negative.
        report = build_offer_days_report([_row("05-Assessment", TODAY.isoformat())], TODAY)
        self.assertEqual(report["overall"]["0-10 Days"], 1)


class DateSafetyTests(unittest.TestCase):
    def test_blank_submitted_to_uni_is_excluded_safely(self):
        report = build_offer_days_report([_row("05-Assessment", None)], TODAY)
        self.assertEqual(report["total"], 0)
        self.assertEqual(report["invalid_date_count"], 1)

    def test_malformed_submitted_to_uni_is_excluded_safely(self):
        report = build_offer_days_report([_row("05-Assessment", "not-a-date")], TODAY)
        self.assertEqual(report["total"], 0)
        self.assertEqual(report["invalid_date_count"], 1)

    def test_future_submitted_to_uni_is_excluded_from_buckets_but_counted_separately(self):
        report = build_offer_days_report([_row("05-Assessment", _future(3))], TODAY)
        self.assertEqual(report["total"], 0)
        self.assertEqual(report["future_date_count"], 1)
        self.assertEqual(report["invalid_date_count"], 0)


class GroupingAndTotalsTests(unittest.TestCase):
    def setUp(self):
        self.rows = [
            _row("05-Assessment", _ago(5), "Zoe"),
            _row("06-Decision", _ago(15), "Anum"),
            _row("04-Onboarding", _ago(35), ""),
            _row("05-Assessment", _ago(25), None),
        ]
        self.report = build_offer_days_report(self.rows, TODAY)

    def test_grouped_and_ranked_by_total_descending(self):
        # Unassigned (2 records) outranks Anum/Zoe (1 each) - Anum then
        # sorts before Zoe alphabetically as the tie-break.
        names = [m["name"] for m in self.report["manager_rows"]]
        self.assertEqual(names, ["Unassigned", "Anum", "Zoe"])

    def test_blank_application_folded_into_unassigned(self):
        unassigned = next(m for m in self.report["manager_rows"] if m["name"] == "Unassigned")
        self.assertEqual(unassigned["total"], 2)

    def test_each_record_counted_exactly_once(self):
        self.assertEqual(self.report["total"], 4)
        self.assertEqual(sum(self.report["overall"].values()), 4)

    def test_manager_total_equals_sum_of_own_buckets(self):
        for manager in self.report["manager_rows"]:
            self.assertEqual(manager["total"], sum(manager["buckets"].values()))

    def test_overall_bucket_totals_equal_sum_across_managers(self):
        for bucket in BUCKETS:
            total_across_managers = sum(m["buckets"][bucket] for m in self.report["manager_rows"])
            self.assertEqual(self.report["overall"][bucket], total_across_managers)

    def test_segment_widths_scale_by_largest_managers_total_and_stay_internally_proportional(self):
        rows = (
            [_row("05-Assessment", _ago(5), "Big")] * 4
            + [_row("05-Assessment", _ago(15), "Big")] * 4
            + [_row("05-Assessment", _ago(5), "Small")] * 2
        )
        report = build_offer_days_report(rows, TODAY)
        by_name = {m["name"]: m for m in report["manager_rows"]}
        big_width = sum(s["width_pct"] for s in by_name["Big"]["segments"])
        small_width = sum(s["width_pct"] for s in by_name["Small"]["segments"])
        self.assertAlmostEqual(big_width, 100.0)  # Big has the max total (8)
        self.assertAlmostEqual(small_width, 25.0)  # Small (2) is 2/8 of max

    def test_tie_in_total_breaks_alphabetically(self):
        rows = [
            _row("05-Assessment", _ago(5), "Zed"),
            _row("06-Decision", _ago(15), "Amy"),
        ]
        report = build_offer_days_report(rows, TODAY)
        names = [m["name"] for m in report["manager_rows"]]
        self.assertEqual(names, ["Amy", "Zed"])


class UniversityGroupingTests(unittest.TestCase):
    """The University breakdown reuses the exact same qualifying-records
    list and bucketing logic as the Application Manager breakdown (via
    _build_bucket_chart_rows), just grouped by University Name instead -
    these tests protect that it behaves identically in every way that
    matters, just keyed differently."""

    def setUp(self):
        self.rows = [
            _row("05-Assessment", _ago(5), "Zoe", **{"University Name": "UWS"}),
            _row("06-Decision", _ago(15), "Anum", **{"University Name": "Arden"}),
            _row("04-Onboarding", _ago(35), "Mo", **{"University Name": ""}),
            _row("05-Assessment", _ago(25), "Mo", **{"University Name": None}),
        ]
        self.report = build_offer_days_report(self.rows, TODAY)

    def test_grouped_and_ranked_by_total_descending(self):
        # Unassigned (2 records) outranks Arden/UWS (1 each) - Arden then
        # sorts before UWS alphabetically as the tie-break, matching
        # pipeline.build_pipeline_report()'s rank_by_total convention.
        names = [u["name"] for u in self.report["university_rows"]]
        self.assertEqual(names, ["Unassigned", "Arden", "UWS"])

    def test_blank_university_folded_into_unassigned(self):
        unassigned = next(u for u in self.report["university_rows"] if u["name"] == "Unassigned")
        self.assertEqual(unassigned["total"], 2)

    def test_each_record_counted_exactly_once(self):
        self.assertEqual(sum(u["total"] for u in self.report["university_rows"]), 4)

    def test_university_total_equals_sum_of_own_buckets(self):
        for university in self.report["university_rows"]:
            self.assertEqual(university["total"], sum(university["buckets"].values()))

    def test_overall_bucket_totals_equal_sum_across_universities(self):
        for bucket in BUCKETS:
            total_across_universities = sum(u["buckets"][bucket] for u in self.report["university_rows"])
            self.assertEqual(self.report["overall"][bucket], total_across_universities)

    def test_manager_and_university_breakdowns_are_independent(self):
        # Same qualifying records, two different groupings, each ranked by
        # its own total - manager_rows must be completely unaffected by
        # University Name (Mo has 2 records total - both Unassigned
        # university - so Mo outranks Anum/Zoe here even though University
        # Name plays no part in the manager grouping at all).
        manager_names = [m["name"] for m in self.report["manager_rows"]]
        self.assertEqual(manager_names, ["Mo", "Anum", "Zoe"])

    def test_tie_in_total_breaks_alphabetically(self):
        rows = [
            _row("05-Assessment", _ago(5), "Mo", **{"University Name": "Zed Uni"}),
            _row("06-Decision", _ago(15), "Mo", **{"University Name": "Amy Uni"}),
        ]
        report = build_offer_days_report(rows, TODAY)
        names = [u["name"] for u in report["university_rows"]]
        self.assertEqual(names, ["Amy Uni", "Zed Uni"])


class ListQualifyingRecordsMatchesReportTests(unittest.TestCase):
    """The export must always agree with the dashboard - both are built from
    the exact same underlying qualifying-records list."""

    def setUp(self):
        self.rows = [
            _row("05-Assessment", _ago(5), "Anum"),
            _row("06-Decision", _ago(15), "Mo"),
            _row("04-Onboarding", _ago(35), "Mo"),
            _row("07-Ready", _ago(5), "Mo"),  # excluded: wrong status
            _row("05-Assessment", None, "Mo"),  # excluded: no date
            _row("05-Assessment", _future(2), "Mo"),  # excluded: future date
        ]
        self.report = build_offer_days_report(self.rows, TODAY)
        self.qualifying = list_qualifying_records(self.rows, TODAY)

    def test_total_counts_match(self):
        self.assertEqual(len(self.qualifying), self.report["total"])

    def test_per_bucket_counts_match(self):
        for bucket in BUCKETS:
            n = len([r for r in self.qualifying if r["bucket"] == bucket])
            self.assertEqual(n, self.report["overall"][bucket], msg=bucket)

    def test_excluded_records_never_appear_in_qualifying_list(self):
        statuses = {rec["row"]["Status"] for rec in self.qualifying}
        self.assertNotIn("07-Ready", statuses)


class AverageAgeDaysTests(unittest.TestCase):
    """The Company Dashboard's Offer Days tile - average age across every
    currently-qualifying record (this page's own "Total" population),
    not broken down by bucket."""

    def test_empty_input_gives_none_not_a_divide_by_zero(self):
        self.assertIsNone(average_age_days([]))

    def test_average_is_computed_across_all_qualifying_records(self):
        rows = [
            _row("05-Assessment", _ago(5), "Anum"),
            _row("06-Decision", _ago(15), "Mo"),
            _row("04-Onboarding", _ago(40), "Mo"),
        ]
        qualifying = list_qualifying_records(rows, TODAY)
        self.assertEqual(average_age_days(qualifying), 20.0)  # (5 + 15 + 40) / 3

    def test_result_is_rounded_to_one_decimal_place(self):
        rows = [
            _row("05-Assessment", _ago(5), "Anum"),
            _row("06-Decision", _ago(6), "Mo"),
            _row("06-Decision", _ago(6), "Mo"),
        ]
        qualifying = list_qualifying_records(rows, TODAY)
        self.assertEqual(average_age_days(qualifying), 5.7)  # (5 + 6 + 6) / 3 = 5.666...


class BuildOfferDaysExportTests(unittest.TestCase):
    def setUp(self):
        self.rows = [
            _row("05-Assessment", _ago(5), "Mo", **{
                "Student Code": "S001", "Student Name": "Zed Alpha", "University Name": "Uni A",
                "Course Name": "Course A", "Consultant": "Zara",
            }),
            _row("05-Assessment", _ago(20), "Mo", **{
                "Student Code": "S002", "Student Name": "Amy Beta", "University Name": "Uni B",
                "Course Name": "Course B", "Consultant": "Amir",
            }),
            _row("06-Decision", _ago(2), "Anum", **{
                "Student Code": "S003", "Student Name": "Beth Gamma", "University Name": "Uni C",
                "Course Name": "Course C", "Consultant": "Amir",
            }),
            _row("04-Onboarding", None, "Mo", **{
                "Student Code": "S999", "Student Name": "Excluded NoDate", "University Name": "X",
                "Course Name": "X", "Consultant": "Zara",
            }),
        ]
        self.qualifying = list_qualifying_records(self.rows, TODAY)

    def test_export_row_count_matches_qualifying_count(self):
        buffer = build_offer_days_export(self.qualifying, sheet_title="Total")
        wb = openpyxl.load_workbook(buffer)
        ws = wb.active
        self.assertEqual(ws.max_row - 1, len(self.qualifying))
        self.assertEqual(len(self.qualifying), 3)

    def test_columns_are_in_exact_requested_order(self):
        buffer = build_offer_days_export(self.qualifying, sheet_title="Total")
        wb = openpyxl.load_workbook(buffer)
        header = [c.value for c in wb.active[1]]
        self.assertEqual(header, EXPORT_COLUMNS)

    def test_no_index_column(self):
        buffer = build_offer_days_export(self.qualifying, sheet_title="Total")
        header = [c.value for c in openpyxl.load_workbook(buffer).active[1]]
        self.assertEqual(header[0], "Student Code")

    def test_header_row_is_bold_frozen_and_filterable(self):
        buffer = build_offer_days_export(self.qualifying, sheet_title="Total")
        ws = openpyxl.load_workbook(buffer).active
        self.assertTrue(all(c.font.bold for c in ws[1]))
        self.assertEqual(ws.freeze_panes, "A2")
        self.assertIsNotNone(ws.auto_filter.ref)

    def test_sorted_by_consultant_then_oldest_date_first(self):
        buffer = build_offer_days_export(self.qualifying, sheet_title="Total")
        ws = openpyxl.load_workbook(buffer).active
        rows = list(ws.iter_rows(min_row=2, values_only=True))
        consultants = [r[5] for r in rows]
        self.assertEqual(consultants, sorted(consultants, key=lambda c: (c or "").lower()))
        # Both Amir rows: S002 (20 days ago) should come before S003 (2 days ago).
        amir_codes = [r[0] for r in rows if r[5] == "Amir"]
        self.assertEqual(amir_codes, ["S002", "S003"])

    def test_date_column_formatted_ddmmyyyy(self):
        buffer = build_offer_days_export(self.qualifying, sheet_title="Total")
        ws = openpyxl.load_workbook(buffer).active
        date_col = EXPORT_COLUMNS.index("Date Submitted to University") + 1
        for r in range(2, ws.max_row + 1):
            self.assertEqual(ws.cell(row=r, column=date_col).number_format, "DD/MM/YYYY")

    def test_bucket_filtered_export_contains_only_that_bucket(self):
        bucket_records = [r for r in self.qualifying if r["bucket"] == "0-10 Days"]
        buffer = build_offer_days_export(bucket_records, sheet_title="0-10 Days")
        ws = openpyxl.load_workbook(buffer).active
        self.assertEqual(ws.max_row - 1, len(bucket_records))

    def test_application_status_column_exports_exact_current_status(self):
        buffer = build_offer_days_export(self.qualifying, sheet_title="Total")
        ws = openpyxl.load_workbook(buffer).active
        status_col = EXPORT_COLUMNS.index("Application Status") + 1
        code_col = EXPORT_COLUMNS.index("Student Code") + 1
        by_code = {
            ws.cell(row=r, column=code_col).value: ws.cell(row=r, column=status_col).value
            for r in range(2, ws.max_row + 1)
        }
        expected = {rec["row"]["Student Code"]: rec["row"]["Status"] for rec in self.qualifying}
        self.assertEqual(by_code, expected)

    def test_offer_days_column_stored_as_whole_number_integer(self):
        buffer = build_offer_days_export(self.qualifying, sheet_title="Total")
        ws = openpyxl.load_workbook(buffer).active
        offer_days_col = EXPORT_COLUMNS.index("Offer Days") + 1
        for r in range(2, ws.max_row + 1):
            value = ws.cell(row=r, column=offer_days_col).value
            self.assertIsInstance(value, int)

    def test_offer_days_column_matches_the_exact_age_used_for_bucket_classification(self):
        buffer = build_offer_days_export(self.qualifying, sheet_title="Total")
        ws = openpyxl.load_workbook(buffer).active
        code_col = EXPORT_COLUMNS.index("Student Code") + 1
        offer_days_col = EXPORT_COLUMNS.index("Offer Days") + 1
        exported = {
            ws.cell(row=r, column=code_col).value: ws.cell(row=r, column=offer_days_col).value
            for r in range(2, ws.max_row + 1)
        }
        for rec in self.qualifying:
            code = rec["row"]["Student Code"]
            self.assertEqual(exported[code], rec["age_days"], msg=code)
            # Cross-check independently against the exact same reference
            # date used to build self.qualifying, not a re-derivation.
            self.assertEqual((TODAY - rec["submitted"]).days, exported[code], msg=code)

    def test_final_column_order(self):
        self.assertEqual(
            EXPORT_COLUMNS,
            [
                "Student Code",
                "Student Name",
                "University",
                "Course",
                "Application Manager",
                "Consultant",
                "Application Status",
                "Date Submitted to University",
                "Offer Days",
            ],
        )

    def test_sort_tiebreak_by_student_name_when_consultant_and_date_match(self):
        rows = [
            _row("05-Assessment", _ago(10), "Mo", **{
                "Student Code": "S010", "Student Name": "Zed Last", "University Name": "Uni A",
                "Course Name": "Course A", "Consultant": "Amir",
            }),
            _row("05-Assessment", _ago(10), "Mo", **{
                "Student Code": "S011", "Student Name": "Amy First", "University Name": "Uni A",
                "Course Name": "Course A", "Consultant": "Amir",
            }),
        ]
        qualifying = list_qualifying_records(rows, TODAY)
        buffer = build_offer_days_export(qualifying, sheet_title="Total")
        ws = openpyxl.load_workbook(buffer).active
        codes_in_order = [row[0] for row in ws.iter_rows(min_row=2, values_only=True)]
        self.assertEqual(codes_in_order, ["S011", "S010"])


class BuildOfferDaysTotalExportTests(unittest.TestCase):
    """The Total download is the only one that changes shape - one
    worksheet per Application Manager instead of one flat sheet."""

    def setUp(self):
        self.rows = [
            _row("05-Assessment", _ago(5), "Zed", **{
                "Student Code": "S001", "Student Name": "Nina", "University Name": "Uni A",
                "Course Name": "Course A", "Consultant": "Zara",
            }),
            _row("06-Decision", _ago(40), "Zed", **{
                "Student Code": "S002", "Student Name": "Owen", "University Name": "Uni A",
                "Course Name": "Course A", "Consultant": "Amir",
            }),
            _row("05-Assessment", _ago(20), "Amy", **{
                "Student Code": "S003", "Student Name": "Pat", "University Name": "Uni B",
                "Course Name": "Course B", "Consultant": "Zara",
            }),
            _row("04-Onboarding", _ago(12), "Amy", **{
                "Student Code": "S004", "Student Name": "Ray", "University Name": "Uni B",
                "Course Name": "Course B", "Consultant": "Amir",
            }),
            _row("05-Assessment", _ago(15), "Amy", **{
                "Student Code": "S005", "Student Name": "Sam", "University Name": "Uni B",
                "Course Name": "Course B", "Consultant": "Amir",
            }),
            _row("06-Decision", _ago(9), "Mo", **{
                "Student Code": "S006", "Student Name": "Tia", "University Name": "Uni C",
                "Course Name": "Course C", "Consultant": "Zara",
            }),
            _row("05-Assessment", _ago(7), "", **{
                "Student Code": "S007", "Student Name": "Uma", "University Name": "Uni D",
                "Course Name": "Course D", "Consultant": "Zara",
            }),
            _row("04-Onboarding", _ago(22), None, **{
                "Student Code": "S008", "Student Name": "Vik", "University Name": "Uni D",
                "Course Name": "Course D", "Consultant": "Amir",
            }),
        ]
        self.qualifying = list_qualifying_records(self.rows, TODAY)
        self.report = build_offer_days_report(self.rows, TODAY)
        self.buffer = build_offer_days_total_export(self.qualifying)
        self.workbook = openpyxl.load_workbook(self.buffer)

    def test_one_worksheet_per_application_manager(self):
        self.assertEqual(set(self.workbook.sheetnames), {"Amy", "Mo", "Unassigned", "Zed"})

    def test_tabs_are_alphabetical_with_unassigned_last(self):
        self.assertEqual(self.workbook.sheetnames, ["Amy", "Mo", "Zed", "Unassigned"])

    def test_each_tab_contains_only_that_managers_records(self):
        for sheet_name, expected_codes in [
            ("Zed", {"S001", "S002"}),
            ("Amy", {"S003", "S004", "S005"}),
            ("Mo", {"S006"}),
            ("Unassigned", {"S007", "S008"}),
        ]:
            ws = self.workbook[sheet_name]
            codes = {row[0] for row in ws.iter_rows(min_row=2, values_only=True)}
            self.assertEqual(codes, expected_codes, msg=sheet_name)

    def test_column_order_unchanged_on_every_tab(self):
        for sheet_name in self.workbook.sheetnames:
            header = [c.value for c in self.workbook[sheet_name][1]]
            self.assertEqual(header, EXPORT_COLUMNS, msg=sheet_name)

    def test_application_manager_column_still_present_on_each_tab(self):
        manager_col = EXPORT_COLUMNS.index("Application Manager")
        for sheet_name in self.workbook.sheetnames:
            ws = self.workbook[sheet_name]
            for row in ws.iter_rows(min_row=2, values_only=True):
                self.assertEqual(row[manager_col], sheet_name)

    def test_sorting_within_each_tab_is_date_first_not_consultant_first(self):
        # Amy's tab: Pat (Zara, 20 days ago), Sam (Amir, 15 days ago), Ray
        # (Amir, 12 days ago). A Consultant-first sort would group both Amir
        # records ahead of Zara regardless of date, giving [Sam, Ray, Pat] -
        # that would be the bug this test catches. The required date-first
        # order is oldest-to-newest regardless of Consultant: Pat (20 days,
        # oldest) must come first, then Sam (15), then Ray (12, newest).
        ws = self.workbook["Amy"]
        codes_in_order = [row[0] for row in ws.iter_rows(min_row=2, values_only=True)]
        self.assertEqual(codes_in_order, ["S003", "S005", "S004"])

    def test_offer_days_values_remain_exact_on_each_tab(self):
        ws = self.workbook["Zed"]
        offer_days_col = EXPORT_COLUMNS.index("Offer Days")
        values = {row[0]: row[offer_days_col] for row in ws.iter_rows(min_row=2, values_only=True)}
        self.assertEqual(values["S001"], 5)
        self.assertEqual(values["S002"], 40)

    def test_date_formatting_unchanged_on_every_tab(self):
        date_col_idx = EXPORT_COLUMNS.index("Date Submitted to University") + 1
        for sheet_name in self.workbook.sheetnames:
            ws = self.workbook[sheet_name]
            for r in range(2, ws.max_row + 1):
                self.assertEqual(ws.cell(row=r, column=date_col_idx).number_format, "DD/MM/YYYY")

    def test_header_bold_frozen_filterable_on_every_tab(self):
        for sheet_name in self.workbook.sheetnames:
            ws = self.workbook[sheet_name]
            self.assertTrue(all(c.font.bold for c in ws[1]))
            self.assertEqual(ws.freeze_panes, "A2")
            self.assertIsNotNone(ws.auto_filter.ref)

    def test_total_rows_across_all_tabs_equals_total_card_count(self):
        total_rows = sum(self.workbook[name].max_row - 1 for name in self.workbook.sheetnames)
        self.assertEqual(total_rows, self.report["total"])
        self.assertEqual(total_rows, len(self.qualifying))
        self.assertEqual(total_rows, 8)

    def test_no_record_duplicated_or_omitted_across_tabs(self):
        all_codes = []
        for name in self.workbook.sheetnames:
            ws = self.workbook[name]
            all_codes.extend(row[0] for row in ws.iter_rows(min_row=2, values_only=True))
        self.assertEqual(len(all_codes), len(set(all_codes)))  # no duplicates
        self.assertEqual(set(all_codes), {r["row"]["Student Code"] for r in self.qualifying})

    def test_empty_input_still_produces_a_valid_openable_workbook(self):
        buffer = build_offer_days_total_export([])
        workbook = openpyxl.load_workbook(buffer)
        self.assertEqual(len(workbook.sheetnames), 1)
        ws = workbook.active
        self.assertEqual(ws.max_row, 1)  # header row only

    def test_sheet_name_collision_after_sanitisation_is_resolved_uniquely(self):
        rows = [
            _row("05-Assessment", _ago(1), "Anna:Marie", **{
                "Student Code": "C001", "Student Name": "A", "Consultant": "X",
            }),
            _row("05-Assessment", _ago(2), "Anna?Marie", **{
                "Student Code": "C002", "Student Name": "B", "Consultant": "X",
            }),
        ]
        qualifying = list_qualifying_records(rows, TODAY)
        buffer = build_offer_days_total_export(qualifying)
        workbook = openpyxl.load_workbook(buffer)
        self.assertEqual(len(workbook.sheetnames), 2)
        self.assertEqual(len(set(workbook.sheetnames)), 2)  # both unique
        # Every record still present exactly once across the two sheets.
        all_codes = []
        for name in workbook.sheetnames:
            all_codes.extend(row[0] for row in workbook[name].iter_rows(min_row=2, values_only=True))
        self.assertEqual(sorted(all_codes), ["C001", "C002"])

    def test_worksheet_title_truncated_to_31_characters(self):
        long_name = "A" * 50
        rows = [_row("05-Assessment", _ago(1), long_name, **{
            "Student Code": "L001", "Student Name": "Long", "Consultant": "X",
        })]
        qualifying = list_qualifying_records(rows, TODAY)
        buffer = build_offer_days_total_export(qualifying)
        workbook = openpyxl.load_workbook(buffer)
        self.assertEqual(len(workbook.sheetnames[0]), 31)


class TotalExportDateFirstSortingTests(unittest.TestCase):
    """Regression coverage for the specific bug: rows within an Application
    Manager tab in the Total export must be ordered by the actual parsed
    Submitted To Uni date first, not grouped by Consultant first."""

    def _build(self, rows):
        qualifying = list_qualifying_records(rows, TODAY)
        buffer = build_offer_days_total_export(qualifying)
        return openpyxl.load_workbook(buffer)

    def test_exact_regression_case_from_the_spec(self):
        # 02/08/2026, 15/07/2026, 28/07/2026, 05/08/2026 - deliberately given
        # Consultants that would produce a different (wrong) order if the
        # sort were still Consultant-first: Amir's two records (02/08 and
        # 05/08) would be grouped together ahead of Mo/Zara despite not
        # being the oldest.
        rows = [
            _row("05-Assessment", "2026-08-02", "Same Manager", **{
                "Student Code": "A", "Student Name": "A", "Consultant": "Amir",
            }),
            _row("05-Assessment", "2026-07-15", "Same Manager", **{
                "Student Code": "B", "Student Name": "B", "Consultant": "Zara",
            }),
            _row("06-Decision", "2026-07-28", "Same Manager", **{
                "Student Code": "C", "Student Name": "C", "Consultant": "Mo",
            }),
            _row("05-Assessment", "2026-08-05", "Same Manager", **{
                "Student Code": "D", "Student Name": "D", "Consultant": "Amir",
            }),
        ]
        workbook = self._build(rows)
        ws = workbook["Same Manager"]
        dates_in_order = [row[7] for row in ws.iter_rows(min_row=2, values_only=True)]
        codes_in_order = [row[0] for row in ws.iter_rows(min_row=2, values_only=True)]
        self.assertEqual(codes_in_order, ["B", "C", "A", "D"])
        self.assertEqual(
            [d.strftime("%d/%m/%Y") for d in dates_in_order],
            ["15/07/2026", "28/07/2026", "02/08/2026", "05/08/2026"],
        )

    def test_dates_sort_chronologically_not_lexicographically(self):
        # As DD/MM/YYYY text, "05/03/2026" < "20/01/2026" lexicographically
        # (comparing the leading day digits "0" vs "2" first) - but
        # chronologically 20 January 2026 is well before 5 March 2026. Both
        # dates must be in the past relative to TODAY (2026-08-13) to
        # qualify at all; only sorting on the real date object (as done
        # here, never the formatted display string) gets this right.
        rows = [
            _row("05-Assessment", "2026-03-05", "Mgr", **{
                "Student Code": "MAR", "Student Name": "Mar", "Consultant": "A",
            }),
            _row("05-Assessment", "2026-01-20", "Mgr", **{
                "Student Code": "JAN", "Student Name": "Jan", "Consultant": "A",
            }),
        ]
        workbook = self._build(rows)
        ws = workbook["Mgr"]
        codes_in_order = [row[0] for row in ws.iter_rows(min_row=2, values_only=True)]
        self.assertEqual(codes_in_order, ["JAN", "MAR"])

    def test_oldest_date_is_first(self):
        rows = [
            _row("05-Assessment", "2026-08-02", "Mgr", **{
                "Student Code": "A", "Student Name": "A", "Consultant": "Z",
            }),
            _row("05-Assessment", "2026-07-15", "Mgr", **{
                "Student Code": "B", "Student Name": "B", "Consultant": "A",
            }),
        ]
        workbook = self._build(rows)
        ws = workbook["Mgr"]
        first_code = list(ws.iter_rows(min_row=2, values_only=True))[0][0]
        self.assertEqual(first_code, "B")

    def test_newest_date_is_last(self):
        rows = [
            _row("05-Assessment", "2026-08-02", "Mgr", **{
                "Student Code": "A", "Student Name": "A", "Consultant": "Z",
            }),
            _row("05-Assessment", "2026-07-15", "Mgr", **{
                "Student Code": "B", "Student Name": "B", "Consultant": "A",
            }),
        ]
        workbook = self._build(rows)
        ws = workbook["Mgr"]
        last_code = list(ws.iter_rows(min_row=2, values_only=True))[-1][0]
        self.assertEqual(last_code, "A")

    def test_same_date_records_sort_by_consultant_alphabetically(self):
        rows = [
            _row("05-Assessment", "2026-08-02", "Mgr", **{
                "Student Code": "Z1", "Student Name": "Same", "Consultant": "Zara",
            }),
            _row("05-Assessment", "2026-08-02", "Mgr", **{
                "Student Code": "A1", "Student Name": "Same", "Consultant": "Amir",
            }),
        ]
        workbook = self._build(rows)
        ws = workbook["Mgr"]
        codes_in_order = [row[0] for row in ws.iter_rows(min_row=2, values_only=True)]
        self.assertEqual(codes_in_order, ["A1", "Z1"])

    def test_same_date_and_consultant_records_sort_by_student_name(self):
        rows = [
            _row("05-Assessment", "2026-08-02", "Mgr", **{
                "Student Code": "Z1", "Student Name": "Zed Student", "Consultant": "Amir",
            }),
            _row("05-Assessment", "2026-08-02", "Mgr", **{
                "Student Code": "A1", "Student Name": "Amy Student", "Consultant": "Amir",
            }),
        ]
        workbook = self._build(rows)
        ws = workbook["Mgr"]
        codes_in_order = [row[0] for row in ws.iter_rows(min_row=2, values_only=True)]
        self.assertEqual(codes_in_order, ["A1", "Z1"])

    def test_every_application_manager_tab_follows_the_same_date_first_rule(self):
        rows = []
        for manager in ("Alpha", "Beta", "Gamma"):
            rows.append(_row("05-Assessment", "2026-08-05", manager, **{
                "Student Code": f"{manager}-NEW", "Student Name": "N", "Consultant": "Zara",
            }))
            rows.append(_row("05-Assessment", "2026-07-15", manager, **{
                "Student Code": f"{manager}-OLD", "Student Name": "O", "Consultant": "Amir",
            }))
        workbook = self._build(rows)
        for manager in ("Alpha", "Beta", "Gamma"):
            ws = workbook[manager]
            codes_in_order = [row[0] for row in ws.iter_rows(min_row=2, values_only=True)]
            self.assertEqual(codes_in_order, [f"{manager}-OLD", f"{manager}-NEW"], msg=manager)


class OfferDaysExportExactAgeTests(unittest.TestCase):
    """Protects the exact Offer Days value the export shows for boundary
    and beyond-boundary ages, and that it always agrees with whichever
    bucket the record was classified into."""

    def _export_offer_days_for(self, days_ago):
        rows = [_row("05-Assessment", _ago(days_ago), "Mo", **{
            "Student Code": "S001", "Student Name": "Test Student",
            "University Name": "Uni", "Course Name": "Course", "Consultant": "Amir",
        })]
        qualifying = list_qualifying_records(rows, TODAY)
        self.assertEqual(len(qualifying), 1)
        rec = qualifying[0]
        buffer = build_offer_days_export(qualifying, sheet_title="Total")
        ws = openpyxl.load_workbook(buffer).active
        offer_days_col = EXPORT_COLUMNS.index("Offer Days") + 1
        exported_value = ws.cell(row=2, column=offer_days_col).value
        return exported_value, rec["bucket"], rec["age_days"]

    def test_submitted_today_is_zero(self):
        value, bucket, age_days = self._export_offer_days_for(0)
        self.assertEqual(value, 0)
        self.assertEqual(bucket, "0-10 Days")
        self.assertEqual(value, age_days)

    def test_ten_days_ago_is_ten(self):
        value, bucket, age_days = self._export_offer_days_for(10)
        self.assertEqual(value, 10)
        self.assertEqual(bucket, "0-10 Days")
        self.assertEqual(value, age_days)

    def test_eleven_days_ago_is_eleven(self):
        value, bucket, age_days = self._export_offer_days_for(11)
        self.assertEqual(value, 11)
        self.assertEqual(bucket, "11-20 Days")
        self.assertEqual(value, age_days)

    def test_thirty_days_ago_is_thirty(self):
        value, bucket, age_days = self._export_offer_days_for(30)
        self.assertEqual(value, 30)
        self.assertEqual(bucket, "21-30 Days")
        self.assertEqual(value, age_days)

    def test_thirty_one_days_ago_is_thirty_one(self):
        value, bucket, age_days = self._export_offer_days_for(31)
        self.assertEqual(value, 31)
        self.assertEqual(bucket, "31+ Days")
        self.assertEqual(value, age_days)

    def test_older_records_show_true_exact_age_not_a_rounded_31(self):
        for days_ago in (38, 47, 62, 90):
            value, bucket, age_days = self._export_offer_days_for(days_ago)
            self.assertEqual(value, days_ago, msg=days_ago)
            self.assertEqual(bucket, "31+ Days", msg=days_ago)
            self.assertEqual(value, age_days, msg=days_ago)


class OfferDaysExportsReconcileWithDashboardTests(unittest.TestCase):
    """All five card exports (Total + 4 buckets) must reconcile exactly to
    the dashboard's own counts for the same dataset."""

    def setUp(self):
        self.rows = (
            [_row("05-Assessment", _ago(3), "Alex", **{"Student Code": f"A{i}", "Consultant": "Amir"}) for i in range(4)]
            + [_row("06-Decision", _ago(15), "Alex", **{"Student Code": f"B{i}", "Consultant": "Amir"}) for i in range(3)]
            + [_row("04-Onboarding", _ago(25), "Mo", **{"Student Code": f"C{i}", "Consultant": "Zara"}) for i in range(2)]
            + [_row("05-Assessment", _ago(45), "Mo", **{"Student Code": f"D{i}", "Consultant": "Zara"}) for i in range(5)]
        )
        self.report = build_offer_days_report(self.rows, TODAY)
        self.qualifying = list_qualifying_records(self.rows, TODAY)

    def test_total_export_reconciles_with_dashboard_total(self):
        buffer = build_offer_days_export(self.qualifying, sheet_title="Total")
        ws = openpyxl.load_workbook(buffer).active
        self.assertEqual(ws.max_row - 1, self.report["total"])
        self.assertEqual(ws.max_row - 1, 14)

    def test_each_bucket_export_reconciles_with_its_dashboard_card(self):
        for bucket in BUCKETS:
            bucket_records = [r for r in self.qualifying if r["bucket"] == bucket]
            buffer = build_offer_days_export(bucket_records, sheet_title=bucket)
            ws = openpyxl.load_workbook(buffer).active
            exported_count = ws.max_row - 1
            self.assertEqual(exported_count, self.report["overall"][bucket], msg=bucket)


class ExportSlugAndFilenameTests(unittest.TestCase):
    def test_total_slug_resolves_to_no_bucket_filter(self):
        bucket_label, display_label = resolve_export_bucket(TOTAL_EXPORT_SLUG)
        self.assertIsNone(bucket_label)
        self.assertEqual(display_label, "Total")

    def test_bucket_slug_resolves_to_its_bucket_label(self):
        bucket_label, display_label = resolve_export_bucket("31-plus")
        self.assertEqual(bucket_label, "31+ Days")
        self.assertEqual(display_label, "31+ Days")

    def test_unknown_slug_is_flagged_invalid(self):
        _, display_label = resolve_export_bucket("bogus")
        self.assertIsNone(display_label)

    def test_filenames(self):
        self.assertEqual(
            export_filename(TOTAL_EXPORT_SLUG, date(2026, 8, 13)), "Offer_Days_Total_13-08-2026.xlsx"
        )
        self.assertEqual(
            export_filename("31-plus", date(2026, 8, 13)), "Offer_Days_31_Plus_13-08-2026.xlsx"
        )
        self.assertEqual(
            export_filename("11-20", date(2026, 8, 13)), "Offer_Days_11-20_13-08-2026.xlsx"
        )

    def test_filename_includes_intake_year_when_given(self):
        self.assertEqual(
            export_filename(TOTAL_EXPORT_SLUG, date(2026, 8, 13), intake_year=2026),
            "Offer_Days_Total_2026_13-08-2026.xlsx",
        )
        self.assertEqual(
            export_filename("31-plus", date(2026, 8, 13), intake_year=2027),
            "Offer_Days_31_Plus_2027_13-08-2026.xlsx",
        )

    def test_filename_includes_intake_bucket_label_when_given(self):
        self.assertEqual(
            export_filename(
                TOTAL_EXPORT_SLUG, date(2026, 8, 13), intake_year=2027, intake_bucket_label="Intake 01"
            ),
            "Offer_Days_Total_2027_Intake01_13-08-2026.xlsx",
        )

    def test_filename_omits_intake_bucket_label_when_not_given(self):
        self.assertEqual(
            export_filename(TOTAL_EXPORT_SLUG, date(2026, 8, 13), intake_year=2027),
            "Offer_Days_Total_2027_13-08-2026.xlsx",
        )


class FormulaInjectionProtectionTests(unittest.TestCase):
    """Confirms build_offer_days_export()/build_offer_days_total_export()
    (both funnel through _write_records_worksheet) are actually wired to
    excel_export_helpers.safe_append_row() (Finding 11)."""

    def setUp(self):
        self.rows = [
            _row("04-Onboarding", _ago(5), "Mo", **{
                "Student Code": "S001", "Student Name": "=SUM(1,1)", "University Name": "Uni A",
                "Course Name": "Course A", "Consultant": "Zara",
            }),
        ]
        self.qualifying = list_qualifying_records(self.rows, TODAY)

    def test_single_sheet_export_does_not_store_a_formula(self):
        buffer = build_offer_days_export(self.qualifying, sheet_title="Total")
        wb = openpyxl.load_workbook(buffer)
        ws = wb.active
        cell = ws.cell(row=2, column=EXPORT_COLUMNS.index("Student Name") + 1)
        self.assertEqual(cell.value, "=SUM(1,1)")
        self.assertNotEqual(cell.data_type, "f")

    def test_total_export_does_not_store_a_formula(self):
        buffer = build_offer_days_total_export(self.qualifying)
        wb = openpyxl.load_workbook(buffer)
        ws = wb["Mo"]
        cell = ws.cell(row=2, column=EXPORT_COLUMNS.index("Student Name") + 1)
        self.assertEqual(cell.value, "=SUM(1,1)")
        self.assertNotEqual(cell.data_type, "f")


if __name__ == "__main__":
    unittest.main()
