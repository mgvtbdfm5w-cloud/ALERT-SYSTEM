"""The University Pipeline page has no Number Breakdown section."""

import io
import unittest

from tests.flask_test_support import IsolatedAppTestCase, extract_token
from tests.test_upload_atomicity import book, row


class UniversityPipelinePageTests(IsolatedAppTestCase):
    def setUp(self):
        super().setUp()
        self.full = self._client_logged_in_as("full")
        token = extract_token(self.full.get("/login").get_data(as_text=True))
        data = book([row(**{"Student Code": "P1", "Student Name": "A", "Application Status": "Assessment", "Intake": "September 2026",
                            "University Name": "Uni One"})], lookups={"status": [("Assessment", "05-Assessment")]})
        self.assertEqual(self.full.post("/upload", data={"csrf_token": token, "excel_file": (io.BytesIO(data), "f.xlsx")},
                                        content_type="multipart/form-data").status_code, 302)

    def test_the_breakdown_table_is_gone_but_the_chart_and_card_remain(self):
        html = self.full.get("/university-pipeline?year=2026").get_data(as_text=True)
        self.assertNotIn("Number Breakdown", html)
        self.assertNotIn("pipeline-table", html)
        self.assertNotIn("Grand Total", html)
        self.assertIn("University Pipeline Health", html)
        self.assertIn("Uni One", html)
        self.assertIn("summary-card-overall", html)

    def test_other_pages_keep_their_breakdown(self):
        for path in ("/enrolled?year=2026",):
            self.assertIn("Number Breakdown", self.full.get(path).get_data(as_text=True), path)


if __name__ == "__main__":
    unittest.main()
