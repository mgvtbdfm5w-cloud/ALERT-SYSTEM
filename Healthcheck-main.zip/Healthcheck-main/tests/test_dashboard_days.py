"""Application Manager Pipeline Health pop-up: a Days column, counted from the
Submitted To Uni date - today minus it while the application is Pending Assessment,
Offer Accepted Date minus it in any other stage. The other pages' pop-ups have no
such column."""

import unittest
from datetime import date

from pipeline import DAYS_RECORD_COLUMNS, APPLICATION_RECORD_COLUMNS, days_since_submitted
from tests.test_bonus import TODAY, PageBase, app, d, workbook_rows

ROWS = [
    app("PA1", sub=d(17)),                                  # pending assessment, submitted 17 days ago
    app("PA2", sub=d(17), accepted=d(2)),                   # an offer date does not matter while Pending Assessment
    app("PA3", sub=None),                                   # no submitted date
    app("EN1", sub=d(40), accepted=d(10), status="09-Enrolled"),   # 30 days from submission to offer
    app("EN2", sub=d(40), status="09-Enrolled"),            # no offer accepted date
    app("EN3", sub=None, accepted=d(10), status="09-Enrolled"),    # no submitted date
    app("EN4", sub=d(10), accepted=d(40), status="09-Enrolled"),   # offer dated before submission
]


class DaysColumnTests(PageBase):
    ROWS = workbook_rows(ROWS)

    def days(self, group, query="year=2026"):
        response = self.full.get(f"/dashboard/records?{query}&manager=Alice&group={group}")
        self.assertEqual(response.status_code, 200)
        return {r["code"]: r["days"] for r in response.get_json()["records"]}

    def test_pending_assessment_is_today_minus_the_submitted_date(self):
        self.assertEqual(self.days("pending_assessment"), {"PA1": "17", "PA2": "17", "PA3": ""})

    def test_any_other_stage_is_offer_accepted_minus_the_submitted_date(self):
        self.assertEqual(self.days("enrolled_this_intake"), {"EN1": "30", "EN2": "", "EN3": "", "EN4": "-30"})

    def test_the_window_gets_a_days_column_after_the_usual_six(self):
        data = self.full.get("/dashboard/records?year=2026&manager=Alice&group=pending_assessment").get_json()
        self.assertEqual(data["columns"], DAYS_RECORD_COLUMNS)
        self.assertEqual(data["columns"][:6], APPLICATION_RECORD_COLUMNS)
        self.assertEqual(data["columns"][6], ["Days", "days"])
        self.assertEqual(sorted(data["records"][0]), sorted(k for _, k in DAYS_RECORD_COLUMNS))

    def test_the_count_and_the_applications_are_the_same_as_before(self):
        data = self.full.get("/dashboard/records?year=2026&manager=Alice&group=pending_assessment").get_json()
        self.assertEqual(data["count"], 3)
        self.assertEqual([r["code"] for r in data["records"]], ["PA1", "PA2", "PA3"])

    def test_other_pages_windows_have_no_days_column(self):
        for url in ("/thirty-days/records?year=2026&manager=Alice&status=open",
                    "/dashboard/just-jon/records?year=2026&chart=manager&name=Alice&stage=05-Assessment"):
            data = self.full.get(url).get_json()
            self.assertNotIn("days", data["records"][0] if data["records"] else {}, url)
            self.assertNotIn(["Days", "days"], data.get("columns", []), url)


class DaysSinceSubmittedTests(unittest.TestCase):
    TODAY = date(2026, 11, 1)

    def test_waiting_uses_today_and_otherwise_the_offer_accepted_date(self):
        row = {"Submitted To Uni": "2026-10-01", "Offer Accepted Date": "2026-10-11"}
        self.assertEqual(days_since_submitted(row, self.TODAY, True), {"days": "31"})
        self.assertEqual(days_since_submitted(row, self.TODAY, False), {"days": "10"})

    def test_blank_when_a_needed_date_is_missing_or_unreadable(self):
        self.assertEqual(days_since_submitted({"Offer Accepted Date": "2026-10-11"}, self.TODAY, False), {"days": ""})
        self.assertEqual(days_since_submitted({"Submitted To Uni": "2026-10-01"}, self.TODAY, False), {"days": ""})
        self.assertEqual(days_since_submitted({"Submitted To Uni": "nonsense"}, self.TODAY, True), {"days": ""})
        self.assertEqual(days_since_submitted({}, self.TODAY, True), {"days": ""})

    def test_the_same_day_is_zero(self):
        row = {"Submitted To Uni": "2026-11-01", "Offer Accepted Date": "2026-11-01"}
        self.assertEqual(days_since_submitted(row, self.TODAY, True), {"days": "0"})
        self.assertEqual(days_since_submitted(row, self.TODAY, False), {"days": "0"})


if __name__ == "__main__":
    unittest.main()
