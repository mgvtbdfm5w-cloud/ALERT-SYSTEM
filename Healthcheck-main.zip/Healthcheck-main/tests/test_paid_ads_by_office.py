"""Paid Ads page: Paid Leads by Sales Office - a row per month (newest first) that
opens to show its days, a column per Sales Office and a Total column."""

import io
import re
import unittest
from contextlib import contextmanager
from datetime import date
from unittest import mock

from flask import template_rendered

from paid_ads import build_paid_leads_by_office
from tests.flask_test_support import IsolatedAppTestCase, app_module, extract_token
from tests.test_allocation import lead, leads_book

OFFICES = {"mel": "OXF", "hannah": "LON", "kian": "MAN", "jalloh": "CAR", "raymond": "LON"}
OTHERS = {"raymond"}
TODAY = date(2026, 10, 18)                       # a Sunday


def row(day, consultant, source="Paid Ad"):
    return {"Creation Date": day, "Consultant": consultant, "Lead Source": source}


class BuilderTests(unittest.TestCase):
    def build(self, rows, as_of=TODAY):
        return build_paid_leads_by_office(rows, OFFICES, OTHERS, as_of)

    def test_only_paid_ad_leads_are_counted(self):
        rows = [row("2026-10-01", "Mel"), row("2026-10-01", "Mel", " paid ad "), row("2026-10-01", "Mel", "Agent"), row("2026-10-01", "Mel", "Paid Ads"),
                row("2026-10-01", "Mel", "Inbound Call"), row("2026-10-01", "Mel", ""), row("2026-10-01", "Mel", None)]
        report = self.build(rows)
        self.assertEqual(report["totals"]["total"], 2)
        self.assertEqual(report["totals"]["counts"]["OXF"], 2)

    def test_columns_are_lon_car_man_oxf_then_other_offices_then_unassigned(self):
        self.assertEqual(self.build([])["offices"], ["LON", "CAR", "MAN", "OXF"])
        rows = [row("2026-10-01", "Mel"), row("2026-10-01", "Newbie"), row("2026-10-01", ""), row("2026-10-01", "Zed")]
        self.assertEqual(self.build(rows)["offices"], ["LON", "CAR", "MAN", "OXF", "Other", "Unassigned"])

    def test_a_consultant_goes_to_their_offices_column_even_when_set_to_group_as_other(self):
        report = self.build([row("2026-10-01", "Raymond"), row("2026-10-01", "Hannah")])
        self.assertEqual(report["totals"]["counts"]["LON"], 2)
        self.assertNotIn("Other", report["offices"])

    def test_a_consultant_not_on_the_lookup_is_other_and_no_consultant_is_unassigned(self):
        report = self.build([row("2026-10-01", "Newbie"), row("2026-10-01", ""), row("2026-10-01", None), row("2026-10-01", "   ")])
        self.assertEqual(report["totals"]["counts"]["Other"], 1)
        self.assertEqual(report["totals"]["counts"]["Unassigned"], 3)

    def test_months_newest_first_and_days_newest_first(self):
        rows = [row("2026-08-31", "Mel"), row("2026-10-03", "Kian"), row("2026-09-15", "Hannah"), row("2026-10-10", "Mel"), row("2025-12-25", "Jalloh")]
        report = self.build(rows)
        self.assertEqual([m["month_key"] for m in report["months"]], ["2026-10", "2026-09", "2026-08", "2025-12"])
        october = report["months"][0]
        self.assertEqual([d["date"] for d in october["days"]], sorted((d["date"] for d in october["days"]), reverse=True))

    def test_every_calendar_day_is_listed_with_zeros_up_to_the_day_the_data_runs_to_for_the_newest_month(self):
        report = self.build([row("2026-10-03", "Mel"), row("2026-10-10", "Kian")])
        october = report["months"][0]
        self.assertEqual([d["date"].day for d in october["days"]], list(range(18, 0, -1)), "1 to 18 October, newest first")
        by_day = {d["date"].day: d for d in october["days"]}
        self.assertEqual(by_day[3]["counts"]["OXF"], 1)
        self.assertEqual(by_day[4]["total"], 0)
        self.assertEqual(by_day[18]["total"], 0, "the day the data runs to has no lead but is listed")

    def test_a_past_month_lists_all_its_days_including_a_leap_february(self):
        report = self.build([row("2024-02-10", "Mel"), row("2026-09-05", "Mel")])
        feb, sep = report["months"][1], report["months"][0]
        self.assertEqual(len(feb["days"]), 29)
        self.assertEqual(len(sep["days"]), 30)
        self.assertEqual(feb["days"][0]["date"], date(2024, 2, 29))
        self.assertEqual(feb["days"][-1]["date"], date(2024, 2, 1))

    def test_when_the_data_runs_into_a_later_month_the_newest_month_with_leads_is_complete(self):
        report = self.build([row("2026-10-03", "Mel"), row("2026-09-05", "Mel")], as_of=date(2026, 11, 1))
        self.assertEqual(len(report["months"][0]["days"]), 31, "all of October: the data runs to 1 November")
        self.assertEqual(report["months"][0]["days"][0]["date"], date(2026, 10, 31))

    def test_the_newest_month_stops_at_the_day_the_data_runs_to_not_the_end_of_the_month(self):
        report = self.build([row("2026-10-03", "Mel")], as_of=date(2026, 10, 12))
        self.assertEqual([d["date"].day for d in report["months"][0]["days"]], list(range(12, 0, -1)))
        older = self.build([row("2026-10-03", "Mel"), row("2026-09-05", "Mel")], as_of=date(2026, 10, 12))
        self.assertEqual(len(older["months"][1]["days"]), 30, "an older month is always complete")

    def test_a_lead_in_a_month_after_the_as_of_day_still_stops_at_that_lead(self):
        report = self.build([row("2026-09-05", "Mel"), row("2026-11-05", "Mel")], as_of=date(2026, 10, 12))
        self.assertEqual(report["months"][0]["month_key"], "2026-11")
        self.assertEqual([d["date"].day for d in report["months"][0]["days"]], [5, 4, 3, 2, 1], "not the whole of November")

    def test_a_lead_dated_after_the_as_of_day_is_still_shown(self):
        report = self.build([row("2026-10-25", "Mel")])
        october = report["months"][0]
        self.assertEqual(october["days"][0]["date"], date(2026, 10, 25))
        self.assertEqual(october["total"], 1)

    def test_the_numbers_add_up_every_way(self):
        rows = [row(f"2026-{m:02d}-{d:02d}", name) for m in (8, 9, 10) for d in range(1, 15) for name in ("Mel", "Mel", "Kian", "Hannah", "Newbie", "")[: (d % 6) + 1]]
        report = self.build(rows)
        offices = report["offices"]
        for month in report["months"]:
            self.assertEqual(sum(month["counts"].values()), month["total"])
            for office in offices:
                self.assertEqual(sum(d["counts"][office] for d in month["days"]), month["counts"][office])
            for day in month["days"]:
                self.assertEqual(sum(day["counts"].values()), day["total"])
        for office in offices:
            self.assertEqual(sum(m["counts"][office] for m in report["months"]), report["totals"]["counts"][office])
        self.assertEqual(sum(m["total"] for m in report["months"]), report["totals"]["total"])
        self.assertEqual(report["totals"]["total"], len(rows))

    def test_several_leads_for_one_office_on_one_day_are_all_counted_everywhere(self):
        report = self.build([row("2026-10-05", "Mel")] * 5 + [row("2026-10-05", "Kian")] * 3 + [row("2026-10-06", "Mel")])
        october = report["months"][0]
        day5 = next(d for d in october["days"] if d["date"].day == 5)
        self.assertEqual((day5["counts"]["OXF"], day5["counts"]["MAN"], day5["total"]), (5, 3, 8))
        self.assertEqual((october["counts"]["OXF"], october["counts"]["MAN"], october["total"]), (6, 3, 9))
        self.assertEqual((report["totals"]["counts"]["OXF"], report["totals"]["total"]), (6, 9))

    def test_leads_with_no_usable_creation_date_are_ignored(self):
        report = self.build([row(None, "Mel"), row("", "Mel"), row("garbage", "Mel"), row("2026-10-02", "Mel")])
        self.assertEqual(report["totals"]["total"], 1)

    def test_no_paid_leads_gives_no_months(self):
        report = self.build([row("2026-10-02", "Mel", "Agent")])
        self.assertEqual((report["months"], report["totals"]["total"]), ([], 0))
        self.assertEqual(self.build([])["months"], [])

    def test_the_input_is_not_modified(self):
        rows = [row("2026-10-02", "Mel")]
        self.build(rows)
        self.assertEqual(rows, [row("2026-10-02", "Mel")])


@contextmanager
def captured():
    rendered = []

    def record(sender, template, context, **extra):
        rendered.append((template.name, dict(context)))

    template_rendered.connect(record, app_module.app)
    try:
        yield rendered
    finally:
        template_rendered.disconnect(record, app_module.app)


LEADS = [
    # October (month in progress)
    lead("A1", "Mel X", "03/10/2026", source="Paid Ad/Google"), lead("A2", "Mel X", "03/10/2026", source="Paid Ad/Google"),
    lead("A3", "Hannah Y", "03/10/2026", source="Paid Ad/Meta"), lead("A4", "Kian Q", "10/10/2026", source="Paid Ad/Google"),
    lead("A5", "Raymond P", "10/10/2026", source="Paid Ad/Google"), lead("A6", "Jalloh Z", "17/10/2026", source="Paid Ad/Google"),
    lead("A7", "Newbie N", "17/10/2026", source="Paid Ad/Google"), lead("A8", "", "17/10/2026", source="Paid Ad/Google"),
    lead("X1", "Mel X", "03/10/2026", source="Agent/Someone"),                                        # not paid
    # September
    lead("B1", "Mel X", "30/09/2026", source="Paid Ad/Google"), lead("B2", "Hannah Y", "01/09/2026", source="Paid Ad/Google"),
    lead("X2", "Kian Q", "05/09/2026", source="Inbound Call/Phone"),
    # August
    lead("C1", "Kian Q", "20/08/2026", source="Paid Ad/Google"),
]


class PageTests(IsolatedAppTestCase):
    def setUp(self):
        super().setUp()
        self.full = self._client_logged_in_as("full")
        token = lambda: extract_token(self.full.get("/login").get_data(as_text=True))
        self.assertEqual(self.full.post("/leads/upload", data={"csrf_token": token(), "excel_file": (io.BytesIO(leads_book(LEADS)), "l.xlsx")},
                                        content_type="multipart/form-data").status_code, 302)
        for consultant, office, other in (("Mel", "OXF", False), ("Hannah", "LON", False), ("Kian", "MAN", False), ("Jalloh", "CAR", False), ("Raymond", "LON", True)):
            data = {"csrf_token": token(), "source_value": consultant, "mapped_value": office}
            if other:
                data["group_as_other"] = "on"
            self.assertEqual(self.full.post("/admin/lookups/sales_office/add", data=data).status_code, 302)
        patcher = mock.patch.object(app_module, "today_uk", return_value=TODAY)
        patcher.start()
        self.addCleanup(patcher.stop)

    def page(self, client=None):
        with captured() as rendered:
            r = (client or self.full).get("/paid-ads")
        self.assertEqual(r.status_code, 200)
        return r.get_data(as_text=True), next(c for name, c in rendered if name == "paid_ads.html")

    def table(self, html):
        section = html[html.index("<h2>Paid Leads by Sales Office</h2>"):]
        return section[:section.index("</section>")]

    def cells(self, tr):
        return [re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", c)).strip() for c in re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", tr, re.S)]

    def month_rows(self, html):
        out = {}
        for tr in re.findall(r'<tr class="po-month">.*?</tr>', self.table(html), re.S):
            cells = self.cells(tr)
            out[cells[0]] = cells[1:]
        return out

    def test_the_section_sits_below_the_monthly_performance_table(self):
        html, _ = self.page()
        self.assertLess(html.index("Paid Ad Performance by Month"), html.index("Paid Leads by Sales Office"))

    def test_the_performance_table_lists_months_newest_first(self):
        html, context = self.page()
        section = html[html.index("<h2>Paid Ad Performance by Month</h2>"):html.index("<h2>Paid Leads by Sales Office</h2>")]
        body = section[section.index("<tbody>"):section.index("</tbody>")]
        months = [re.sub(r"\s*\(to date\)", "", self.cells(tr)[0]) for tr in re.findall(r"<tr>.*?</tr>", body, re.S)]
        self.assertEqual(months, ["October 2026", "September 2026", "August 2026"])
        self.assertEqual([r["month_key"] for r in context["report"]["rows"]], ["2026-08", "2026-09", "2026-10"], "the report itself is unchanged: oldest first")

    def test_the_total_row_is_still_last_and_unchanged(self):
        html, context = self.page()
        section = html[html.index("<h2>Paid Ad Performance by Month</h2>"):html.index("<h2>Paid Leads by Sales Office</h2>")]
        foot = section[section.index("<tfoot>"):section.index("</tfoot>")]
        self.assertEqual(self.cells(foot)[0], "Total")
        self.assertEqual(self.cells(foot)[1], f"{context['report']['totals']['paid_leads']:,}")
        self.assertLess(section.index("</tbody>"), section.index("<tfoot>"))

    def test_both_tables_on_the_page_now_run_newest_to_oldest(self):
        html, _ = self.page()
        top = html[html.index("<h2>Paid Ad Performance by Month</h2>"):html.index("<h2>Paid Leads by Sales Office</h2>")]
        first = [m for m in re.findall(r"(October|September|August) 2026", top)]
        second = list(self.month_rows(html))
        self.assertEqual(first, ["October", "September", "August"])
        self.assertEqual(second, ["October 2026", "September 2026", "August 2026"])

    def test_columns_are_the_offices_then_total(self):
        html, _ = self.page()
        head = self.table(html)
        head = head[head.index("<thead>"):head.index("</thead>")]
        self.assertEqual(self.cells(head), ["Month", "LON", "CAR", "MAN", "OXF", "Other", "Unassigned", "Total"])

    def test_a_row_per_month_newest_first_with_a_total_for_each(self):
        html, _ = self.page()
        rows = self.month_rows(html)
        self.assertEqual(list(rows), ["October 2026", "September 2026", "August 2026"])
        self.assertEqual(rows["October 2026"], ["2", "1", "1", "2", "1", "1", "8"])          # LON: Hannah + Raymond   CAR: Jalloh   MAN: Kian   OXF: Mel x2   Other: Newbie   Unassigned
        self.assertEqual(rows["September 2026"], ["1", "0", "0", "1", "0", "0", "2"])
        self.assertEqual(rows["August 2026"], ["0", "0", "1", "0", "0", "0", "1"])

    def test_the_bottom_row_totals_every_month(self):
        html, _ = self.page()
        foot = self.table(html)
        foot = foot[foot.index("<tfoot>"):foot.index("</tfoot>")]
        self.assertEqual(self.cells(foot), ["Total", "3", "1", "2", "3", "1", "1", "11"])

    def test_not_paid_leads_are_not_counted(self):
        html, context = self.page()
        self.assertEqual(context["office_report"]["totals"]["total"], 11)          # 14 leads, 3 of them not Paid Ad

    def test_every_month_total_agrees_with_the_paid_leads_column_of_the_performance_table(self):
        html, context = self.page()
        performance = {r["month_key"]: r["paid_leads"] for r in context["report"]["rows"]}
        by_office = {m["month_key"]: m["total"] for m in context["office_report"]["months"]}
        self.assertEqual(by_office, {k: v for k, v in performance.items() if v})
        self.assertEqual(by_office, {"2026-10": 8, "2026-09": 2, "2026-08": 1})

    def test_each_month_opens_to_its_days_newest_first_with_zero_days_too(self):
        html, _ = self.page()
        october = [self.cells(tr) for tr in re.findall(r'<tr class="po-day[^"]*" data-month="2026-10".*?</tr>', self.table(html), re.S)]
        self.assertEqual(len(october), 18, "1 to 18 October")
        self.assertEqual(october[0][0], "Sunday 18 October 2026")
        self.assertEqual(october[1], ["Saturday 17 October 2026", "0", "1", "0", "0", "1", "1", "3"])
        self.assertEqual([r for r in october if r[0] == "Saturday 10 October 2026"][0], ["Saturday 10 October 2026", "1", "0", "1", "0", "0", "0", "2"])
        self.assertEqual([r for r in october if r[0] == "Saturday 3 October 2026"][0], ["Saturday 3 October 2026", "1", "0", "0", "2", "0", "0", "3"])
        self.assertEqual(october[-1][0], "Thursday 1 October 2026")
        self.assertIn("po-day-empty", re.search(r'<tr class="(po-day[^"]*)" data-month="2026-10"', self.table(html)).group(1), "an empty day is greyed")
        september = re.findall(r'<tr class="po-day[^"]*" data-month="2026-09"', self.table(html))
        self.assertEqual(len(september), 30)

    def test_the_days_add_up_to_their_month_on_the_page(self):
        html, _ = self.page()
        table = self.table(html)
        for key, label in (("2026-10", "October 2026"), ("2026-09", "September 2026"), ("2026-08", "August 2026")):
            days = [self.cells(tr) for tr in re.findall(rf'<tr class="po-day[^"]*" data-month="{key}".*?</tr>', table, re.S)]
            summed = [sum(int(d[i]) for d in days) for i in range(1, 8)]
            self.assertEqual([str(n) for n in summed], self.month_rows(html)[label], key)

    def test_each_month_has_a_button_that_opens_it_and_the_page_script_wires_it(self):
        html, _ = self.page()
        table = self.table(html)
        buttons = re.findall(r'<button type="button" class="po-toggle" aria-expanded="false" aria-controls="(po-days-[0-9-]+)">', table)
        self.assertEqual(buttons, ["po-days-2026-10", "po-days-2026-09", "po-days-2026-08"])
        for target in buttons:
            self.assertEqual(table.count(f'id="{target}"'), 1, target)
        self.assertIn("table.classList.add('po-js')", table)
        self.assertIn("group.classList.toggle('po-open', open)", table)
        self.assertIn("Click a month to see it day by day.", table)

    def test_the_stylesheet_hides_days_only_when_javascript_is_on_and_shows_them_when_a_month_is_open(self):
        css = self.full.get("/static/style.css").get_data(as_text=True)
        self.assertRegex(css, r"\.paid-office-table\.po-js \.po-day \{\s*display: none;")
        self.assertRegex(css, r"\.paid-office-table\.po-js \.po-open \.po-day \{\s*display: table-row;")
        self.assertNotRegex(css, r"\.paid-office-table \.po-day \{\s*display: none")

    def upload_leads(self, rows):
        token = extract_token(self.full.get("/login").get_data(as_text=True))
        r = self.full.post("/leads/upload", data={"csrf_token": token, "excel_file": (io.BytesIO(leads_book(rows)), "l.xlsx")}, content_type="multipart/form-data")
        self.assertEqual(r.status_code, 302)

    def test_with_leads_but_none_of_them_paid_the_section_says_there_are_none(self):
        self.upload_leads([lead("Z1", "Mel X", "03/10/2026", source="Agent/Z")])
        html, context = self.page()
        self.assertIn("<h2>Paid Leads by Sales Office</h2>", html)
        self.assertIn("No Paid Ad leads yet.", self.table(html))
        self.assertNotIn('<table class="data-table paid-office-table"', html)
        self.assertEqual(context["office_report"]["months"], [])
        self.assertIn("Paid Ad Performance by Month", html, "the rest of the page is unaffected")

    def test_with_no_leads_file_at_all_the_section_says_there_are_none(self):
        import sqlite3
        from tests.flask_test_support import db_module
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute("DELETE FROM active_leads_dataset")
        conn.commit()
        conn.close()
        html, _ = self.page()
        self.assertIn("No Paid Ad leads yet.", self.table(html))
        self.assertIn("No Leads file has been uploaded yet", html)

    def test_the_newest_months_days_stop_at_the_day_the_leads_file_was_uploaded(self):
        import sqlite3
        from tests.flask_test_support import db_module
        self.upload_leads([lead("U1", "Mel X", "03/10/2026", source="Paid Ad/Google"), lead("U2", "Kian Q", "10/10/2026", source="Paid Ad/Google"),
                           lead("U3", "Mel X", "30/09/2026", source="Paid Ad/Google")])
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute("UPDATE active_leads_dataset SET uploaded_at = '2026-10-12T09:30:00'")
        conn.commit()
        conn.close()
        html, _ = self.page()
        days = re.findall(r'<tr class="po-day[^"]*" data-month="2026-10".*?</tr>', self.table(html), re.S)
        self.assertEqual([self.cells(tr)[0] for tr in days][:2], ["Monday 12 October 2026", "Sunday 11 October 2026"])
        self.assertEqual(len(days), 12, "1 to 12 October: nothing was uploaded for later days, so they are not shown as zeros")
        self.assertEqual(len(re.findall(r'data-month="2026-09"', self.table(html))), 30, "an older month is complete")

    def test_a_new_leads_upload_changes_the_table(self):
        self.upload_leads([lead("N1", "Kian Q", "17/10/2026", source="Paid Ad/Google")])
        html, context = self.page()
        self.assertEqual(context["office_report"]["offices"], ["LON", "CAR", "MAN", "OXF"], "no Other or Unassigned column when there is nothing in them")
        self.assertEqual(self.month_rows(html), {"October 2026": ["0", "0", "1", "0", "1"]})

    def test_only_full_access_and_admissions_can_open_the_page_as_before(self):
        for role, expected in (("full", 200), ("admissions", 200), ("consultants", 403), ("marketing", 403)):
            self.assertEqual(self._client_logged_in_as(role).get("/paid-ads").status_code, expected, role)

    def test_other_pages_do_not_have_the_table(self):
        for path in ("/leads-dashboard?month=2026-10", "/allocation?month=2026-10", "/split?month=2026-10"):
            self.assertNotIn("Paid Leads by Sales Office", self.full.get(path).get_data(as_text=True), path)


if __name__ == "__main__":
    unittest.main()
