"""db.db_connection(): the one context manager that owns a connection.

Pinned behaviour: the connection is ALWAYS closed (success, ordinary
exception, sqlite3 errors, KeyboardInterrupt, any other BaseException); an
open transaction is rolled back explicitly when the block fails; a
successful block is NOT implicitly committed (the app's helpers commit
explicitly); the next writer can take the database immediately; and the
connection itself is still the unchanged get_connection() one.

This is deliberately NOT sqlite3's own `with conn:`, which commits/rolls
back but never closes - see test_sqlite_builtin_context_manager_does_not_close
for the fact the design rests on. Temp databases only; nothing sleeps and
nothing depends on garbage collection (every connection is held by the test).
"""

import inspect
import shutil
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import db
from tests.connection_tracking import ConnectionTracker, FaultyConnection, is_closed


class _OddBaseException(BaseException):
    """Stands in for "some other BaseException" (like GeneratorExit)."""


class DbConnectionTestCase(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="gsp_dbconn_test_"))
        patcher = mock.patch.object(db, "DB_PATH", self.tmp / "t.db")
        patcher.start()
        self.addCleanup(patcher.stop)
        self.addCleanup(shutil.rmtree, self.tmp, True)
        setup = sqlite3.connect(db.DB_PATH)
        setup.execute("CREATE TABLE t (id INTEGER PRIMARY KEY, name TEXT)")
        setup.commit()
        setup.close()
        self.tracker = ConnectionTracker(db)
        self.tracker.install()
        self.addCleanup(self.tracker.uninstall)

    # helpers --------------------------------------------------------------
    def rows(self):
        conn = sqlite3.connect(db.DB_PATH)
        try:
            return [r[0] for r in conn.execute("SELECT name FROM t ORDER BY id")]
        finally:
            conn.close()

    def assert_next_writer_is_immediate(self):
        """A second connection with a ZERO timeout can write straight away -
        proof no lock was left behind (and no reliance on GC: the tracker
        still holds the first connection)."""
        writer = sqlite3.connect(db.DB_PATH, timeout=0)
        try:
            writer.execute("INSERT INTO t (name) VALUES ('next-writer')")
            writer.commit()
        finally:
            writer.close()
        self.assertIn("next-writer", self.rows())

    def only_connection(self):
        self.assertEqual(self.tracker.opened, 1)
        return self.tracker.connections[0]


class ClosesAlwaysTests(DbConnectionTestCase):
    def test_closes_on_success(self):
        with db.db_connection() as conn:
            self.assertFalse(is_closed(conn))
            conn.execute("SELECT 1").fetchone()
        self.assertTrue(is_closed(self.only_connection()))

    def test_closes_on_runtime_error_and_reraises_the_same_exception(self):
        boom = RuntimeError("boom")
        with self.assertRaises(RuntimeError) as caught:
            with db.db_connection():
                raise boom
        self.assertIs(caught.exception, boom)
        self.assertTrue(is_closed(self.only_connection()))

    def test_closes_on_operational_error(self):
        with self.assertRaises(sqlite3.OperationalError):
            with db.db_connection() as conn:
                conn.execute("SELECT * FROM table_that_does_not_exist")
        self.assertTrue(is_closed(self.only_connection()))

    def test_closes_on_an_injected_execute_failure(self):
        with self.tracker.failing("execute"):
            with self.assertRaises(sqlite3.OperationalError):
                with db.db_connection() as conn:
                    conn.execute("SELECT 1")
        self.assertTrue(is_closed(self.only_connection()))

    def test_closes_on_keyboard_interrupt(self):
        with self.assertRaises(KeyboardInterrupt):
            with db.db_connection():
                raise KeyboardInterrupt()
        self.assertTrue(is_closed(self.only_connection()))

    def test_closes_on_other_base_exceptions(self):
        for exc in (_OddBaseException(), SystemExit(3), GeneratorExit()):
            with self.subTest(exc=type(exc).__name__):
                self.tracker.reset()
                with self.assertRaises(type(exc)):
                    with db.db_connection():
                        raise exc
                self.assertTrue(is_closed(self.only_connection()))

    def test_closes_when_the_block_returns_early_from_a_function(self):
        def early_return():
            with db.db_connection() as conn:
                conn.execute("SELECT 1")
                return "left early"

        self.assertEqual(early_return(), "left early")
        self.assertTrue(is_closed(self.only_connection()))

    def test_each_use_gets_its_own_connection_and_all_are_closed(self):
        for _ in range(25):
            with db.db_connection() as conn:
                conn.execute("SELECT 1")
        self.assertEqual(self.tracker.opened, 25)
        self.assertEqual(self.tracker.leaked(), [])
        self.assertEqual(self.tracker.max_open, 1)


class TransactionSemanticsTests(DbConnectionTestCase):
    def test_rolls_back_an_active_write_transaction_on_exception(self):
        with self.assertRaises(RuntimeError):
            with db.db_connection() as conn:
                conn.execute("INSERT INTO t (name) VALUES ('uncommitted')")
                self.assertTrue(conn.in_transaction)
                raise RuntimeError("fail mid-write")
        self.assertEqual(self.rows(), [])
        self.assertGreaterEqual(
            self.only_connection().rollback_calls, 1, "rollback must be explicit, not just implied by close()"
        )

    def test_rolls_back_on_keyboard_interrupt_too(self):
        with self.assertRaises(KeyboardInterrupt):
            with db.db_connection() as conn:
                conn.execute("INSERT INTO t (name) VALUES ('uncommitted')")
                raise KeyboardInterrupt()
        self.assertEqual(self.rows(), [])
        self.assertGreaterEqual(self.only_connection().rollback_calls, 1)

    def test_does_not_implicitly_commit_on_successful_exit(self):
        with db.db_connection() as conn:
            conn.execute("INSERT INTO t (name) VALUES ('never-committed')")
        self.assertEqual(self.rows(), [], "a block that forgets to commit must not be committed for it")
        self.assertEqual(self.only_connection().commit_calls, 0)

    def test_an_explicit_commit_inside_the_block_persists(self):
        with db.db_connection() as conn:
            conn.execute("INSERT INTO t (name) VALUES ('committed')")
            conn.commit()
        self.assertEqual(self.rows(), ["committed"])

    def test_work_committed_before_a_later_failure_is_kept(self):
        with self.assertRaises(RuntimeError):
            with db.db_connection() as conn:
                conn.execute("INSERT INTO t (name) VALUES ('first')")
                conn.commit()
                conn.execute("INSERT INTO t (name) VALUES ('second')")
                raise RuntimeError("boom")
        self.assertEqual(self.rows(), ["first"], "only the uncommitted part is rolled back")

    def test_no_rollback_is_issued_when_no_transaction_is_open(self):
        with self.assertRaises(RuntimeError):
            with db.db_connection() as conn:
                conn.execute("SELECT 1").fetchone()
                raise RuntimeError("boom")
        self.assertEqual(self.only_connection().rollback_calls, 0)

    def test_a_failing_rollback_cannot_mask_the_original_exception_or_prevent_the_close(self):
        original = RuntimeError("the real problem")
        with mock.patch.object(FaultyConnection, "rollback", side_effect=sqlite3.OperationalError("cannot rollback")):
            with self.assertRaises(RuntimeError) as caught:
                with db.db_connection() as conn:
                    conn.execute("INSERT INTO t (name) VALUES ('x')")
                    raise original
        self.assertIs(caught.exception, original)
        self.assertTrue(is_closed(self.only_connection()))
        self.assertEqual(self.rows(), [])


class NextWriterTests(DbConnectionTestCase):
    def test_the_next_writer_gets_the_database_immediately_after_a_failure_mid_write(self):
        with self.assertRaises(RuntimeError):
            with db.db_connection() as conn:
                conn.execute("INSERT INTO t (name) VALUES ('half-done')")
                raise RuntimeError("fail mid-write")
        self.assert_next_writer_is_immediate()
        self.assertEqual(self.rows(), ["next-writer"])

    def test_the_next_writer_gets_the_database_immediately_after_success(self):
        with db.db_connection() as conn:
            conn.execute("INSERT INTO t (name) VALUES ('ok')")
            conn.commit()
        self.assert_next_writer_is_immediate()

    def test_and_after_a_keyboard_interrupt(self):
        with self.assertRaises(KeyboardInterrupt):
            with db.db_connection() as conn:
                conn.execute("INSERT INTO t (name) VALUES ('half-done')")
                raise KeyboardInterrupt()
        self.assert_next_writer_is_immediate()

    def test_contrast_a_leaked_mid_write_connection_DOES_block_the_next_writer(self):
        """Why the guarantee matters: the same failure WITHOUT the context
        manager (the connection simply kept alive, as a leak is) holds the
        write lock, and a zero-timeout writer is refused."""
        leaked = db.get_connection()
        leaked.execute("INSERT INTO t (name) VALUES ('leaked-write')")
        writer = sqlite3.connect(db.DB_PATH, timeout=0)
        try:
            with self.assertRaises(sqlite3.OperationalError):
                writer.execute("INSERT INTO t (name) VALUES ('blocked')")
        finally:
            writer.close()
            leaked.rollback()
            leaked.close()


class UnchangedConnectionTests(DbConnectionTestCase):
    def test_the_connection_is_the_unchanged_factory_connection(self):
        self.tracker.uninstall()                                     # use the real db.get_connection
        with db.db_connection() as conn:
            self.assertIs(conn.row_factory, sqlite3.Row)
            self.assertEqual(conn.execute("PRAGMA busy_timeout").fetchone()[0], 5000)
            self.assertEqual(conn.execute("PRAGMA journal_mode").fetchone()[0], "delete")
            self.assertEqual(conn.isolation_level, "")
        source = inspect.getsource(db.get_connection)
        self.assertEqual(source.count("sqlite3.connect(DB_PATH)"), 1)
        self.assertNotIn("PRAGMA", source)

    def test_it_obtains_its_connection_from_get_connection(self):
        with db.db_connection():
            pass
        self.assertEqual(self.tracker.opened, 1)

    def test_sqlite_builtin_context_manager_does_not_close(self):
        """The fact the design rests on: `with conn:` commits/rolls back but
        leaves the connection OPEN - which is why db_connection() exists."""
        conn = db.get_connection()
        with conn:
            conn.execute("INSERT INTO t (name) VALUES ('via-with-conn')")
        self.assertFalse(is_closed(conn))
        self.assertEqual(self.rows(), ["via-with-conn"], "...and it committed implicitly")
        conn.close()

    def test_the_implementation_does_not_use_the_builtin_context_manager(self):
        import ast
        tree = ast.parse(inspect.getsource(db.db_connection))
        self.assertEqual([n for n in ast.walk(tree) if isinstance(n, ast.With)], [], "must not rely on sqlite3's `with conn:`")
        closes = [n for n in ast.walk(tree) if isinstance(n, ast.Call) and getattr(n.func, "attr", "") == "close"]
        self.assertEqual(len(closes), 1, "exactly one explicit close(), in the finally clause")
        finally_calls = [c for t in ast.walk(tree) if isinstance(t, ast.Try) for stmt in t.finalbody for c in ast.walk(stmt) if isinstance(c, ast.Call)]
        self.assertTrue(any(getattr(c.func, "attr", "") == "close" for c in finally_calls))


if __name__ == "__main__":
    unittest.main()
