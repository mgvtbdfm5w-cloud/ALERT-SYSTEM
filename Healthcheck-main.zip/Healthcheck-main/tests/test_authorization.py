"""Authorization tests: the ENFORCEMENT MECHANISM (authorization.py + app.py's
single before_request hook) and the CURRENT ROLE POLICY.

The expected policy is written out here, independently, as EXPECTED_ROLE_ACCESS
(literal role names, not the constants authorization.py uses), so a change to
ENDPOINT_ROLES can never be silent: editing the policy without editing this
matrix fails test_policy_table_matches_the_expected_matrix, and the HTTP tests
below prove the matrix is what the running app actually does.

What is pinned:

1. Full can reach every protected endpoint.
2. Admissions can upload Applications/Leads, run Reprocess, and take the full
   Applications/Leads downloads - but gets 403 for lookup add/edit/delete,
   Forecast settings and KPI targets.
3. Consultants and Marketing get 403 for all of the above (uploads,
   Reprocess, full downloads, lookups, Forecast, KPI targets) yet can still
   reach every dashboard/report page and the page-level exports.
4. The mechanism fails closed for an unknown/missing role and for an endpoint
   missing from the policy, works by direct URL and for state-changing POSTs,
   and sits behind (never replaces) CSRF protection.

Uses the shared isolated Flask test-client infrastructure in
tests/flask_test_support.py (also used by test_csrf.py, so neither suite
depends on the other): a fresh temporary database and uploads directory
per test, disposable credentials, CSRFProtect never disabled. Nothing here
touches the real data/app.db or uploads/ folder.
"""

import re
import sqlite3
import unittest
from unittest import mock

from authorization import (
    ALLOW,
    DENY,
    ENDPOINT_ROLES,
    KNOWN_ROLES,
    PUBLIC_ENDPOINTS,
    REQUIRE_LOGIN,
    authorize,
)
from tests.flask_test_support import (
    IsolatedAppTestCase,
    app_module,
    db_module,
    extract_token,
    make_xlsx,
)
from leads import REQUIRED_LEADS_SOURCE_COLUMNS
from pipeline import seed_forecast_settings_if_empty
from processing import REQUIRED_IMPORT_COLUMNS

ALL = frozenset({"full", "admissions", "consultants", "marketing"})
FULL_ADMISSIONS = frozenset({"full", "admissions"})
FULL_ONLY_ROLES = frozenset({"full"})

# The approved policy, endpoint -> roles allowed. Written out literally and
# separately from authorization.py on purpose (see module docstring).
EXPECTED_ROLE_ACCESS = {
    # Every dashboard / report page: all four roles.
    "company_dashboard": ALL, "todo": ALL, "interviews": ALL, "dashboard": ALL,
    "university_pipeline": ALL, "just_jon": ALL, "faheem": ALL, "consultants": ALL, "consultants_records": ALL, "enrolled": ALL,
    "university_report": ALL, "kpi": ALL, "offer_days": ALL, "lost_reasons": ALL,
    "submissions": ALL, "doc_check": ALL, "leads_dashboard": ALL, "allocation": ALL, "split": ALL, "ninety_days": ALL, "admin": ALL,
    # Page-level exports: all four roles.
    "dashboard_export": ALL, "just_jon_export": ALL, "university_pipeline_export": ALL, "university_pipeline_records": ALL, "just_jon_records": ALL, "dashboard_records": ALL, "dashboard_loss_records": ALL, "thirty_days": ALL, "thirty_days_records": ALL, "thirty_days_export": ALL, "incentives": ALL, "incentives_records": ALL, "just_jon_lead_records": ALL, "just_jon_leads_export": ALL,
    "enrolled_export_intake_03": ALL, "enrolled_export_current_intake": ALL,
    "offer_days_export": ALL,
    # Full Applications / Leads downloads, uploads, Reprocess: Full + Admissions.
    "download": FULL_ADMISSIONS, "leads_download": FULL_ADMISSIONS,
    "upload": FULL_ADMISSIONS, "leads_upload": FULL_ADMISSIONS,
    "reprocess": FULL_ADMISSIONS,
    # Lookup mappings, Forecast settings, KPI targets: Full only.
    "add_lookup_route": FULL_ONLY_ROLES, "edit_lookup_route": FULL_ONLY_ROLES,
    "delete_lookup_route": FULL_ONLY_ROLES,
    "update_forecast_setting_route": FULL_ONLY_ROLES,
    "update_kpi_target_route": FULL_ONLY_ROLES,
    # Paid Ad spend: the page and its figures for Full + Admissions; changing spend/budget/earning: Full only.
    "paid_ads": FULL_ADMISSIONS,
    "save_paid_ad_spend_route": FULL_ONLY_ROLES, "delete_paid_ad_spend_route": FULL_ONLY_ROLES,
    "save_paid_ad_settings_route": FULL_ONLY_ROLES,
    # The Admin page's access grid: Full only.
    "save_role_access_route": FULL_ONLY_ROLES, "reset_role_access_route": FULL_ONLY_ROLES,
    "admin_restore": FULL_ONLY_ROLES,
}

# Representative pages, all GETs, open to every role.
DASHBOARD_PAGES = ["/company-dashboard", "/dashboard", "/kpi", "/leads-dashboard"]
PROTECTED_GET_PAGES = DASHBOARD_PAGES + [
    "/admin",
    "/todo",
    "/interviews",
    "/thirty-days",
    "/university-pipeline",
    "/dashboard/just-jon",
    "/dashboard/faheem",
    "/consultants",
    "/enrolled",
    "/university-report",
    "/offer-days",
    "/lost-reasons",
    "/submissions",
    "/doc-check",
]
DOWNLOAD_PAGES = ["/download", "/leads/download"]
# Full student-level downloads (Full + Admissions only).
FULL_DATA_DOWNLOADS = DOWNLOAD_PAGES
# Page-level exports (every role).
PAGE_LEVEL_EXPORTS = [
    "/dashboard/export",
    "/dashboard/just-jon/export",
    "/enrolled/export/intake-03",
    "/enrolled/export/current-intake",
    "/offer-days/export/total",
]
NON_FULL_ROLES = ("admissions", "consultants", "marketing")
RESTRICTED_FROM_VIEWERS = ("consultants", "marketing")


class AuthzTestCase(IsolatedAppTestCase):
    """Isolated app plus a seeded (empty-payload) Applications and Leads
    dataset so the download routes return real files."""

    def setUp(self):
        super().setUp()

        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute(
            "INSERT INTO active_dataset (original_filename, stored_filename, uploaded_at, row_count, data_json) "
            "VALUES ('a.xlsx', '20260101000000_a.xlsx', '2026-01-01T00:00:00', 0, '[]')"
        )
        conn.execute(
            "INSERT INTO active_leads_dataset "
            "(original_filename, stored_filename, uploaded_at, row_count, columns_json, data_json) "
            "VALUES ('l.xlsx', 'leads_20260101000000_l.xlsx', '2026-01-01T00:00:00', 0, '[]', '[]')"
        )
        conn.commit()
        conn.close()

    def _admin_token(self, client):
        """A valid CSRF token for `client`'s session. Taken from /login
        (rendered for every session, whatever its role) rather than /admin:
        the Admin page no longer contains any form for a role that cannot
        use one, and the token is session-bound, not page-bound."""
        return extract_token(client.get("/login").get_data(as_text=True))

    def _count(self, table):
        conn = sqlite3.connect(db_module.DB_PATH)
        count = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
        conn.close()
        return count

    def _applications_xlsx(self):
        row = {col: "" for col in REQUIRED_IMPORT_COLUMNS}
        row.update({
            "Student Code": "PES-AUTHZ-001", "Student Name": "Test Student", "Intake": "2026",
            "University Name": "Test University", "Course Name": "Test Course",
        })
        return make_xlsx(REQUIRED_IMPORT_COLUMNS, [row])

    def _leads_xlsx(self):
        row = {col: "" for col in REQUIRED_LEADS_SOURCE_COLUMNS}
        row.update({"Student Id": "PES-AUTHZ-LEAD-001", "Name": "Test Lead"})
        return make_xlsx(REQUIRED_LEADS_SOURCE_COLUMNS, [row])

    def _seed_reprocessable_file(self):
        """The seeded dataset row points at 20260101000000_a.xlsx - put a
        real, parseable workbook there (isolated temp uploads dir only) so
        an ALLOWED reprocess genuinely runs."""
        (self.tmp_uploads_dir / "20260101000000_a.xlsx").write_bytes(self._applications_xlsx().getvalue())

    def _seed_lookup_row(self):
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute(
            "INSERT INTO lookup_tables (table_name, source_value, mapped_value, created_at) "
            "VALUES ('status', 'A', 'B', '2026-01-01T00:00:00')"
        )
        conn.commit()
        conn.close()
        return self._query("SELECT id FROM lookup_tables")[0]["id"]

    def _seed_forecast(self):
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.row_factory = sqlite3.Row
        seed_forecast_settings_if_empty(conn)
        conn.commit()
        conn.close()

    def _forecast_value(self):
        return self._query("SELECT forecast_percent FROM forecast_settings WHERE stage = '02-PendingQA'")[0][
            "forecast_percent"
        ]

    def _lookup_count(self):
        conn = sqlite3.connect(db_module.DB_PATH)
        count = conn.execute("SELECT COUNT(*) FROM lookup_tables").fetchone()[0]
        conn.close()
        return count


class PolicyCoverageTests(unittest.TestCase):
    """A route added to app.py without a policy entry must fail the build -
    the whole point of the central table."""

    def _endpoints(self):
        return {rule.endpoint for rule in app_module.app.url_map.iter_rules()}

    def test_every_registered_endpoint_is_covered_by_the_policy(self):
        accounted_for = set(PUBLIC_ENDPOINTS) | set(ENDPOINT_ROLES)
        missing = self._endpoints() - accounted_for
        self.assertEqual(
            missing,
            set(),
            f"Endpoints with no authorization policy entry (add them to "
            f"authorization.ENDPOINT_ROLES or PUBLIC_ENDPOINTS): {sorted(missing)}",
        )

    def test_policy_has_no_stale_entries_for_endpoints_that_no_longer_exist(self):
        stale = (set(ENDPOINT_ROLES) | set(PUBLIC_ENDPOINTS)) - self._endpoints()
        self.assertEqual(stale, set(), f"Policy entries for non-existent endpoints: {sorted(stale)}")

    def test_no_endpoint_is_both_public_and_role_restricted(self):
        self.assertEqual(set(PUBLIC_ENDPOINTS) & set(ENDPOINT_ROLES), set())

    def test_known_roles_match_the_roles_the_app_can_log_in_as(self):
        self.assertEqual(set(KNOWN_ROLES), set(app_module.ROLE_PASSWORDS))
        self.assertEqual(set(KNOWN_ROLES), set(app_module.ROLE_LABELS))

    def test_every_policy_entry_only_names_known_roles(self):
        for endpoint, roles in ENDPOINT_ROLES.items():
            self.assertTrue(set(roles) <= set(KNOWN_ROLES), endpoint)
            self.assertTrue(roles, f"{endpoint} allows no role at all")

    def test_every_authenticated_view_keeps_its_login_required_decorator(self):
        # Defense in depth: the per-route @login_required stays as a
        # second, independent layer behind the global hook.
        for endpoint in ENDPOINT_ROLES:
            view = app_module.app.view_functions[endpoint]
            self.assertTrue(hasattr(view, "__wrapped__"), f"{endpoint} lost login_required")

    def test_policy_table_matches_the_expected_matrix(self):
        """Any change to who may reach what must be made here AND in
        authorization.ENDPOINT_ROLES - never one without the other."""
        self.assertEqual(set(ENDPOINT_ROLES), set(EXPECTED_ROLE_ACCESS))
        for endpoint, expected_roles in EXPECTED_ROLE_ACCESS.items():
            self.assertEqual(set(ENDPOINT_ROLES[endpoint]), set(expected_roles), endpoint)

    def test_full_is_allowed_on_every_endpoint(self):
        for endpoint, roles in ENDPOINT_ROLES.items():
            self.assertIn("full", roles, endpoint)


class AuthorizeFunctionTests(unittest.TestCase):
    """authorize() on its own - no Flask involved."""

    def test_public_endpoints_are_allowed_without_login(self):
        for endpoint in PUBLIC_ENDPOINTS:
            self.assertEqual(authorize(endpoint, False, None), ALLOW)

    def test_unmatched_route_is_left_to_flask(self):
        self.assertEqual(authorize(None, False, None), ALLOW)

    def test_unauthenticated_request_to_protected_endpoint_requires_login(self):
        self.assertEqual(authorize("admin", False, None), REQUIRE_LOGIN)
        self.assertEqual(authorize("admin", None, "full"), REQUIRE_LOGIN)

    def test_authorize_matches_the_expected_matrix_for_every_role_and_endpoint(self):
        for endpoint, allowed_roles in EXPECTED_ROLE_ACCESS.items():
            for role in KNOWN_ROLES:
                expected = ALLOW if role in allowed_roles else DENY
                self.assertEqual(authorize(endpoint, True, role), expected, (endpoint, role))

    def test_full_is_allowed_everywhere(self):
        for endpoint in ENDPOINT_ROLES:
            self.assertEqual(authorize(endpoint, True, "full"), ALLOW, endpoint)

    def test_unknown_missing_or_tampered_roles_fail_closed(self):
        for bad_role in ("unknown-role", "", None, "FULL", " full", 123, ["full"], True):
            self.assertEqual(authorize("admin", True, bad_role), DENY, repr(bad_role))

    def test_endpoint_missing_from_the_policy_fails_closed(self):
        self.assertEqual(authorize("brand_new_route", True, "full"), DENY)
        # ...and an unauthenticated visitor still just gets the login
        # redirect, never access.
        self.assertEqual(authorize("brand_new_route", False, None), REQUIRE_LOGIN)

    def test_a_role_outside_an_endpoints_allowed_set_is_denied(self):
        # Proves the mechanism can express a restriction, which the next
        # phase will rely on - without changing the real policy.
        with mock.patch.dict(ENDPOINT_ROLES, {"admin": frozenset({"full"})}):
            self.assertEqual(authorize("admin", True, "full"), ALLOW)
            self.assertEqual(authorize("admin", True, "marketing"), DENY)


class FullAccessTests(AuthzTestCase):
    """1. Full Access can reach every protected endpoint."""

    def test_full_can_reach_every_protected_page_and_download(self):
        client = self._client_logged_in_as("full")
        for path in PROTECTED_GET_PAGES + DOWNLOAD_PAGES + PAGE_LEVEL_EXPORTS:
            with self.subTest(path=path):
                status = client.get(path).status_code
                self.assertNotIn(status, (403, 404))

    def test_full_is_never_denied_by_any_registered_endpoint(self):
        for endpoint in ENDPOINT_ROLES:
            self.assertEqual(authorize(endpoint, True, "full"), ALLOW, endpoint)

    def test_full_can_perform_every_restricted_action(self):
        self._seed_reprocessable_file()
        self._seed_forecast()
        client = self._client_logged_in_as("full")
        token = self._admin_token(client)

        resp = client.post("/upload", data={"csrf_token": token, "excel_file": (self._applications_xlsx(), "t.xlsx")},
                           content_type="multipart/form-data")
        self.assertEqual(resp.status_code, 302)
        resp = client.post("/leads/upload", data={"csrf_token": token, "excel_file": (self._leads_xlsx(), "t.xlsx")},
                           content_type="multipart/form-data")
        self.assertEqual(resp.status_code, 302)
        self.assertEqual(client.post("/admin/reprocess", data={"csrf_token": token}).status_code, 302)
        self.assertEqual(client.post("/admin/lookups/status/add",
                                     data={"source_value": "F", "mapped_value": "x", "csrf_token": token}).status_code, 302)
        self.assertEqual(client.post("/admin/forecast-settings/02-PendingQA",
                                     data={"forecast_percent": "42", "csrf_token": token}).status_code, 302)
        self.assertEqual(self._forecast_value(), 42.0)
        self.assertEqual(client.post("/admin/kpi-targets/__COMPANY__",
                                     data={"month_key": "2026-08", "target_value": "100", "csrf_token": token}).status_code, 302)
        self.assertEqual(self._count("kpi_targets"), 1)
        for path in DOWNLOAD_PAGES:
            self.assertEqual(client.get(path).status_code, 200)


class AdmissionsPermissionTests(AuthzTestCase):
    """2 + 3. Admissions: data upload / reprocess / full downloads allowed;
    lookups, Forecast settings and KPI targets are 403 - even with a valid
    CSRF token - and change nothing."""

    def setUp(self):
        super().setUp()
        self.client = self._client_logged_in_as("admissions")
        self.token = self._admin_token(self.client)

    def test_can_upload_applications(self):
        before = self._count("active_dataset")
        resp = self.client.post("/upload", data={"csrf_token": self.token, "excel_file": (self._applications_xlsx(), "t.xlsx")},
                                content_type="multipart/form-data")
        self.assertEqual(resp.status_code, 302)
        self.assertEqual(self._count("active_dataset"), before + 1)

    def test_can_upload_leads(self):
        before = self._count("active_leads_dataset")
        resp = self.client.post("/leads/upload", data={"csrf_token": self.token, "excel_file": (self._leads_xlsx(), "t.xlsx")},
                                content_type="multipart/form-data")
        self.assertEqual(resp.status_code, 302)
        self.assertEqual(self._count("active_leads_dataset"), before + 1)

    def test_can_reprocess(self):
        self._seed_reprocessable_file()
        before = self._count("active_dataset")
        resp = self.client.post("/admin/reprocess", data={"csrf_token": self.token})
        self.assertEqual(resp.status_code, 302)
        self.assertEqual(self._count("active_dataset"), before + 1)

    def test_can_take_the_full_applications_and_leads_downloads(self):
        for path, name in (("/download", "Applications.xlsx"), ("/leads/download", "Leads.xlsx")):
            with self.subTest(path=path):
                resp = self.client.get(path)
                self.assertEqual(resp.status_code, 200)
                self.assertIn("attachment", resp.headers.get("Content-Disposition", ""))
                self.assertIn(name, resp.headers.get("Content-Disposition", ""))

    def test_lookup_add_is_403(self):
        resp = self.client.post("/admin/lookups/status/add",
                                data={"source_value": "x", "mapped_value": "y", "csrf_token": self.token})
        self.assertEqual(resp.status_code, 403)
        self.assertEqual(self._lookup_count(), 0)

    def test_lookup_edit_is_403(self):
        row_id = self._seed_lookup_row()
        resp = self.client.post(f"/admin/lookups/status/{row_id}/edit",
                                data={"source_value": "Changed", "mapped_value": "B", "csrf_token": self.token})
        self.assertEqual(resp.status_code, 403)
        self.assertEqual(self._query("SELECT source_value FROM lookup_tables")[0]["source_value"], "A")

    def test_lookup_delete_is_403(self):
        row_id = self._seed_lookup_row()
        resp = self.client.post(f"/admin/lookups/status/{row_id}/delete", data={"csrf_token": self.token})
        self.assertEqual(resp.status_code, 403)
        self.assertEqual(self._lookup_count(), 1)

    def test_forecast_setting_change_is_403(self):
        self._seed_forecast()
        before = self._forecast_value()
        resp = self.client.post("/admin/forecast-settings/02-PendingQA",
                                data={"forecast_percent": "42", "csrf_token": self.token})
        self.assertEqual(resp.status_code, 403)
        self.assertEqual(self._forecast_value(), before)

    def test_kpi_target_change_is_403(self):
        resp = self.client.post("/admin/kpi-targets/__COMPANY__",
                                data={"month_key": "2026-08", "target_value": "100", "csrf_token": self.token})
        self.assertEqual(resp.status_code, 403)
        self.assertEqual(self._count("kpi_targets"), 0)

    def test_can_view_every_page_and_page_level_export(self):
        for path in PROTECTED_GET_PAGES + PAGE_LEVEL_EXPORTS:
            with self.subTest(path=path):
                self.assertNotEqual(self.client.get(path).status_code, 403)


class ViewerRolePermissionTests(AuthzTestCase):
    """4 + 5. Consultants and Marketing (identical rights today): every
    restricted action is 403 - even with a valid CSRF token - and changes
    nothing; every normal page and page-level export
    stay available."""

    def _each_role(self):
        for role in RESTRICTED_FROM_VIEWERS:
            client = self._client_logged_in_as(role)
            with self.subTest(role=role):
                yield role, client, self._admin_token(client)

    def test_applications_upload_is_403_and_stores_nothing(self):
        for _role, client, token in self._each_role():
            before = self._count("active_dataset")
            resp = client.post("/upload", data={"csrf_token": token, "excel_file": (self._applications_xlsx(), "t.xlsx")},
                               content_type="multipart/form-data")
            self.assertEqual(resp.status_code, 403)
            self.assertEqual(self._count("active_dataset"), before)
            self.assertEqual(list(self.tmp_uploads_dir.iterdir()), [])

    def test_leads_upload_is_403_and_stores_nothing(self):
        for _role, client, token in self._each_role():
            before = self._count("active_leads_dataset")
            resp = client.post("/leads/upload", data={"csrf_token": token, "excel_file": (self._leads_xlsx(), "t.xlsx")},
                               content_type="multipart/form-data")
            self.assertEqual(resp.status_code, 403)
            self.assertEqual(self._count("active_leads_dataset"), before)
            self.assertEqual(list(self.tmp_uploads_dir.iterdir()), [])

    def test_reprocess_is_403(self):
        self._seed_reprocessable_file()
        for _role, client, token in self._each_role():
            before = self._count("active_dataset")
            self.assertEqual(client.post("/admin/reprocess", data={"csrf_token": token}).status_code, 403)
            self.assertEqual(self._count("active_dataset"), before)

    def test_full_applications_and_leads_downloads_are_403(self):
        for _role, client, _token in self._each_role():
            for path in FULL_DATA_DOWNLOADS:
                with self.subTest(path=path):
                    resp = client.get(path)
                    self.assertEqual(resp.status_code, 403)
                    self.assertNotIn("attachment", resp.headers.get("Content-Disposition", ""))

    def test_lookup_add_edit_delete_are_403(self):
        row_id = self._seed_lookup_row()
        for _role, client, token in self._each_role():
            add = client.post("/admin/lookups/status/add",
                              data={"source_value": "x", "mapped_value": "y", "csrf_token": token})
            edit = client.post(f"/admin/lookups/status/{row_id}/edit",
                               data={"source_value": "Changed", "mapped_value": "B", "csrf_token": token})
            delete = client.post(f"/admin/lookups/status/{row_id}/delete", data={"csrf_token": token})
            self.assertEqual((add.status_code, edit.status_code, delete.status_code), (403, 403, 403))
        rows = self._query("SELECT source_value FROM lookup_tables")
        self.assertEqual([r["source_value"] for r in rows], ["A"])  # untouched

    def test_forecast_setting_change_is_403(self):
        self._seed_forecast()
        before = self._forecast_value()
        for _role, client, token in self._each_role():
            resp = client.post("/admin/forecast-settings/02-PendingQA",
                               data={"forecast_percent": "42", "csrf_token": token})
            self.assertEqual(resp.status_code, 403)
            self.assertEqual(self._forecast_value(), before)

    def test_kpi_target_change_is_403(self):
        for _role, client, token in self._each_role():
            resp = client.post("/admin/kpi-targets/__COMPANY__",
                               data={"month_key": "2026-08", "target_value": "100", "csrf_token": token})
            self.assertEqual(resp.status_code, 403)
            self.assertEqual(self._count("kpi_targets"), 0)

    def test_every_normal_dashboard_and_report_page_is_still_available(self):
        full = self._client_logged_in_as("full")
        baseline = {path: full.get(path).status_code for path in PROTECTED_GET_PAGES}
        for _role, client, _token in self._each_role():
            for path in PROTECTED_GET_PAGES:
                with self.subTest(path=path):
                    self.assertEqual(client.get(path).status_code, baseline[path])
                    self.assertNotEqual(client.get(path).status_code, 403)

    def test_page_level_exports_are_still_available(self):
        full = self._client_logged_in_as("full")
        baseline = {path: full.get(path).status_code for path in PAGE_LEVEL_EXPORTS}
        for _role, client, _token in self._each_role():
            for path in PAGE_LEVEL_EXPORTS:
                with self.subTest(path=path):
                    self.assertNotEqual(client.get(path).status_code, 403)
                    self.assertEqual(client.get(path).status_code, baseline[path])

    def test_denied_posts_without_a_valid_token_are_still_a_csrf_400(self):
        for _role, client, _token in self._each_role():
            self.assertEqual(client.post("/upload", data={}).status_code, 400)
            self.assertEqual(client.post("/admin/reprocess", data={}).status_code, 400)


class DeniedRoleResponseTests(AuthzTestCase):
    """Denied authenticated users get the existing styled 403, the same by
    direct URL as any other route - and a role denied one thing keeps its
    session and the rest of its access."""

    def test_denied_role_gets_the_styled_403_page(self):
        client = self._client_logged_in_as("marketing")
        resp = client.get("/download")
        body = resp.get_data(as_text=True)
        self.assertEqual(resp.status_code, 403)
        self.assertIn("Access Denied", body)
        self.assertIn("topbar", body)
        self.assertNotIn("Location", resp.headers)

    def test_a_denied_action_does_not_end_the_session(self):
        client = self._client_logged_in_as("consultants")
        self.assertEqual(client.get("/download").status_code, 403)
        self.assertEqual(client.get("/kpi").status_code, 200)

    def test_navigation_is_still_not_role_aware(self):
        """Deliberately unchanged in this phase: every role still sees every
        link; a disallowed action is refused server-side with a 403."""
        for role in KNOWN_ROLES:
            with self.subTest(role=role):
                body = self._client_logged_in_as(role).get("/company-dashboard").get_data(as_text=True)
                for link in ("/company-dashboard", "/admin", "/todo"):
                    self.assertIn(f'href="{link}"', body)
                self.assertIn('action="/logout"', body)  # POST form, not a link


class UnauthenticatedTests(AuthzTestCase):
    """Unauthenticated behaviour is exactly what it was: redirect to login."""

    def test_protected_get_pages_redirect_to_login(self):
        client = app_module.app.test_client()
        for path in PROTECTED_GET_PAGES + DOWNLOAD_PAGES:
            with self.subTest(path=path):
                resp = client.get(path)
                self.assertEqual(resp.status_code, 302)
                self.assertTrue(resp.headers["Location"].endswith("/login"))

    def test_protected_post_with_a_valid_token_redirects_to_login(self):
        client = app_module.app.test_client()
        token = self._get_login_token(client)
        resp = client.post("/admin/lookups/status/add", data={"source_value": "x", "csrf_token": token})
        self.assertEqual(resp.status_code, 302)
        self.assertTrue(resp.headers["Location"].endswith("/login"))
        self.assertEqual(self._lookup_count(), 0)

    def test_public_endpoints_stay_reachable_without_login(self):
        client = app_module.app.test_client()
        self.assertEqual(client.get("/login").status_code, 200)
        # Logout is POST-only: a GET changes nothing and is simply refused.
        self.assertEqual(client.get("/logout").status_code, 405)
        token = self._get_login_token(client)
        resp = client.post("/logout", data={"csrf_token": token})
        self.assertEqual(resp.status_code, 302)
        self.assertTrue(resp.headers["Location"].endswith("/login"))
        self.assertEqual(client.get("/").status_code, 302)

    def test_static_files_are_still_served_without_login(self):
        client = app_module.app.test_client()
        self.assertEqual(client.get("/static/style.css").status_code, 200)


class UnknownRoleTests(AuthzTestCase):
    """An authenticated session whose role is not one of the four known
    roles - whether forged, corrupted, or from before roles existed - gets
    nothing, by direct URL, for reads, downloads, and POSTs."""

    BAD_SESSIONS = [
        {"logged_in": True, "role": "unknown-role"},
        {"logged_in": True, "role": "FULL"},
        {"logged_in": True, "role": ""},
        {"logged_in": True},  # logged in with no role at all
    ]

    def test_protected_pages_return_403_by_direct_url(self):
        for session_values in self.BAD_SESSIONS:
            client = self._client_with_session(**session_values)
            for path in PROTECTED_GET_PAGES:
                with self.subTest(session=session_values, path=path):
                    self.assertEqual(client.get(path).status_code, 403)

    def test_downloads_return_403_and_have_no_side_effects(self):
        client = self._client_with_session(logged_in=True, role="unknown-role")
        for path in DOWNLOAD_PAGES:
            with self.subTest(path=path):
                self.assertEqual(client.get(path).status_code, 403)

    def test_post_with_a_valid_token_returns_403_and_changes_nothing(self):
        client = self._client_with_session(logged_in=True, role="unknown-role")
        token = self._get_login_token(client)
        resp = client.post("/admin/lookups/status/add", data={"source_value": "x", "csrf_token": token})
        self.assertEqual(resp.status_code, 403)
        self.assertEqual(self._lookup_count(), 0)

    def test_public_endpoints_still_work_for_an_unknown_role(self):
        client = self._client_with_session(logged_in=True, role="unknown-role")
        self.assertEqual(client.get("/login").status_code, 200)
        self.assertEqual(client.get("/static/style.css").status_code, 200)
        # Logging out is the way out of a bad session (POST + its own token).
        self.assertEqual(client.get("/logout").status_code, 405)
        self.assertEqual(client.get("/admin").status_code, 403)  # GET did not log it out
        resp = client.post("/logout", data={"csrf_token": self._get_login_token(client)})
        self.assertEqual(resp.status_code, 302)
        self.assertEqual(client.get("/admin").status_code, 302)  # now plain unauthenticated


class MissingPolicyFailsClosedTests(AuthzTestCase):
    """Simulates "a route was added without a policy entry" by removing a
    REAL endpoint's entry for the duration of one test (mock.patch.dict
    restores it afterwards) - no production route is added or modified."""

    def test_authenticated_get_to_an_unlisted_endpoint_is_denied(self):
        client = self._client_logged_in_as("full")
        self.assertEqual(client.get("/kpi").status_code, 200)
        with mock.patch.dict(ENDPOINT_ROLES):
            del ENDPOINT_ROLES["kpi"]
            self.assertEqual(client.get("/kpi").status_code, 403)
            # ...while a listed endpoint is unaffected.
            self.assertEqual(client.get("/company-dashboard").status_code, 200)
        self.assertEqual(client.get("/kpi").status_code, 200)  # restored

    def test_authenticated_post_to_an_unlisted_endpoint_is_denied(self):
        client = self._client_logged_in_as("full")
        token = extract_token(client.get("/admin").get_data(as_text=True))
        with mock.patch.dict(ENDPOINT_ROLES):
            del ENDPOINT_ROLES["add_lookup_route"]
            resp = client.post(
                "/admin/lookups/status/add", data={"source_value": "x", "csrf_token": token}
            )
        self.assertEqual(resp.status_code, 403)
        self.assertEqual(self._lookup_count(), 0)

    def test_unauthenticated_request_to_an_unlisted_endpoint_still_just_goes_to_login(self):
        client = app_module.app.test_client()
        with mock.patch.dict(ENDPOINT_ROLES):
            del ENDPOINT_ROLES["kpi"]
            resp = client.get("/kpi")
        self.assertEqual(resp.status_code, 302)
        self.assertTrue(resp.headers["Location"].endswith("/login"))


class RestrictionMechanismTests(AuthzTestCase):
    """The mechanism can express a per-role restriction over real HTTP
    (without changing the real policy), which the next phase relies on."""

    def test_a_narrowed_endpoint_denies_other_roles_by_get_and_post(self):
        with mock.patch.dict(
            ENDPOINT_ROLES,
            {"kpi": frozenset({"full"}), "add_lookup_route": frozenset({"full"})},
        ):
            full = self._client_logged_in_as("full")
            marketing = self._client_logged_in_as("marketing")

            self.assertEqual(full.get("/kpi").status_code, 200)
            self.assertEqual(marketing.get("/kpi").status_code, 403)

            token = extract_token(marketing.get("/login").get_data(as_text=True))
            resp = marketing.post(
                "/admin/lookups/status/add", data={"source_value": "x", "csrf_token": token}
            )
            self.assertEqual(resp.status_code, 403)
            self.assertEqual(self._lookup_count(), 0)

            # A role that is allowed still works through the same mechanism.
            full_token = extract_token(full.get("/login").get_data(as_text=True))
            resp = full.post(
                "/admin/lookups/status/add", data={"source_value": "y", "csrf_token": full_token}
            )
            self.assertEqual(resp.status_code, 302)


class ForbiddenResponseTests(AuthzTestCase):
    """The 403 page is explicit but reveals nothing about the policy."""

    def setUp(self):
        super().setUp()
        self.client = self._client_with_session(logged_in=True, role="unknown-role")
        self.resp = self.client.get("/admin")
        self.body = self.resp.get_data(as_text=True)

    def test_status_is_403_not_a_redirect(self):
        self.assertEqual(self.resp.status_code, 403)
        self.assertNotIn("Location", self.resp.headers)

    def test_page_shows_the_friendly_message(self):
        self.assertIn("You don't have permission to access this page or perform this action.", self.body)

    def test_page_is_application_styled(self):
        self.assertIn("topbar", self.body)  # extends layout.html

    def test_page_does_not_expose_policy_roles_endpoints_or_tracebacks(self):
        for leaked in (
            "unknown-role",
            "ENDPOINT_ROLES",
            "authorization",
            "add_lookup_route",
            "Traceback",
            ".py",
        ):
            self.assertNotIn(leaked, self.body, leaked)
        for role in KNOWN_ROLES:
            self.assertNotIn(f"'{role}'", self.body)


class CsrfOrderingTests(AuthzTestCase):
    """Documents and locks the natural ordering: Flask-WTF's CSRF check
    is registered first, so it runs BEFORE the authorization hook. A POST
    without a valid token is a 400 regardless of who sent it; only a
    request that passes CSRF is then authorized (403 / login redirect)."""

    def _post_targets(self):
        urls = {}
        for rule in app_module.app.url_map.iter_rules():
            if "POST" in rule.methods:
                urls[rule.endpoint] = re.sub(r"<(?:\w+:)?\w+>", "1", rule.rule)
        return urls

    def test_csrf_check_runs_before_authorization_for_a_forbidden_role(self):
        client = self._client_with_session(logged_in=True, role="unknown-role")
        resp = client.post("/admin/lookups/status/add", data={"source_value": "x"})
        self.assertEqual(resp.status_code, 400)  # CSRF, not 403

    def test_csrf_check_runs_before_login_redirect_for_an_unauthenticated_post(self):
        client = app_module.app.test_client()
        resp = client.post("/admin/lookups/status/add", data={"source_value": "x"})
        self.assertEqual(resp.status_code, 400)

    def test_valid_token_then_reaches_authorization(self):
        client = self._client_with_session(logged_in=True, role="unknown-role")
        token = self._get_login_token(client)
        resp = client.post("/admin/lookups/status/add", data={"source_value": "x", "csrf_token": token})
        self.assertEqual(resp.status_code, 403)

    def test_no_post_route_has_a_csrf_exemption_for_any_role(self):
        targets = self._post_targets()
        self.assertGreaterEqual(len(targets), 9)  # login + 8 admin/upload routes
        for role in KNOWN_ROLES:
            client = self._client_logged_in_as(role)
            for endpoint, url in targets.items():
                with self.subTest(role=role, endpoint=endpoint):
                    self.assertEqual(client.post(url, data={}).status_code, 400)

    def test_csrf_still_protects_every_post_route_when_unauthenticated(self):
        client = app_module.app.test_client()
        for endpoint, url in self._post_targets().items():
            with self.subTest(endpoint=endpoint):
                self.assertEqual(client.post(url, data={}).status_code, 400)


if __name__ == "__main__":
    unittest.main()
