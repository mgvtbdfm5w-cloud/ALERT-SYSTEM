"""The Paid Leads by Sales Office table in a REAL browser (headless Chrome): months
open and close to show their days. Skipped when no Chrome/Chromium is installed
(set CHROME_BIN). Same method as test_university_pipeline_records_browser.py: a
local copy of the app, a tiny stand-in server that holds the login and adds a
driver script to the page, and headless Chrome reporting what it saw."""

import http.cookiejar
import http.server
import io
import re
import shutil
import subprocess
import tempfile
import threading
import unittest
import urllib.parse
import urllib.request
from html import unescape

from werkzeug.serving import make_server

from tests.flask_test_support import FULL_PASSWORD, IsolatedAppTestCase, app_module, extract_token
from tests.test_allocation import leads_book
from tests.test_paid_ads_by_office import LEADS
from tests.test_university_pipeline_records_browser import find_chrome

DRIVER = r"""
window.addEventListener('load', function () {
  var log = [];
  var table = document.getElementById('paid-office-table');
  function visibleDays(monthKey) {
    return Array.prototype.filter.call(table.querySelectorAll('tr.po-day[data-month="' + monthKey + '"]'), function (tr) {
      return getComputedStyle(tr).display !== 'none';
    }).length;
  }
  var groups = table.querySelectorAll('.po-month-group');
  var oct = groups[0], sep = groups[1];
  var octButton = oct.querySelector('.po-toggle'), sepButton = sep.querySelector('.po-toggle');
  log.push('js-class=' + table.classList.contains('po-js'));
  log.push('oct-days-visible-at-start=' + visibleDays('2026-10'));
  log.push('sep-days-visible-at-start=' + visibleDays('2026-09'));
  log.push('month-rows-visible=' + Array.prototype.filter.call(table.querySelectorAll('tr.po-month'), function (tr) { return getComputedStyle(tr).display !== 'none'; }).length);
  log.push('chevron-shown=' + (getComputedStyle(octButton.querySelector('.po-chevron')).display !== 'none'));
  octButton.click();
  log.push('oct-days-visible-after-open=' + visibleDays('2026-10'));
  log.push('oct-expanded=' + octButton.getAttribute('aria-expanded'));
  log.push('sep-days-visible-while-oct-open=' + visibleDays('2026-09'));
  sepButton.click();
  log.push('both-open=' + visibleDays('2026-10') + ',' + visibleDays('2026-09'));
  octButton.click();
  log.push('oct-days-visible-after-close=' + visibleDays('2026-10'));
  log.push('oct-expanded-after-close=' + octButton.getAttribute('aria-expanded'));
  log.push('sep-still-open=' + visibleDays('2026-09'));
  log.push('totals-always-visible=' + (getComputedStyle(table.querySelector('tfoot tr')).display !== 'none'));
  var pre = document.createElement('pre'); pre.id = 'result'; pre.textContent = log.join('\n'); document.body.appendChild(pre);
});
"""


@unittest.skipUnless(find_chrome(), "needs Chrome or Chromium (set CHROME_BIN)")
class MonthsOpenInARealBrowserTests(IsolatedAppTestCase):
    def setUp(self):
        super().setUp()
        full = self._client_logged_in_as("full")
        token = lambda: extract_token(full.get("/login").get_data(as_text=True))
        self.assertEqual(full.post("/leads/upload", data={"csrf_token": token(), "excel_file": (io.BytesIO(leads_book(LEADS)), "l.xlsx")},
                                   content_type="multipart/form-data").status_code, 302)
        from datetime import date
        from unittest import mock
        patcher = mock.patch.object(app_module, "today_uk", return_value=date(2026, 10, 18))
        patcher.start()
        self.addCleanup(patcher.stop)

        self.app_server = make_server("127.0.0.1", 0, app_module.app, threaded=True)
        threading.Thread(target=self.app_server.serve_forever, daemon=True).start()
        self.addCleanup(self.app_server.shutdown)
        base = f"http://127.0.0.1:{self.app_server.server_port}"
        opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
        opener.open(base + "/login", urllib.parse.urlencode({"csrf_token": extract_token(opener.open(base + "/login").read().decode()), "password": FULL_PASSWORD}).encode())

        class Forward(http.server.BaseHTTPRequestHandler):
            def do_GET(handler):
                try:
                    response = opener.open(base + handler.path)
                except Exception:
                    handler.send_response(404)
                    handler.end_headers()
                    return
                body = response.read()
                if handler.path.startswith("/paid-ads"):
                    body = body.decode().replace("</body>", "<script>" + DRIVER + "</script></body>").encode()
                handler.send_response(200)
                handler.send_header("Content-Type", response.headers.get("Content-Type", "text/html"))
                handler.end_headers()
                handler.wfile.write(body)

            def log_message(handler, *args):
                pass

        self.front = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Forward)
        threading.Thread(target=self.front.serve_forever, daemon=True).start()
        self.addCleanup(self.front.shutdown)

    def seen(self):
        profile = tempfile.mkdtemp(prefix="gsp_chrome_")
        self.addCleanup(shutil.rmtree, profile, True)
        result = subprocess.run(
            [find_chrome(), "--headless=new", "--disable-gpu", "--no-sandbox", f"--user-data-dir={profile}", "--virtual-time-budget=8000", "--dump-dom",
             f"http://127.0.0.1:{self.front.server_port}/paid-ads"],
            capture_output=True, text=True, timeout=90,
        )
        match = re.search(r'<pre id="result">(.*?)</pre>', result.stdout, re.S)
        self.assertIsNotNone(match, "the driver did not finish: " + result.stderr[-300:])
        return dict(line.split("=", 1) for line in unescape(match.group(1)).split("\n"))

    def test_months_start_closed_open_and_close_independently_and_the_totals_stay(self):
        seen = self.seen()
        self.assertEqual(seen["js-class"], "true")
        self.assertEqual(seen["oct-days-visible-at-start"], "0")
        self.assertEqual(seen["sep-days-visible-at-start"], "0")
        self.assertEqual(seen["month-rows-visible"], "3")
        self.assertEqual(seen["chevron-shown"], "true")
        self.assertEqual(seen["oct-days-visible-after-open"], "18", "1 to 18 October")
        self.assertEqual(seen["oct-expanded"], "true")
        self.assertEqual(seen["sep-days-visible-while-oct-open"], "0")
        self.assertEqual(seen["both-open"], "18,30")
        self.assertEqual(seen["oct-days-visible-after-close"], "0")
        self.assertEqual(seen["oct-expanded-after-close"], "false")
        self.assertEqual(seen["sep-still-open"], "30")
        self.assertEqual(seen["totals-always-visible"], "true")


if __name__ == "__main__":
    unittest.main()
