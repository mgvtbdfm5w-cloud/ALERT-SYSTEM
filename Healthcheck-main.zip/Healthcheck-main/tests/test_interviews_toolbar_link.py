"""The toolbar has an Interviews link, after University Pipeline and Incentives and before Admin."""

import re
import unittest

from tests.flask_test_support import IsolatedAppTestCase, app_module

ROLES = ("full", "admissions", "consultants", "marketing")


class ToolbarLinkTests(IsolatedAppTestCase):
    def nav(self, client, path="/kpi"):
        html = client.get(path).get_data(as_text=True)
        return html[html.index('<nav class="nav">'):html.index("</nav>")]

    def test_every_login_sees_an_interviews_link_that_goes_to_the_interviews_page(self):
        for role in ROLES:
            nav = self.nav(self._client_logged_in_as(role))
            self.assertRegex(nav, r'<a href="/interviews" class="[^"]*">Interviews</a>', role)
            self.assertEqual(nav.count(">Interviews</a>"), 1, role)

    def test_it_sits_after_incentives_and_before_admin(self):
        nav = self.nav(self._client_logged_in_as("full"))
        labels = re.findall(r">([^<]+)</a>", nav)
        self.assertEqual(labels, ["Company Dashboard", "Consultants", "University Pipeline", "Incentives", "Interviews", "Admin", "To Do List"])

    def test_the_link_leads_to_a_working_interviews_page(self):
        client = self._client_logged_in_as("full")
        href = re.search(r'<a href="(/[^"]*)" class="[^"]*">Interviews</a>', self.nav(client)).group(1)
        self.assertEqual(href, "/interviews")
        self.assertEqual(client.get(href).status_code, 200)

    def test_it_is_highlighted_on_the_interviews_page_and_only_there(self):
        client = self._client_logged_in_as("full")
        on = re.search(r'<a href="/interviews" class="([^"]*)">', self.nav(client, "/interviews")).group(1)
        off = re.search(r'<a href="/interviews" class="([^"]*)">', self.nav(client, "/kpi")).group(1)
        self.assertEqual((on, off), ("active", ""))
        nav = self.nav(client, "/interviews")
        self.assertEqual(nav.count('class="active"'), 1, "the other links are not highlighted")

    def test_no_link_before_logging_in(self):
        html = app_module.app.test_client().get("/login").get_data(as_text=True)
        self.assertNotIn(">Interviews</a>", html)

    def test_the_admin_pages_panel_still_has_its_interviews_link(self):
        html = self._client_logged_in_as("full").get("/admin").get_data(as_text=True)
        self.assertIn('<a class="page-link" href="/interviews">Interviews</a>', html)


if __name__ == "__main__":
    unittest.main()
