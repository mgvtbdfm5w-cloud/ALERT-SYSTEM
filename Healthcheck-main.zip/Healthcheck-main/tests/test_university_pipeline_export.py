"""The University Pipeline Excel download: exactly the page as filtered."""

import io
import math
import re
import unittest
from contextlib import contextmanager
from datetime import date, timedelta
from unittest import mock

import openpyxl
from flask import template_rendered

import university_pipeline_export as export
from dateutils import today_uk
from tests.flask_test_support import IsolatedAppTestCase, app_module, extract_token
from tests.test_role_access import AccessRouteTestCase
from tests.test_upload_atomicity import book, row

SALES_OFFICE_LOOKUP = [("Raneen", "OXF"), ("Mel", "MAN"), ("Hannah", "LON")]
STATUS_LOOKUP = [("QA", "02-PendingQA"), ("Assessment", "05-Assessment"), ("Decision", "06-Decision"),
                 ("Enrolled", "09-Enrolled"), ("Lost", "10-Lost"), ("Rejected", "00-QARejected")]


def submitted_days_ago(n):
    return (today_uk() - timedelta(days=n)).strftime("%d/%m/%Y")


def app_row(code, intake, status, manager="", university="Uni A", name=None, consultant="Raneen R", **extra):
    return row(**{"Student Code": code, "Student Name": name or code, "Application Status": status, "Intake": intake,
                  "University Name": university, "Admission Officer": manager, "Course Name": "Course X", "Counsellor": consultant, **extra})


ROWS = [
    app_row("A1", "August 2026", "Assessment", "Nouran X", "Uni A", **{"Uni Submission Done": submitted_days_ago(12)}),
    app_row("A2", "September 2026", "Decision", "Nouran X", "Uni B", consultant="Mel M", **{"Uni Submission Done": submitted_days_ago(25)}),
    app_row("A3", "September 2026", "Enrolled", "Mo Y", "Uni A"),
    app_row("A4", "September 2026", "QA", "", "Uni A"),                          # earliest stage: not on the chart, but an application
    app_row("A5", "October 2026", "Lost", "Mo Y", "Uni B", consultant="Mel M"),
    app_row("A6", "November 2026", "Assessment", "Nouran X", "Uni A", consultant="Hannah H",
            **{"Uni Submission Done": submitted_days_ago(41)}),                   # 12 and 41 days: a 26.5 average, which must round UP to 27
    app_row("A7", "September 2026", "Rejected", "Mo Y", "Uni A"),                # outside the pipeline stages entirely
    app_row("A8", "September 2026", "Enrolled", "Mo Y", "", name="=SUM(1,1)"),   # no university; formula-looking name
    app_row("B1", "January 2027", "Assessment", "Mo Y", "Uni C", consultant="Mel M"),
    app_row("B2", "February 2027", "Decision", "Nouran X", "Uni C"),
    app_row("B3", "September 2027", "Enrolled", "Nouran X", "Uni C"),
]

QUERIES = ["?year=2026&office=OXF", "?year=2026&office=MAN&status=10-Lost", "?year=2026&office=OXF&manager=Nouran&intake_month=8&intake_month=10",
           "?year=2026&office=LON", "?year=2027&intake=intake_01&office=MAN", "?year=2026&office=CAR",
           "?year=2026&consultant=Raneen", "?year=2026&consultant=Mel&manager=Nouran", "?year=2026&consultant=Raneen&status=09-Enrolled&intake_month=9&intake_month=10",
           "?year=2026&consultant=Hannah", "?year=2027&intake=intake_01&consultant=Mel", "?year=2026&consultant=Nobody",
           "?year=2026&status=05-Assessment", "?year=2026&status=09-Enrolled&manager=Mo", "?year=2026&intake_month=9&intake_month=10",
           "?year=2026&status=02-PendingQA", "?year=2026&status=10-Lost&intake_month=8&intake_month=11", "?year=2026&status=Nope&intake_month=9&intake_month=99",
           "?year=2026", "?year=2026&manager=Nouran", "?year=2026&manager=Mo", "?year=2026&manager=Unassigned", "?year=2026&intake_month=9",
           "?year=2026&manager=Mo&intake_month=9", "?year=2026&manager=Nouran&intake_month=10", "?year=2027", "?year=2027&intake=intake_01",
           "?year=2027&intake=intake_03&manager=Nouran", "?year=2026&manager=Nobody&intake_month=99"]


LOOKUPS = {"status": STATUS_LOOKUP, "sales_office": SALES_OFFICE_LOOKUP}


@contextmanager
def captured():
    rendered = []

    def record(sender, template, context, **extra):
        rendered.append((template.name, dict(context)))

    template_rendered.connect(record, app_module.app)
    try:
        yield rendered
    finally:
        template_rendered.disconnect(record, app_module.app)


class FilenameTests(unittest.TestCase):
    def test_filename_carries_the_filters_applied(self):
        today = date(2026, 10, 14)
        self.assertEqual(export.export_filename(today, 2026), "University_Pipeline_2026_14-10-2026.xlsx")
        self.assertEqual(export.export_filename(today, 2027, "Intake 03"), "University_Pipeline_2027_Intake03_14-10-2026.xlsx")
        self.assertEqual(export.export_filename(today, 2026, None, "Nouran", None, ["September 2026"]), "University_Pipeline_2026_Nouran_Sep_14-10-2026.xlsx")
        self.assertEqual(export.export_filename(today, 2027, "Intake 01", "Mo Y/../x", None, ["January 2027"]),
                         "University_Pipeline_2027_Intake01_Mo-Y----x_Jan_14-10-2026.xlsx")
        self.assertEqual(export.export_filename(today, 2026, None, None, ["05-Assessment"], ["September 2026", "October 2026", "November 2026"]),
                         "University_Pipeline_2026_05-Assessment_Sep-Oct-Nov_14-10-2026.xlsx")
        self.assertEqual(export.export_filename(today, 2026, None, "Mo", ["09-Enrolled"]), "University_Pipeline_2026_Mo_09-Enrolled_14-10-2026.xlsx")
        self.assertEqual(export.export_filename(today, 2026, None, "Mo", ["05-Assessment", "06-Decision", "09-Enrolled"], ["October 2026"]),
                         "University_Pipeline_2026_Mo_Status05-06-09_Oct_14-10-2026.xlsx")
        self.assertEqual(export.export_filename(today, 2026, None, None, [], []), "University_Pipeline_2026_14-10-2026.xlsx")
        self.assertEqual(export.export_filename(today, 2026, None, "Nouran", [], [], consultant="Mel M"), "University_Pipeline_2026_Nouran_Mel-M_14-10-2026.xlsx")
        self.assertEqual(export.export_filename(today, 2026, None, None, [], [], consultant="Mel"), "University_Pipeline_2026_Mel_14-10-2026.xlsx")
        self.assertEqual(export.export_filename(today, 2027, "Intake 03", "Nouran", [], [], consultant="Mel M", office="OXF"),
                         "University_Pipeline_2027_Intake03_OXF_Nouran_Mel-M_14-10-2026.xlsx")
        self.assertEqual(export.export_filename(today, 2026, None, None, [], [], office="a/../b"), "University_Pipeline_2026_a----b_14-10-2026.xlsx")

    def test_a_manager_name_cannot_inject_path_characters(self):
        name = export.export_filename(date(2026, 1, 1), 2026, None, '../../etc/passwd"\r\n;', ['x/../"\r\n;'])
        self.assertNotRegex(name, r'[/\\"\r\n;]')
        self.assertTrue(name.endswith("_01-01-2026.xlsx"))


class WorkbookTests(unittest.TestCase):
    def test_application_rows_keep_only_pipeline_statuses_and_sort_by_status_then_university_then_name(self):
        rows = [
            {"Student Code": "1", "Student Name": "Zed", "University Name": "beta", "Status": "05-Assessment"},
            {"Student Code": "2", "Student Name": "Amy", "University Name": "Alpha", "Status": "09-Enrolled"},
            {"Student Code": "3", "Student Name": "Bob", "University Name": "Alpha", "Status": "05-Assessment"},
            {"Student Code": "4", "Student Name": "Cat", "University Name": "Alpha", "Status": "05-Assessment"},
            {"Student Code": "5", "Student Name": "Dan", "University Name": "Alpha", "Status": "00-QARejected"},
            {"Student Code": "6", "Student Name": "Eve", "University Name": "", "Status": "10-Lost"},
            {"Student Code": "7", "Student Name": "Fay", "University Name": "Alpha", "Status": ""},
        ]
        wb = openpyxl.load_workbook(export.build_university_pipeline_export(rows, [], "T", "F", "O"))
        ws = wb[export.APPLICATIONS_SHEET]
        self.assertEqual([c.value for c in ws[1]], export.APPLICATION_COLUMNS)
        self.assertEqual([r[7] for r in ws.iter_rows(min_row=2, values_only=True)], ["05-Assessment"] * 3 + ["09-Enrolled", "10-Lost"], "Status order, across universities")
        self.assertEqual([r[0] for r in ws.iter_rows(min_row=2, values_only=True)], ["3", "4", "1", "2", "6"])
        self.assertEqual([r[2] for r in ws.iter_rows(min_row=2, values_only=True)], ["Alpha", "Alpha", "beta", "Alpha", "Unassigned"])

    def test_the_status_cell_is_coloured_and_formula_looking_text_stays_text(self):
        rows = [{"Student Code": "1", "Student Name": "=SUM(1,1)", "University Name": "U", "Status": "09-Enrolled"}]
        ws = openpyxl.load_workbook(export.build_university_pipeline_export(rows, [], "T", "F", "O"))[export.APPLICATIONS_SHEET]
        self.assertEqual(ws["B2"].value, "=SUM(1,1)")
        self.assertNotEqual(ws["B2"].data_type, "f")
        self.assertEqual(ws["H2"].value, "09-Enrolled")
        self.assertEqual(ws["H2"].fill.fill_type, "solid")

    def test_summary_sheet_layout(self):
        summary = [{"university": "Alpha", "pending_assessment": 2, "pending_offer": 1, "pending_enrolment": 0, "enrolled_this_intake": 3, "lost": 1,
                    "total": 7, "forecast": 4, "conversion": 57, "avg_pending_assessment": 11, "avg_pending_offer": None, "all_stages_total": 9}]
        ws = openpyxl.load_workbook(export.build_university_pipeline_export([], summary, "Title", "Filters here", "Overall here"))[export.SUMMARY_SHEET]
        self.assertEqual([ws["A1"].value, ws["A2"].value, ws["A3"].value], ["Title", "Filters here", "Overall here"])
        self.assertEqual([c.value for c in ws[5]], [h for h, _ in export.SUMMARY_COLUMNS])
        self.assertEqual([c.value for c in ws[6]], ["Alpha", 2, 1, 0, 3, 1, 7, 4, 57, 11, None, 9])
        self.assertEqual(ws.freeze_panes, "B6")

    def test_a_university_name_that_looks_like_a_formula_stays_text(self):
        summary = [{"university": "=1+1", "pending_assessment": 0, "pending_offer": 0, "pending_enrolment": 0, "enrolled_this_intake": 0, "lost": 0,
                    "total": 0, "forecast": 0, "conversion": 0, "avg_pending_assessment": None, "avg_pending_offer": None, "all_stages_total": 0}]
        ws = openpyxl.load_workbook(export.build_university_pipeline_export([], summary, "T", "F", "O"))[export.SUMMARY_SHEET]
        self.assertEqual(ws["A6"].value, "=1+1")
        self.assertNotEqual(ws["A6"].data_type, "f")

    def test_an_empty_export_is_still_a_valid_workbook(self):
        wb = openpyxl.load_workbook(export.build_university_pipeline_export([], [], "T", "F", "O"))
        self.assertEqual(wb.sheetnames, ["Summary", "Applications"])
        self.assertEqual(wb["Applications"].max_row, 1)


class RouteTests(IsolatedAppTestCase):
    def setUp(self):
        super().setUp()
        self.full = self._client_logged_in_as("full")
        token = extract_token(self.full.get("/login").get_data(as_text=True))
        data = book(ROWS, lookups=LOOKUPS)
        self.assertEqual(self.full.post("/upload", data={"csrf_token": token, "excel_file": (io.BytesIO(data), "f.xlsx")},
                                        content_type="multipart/form-data").status_code, 302)

    def download(self, query="?year=2026", client=None):
        r = (client or self.full).get("/university-pipeline/export" + query)
        self.assertEqual(r.status_code, 200, query)
        self.assertIn("spreadsheetml", r.mimetype)
        return r, openpyxl.load_workbook(io.BytesIO(r.data))

    def page_context(self, query):
        with captured() as rendered:
            self.assertEqual(self.full.get("/university-pipeline" + query).status_code, 200)
        return next(c for name, c in rendered if name == "university_pipeline.html")

    def summary_rows(self, wb):
        ws = wb["Summary"]
        header = [c.value for c in ws[5]]
        return [dict(zip(header, r)) for r in ws.iter_rows(min_row=6, values_only=True) if r[0] is not None]

    def applications(self, wb):
        ws = wb["Applications"]
        header = [c.value for c in ws[1]]
        return [dict(zip(header, r)) for r in ws.iter_rows(min_row=2, values_only=True)]

    def test_the_download_matches_the_page_for_every_filter_combination(self):
        for query in QUERIES:
            context = self.page_context(query)
            _, wb = self.download(query)
            chart = [(r["name"], r["total"], r["forecast"], r["conversion"]) for g in context["pending_stage_chart_groups"] for r in g["rows"]]
            summary = self.summary_rows(wb)
            self.assertEqual([(s["University"], s["Total"], s["Forecast"], s["Conversion %"]) for s in summary], chart, query)
            overall = context["university_summary_cards"][0]["total"]
            apps = self.applications(wb)
            self.assertEqual(len(apps), overall, query)
            self.assertEqual(sum(s["All Stages Total"] for s in summary), overall, query)
            for s in summary:
                self.assertEqual(sum(1 for a in apps if a["University Name"] == s["University"]), s["All Stages Total"], (query, s["University"]))
            self.assertIn(f"Overall: {overall:,} apps", wb["Summary"]["A3"].value, query)

    def test_the_figures_are_right_for_a_known_case(self):
        _, wb = self.download("?year=2026")
        by_uni = {s["University"]: s for s in self.summary_rows(wb)}
        a = by_uni["Uni A"]
        self.assertEqual((a["Pending Assessment"], a["Pending Offer"], a["Enrolled This Intake"], a["Lost"], a["Total"], a["All Stages Total"]), (2, 0, 1, 0, 3, 4))  # A1 A6 assessing, A3 enrolled; A4 is QA (all-stages only); A8 belongs to Unassigned
        self.assertEqual(by_uni["Unassigned"]["All Stages Total"], 1)
        self.assertEqual(by_uni["Uni B"]["Pending Offer"], 1)
        self.assertEqual(by_uni["Uni B"]["Lost"], 1)
        codes = {x["Student Code"] for x in self.applications(wb)}
        self.assertEqual(codes, {"A1", "A2", "A3", "A4", "A5", "A6", "A8"}, "A7 (QA-rejected) is not an application in the pipeline; 2027 rows are on the 2027 tab")

    def test_offer_days_averages_match_the_page(self):
        context = self.page_context("?year=2026")
        _, wb = self.download("?year=2026")
        by_uni = {s["University"]: s for s in self.summary_rows(wb)}
        page = context["manager_average_offer_days"]
        for name, figures in page.items():
            for key, header in (("pending_assessment", "Avg Days Pending Assessment"), ("pending_offer", "Avg Days Pending Offer")):
                expected = None if figures.get(key) is None else math.ceil(figures[key])
                self.assertEqual(by_uni[name][header], expected, (name, key))
        self.assertNotEqual(page["Uni A"]["pending_assessment"], int(page["Uni A"]["pending_assessment"]), "a fractional average, so rounding matters")
        self.assertEqual(by_uni["Uni A"]["Avg Days Pending Assessment"], math.ceil(page["Uni A"]["pending_assessment"]))

    def test_application_manager_filter(self):
        _, wb = self.download("?year=2026&manager=Nouran")
        apps = self.applications(wb)
        self.assertEqual({a["Student Code"] for a in apps}, {"A1", "A2", "A6"})
        self.assertEqual({a["Application Manager"] for a in apps}, {"Nouran"})
        _, wb = self.download("?year=2026&manager=Unassigned")
        self.assertEqual({a["Student Code"] for a in self.applications(wb)}, {"A4"})
        self.assertEqual({a["Application Manager"] for a in self.applications(wb)}, {"Unassigned"})

    def test_intake_month_filter(self):
        _, wb = self.download("?year=2026&intake_month=9")
        apps = self.applications(wb)
        self.assertEqual({a["Student Code"] for a in apps}, {"A2", "A3", "A4", "A8"})
        self.assertEqual({a["Intake"] for a in apps}, {"September 2026"})

    def test_both_filters_and_the_intake_tab(self):
        _, wb = self.download("?year=2026&manager=Mo&intake_month=9")
        self.assertEqual({a["Student Code"] for a in self.applications(wb)}, {"A3", "A8"})
        _, wb = self.download("?year=2027&intake=intake_03")
        self.assertEqual({a["Student Code"] for a in self.applications(wb)}, {"B3"})
        _, wb = self.download("?year=2027&intake=intake_01&manager=Nouran")
        self.assertEqual({a["Student Code"] for a in self.applications(wb)}, {"B2"})

    def test_filters_that_are_not_options_are_ignored(self):
        _, unfiltered = self.download("?year=2026")
        _, wb = self.download("?year=2026&manager=Nobody&intake_month=99&intake_month=abc")
        self.assertEqual(len(self.applications(wb)), len(self.applications(unfiltered)))

    def test_the_applications_sheet_is_in_status_order_then_university_then_name(self):
        _, wb = self.download("?year=2026")
        apps = self.applications(wb)
        order = ["02-PendingQA", "03-PendingSubmission", "04-Onboarding", "05-Assessment", "06-Decision", "07-Ready", "08-Pre-Enrolled", "09-Enrolled", "10-Lost"]
        keys = [(order.index(a["Status"]), a["University Name"].lower(), (a["Student Name"] or "").lower()) for a in apps]
        self.assertEqual(keys, sorted(keys))
        self.assertEqual([a["Status"] for a in apps], ["02-PendingQA", "05-Assessment", "05-Assessment", "06-Decision", "09-Enrolled", "09-Enrolled", "10-Lost"])
        self.assertEqual([a["Student Code"] for a in apps], ["A4", "A1", "A6", "A2", "A8", "A3", "A5"], "within a status, universities alphabetically: Unassigned before Uni A")

    def test_status_filter(self):
        _, wb = self.download("?year=2026&status=05-Assessment")
        apps = self.applications(wb)
        self.assertEqual({a["Student Code"] for a in apps}, {"A1", "A6"})
        self.assertEqual({a["Status"] for a in apps}, {"05-Assessment"})
        self.assertIn("Status: 05-Assessment", wb["Summary"]["A2"].value)
        _, wb = self.download("?year=2026&status=02-PendingQA")
        self.assertEqual({a["Student Code"] for a in self.applications(wb)}, {"A4"}, "an application at a stage the chart leaves out is still in the download")
        self.assertEqual(self.summary_rows(wb)[0]["All Stages Total"], 1)
        _, wb = self.download("?year=2026&status=09-Enrolled&manager=Mo&intake_month=9")
        self.assertEqual({a["Student Code"] for a in self.applications(wb)}, {"A3", "A8"})

    def test_office_filter(self):
        _, wb = self.download("?year=2026&office=OXF")
        apps = self.applications(wb)
        self.assertEqual({a["Student Code"] for a in apps}, {"A1", "A3", "A4", "A8"}, "A4 is at 02-PendingQA: not on the chart but in the download")
        self.assertEqual({a["Consultant"] for a in apps}, {"Raneen"})
        self.assertIn("Office: OXF", wb["Summary"]["A2"].value)
        _, wb = self.download("?year=2026&office=MAN")
        self.assertEqual({a["Student Code"] for a in self.applications(wb)}, {"A2", "A5"})
        _, wb = self.download("?year=2026&office=LON&manager=Nouran")
        self.assertEqual({a["Student Code"] for a in self.applications(wb)}, {"A6"})
        _, wb = self.download("?year=2026&office=CAR")
        self.assertEqual(len(self.applications(wb)), 7, "CAR has nothing here so it is not an option and is ignored")
        self.assertIn("Office: All", wb["Summary"]["A2"].value)

    def test_consultant_filter(self):
        _, wb = self.download("?year=2026&consultant=Mel")
        apps = self.applications(wb)
        self.assertEqual({a["Student Code"] for a in apps}, {"A2", "A5"})
        self.assertEqual({a["Consultant"] for a in apps}, {"Mel"})
        self.assertIn("Consultant: Mel", wb["Summary"]["A2"].value)
        _, wb = self.download("?year=2026&consultant=Raneen&manager=Mo&status=09-Enrolled&intake_month=9")
        self.assertEqual({a["Student Code"] for a in self.applications(wb)}, {"A3", "A8"})
        self.assertEqual({a["Student Code"] for a in self.applications(self.download("?year=2026&consultant=Hannah")[1])}, {"A6"})
        _, wb = self.download("?year=2026&consultant=Nobody")
        self.assertEqual(len(self.applications(wb)), 7, "not an option, so ignored")
        self.assertIn("Consultant: All", wb["Summary"]["A2"].value)

    def test_several_statuses(self):
        _, wb = self.download("?year=2026&status=05-Assessment&status=09-Enrolled")
        apps = self.applications(wb)
        self.assertEqual({a["Student Code"] for a in apps}, {"A1", "A6", "A3", "A8"})
        self.assertEqual([a["Status"] for a in apps], ["05-Assessment", "05-Assessment", "09-Enrolled", "09-Enrolled"], "in Status order")
        self.assertIn("Status: 05-Assessment, 09-Enrolled", wb["Summary"]["A2"].value)
        _, wb = self.download("?year=2026&status=10-Lost&status=Nope&status=02-PendingQA&status=00-QARejected")
        self.assertEqual([a["Student Code"] for a in self.applications(wb)], ["A4", "A5"])
        self.assertIn("Status: 02-PendingQA, 10-Lost", wb["Summary"]["A2"].value)

    def test_several_months(self):
        _, wb = self.download("?year=2026&intake_month=9&intake_month=10")
        apps = self.applications(wb)
        self.assertEqual({a["Student Code"] for a in apps}, {"A2", "A3", "A4", "A5", "A8"})
        self.assertEqual({a["Intake"] for a in apps}, {"September 2026", "October 2026"})
        self.assertIn("Intake Month: September 2026, October 2026", wb["Summary"]["A2"].value)
        _, wb = self.download("?year=2026&intake_month=8&intake_month=11&intake_month=99&intake_month=x")
        self.assertEqual({a["Student Code"] for a in self.applications(wb)}, {"A1", "A6"})
        self.assertIn("Intake Month: August 2026, November 2026", wb["Summary"]["A2"].value)

    def test_the_summary_heading_says_which_filters_were_applied(self):
        _, wb = self.download("?year=2026&manager=Nouran&intake_month=9")
        ws = wb["Summary"]
        self.assertEqual(ws["A1"].value, "University Pipeline 2026")
        self.assertIn("Application Manager: Nouran", ws["A2"].value)
        self.assertIn("Intake Month: September 2026", ws["A2"].value)
        self.assertIn("Downloaded", ws["A2"].value)
        _, wb = self.download("?year=2027&intake=intake_03")
        self.assertEqual(wb["Summary"]["A1"].value, "University Pipeline 2027 - Intake 03")
        self.assertIn("Office: All  |  Application Manager: All  |  Consultant: All  |  Status: All  |  Intake Month: All", wb["Summary"]["A2"].value)

    def test_the_filename_carries_the_filters(self):
        r, _ = self.download("?year=2026&manager=Nouran&intake_month=9")
        self.assertIn(f'filename=University_Pipeline_2026_Nouran_Sep_{today_uk().strftime("%d-%m-%Y")}.xlsx', r.headers["Content-Disposition"])
        r, _ = self.download("?year=2026&status=05-Assessment&intake_month=9&intake_month=10")
        self.assertIn("filename=University_Pipeline_2026_05-Assessment_Sep-Oct_", r.headers["Content-Disposition"])
        r, _ = self.download("?year=2026&office=OXF&manager=Nouran&consultant=Raneen")
        self.assertIn("filename=University_Pipeline_2026_OXF_Nouran_Raneen_", r.headers["Content-Disposition"])
        r, _ = self.download("?year=2027&intake=intake_03&office=OXF")
        self.assertIn("filename=University_Pipeline_2027_Intake03_OXF_", r.headers["Content-Disposition"])
        r, _ = self.download("?year=2026&consultant=Mel&manager=Nouran")
        self.assertIn("filename=University_Pipeline_2026_Nouran_Mel_", r.headers["Content-Disposition"])
        r, _ = self.download("?year=2026&status=05-Assessment&status=09-Enrolled&status=10-Lost")
        self.assertIn("filename=University_Pipeline_2026_Status05-09-10_", r.headers["Content-Disposition"])
        r, _ = self.download("?year=2027&intake=intake_03")
        self.assertIn("University_Pipeline_2027_Intake03_", r.headers["Content-Disposition"])

    def test_the_download_button_on_the_page_carries_the_current_filters(self):
        html = self.full.get("/university-pipeline?year=2026&manager=Nouran&intake_month=9").get_data(as_text=True)
        href = re.search(r'<a class="uni-download" href="([^"]+)">Download Excel</a>', html).group(1).replace("&amp;", "&")
        self.assertEqual(href, "/university-pipeline/export?year=2026&manager=Nouran&intake_month=9")
        html = self.full.get("/university-pipeline?year=2026&status=05-Assessment&status=09-Enrolled&intake_month=9&intake_month=10&manager=Mo").get_data(as_text=True)
        href = re.search(r'<a class="uni-download" href="([^"]+)">Download Excel</a>', html).group(1).replace("&amp;", "&")
        path, query = href.split("?")
        self.assertEqual(path, "/university-pipeline/export")
        self.assertEqual(sorted(query.split("&")), sorted(["year=2026", "manager=Mo", "status=05-Assessment", "status=09-Enrolled", "intake_month=9", "intake_month=10"]))
        html = self.full.get("/university-pipeline?year=2026&consultant=Mel&manager=Mo").get_data(as_text=True)
        href = re.search(r'<a class="uni-download" href="([^"]+)">Download Excel</a>', html).group(1).replace("&amp;", "&")
        self.assertEqual(sorted(href.split("?")[1].split("&")), ["consultant=Mel", "manager=Mo", "year=2026"])
        html = self.full.get("/university-pipeline?year=2027&intake=intake_03").get_data(as_text=True)
        self.assertIn('href="/university-pipeline/export?year=2027&amp;intake=intake_03"', html)
        html = self.full.get("/university-pipeline?year=2026").get_data(as_text=True)
        self.assertIn('href="/university-pipeline/export?year=2026"', html)

    def test_every_role_can_download_by_default_and_login_is_required(self):
        for role in ("admissions", "consultants", "marketing"):
            _, wb = self.download("?year=2026&manager=Mo", client=self._client_logged_in_as(role))
            self.assertEqual(len(self.applications(wb)), 3, role)       # A3, A5, A8 (A7 is not a pipeline status)
        r = app_module.app.test_client().get("/university-pipeline/export?year=2026")
        self.assertEqual(r.status_code, 302)
        self.assertIn("/login", r.headers["Location"])

    def test_with_no_dataset_it_redirects_with_a_message(self):
        import sqlite3
        from tests.flask_test_support import db_module
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute("DELETE FROM active_dataset")
        conn.commit()
        conn.close()
        r = self.full.get("/university-pipeline/export?year=2026")
        self.assertEqual(r.status_code, 302)
        self.assertTrue(r.headers["Location"].endswith("/university-pipeline"))

    def test_a_filter_that_matches_nothing_gives_a_valid_empty_workbook(self):
        _, wb = self.download("?year=2026&manager=Mo&intake_month=8")
        self.assertEqual(self.applications(wb), [])
        self.assertEqual(self.summary_rows(wb), [])


class AccessGridTests(AccessRouteTestCase):
    """The download follows the Admin access grid's page-export switch."""

    def setUp(self):
        super().setUp()
        token = self.token(self.full)
        data = book(ROWS, lookups=LOOKUPS)
        self.full.post("/upload", data={"csrf_token": token, "excel_file": (io.BytesIO(data), "f.xlsx")}, content_type="multipart/form-data")

    def test_switching_page_exports_off_hides_the_button_and_blocks_the_download(self):
        marketing = self._client_logged_in_as("marketing")
        self.assertIn("Download Excel", marketing.get("/university-pipeline?year=2026").get_data(as_text=True))
        self.save(self.grid_with(marketing=((), ("download_exports",))))
        page = marketing.get("/university-pipeline?year=2026")
        self.assertEqual(page.status_code, 200)
        self.assertNotIn("Download Excel", page.get_data(as_text=True))
        self.assertEqual(marketing.get("/university-pipeline/export?year=2026").status_code, 403)
        self.assertEqual(self.full.get("/university-pipeline/export?year=2026").status_code, 200)
        self.assertEqual(self._client_logged_in_as("admissions").get("/university-pipeline/export?year=2026").status_code, 200)


if __name__ == "__main__":
    unittest.main()
