"""The minimum-age guard in db.cleanup_orphaned_uploads().

Between a request saving its workbook and committing the row that references
it, that file is legitimately unreferenced. If a second user's upload finishes
in that window its cleanup used to delete the first user's file from under
it. The cleanup now leaves any file younger than db.ORPHAN_MIN_AGE_SECONDS
alone; genuinely old orphans are still removed.

Everything here uses temporary folders / databases (never the real uploads/
or data/app.db)."""

import io
import os
import re
import shutil
import sqlite3
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest import mock

import openpyxl

from db import ORPHAN_MIN_AGE_SECONDS, cleanup_orphaned_uploads
from leads import REQUIRED_LEADS_SOURCE_COLUMNS, save_active_leads_dataset
from processing import save_active_dataset
from tests.flask_test_support import IsolatedAppTestCase, app_module, extract_token
from tests.test_upload_atomicity import book, row

MINUTE = 60
APPS_NAME = "20261005120000_apps.xlsx"
LEADS_NAME = "leads_20261005120000_leads.xlsx"


def set_age(path, seconds):
    modified = time.time() - seconds
    os.utime(path, (modified, modified))


class _TempUploadsTestCase(unittest.TestCase):
    def setUp(self):
        self.tmp_dir = Path(tempfile.mkdtemp(prefix="gsp_age_test_"))
        self.addCleanup(shutil.rmtree, self.tmp_dir, ignore_errors=True)
        self.conn = sqlite3.connect(":memory:")
        self.conn.row_factory = sqlite3.Row
        self.addCleanup(self.conn.close)
        self.conn.executescript(
            """
            CREATE TABLE active_dataset (
                id INTEGER PRIMARY KEY AUTOINCREMENT, original_filename TEXT NOT NULL,
                stored_filename TEXT NOT NULL, uploaded_at TEXT NOT NULL, row_count INTEGER, data_json TEXT);
            CREATE TABLE active_leads_dataset (
                id INTEGER PRIMARY KEY AUTOINCREMENT, original_filename TEXT NOT NULL,
                stored_filename TEXT NOT NULL, uploaded_at TEXT NOT NULL, row_count INTEGER,
                columns_json TEXT, data_json TEXT);
            """
        )
        self.conn.commit()

    def make(self, name, age_seconds):
        path = self.tmp_dir / name
        path.write_text("")
        set_age(path, age_seconds)
        return path

    def reference(self, table, name):
        if table == "active_leads_dataset":
            self.conn.execute(
                "INSERT INTO active_leads_dataset (original_filename, stored_filename, uploaded_at, row_count, columns_json, data_json) "
                "VALUES ('x.xlsx', ?, '2026-10-05T12:00:00', 0, '[]', '[]')", (name,))
        else:
            self.conn.execute(
                "INSERT INTO active_dataset (original_filename, stored_filename, uploaded_at, row_count, data_json) "
                "VALUES ('x.xlsx', ?, '2026-10-05T12:00:00', 0, '[]')", (name,))
        self.conn.commit()

    def remaining(self):
        return {p.name for p in self.tmp_dir.iterdir()}


class AgeGuardTests(_TempUploadsTestCase):
    def test_the_threshold_is_five_minutes(self):
        self.assertEqual(ORPHAN_MIN_AGE_SECONDS, 5 * MINUTE)

    def test_a_recent_unreferenced_upload_is_not_deleted(self):
        for name, age in ((APPS_NAME, 0), ("20261005120001_b.xlsx", 5), (LEADS_NAME, MINUTE), ("leads_20261005120002_c.xlsx", 5 * MINUTE - 5)):
            self.make(name, age)
        self.assertEqual(cleanup_orphaned_uploads(self.conn, self.tmp_dir), [])
        self.assertEqual(len(self.remaining()), 4)

    def test_an_old_unreferenced_upload_is_deleted(self):
        self.make(APPS_NAME, 5 * MINUTE + 5)
        self.make(LEADS_NAME, 24 * 60 * MINUTE)
        self.assertEqual(sorted(cleanup_orphaned_uploads(self.conn, self.tmp_dir)), sorted([APPS_NAME, LEADS_NAME]))
        self.assertEqual(self.remaining(), set())

    def test_exactly_at_the_threshold_counts_as_old(self):
        path = self.make(APPS_NAME, 0)
        now = time.time()
        os.utime(path, (now - ORPHAN_MIN_AGE_SECONDS, now - ORPHAN_MIN_AGE_SECONDS))
        self.assertEqual(cleanup_orphaned_uploads(self.conn, self.tmp_dir, now=now), [APPS_NAME])

    def test_a_referenced_upload_is_never_deleted_whatever_its_age(self):
        self.make(APPS_NAME, 10 * 365 * 24 * 60 * MINUTE)
        self.make(LEADS_NAME, 10 * 365 * 24 * 60 * MINUTE)
        self.reference("active_dataset", APPS_NAME)
        self.reference("active_leads_dataset", LEADS_NAME)
        for min_age in (None, 0):
            self.assertEqual(cleanup_orphaned_uploads(self.conn, self.tmp_dir, min_age_seconds=min_age), [])
        self.assertEqual(self.remaining(), {APPS_NAME, LEADS_NAME})

    def test_age_comes_from_the_modification_time_not_the_timestamp_in_the_name(self):
        """Both names look ancient / brand new respectively, which must not matter."""
        self.make("20200101000000_ancient_name_fresh_file.xlsx", 1)
        self.make("20991231235959_future_name_old_file.xlsx", 2 * ORPHAN_MIN_AGE_SECONDS)
        self.assertEqual(cleanup_orphaned_uploads(self.conn, self.tmp_dir), ["20991231235959_future_name_old_file.xlsx"])
        self.assertEqual(self.remaining(), {"20200101000000_ancient_name_fresh_file.xlsx"})

    def test_a_modification_time_in_the_future_is_treated_as_recent(self):
        self.make(APPS_NAME, -3600)
        self.assertEqual(cleanup_orphaned_uploads(self.conn, self.tmp_dir), [])

    def test_a_file_whose_age_cannot_be_read_is_left_alone_and_nothing_raises(self):
        self.make(APPS_NAME, 24 * 60 * MINUTE)
        real_stat = Path.stat

        def flaky_stat(path, *a, **k):
            if path.name == APPS_NAME and getattr(flaky_stat, "armed", False):
                raise PermissionError("denied")
            result = real_stat(path, *a, **k)
            if path.name == APPS_NAME:
                flaky_stat.armed = True  # the first stat (is_file) works, the age stat fails
            return result

        with mock.patch.object(Path, "stat", flaky_stat):
            self.assertEqual(cleanup_orphaned_uploads(self.conn, self.tmp_dir), [])
        self.assertEqual(self.remaining(), {APPS_NAME})

    def test_other_protections_are_unchanged_for_old_files(self):
        self.make(".gitkeep", 24 * 60 * MINUTE)
        self.make("notes.xlsx", 24 * 60 * MINUTE)
        self.make("20261005_missing_seconds.xlsx", 24 * 60 * MINUTE)
        (self.tmp_dir / "20261005120000_a_directory.xlsx").mkdir()
        self.assertEqual(cleanup_orphaned_uploads(self.conn, self.tmp_dir), [])
        self.assertEqual(len(self.remaining()), 4)

    def test_the_explicit_arguments_override_the_default(self):
        self.make(APPS_NAME, 30)
        self.assertEqual(cleanup_orphaned_uploads(self.conn, self.tmp_dir, min_age_seconds=10), [APPS_NAME])
        self.make(LEADS_NAME, 30)
        self.assertEqual(cleanup_orphaned_uploads(self.conn, self.tmp_dir, now=time.time() + 10 * MINUTE), [LEADS_NAME])


class OverlappingSaveTests(_TempUploadsTestCase):
    """Request A has saved its workbook but not committed; request B then
    finishes - with the real save functions, so B's cleanup really runs."""

    def finish_applications(self, name):
        save_active_dataset(self.conn, "x.xlsx", name, "2026-10-05T12:00:00", [], self.tmp_dir)

    def finish_leads(self, name):
        save_active_leads_dataset(self.conn, "l.xlsx", name, "2026-10-05T12:00:00", ["X"], [{"X": 1}], self.tmp_dir)

    def test_a_leads_save_cannot_delete_an_in_flight_applications_file(self):
        in_flight = self.make(APPS_NAME, 1)
        self.make(LEADS_NAME, 1)
        self.finish_leads(LEADS_NAME)
        self.assertTrue(in_flight.exists())
        self.finish_applications(APPS_NAME)  # request A now completes
        self.assertEqual(self.remaining(), {APPS_NAME, LEADS_NAME})

    def test_an_applications_save_cannot_delete_an_in_flight_leads_file(self):
        in_flight = self.make(LEADS_NAME, 1)
        self.make(APPS_NAME, 1)
        self.finish_applications(APPS_NAME)
        self.assertTrue(in_flight.exists())
        self.finish_leads(LEADS_NAME)
        self.assertEqual(self.remaining(), {APPS_NAME, LEADS_NAME})

    def test_two_overlapping_applications_uploads_cannot_delete_each_other(self):
        a, b = "20261005120000_a.xlsx", "20261005120001_b.xlsx"
        self.make(a, 2)
        self.make(b, 1)
        self.finish_applications(b)
        self.assertTrue((self.tmp_dir / a).exists(), "A's file survived B's cleanup")
        self.finish_applications(a)
        self.assertEqual(self.remaining(), {a, b})

    def test_once_it_has_aged_an_orphan_is_removed_by_a_later_save(self):
        orphan = self.make("20261005110000_failed_upload.xlsx", 1)
        self.make(APPS_NAME, 1)
        self.finish_applications(APPS_NAME)
        self.assertTrue(orphan.exists())
        set_age(orphan, 10 * MINUTE)
        self.make("20261005130000_next.xlsx", 1)
        self.finish_applications("20261005130000_next.xlsx")
        self.assertFalse(orphan.exists())


def leads_book():
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Leads"
    ws.append(REQUIRED_LEADS_SOURCE_COLUMNS)
    r = {c: "" for c in REQUIRED_LEADS_SOURCE_COLUMNS}
    r.update({"Student Id": "PES-L1", "Name": "Lead One", "Lead Status": "Qualified", "Creation Date": "01/10/2026"})
    ws.append([r[c] for c in REQUIRED_LEADS_SOURCE_COLUMNS])
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


APPS_BOOK = book([row(**{"Student Code": "P1", "Student Name": "A", "Application Status": "x"})])
LEADS_BOOK = leads_book()


class RouteTests(IsolatedAppTestCase):
    def setUp(self):
        super().setUp()
        self.client = self._client_logged_in_as("full")

    def token(self, client=None):
        return extract_token((client or self.client).get("/login").get_data(as_text=True))

    def upload(self, path, data, client=None):
        client = client or self.client
        return client.post(path, data={"csrf_token": self.token(client), "excel_file": (io.BytesIO(data), "t.xlsx")},
                           content_type="multipart/form-data")

    def stored(self):
        return {p.name for p in self.tmp_uploads_dir.iterdir()}

    def flash_texts(self, response, client=None):
        page = (client or self.client).get(response.headers["Location"]).get_data(as_text=True)
        return re.findall(r'class="flash (\w+)">([^<]+)<', page)

    def test_applications_upload_still_succeeds(self):
        response = self.upload("/upload", APPS_BOOK)
        self.assertEqual(response.status_code, 302)
        self.assertEqual(len(self.stored()), 1)
        self.assertEqual([k for k, _ in self.flash_texts(response)], ["success"])

    def test_leads_upload_still_succeeds(self):
        response = self.upload("/leads/upload", LEADS_BOOK)
        self.assertEqual(response.status_code, 302)
        self.assertEqual(len([n for n in self.stored() if n.startswith("leads_")]), 1)
        self.assertEqual([k for k, _ in self.flash_texts(response)], ["success"])

    def test_reprocess_still_finds_the_original_workbook(self):
        self.upload("/upload", APPS_BOOK)
        self.upload("/leads/upload", LEADS_BOOK)  # its cleanup must not take the Applications file
        response = self.client.post("/admin/reprocess", data={"csrf_token": self.token()})
        kinds = [k for k, _ in self.flash_texts(response)]
        self.assertEqual(kinds, ["success"], "not 'original workbook could not be found'")

    def test_a_recent_orphan_survives_an_upload_but_an_old_one_is_removed(self):
        recent = self.tmp_uploads_dir / "20261005110000_recent_orphan.xlsx"
        old = self.tmp_uploads_dir / "20261005100000_old_orphan.xlsx"
        for path, age in ((recent, 30), (old, 2 * ORPHAN_MIN_AGE_SECONDS)):
            path.write_text("")
            set_age(path, age)
        self.upload("/upload", APPS_BOOK)
        self.assertTrue(recent.exists())
        self.assertFalse(old.exists())

    def test_two_users_uploading_at_the_same_moment_do_not_break_each_other(self):
        """The real race: user A's request is paused after its workbook is
        saved and before it is processed/committed, while user B's whole
        Leads upload (including its cleanup) completes."""
        client_a, client_b = self._client_logged_in_as("full"), self._client_logged_in_as("admissions")
        a_saved, b_done = threading.Event(), threading.Event()
        real_process = app_module.process_workbook

        def paused_process(path, conn, now_iso):
            a_saved.set()                         # A's file is on disk, not yet referenced by any row
            self.assertTrue(b_done.wait(30), "B did not finish")
            return real_process(path, conn, now_iso)

        result = {}

        def user_a():
            with mock.patch.object(app_module, "process_workbook", paused_process):
                result["a"] = self.upload("/upload", APPS_BOOK, client_a)

        thread = threading.Thread(target=user_a)
        thread.start()
        try:
            self.assertTrue(a_saved.wait(30), "A never reached processing")
            apps_files = [n for n in self.stored() if not n.startswith("leads_")]
            self.assertEqual(len(apps_files), 1)
            response_b = self.upload("/leads/upload", LEADS_BOOK, client_b)   # B finishes, cleanup runs
            self.assertEqual(response_b.status_code, 302)
            self.assertTrue((self.tmp_uploads_dir / apps_files[0]).exists(), "B's cleanup deleted A's in-flight file")
        finally:
            b_done.set()
            thread.join(30)
        self.assertFalse(thread.is_alive())
        self.assertEqual(result["a"].status_code, 302)
        self.assertEqual([k for k, _ in self.flash_texts(result["a"], client_a)], ["success"], "A's upload succeeded")
        reprocess = client_a.post("/admin/reprocess", data={"csrf_token": self.token(client_a)})
        self.assertEqual([k for k, _ in self.flash_texts(reprocess, client_a)], ["success"], "and A's workbook is still there to reprocess")


if __name__ == "__main__":
    unittest.main()
