"""No full test suite existed for this module before Finding 11 - this
file is deliberately scoped to just the formula-injection wiring check
(the "minimum shared helper infrastructure" requirement), not general
coverage of enrolled_intake_export.py."""

import unittest

import openpyxl

from enrolled_intake_export import EXPORT_COLUMNS, SHEET_TITLE, build_enrolled_current_intake_export


class FormulaInjectionProtectionTests(unittest.TestCase):
    def test_formula_looking_student_name_is_not_stored_as_a_formula(self):
        rows = [{"Student Code": "PES-001", "Student Name": "=SUM(1,1)"}]
        buffer = build_enrolled_current_intake_export(rows)
        wb = openpyxl.load_workbook(buffer)
        ws = wb[SHEET_TITLE]
        cell = ws.cell(row=2, column=EXPORT_COLUMNS.index("Student Name") + 1)
        self.assertEqual(cell.value, "=SUM(1,1)")
        self.assertNotEqual(cell.data_type, "f")


if __name__ == "__main__":
    unittest.main()
