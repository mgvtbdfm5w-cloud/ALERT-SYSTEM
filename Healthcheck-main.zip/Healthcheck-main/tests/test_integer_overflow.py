"""SQLite INTEGER range validation.

SQLite stores INTEGER values as signed 64-bit numbers; handing it a bigger
Python int raised OverflowError, which surfaced as an HTTP 500 AND leaked the
request's connection. Ordinary typed input - a huge number in a KPI target
or in a lookup Intake 01 / Intake 02 count - could trigger it.

Now such values are refused BEFORE the database is touched, with the
app's normal validation style (a flash message and a redirect):

- the existing business rules are untouched (targets and counts must still
  be whole, non-negative numbers; negatives keep their original messages);
- the largest storable value, 2**63 - 1, is accepted and behaves normally;
- 2**63 and anything bigger is refused: no HTTP 500, no database change,
  no internal SQLite wording shown, and the connection is closed.

The same holds for the two other places a user-controlled number reached
SQLite: the year inside the KPI form's hidden `month_key` field, and the
`lookup_id` in the lookup edit/delete URLs (Flask's <int:> converter accepts
any number of digits). A year too large to store is just an "Invalid month.";
a lookup id too large to exist behaves exactly like any other id that matches
no row.

Temp databases only.
"""

import html
import re
import sqlite3
import unittest

import db
import kpi
import lookups
from tests.connection_tracking import ConnectionTracker
from tests.flask_test_support import IsolatedAppTestCase, app_module, db_module, extract_token

MAX_INT = 2**63 - 1
MIN_INT = -(2**63)
OVERFLOWING = [2**63, 2**63 + 1, 10**30, 10**100, 10**300]


class FitsSqliteIntegerTests(unittest.TestCase):
    def test_boundaries(self):
        self.assertEqual((db.SQLITE_INT_MIN, db.SQLITE_INT_MAX), (-(2**63), 2**63 - 1))
        for ok in (0, 1, -1, MAX_INT, MIN_INT):
            self.assertTrue(db.fits_sqlite_integer(ok), ok)
        for bad in (MAX_INT + 1, MIN_INT - 1, 10**30, -(10**30)):
            self.assertFalse(db.fits_sqlite_integer(bad), bad)

    def test_it_matches_what_sqlite_actually_accepts(self):
        conn = sqlite3.connect(":memory:")
        conn.execute("CREATE TABLE t (n INTEGER)")
        for ok in (MIN_INT, -1, 0, MAX_INT):
            conn.execute("INSERT INTO t VALUES (?)", (ok,))
        for bad in (MAX_INT + 1, MIN_INT - 1):
            with self.assertRaises(OverflowError):
                conn.execute("INSERT INTO t VALUES (?)", (bad,))
        conn.close()


class ValidatorUnitTests(unittest.TestCase):
    def test_kpi_target_validation_keeps_its_rules_and_adds_the_upper_bound(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("CREATE TABLE kpi_targets (id INTEGER PRIMARY KEY, year INTEGER, month INTEGER, target_type TEXT, target_value INTEGER, UNIQUE(year, month, target_type))")
        kpi.set_kpi_target(conn, 2026, 8, "__COMPANY__", str(MAX_INT))
        self.assertEqual(conn.execute("SELECT target_value FROM kpi_targets").fetchone()[0], MAX_INT)
        for raw, message in (
            ("abc", "Target must be a whole number."),
            ("1.5", "Target must be a whole number."),
            ("", "Target must be a whole number."),
            ("-1", "Target must be zero or greater."),
            (str(MIN_INT), "Target must be zero or greater."),
            (str(MIN_INT - 1), "Target must be zero or greater."),
            (str(MAX_INT + 1), "Target is too large."),
            ("9" * 30, "Target is too large."),
            ("9" * 300, "Target is too large."),
        ):
            with self.subTest(raw=raw[:20]):
                with self.assertRaises(kpi.KpiTargetValidationError) as caught:
                    kpi.set_kpi_target(conn, 2026, 9, "__COMPANY__", raw)
                self.assertEqual(str(caught.exception), message)
        self.assertEqual(conn.execute("SELECT COUNT(*) FROM kpi_targets").fetchone()[0], 1, "only the valid one was stored")
        conn.close()

    def test_lookup_count_validation_keeps_its_rules_and_adds_the_upper_bound(self):
        self.assertEqual(lookups._parse_count(None, "Intake 01"), 0)
        self.assertEqual(lookups._parse_count("", "Intake 01"), 0)
        self.assertEqual(lookups._parse_count("  ", "Intake 01"), 0)
        self.assertEqual(lookups._parse_count("0", "Intake 01"), 0)
        self.assertEqual(lookups._parse_count(str(MAX_INT), "Intake 01"), MAX_INT)
        for raw, message in (
            ("abc", "Intake 02 must be a whole number."),
            ("2.5", "Intake 02 must be a whole number."),
            ("-1", "Intake 02 cannot be negative."),
            (str(MIN_INT), "Intake 02 cannot be negative."),
            (str(MIN_INT - 1), "Intake 02 cannot be negative."),
            (str(MAX_INT + 1), "Intake 02 is too large."),
            ("9" * 30, "Intake 02 is too large."),
            ("9" * 300, "Intake 02 is too large."),
        ):
            with self.subTest(raw=raw[:20]):
                with self.assertRaises(lookups.LookupValidationError) as caught:
                    lookups._parse_count(raw, "Intake 02")
                self.assertEqual(str(caught.exception), message)


class OverflowRouteTestCase(IsolatedAppTestCase):
    INTERNAL_WORDS = ("OverflowError", "too large to convert", "Python int", "SQLite INTEGER", "sqlite", "Traceback", "Internal Server Error")

    def setUp(self):
        super().setUp()
        self.tracker = ConnectionTracker(db_module)
        self.tracker.install()
        self.addCleanup(self.tracker.uninstall)
        self.addCleanup(self.tracker.force_close_leaks)
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute(
            "INSERT INTO lookup_tables (table_name, source_value, mapped_value, created_at, intake_01_count, intake_02_count) "
            "VALUES ('sales_office', 'OX', 'Oxford', '2026-01-01T00:00:00', 5, 7)"
        )
        conn.commit()
        conn.close()
        self.office_id = self.query("SELECT id FROM lookup_tables")[0][0]
        self.client = self._client_logged_in_as("full")
        self.token = extract_token(self.client.get("/login").get_data(as_text=True))
        self.tracker.reset()

    def query(self, sql, params=()):
        conn = sqlite3.connect(db_module.DB_PATH)
        try:
            return conn.execute(sql, params).fetchall()
        finally:
            conn.close()

    def snapshot(self):
        return {
            "kpi": self.query("SELECT year, month, target_type, target_value FROM kpi_targets ORDER BY id"),
            "lookups": self.query("SELECT id, table_name, source_value, mapped_value, intake_01_count, intake_02_count FROM lookup_tables ORDER BY id"),
        }

    def post(self, path, **data):
        return self.client.post(path, data={"csrf_token": self.token, **data}, follow_redirects=True)

    def post_no_follow(self, path, **data):
        return self.client.post(path, data={"csrf_token": self.token, **data})

    @staticmethod
    def flashes(response):
        return [(cat, html.unescape(text)) for cat, text in re.findall(r'class="flash (\w+)">([^<]+)<', response.get_data(as_text=True))]

    def assert_database_is_writable_immediately(self):
        """BEGIN IMMEDIATE takes the write lock; with timeout=0 it fails at
        once if a leaked connection is holding it."""
        probe = sqlite3.connect(db_module.DB_PATH, timeout=0, isolation_level=None)
        try:
            probe.execute("BEGIN IMMEDIATE")
            probe.execute("ROLLBACK")
        finally:
            probe.close()

    def assert_refused_cleanly(self, response, message, before):
        body = response.get_data(as_text=True)
        self.assertEqual(response.status_code, 200, "followed redirect lands on a normal page, not a 500")
        self.assertIn(message, body)
        self.assertIn('class="flash error"', body)
        for word in self.INTERNAL_WORDS:
            self.assertNotIn(word, body)
        self.assertEqual(self.snapshot(), before, "nothing was written")
        self.assertEqual(self.tracker.leaked(), [], "no connection left open")


class KpiTargetOverflowRouteTests(OverflowRouteTestCase):
    PATH = "/admin/kpi-targets/__COMPANY__"

    def set_target(self, value):
        return self.post(self.PATH, month_key="2026-08", target_value=str(value))

    def test_the_largest_storable_target_is_accepted_and_stored(self):
        response = self.set_target(MAX_INT)
        self.assertEqual(response.status_code, 200)
        self.assertIn("saved", response.get_data(as_text=True))
        self.assertEqual(self.query("SELECT target_value FROM kpi_targets"), [(MAX_INT,)])
        self.assertEqual(self.tracker.leaked(), [])

    def test_the_pages_still_render_with_the_largest_stored_target(self):
        self.set_target(MAX_INT)
        for path in ("/admin", "/kpi", "/company-dashboard"):
            with self.subTest(path=path):
                self.assertEqual(self.client.get(path).status_code, 200)

    def test_two_to_the_63_and_larger_are_refused_with_a_normal_validation_message(self):
        for value in OVERFLOWING:
            with self.subTest(value=str(value)[:12] + ("..." if len(str(value)) > 12 else "")):
                before = self.snapshot()
                self.tracker.reset()
                response = self.set_target(value)
                self.assert_refused_cleanly(response, "Target is too large.", before)

    def test_a_refused_value_does_not_overwrite_an_existing_target(self):
        self.set_target(100)
        before = self.snapshot()
        self.assert_refused_cleanly(self.set_target(2**63), "Target is too large.", before)
        self.assertEqual(self.query("SELECT target_value FROM kpi_targets"), [(100,)])

    def test_existing_validation_messages_are_unchanged(self):
        for value, message in (("abc", "Target must be a whole number."), ("-1", "Target must be zero or greater."), (str(MIN_INT), "Target must be zero or greater.")):
            with self.subTest(value=value):
                before = self.snapshot()
                self.tracker.reset()
                self.assert_refused_cleanly(self.post(self.PATH, month_key="2026-08", target_value=value), message, before)

    def test_zero_and_ordinary_values_still_work(self):
        for value in (0, 1, 240):
            self.assertIn("saved", self.set_target(value).get_data(as_text=True))
            self.assertEqual(self.query("SELECT target_value FROM kpi_targets"), [(value,)])


class LookupCountOverflowRouteTests(OverflowRouteTestCase):
    ADD = "/admin/lookups/sales_office/add"

    def edit_path(self):
        return f"/admin/lookups/sales_office/{self.office_id}/edit"

    def test_the_largest_storable_counts_are_accepted_on_add_and_edit(self):
        response = self.post(self.ADD, source_value="NEW", mapped_value="x", intake_01_count=str(MAX_INT), intake_02_count=str(MAX_INT))
        self.assertIn("Mapping added.", response.get_data(as_text=True))
        self.assertEqual(self.query("SELECT intake_01_count, intake_02_count FROM lookup_tables WHERE source_value='NEW'"), [(MAX_INT, MAX_INT)])
        response = self.post(self.edit_path(), source_value="OX", mapped_value="Oxford", intake_01_count=str(MAX_INT), intake_02_count="0")
        self.assertIn("Mapping updated.", response.get_data(as_text=True))
        self.assertEqual(self.query("SELECT intake_01_count, intake_02_count FROM lookup_tables WHERE id=?", (self.office_id,)), [(MAX_INT, 0)])
        self.assertEqual(self.tracker.leaked(), [])

    def test_add_refuses_overflowing_intake_counts(self):
        for field, label in (("intake_01_count", "Intake 01"), ("intake_02_count", "Intake 02")):
            for value in OVERFLOWING:
                with self.subTest(field=field, value=str(value)[:12]):
                    before = self.snapshot()
                    self.tracker.reset()
                    response = self.post(self.ADD, source_value=f"X-{field}-{len(str(value))}", mapped_value="x", **{field: str(value)})
                    self.assert_refused_cleanly(response, f"{label} is too large.", before)

    def test_edit_refuses_overflowing_intake_counts_and_leaves_the_row_unchanged(self):
        for field, label in (("intake_01_count", "Intake 01"), ("intake_02_count", "Intake 02")):
            for value in OVERFLOWING:
                with self.subTest(field=field, value=str(value)[:12]):
                    before = self.snapshot()
                    self.tracker.reset()
                    response = self.post(self.edit_path(), source_value="OX-renamed", mapped_value="Changed", **{field: str(value)})
                    self.assert_refused_cleanly(response, f"{label} is too large.", before)
        self.assertEqual(self.query("SELECT source_value, mapped_value, intake_01_count, intake_02_count FROM lookup_tables WHERE id=?", (self.office_id,)), [("OX", "Oxford", 5, 7)])

    def test_existing_validation_messages_are_unchanged(self):
        for value, message in (("abc", "Intake 01 must be a whole number."), ("-1", "Intake 01 cannot be negative."), (str(MIN_INT), "Intake 01 cannot be negative.")):
            with self.subTest(value=value):
                before = self.snapshot()
                self.tracker.reset()
                response = self.post(self.ADD, source_value="Y", mapped_value="x", intake_01_count=value)
                self.assert_refused_cleanly(response, message, before)

    def test_blank_counts_are_still_zero_and_ordinary_values_still_work(self):
        self.post(self.ADD, source_value="Z", mapped_value="x", intake_01_count="", intake_02_count="12")
        self.assertEqual(self.query("SELECT intake_01_count, intake_02_count FROM lookup_tables WHERE source_value='Z'"), [(0, 12)])

    def test_the_other_lookup_tables_are_covered_too(self):
        before = self.snapshot()
        self.tracker.reset()
        response = self.post("/admin/lookups/status/add", source_value="S", mapped_value="x", intake_01_count=str(2**63))
        self.assert_refused_cleanly(response, "Intake 01 is too large.", before)


HUGE_NUMBERS = [2**63, 2**63 + 1, 2**64 + 1, 10**30, 10**300, 10**1000]


class KpiMonthKeyOverflowRouteTests(OverflowRouteTestCase):
    """The hidden `month_key` field is user-controllable; its year used to be
    bound straight into SQLite."""

    PATH = "/admin/kpi-targets/__COMPANY__"

    def test_ordinary_month_keys_still_work(self):
        response = self.post(self.PATH, month_key="2026-08", target_value="100")
        self.assertIn("saved", response.get_data(as_text=True))
        self.assertEqual(self.query("SELECT year, month, target_value FROM kpi_targets"), [(2026, 8, 100)])

    def test_the_largest_storable_year_keeps_its_existing_behaviour(self):
        """The app has never bounded the year beyond 'is an integer'; that
        business rule is untouched, so the largest year SQLite can hold is
        still accepted - and stored without breaking any page."""
        response = self.post(self.PATH, month_key=f"{MAX_INT}-08", target_value="7")
        self.assertIn("saved", response.get_data(as_text=True))
        self.assertEqual(self.query("SELECT year, month, target_value FROM kpi_targets"), [(MAX_INT, 8, 7)])
        self.assertEqual(self.tracker.leaked(), [])
        for path in ("/admin", "/kpi", "/company-dashboard"):
            self.assertEqual(self.client.get(path).status_code, 200, path)

    def test_a_year_too_large_for_sqlite_is_just_an_invalid_month(self):
        for year in HUGE_NUMBERS:
            with self.subTest(year=str(year)[:12] + ("..." if len(str(year)) > 12 else "")):
                before = self.snapshot()
                self.tracker.reset()
                response = self.post_no_follow(self.PATH, month_key=f"{year}-08", target_value="5")
                self.assertEqual(response.status_code, 302, "a normal redirect, not a 500")
                self.assertTrue(response.headers["Location"].endswith("/admin"))
                self.assertEqual(self.tracker.opened, 0, "refused before the database was even opened")
                landing = self.client.get(response.headers["Location"])
                self.assertEqual(self.flashes(landing), [("error", "Invalid month.")])
                for word in self.INTERNAL_WORDS:
                    self.assertNotIn(word, landing.get_data(as_text=True))
                self.assertEqual(self.snapshot(), before, "nothing was written")
                self.assertEqual(self.tracker.leaked(), [])
                self.assert_database_is_writable_immediately()

    def test_the_refusal_is_identical_to_an_ordinary_invalid_month(self):
        ordinary = self.post_no_follow(self.PATH, month_key="garbage", target_value="5")
        for year in (2**63, 10**300):
            response = self.post_no_follow(self.PATH, month_key=f"{year}-08", target_value="5")
            self.assertEqual(response.status_code, ordinary.status_code)
            self.assertEqual(response.headers["Location"], ordinary.headers["Location"])

    def test_existing_month_validation_is_unchanged(self):
        for month_key in ("garbage", "2026-13", "2026-00", "2026", "-2026-08", "2026-8-1", "", "abc-08"):
            with self.subTest(month_key=month_key):
                before = self.snapshot()
                response = self.post_no_follow(self.PATH, month_key=month_key, target_value="5")
                self.assertEqual(response.status_code, 302)
                self.assertEqual(self.flashes(self.client.get(response.headers["Location"])), [("error", "Invalid month.")])
                self.assertEqual(self.snapshot(), before)

    def test_an_invalid_month_still_takes_precedence_over_an_invalid_value(self):
        response = self.post_no_follow(self.PATH, month_key=f"{10**30}-08", target_value="abc")
        self.assertEqual(self.flashes(self.client.get(response.headers["Location"])), [("error", "Invalid month.")])

    def test_a_huge_year_with_a_huge_value_is_still_a_clean_refusal(self):
        before = self.snapshot()
        response = self.post_no_follow(self.PATH, month_key=f"{10**30}-08", target_value=str(10**30))
        self.assertEqual(response.status_code, 302)
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(self.tracker.leaked(), [])


class LookupIdOverflowRouteTests(OverflowRouteTestCase):
    """Flask's <int:lookup_id> converter yields arbitrarily large integers.
    An id that SQLite cannot hold matches no row, so it is treated exactly
    like any other id that matches no row (which these routes have always
    answered with the normal success message and no change)."""

    # 2**63 - 1 is in range (just a nonexistent id); the rest are out of range.
    IDS = [MAX_INT, 2**63, 2**63 + 1, 2**64 + 1, 10**30, 10**300, 10**1000]
    NONEXISTENT_ID = 999999

    def edit(self, lookup_id, **overrides):
        data = dict(source_value="renamed", mapped_value="changed", intake_01_count="1", intake_02_count="2")
        data.update(overrides)
        return self.post_no_follow(f"/admin/lookups/sales_office/{lookup_id}/edit", **data)

    def delete(self, lookup_id):
        return self.post_no_follow(f"/admin/lookups/sales_office/{lookup_id}/delete")

    def label(self, n):
        return str(n)[:12] + ("..." if len(str(n)) > 12 else "")

    # ---- edit -------------------------------------------------------------
    def test_edit_with_any_unrepresentable_id_behaves_like_a_nonexistent_id(self):
        reference = self.edit(self.NONEXISTENT_ID)
        reference_flash = self.flashes(self.client.get(reference.headers["Location"]))
        self.assertEqual(reference_flash, [("success", "Mapping updated.")])
        for lookup_id in self.IDS:
            with self.subTest(lookup_id=self.label(lookup_id)):
                before = self.snapshot()
                self.tracker.reset()
                response = self.edit(lookup_id)
                self.assertEqual(response.status_code, 302, "no 500")
                self.assertEqual(response.headers["Location"], reference.headers["Location"])
                landing = self.client.get(response.headers["Location"])
                self.assertEqual(self.flashes(landing), reference_flash)
                for word in self.INTERNAL_WORDS:
                    self.assertNotIn(word, landing.get_data(as_text=True))
                self.assertEqual(self.snapshot(), before, "no database change")
                self.assertEqual(self.tracker.leaked(), [], "no leaked connection")
                self.assert_database_is_writable_immediately()

    def test_edit_validation_still_takes_precedence_exactly_as_for_a_nonexistent_id(self):
        cases = {
            "empty value": (dict(source_value=""), ("error", "Source / Lookup Value is required.")),
            "duplicate value": (dict(source_value="OX"), ("error", "'OX' already exists in this lookup table. Choose a different value.")),
            "bad count": (dict(intake_01_count="abc"), ("error", "Intake 01 must be a whole number.")),
            "overflowing count": (dict(intake_02_count=str(2**63)), ("error", "Intake 02 is too large.")),
        }
        for label, (override, expected) in cases.items():
            for lookup_id in (self.NONEXISTENT_ID, 2**63, 10**300):
                with self.subTest(case=label, lookup_id=self.label(lookup_id)):
                    before = self.snapshot()
                    response = self.edit(lookup_id, **override)
                    self.assertEqual(self.flashes(self.client.get(response.headers["Location"])), [expected])
                    self.assertEqual(self.snapshot(), before)

    def test_an_id_that_would_wrap_around_to_a_real_row_never_touches_it(self):
        """If a huge id were silently truncated to 64 bits it could hit the
        real row. These ids equal the real id modulo 2**64 / 2**63."""
        for lookup_id in (2**64 + self.office_id, 2**63 + self.office_id, 2**128 + self.office_id):
            with self.subTest(lookup_id=self.label(lookup_id)):
                before = self.snapshot()
                self.edit(lookup_id, source_value="HACKED")
                self.assertEqual(self.snapshot(), before)
                self.assertEqual(self.query("SELECT source_value FROM lookup_tables WHERE id=?", (self.office_id,)), [("OX",)])

    def test_edit_of_a_real_id_still_works(self):
        response = self.edit(self.office_id, source_value="OX2", mapped_value="Oxford2", intake_01_count="9", intake_02_count="8")
        self.assertEqual(self.flashes(self.client.get(response.headers["Location"])), [("success", "Mapping updated.")])
        self.assertEqual(self.query("SELECT source_value, mapped_value, intake_01_count, intake_02_count FROM lookup_tables WHERE id=?", (self.office_id,)), [("OX2", "Oxford2", 9, 8)])

    # ---- delete -----------------------------------------------------------
    def test_delete_with_any_unrepresentable_id_behaves_like_a_nonexistent_id(self):
        reference = self.delete(self.NONEXISTENT_ID)
        reference_flash = self.flashes(self.client.get(reference.headers["Location"]))
        self.assertEqual(reference_flash, [("success", "Mapping deleted.")])
        for lookup_id in self.IDS:
            with self.subTest(lookup_id=self.label(lookup_id)):
                before = self.snapshot()
                self.tracker.reset()
                response = self.delete(lookup_id)
                self.assertEqual(response.status_code, 302, "no 500")
                self.assertEqual(response.headers["Location"], reference.headers["Location"])
                landing = self.client.get(response.headers["Location"])
                self.assertEqual(self.flashes(landing), reference_flash)
                for word in self.INTERNAL_WORDS:
                    self.assertNotIn(word, landing.get_data(as_text=True))
                self.assertEqual(self.snapshot(), before, "no database change")
                self.assertEqual(self.tracker.leaked(), [], "no leaked connection")
                self.assert_database_is_writable_immediately()

    def test_a_delete_id_that_would_wrap_around_to_a_real_row_never_deletes_it(self):
        for lookup_id in (2**64 + self.office_id, 2**63 + self.office_id, 2**128 + self.office_id):
            with self.subTest(lookup_id=self.label(lookup_id)):
                before = self.snapshot()
                self.delete(lookup_id)
                self.assertEqual(self.snapshot(), before)
                self.assertEqual(self.query("SELECT COUNT(*) FROM lookup_tables WHERE id=?", (self.office_id,)), [(1,)])

    def test_delete_of_a_real_id_still_works(self):
        response = self.delete(self.office_id)
        self.assertEqual(self.flashes(self.client.get(response.headers["Location"])), [("success", "Mapping deleted.")])
        self.assertEqual(self.query("SELECT COUNT(*) FROM lookup_tables WHERE id=?", (self.office_id,)), [(0,)])

    # ---- helpers directly --------------------------------------------------
    def test_the_helpers_never_raise_for_any_id(self):
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.row_factory = sqlite3.Row
        try:
            for lookup_id in self.IDS + [0, -1, -(2**63), -(2**63) - 1, -(10**30)]:
                lookups.update_lookup(conn, lookup_id, "sales_office", "someone", "x")
                lookups.delete_lookup(conn, lookup_id, "sales_office")
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM lookup_tables WHERE id=?", (self.office_id,)).fetchone()[0], 1)
        finally:
            conn.close()


class NoHttp500Tests(OverflowRouteTestCase):
    def test_no_overflow_input_ever_produces_a_500(self):
        calls = [
            ("/admin/kpi-targets/__COMPANY__", dict(month_key="2026-08", target_value=str(v))) for v in OVERFLOWING
        ] + [
            (f"/admin/lookups/sales_office/{self.office_id}/edit", dict(source_value="OX", mapped_value="Oxford", intake_01_count=str(v), intake_02_count=str(v))) for v in OVERFLOWING
        ] + [
            ("/admin/lookups/sales_office/add", dict(source_value=f"A{i}", mapped_value="x", intake_01_count=str(v), intake_02_count=str(v))) for i, v in enumerate(OVERFLOWING)
        ] + [
            ("/admin/kpi-targets/__COMPANY__", dict(month_key=f"{v}-08", target_value="5")) for v in HUGE_NUMBERS
        ] + [
            (f"/admin/lookups/sales_office/{v}/edit", dict(source_value="OX", mapped_value="Oxford")) for v in HUGE_NUMBERS
        ] + [
            (f"/admin/lookups/sales_office/{v}/delete", dict()) for v in HUGE_NUMBERS
        ]
        for path, data in calls:
            with self.subTest(path=path):
                response = self.client.post(path, data={"csrf_token": self.token, **data})
                self.assertEqual(response.status_code, 302)
        self.assertEqual(self.tracker.leaked(), [])


if __name__ == "__main__":
    unittest.main()
