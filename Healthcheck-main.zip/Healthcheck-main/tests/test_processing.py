"""Tests for processing.py, including regression coverage for two things
found during a stale-data audit:

1. parse_date() silently dropped genuine Excel date-typed cells (openpyxl
   returns those as real datetime/date objects, not DD/MM/YYYY text) -
   these ended up as None even though the source data was valid.
2. A second successful upload must completely replace the first - no
   record from a previous upload may survive into the new active dataset.
"""
import shutil
import sqlite3
import tempfile
import unittest
from datetime import date, datetime
from pathlib import Path
from unittest import mock

import openpyxl

import db
from db import ACTIVE_DATASET_RETENTION_LIMIT, get_active_dataset_row, load_active_dataset
from healthcheck import run_healthcheck
from processing import (
    COLUMNS,
    DATE_COLUMNS,
    REQUIRED_IMPORT_COLUMNS,
    _load_lookup_dict,
    parse_date,
    build_export_workbook,
    parse_stage_length_days,
    process_workbook,
    save_active_dataset,
    seed_lookup_tables_if_empty,
    split_lead_source,
)


class ParseDateTests(unittest.TestCase):
    def test_dd_mm_yyyy_text_string(self):
        self.assertEqual(parse_date("13/08/2026"), "2026-08-13")

    def test_native_datetime_object_is_parsed_correctly(self):
        # This is the exact shape openpyxl returns for a cell Excel
        # formats as a date - the bug this regression test protects.
        self.assertEqual(parse_date(datetime(2026, 8, 13, 0, 0)), "2026-08-13")

    def test_native_date_object_is_parsed_correctly(self):
        self.assertEqual(parse_date(date(2026, 8, 13)), "2026-08-13")

    def test_datetime_with_nonzero_time_component_still_parses(self):
        self.assertEqual(parse_date(datetime(2026, 8, 13, 14, 30, 45)), "2026-08-13")

    def test_none_is_none(self):
        self.assertIsNone(parse_date(None))

    def test_blank_string_is_none(self):
        self.assertIsNone(parse_date(""))

    def test_whitespace_only_string_is_none(self):
        self.assertIsNone(parse_date("   "))

    def test_malformed_string_is_none(self):
        self.assertIsNone(parse_date("not-a-date"))

    def test_too_short_string_is_none(self):
        self.assertIsNone(parse_date("1/1/26"))

    def test_impossible_calendar_date_is_none(self):
        self.assertIsNone(parse_date("31/02/2026"))

    def test_pre_1900_excel_quirk_still_applies_to_text_input(self):
        # Unchanged pre-existing behaviour: a sliced year of 0-1899 from a
        # text cell is bumped by +1900, mirroring Excel's own DATE()
        # behaviour. Only text-string inputs go through this path.
        self.assertEqual(parse_date("15/06/0026"), "1926-06-15")


class SplitLeadSourceTests(unittest.TestCase):
    def test_basic_split(self):
        self.assertEqual(split_lead_source("Inbound Call / Website"), ("Inbound Call", "Website"))

    def test_no_slash_has_blank_sub_source(self):
        self.assertEqual(split_lead_source("Website"), ("Website", ""))

    def test_blank_value(self):
        self.assertEqual(split_lead_source(""), ("", ""))
        self.assertEqual(split_lead_source(None), ("", ""))

    def test_sub_source_is_title_cased(self):
        self.assertEqual(split_lead_source("Staff Referral / kesh boodhoo"), ("Staff Referral", "Kesh Boodhoo"))

    def test_jon_daniels_tt_variants_are_normalised(self):
        for raw in ("Staff Referral / Jon Daniels TT", "Staff Referral / jon daniels tt",
                    "Staff Referral / Jon Daniels Tt", "Staff Referral / JON DANIELS TT"):
            self.assertEqual(split_lead_source(raw), ("Staff Referral", "Jon Daniels TT"), raw)

    def test_jon_daniels_without_tt_is_also_normalised(self):
        for raw in ("Staff Referral / Jon Daniels", "Staff Referral / jon daniels"):
            self.assertEqual(split_lead_source(raw), ("Staff Referral", "Jon Daniels TT"), raw)

    def test_a_different_jon_is_not_normalised(self):
        self.assertEqual(split_lead_source("Staff Referral / Jon Smith"), ("Staff Referral", "Jon Smith"))

    def test_inbound_call_with_a_staff_name_sub_source_becomes_telephone(self):
        for name in ("Adam Haddadene", "Claudio Rodrigues", "Hannah West", "Jalloh Mohamed",
                     "Mel Imonhimi", "Mustapha Falola", "Nahidul Kamalee", "Nicoleta Dumitrache",
                     "Oliver Hravodsky", "Raneen Ali", "Raymond Odetah", "Solyman Meer",
                     "Tanaka Chitsenga", "Tyrone Roberts", "Yuliia Bashkirova"):
            self.assertEqual(split_lead_source(f"Inbound Call / {name}"), ("Inbound Call", "Telephone"), name)

    def test_inbound_call_staff_name_match_is_case_insensitive(self):
        self.assertEqual(split_lead_source("Inbound Call / mel imonhimi"), ("Inbound Call", "Telephone"))
        # Source casing is preserved verbatim (only stripped, never
        # rewritten) - only the staff-name match itself is
        # case-insensitive.
        self.assertEqual(split_lead_source("inbound call / Mel Imonhimi"), ("inbound call", "Telephone"))

    def test_the_same_staff_name_is_untouched_for_a_different_lead_source(self):
        self.assertEqual(
            split_lead_source("Staff Referral / Mel Imonhimi"), ("Staff Referral", "Mel Imonhimi")
        )

    def test_inbound_call_with_a_non_staff_sub_source_is_untouched(self):
        self.assertEqual(split_lead_source("Inbound Call / Website"), ("Inbound Call", "Website"))


class ParseStageLengthDaysTests(unittest.TestCase):
    """Shared by healthcheck.py's New App/QA "stuck" rules and kpi.py's
    Pipeline Backlog average-days figures - defined here since Stage
    Length is this module's optional column."""

    def test_parses_plural_days(self):
        self.assertEqual(parse_stage_length_days("4 Days ago"), 4)

    def test_parses_singular_day(self):
        self.assertEqual(parse_stage_length_days("0 Day ago"), 0)

    def test_case_insensitive(self):
        self.assertEqual(parse_stage_length_days("11 DAYS AGO"), 11)

    def test_whitespace_is_trimmed(self):
        self.assertEqual(parse_stage_length_days("  32 Days ago  "), 32)

    def test_blank_is_none(self):
        self.assertIsNone(parse_stage_length_days(""))
        self.assertIsNone(parse_stage_length_days(None))

    def test_unrecognised_format_is_none_not_a_crash(self):
        self.assertIsNone(parse_stage_length_days("some other text"))
        self.assertIsNone(parse_stage_length_days("N/A"))


class _IsolatedDatasetTestCase(unittest.TestCase):
    """Base class wiring up a throwaway SQLite DB and temp directory for
    .xlsx fixtures - never touches the real application database or
    uploads folder."""

    def setUp(self):
        self.tmp_dir = Path(tempfile.mkdtemp(prefix="gsp_processing_test_"))
        self.conn = sqlite3.connect(":memory:")
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(
            """
            CREATE TABLE active_dataset (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                original_filename TEXT NOT NULL,
                stored_filename TEXT NOT NULL,
                uploaded_at TEXT NOT NULL,
                row_count INTEGER,
                data_json TEXT
            );
            CREATE TABLE active_leads_dataset (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                original_filename TEXT NOT NULL,
                stored_filename TEXT NOT NULL,
                uploaded_at TEXT NOT NULL,
                row_count INTEGER,
                columns_json TEXT,
                data_json TEXT
            );
            CREATE TABLE lookup_tables (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                table_name TEXT NOT NULL,
                source_value TEXT NOT NULL,
                mapped_value TEXT,
                created_at TEXT NOT NULL
            );
            CREATE TABLE unmapped_lookup_values (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                table_name TEXT NOT NULL,
                value TEXT NOT NULL,
                first_seen_at TEXT NOT NULL,
                resolved INTEGER DEFAULT 0,
                occurrence_count INTEGER DEFAULT 1
            );
            """
        )
        self.conn.commit()

    def tearDown(self):
        self.conn.close()
        shutil.rmtree(self.tmp_dir, ignore_errors=True)

    def _make_workbook(self, filename, student_rows):
        path = self.tmp_dir / filename
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.append(REQUIRED_IMPORT_COLUMNS)
        for sr in student_rows:
            ws.append([sr.get(col, "") for col in REQUIRED_IMPORT_COLUMNS])
        wb.save(path)
        return path

    def _base_row(self, student_code, name="Test Student", **overrides):
        row = {
            "Student Code": student_code,
            "Student Name": name,
            "Intake": "2026",
            "University Name": "Test University",
            "Course Name": "Test Course",
            "Application Status": "",
            "Lead Source": "",
            "Counsellor": "",
            "Admission Officer": "",
            "QA Officer": "",
            "Other Contact": "",
            "Applied On": "01/07/2026",
            "Document Approved Date": "",
            "QA Signed Off": "",
            "Uni Submission Done": "",
            "Submission Complete": "",
            "Application ID": student_code,
            "Interview Booked Date/Time": "",
        }
        row.update(overrides)
        return row

    def _upload(self, path, original_name):
        now_iso = datetime.utcnow().isoformat(timespec="seconds")
        rows, unmapped = process_workbook(path, self.conn, now_iso)
        save_active_dataset(self.conn, original_name, path.name, now_iso, rows, self.tmp_dir)
        return rows, unmapped


class ProcessWorkbookNativeDateCellTests(_IsolatedDatasetTestCase):
    """End-to-end regression: a genuine Excel date-typed cell (not text)
    must survive process_workbook, not be silently dropped to None."""

    def test_native_excel_date_cell_is_not_dropped(self):
        path = self.tmp_dir / "native_date.xlsx"
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.append(REQUIRED_IMPORT_COLUMNS)
        row_values = self._base_row("PES-DATE-001")
        ws.append([row_values.get(col, "") for col in REQUIRED_IMPORT_COLUMNS])

        uni_col_idx = REQUIRED_IMPORT_COLUMNS.index("Uni Submission Done") + 1
        cell = ws.cell(row=2, column=uni_col_idx)
        cell.value = datetime(2026, 8, 13, 0, 0)  # genuine Excel date type, not text
        wb.save(path)

        rows, _ = process_workbook(path, self.conn, datetime.utcnow().isoformat())
        student = next(r for r in rows if r["Student Code"] == "PES-DATE-001")
        self.assertEqual(student["Submitted To Uni"], "2026-08-13")


class StageLengthOptionalColumnTests(_IsolatedDatasetTestCase):
    """Stage Length backs the New App/QA "stuck" Healthcheck rules but is
    not in REQUIRED_IMPORT_COLUMNS - a workbook without it must still
    upload successfully, and one with it must carry the value through."""

    def test_workbook_without_stage_length_column_still_uploads(self):
        # _make_workbook only ever writes REQUIRED_IMPORT_COLUMNS - no
        # Stage Length column exists in this workbook at all.
        path = self._make_workbook("no_stage_length.xlsx", [self._base_row("PES-NOSTAGE-001")])
        rows, _ = self._upload(path, "no_stage_length.xlsx")
        student = next(r for r in rows if r["Student Code"] == "PES-NOSTAGE-001")
        self.assertEqual(student["Stage Length"], "")

    def test_workbook_with_stage_length_column_carries_the_value_through(self):
        path = self.tmp_dir / "with_stage_length.xlsx"
        wb = openpyxl.Workbook()
        ws = wb.active
        columns = REQUIRED_IMPORT_COLUMNS + ["Stage Length"]
        ws.append(columns)
        row_values = self._base_row("PES-STAGE-001")
        row_values["Stage Length"] = "4 Days ago"
        ws.append([row_values.get(col, "") for col in columns])
        wb.save(path)

        rows, _ = self._upload(path, "with_stage_length.xlsx")
        student = next(r for r in rows if r["Student Code"] == "PES-STAGE-001")
        self.assertEqual(student["Stage Length"], "4 Days ago")


class LostReasonAndDateFieldsInCurrentDataTests(_IsolatedDatasetTestCase):
    """Lost Reason, Lost Sub Reason, Enrolled Date, and Offer Accepted Date
    are optional (a workbook missing them still uploads fine) but, unlike
    Stage Length, they ARE in COLUMNS - shown in Current Data and the
    Download Spreadsheet export."""

    def test_all_four_fields_are_in_columns(self):
        for column in ("Lost Reason", "Lost Sub Reason", "Enrolled Date", "Offer Accepted Date"):
            self.assertIn(column, COLUMNS)

    def test_the_two_date_fields_are_in_date_columns(self):
        self.assertIn("Enrolled Date", DATE_COLUMNS)
        self.assertIn("Offer Accepted Date", DATE_COLUMNS)
        self.assertNotIn("Lost Reason", DATE_COLUMNS)
        self.assertNotIn("Lost Sub Reason", DATE_COLUMNS)

    def test_workbook_without_any_of_the_four_columns_still_uploads(self):
        path = self._make_workbook("no_extra_cols.xlsx", [self._base_row("PES-NOEXTRA-001")])
        rows, _ = self._upload(path, "no_extra_cols.xlsx")
        student = next(r for r in rows if r["Student Code"] == "PES-NOEXTRA-001")
        self.assertEqual(student["Lost Reason"], "")
        self.assertEqual(student["Lost Sub Reason"], "")
        self.assertIsNone(student["Enrolled Date"])
        self.assertIsNone(student["Offer Accepted Date"])

    def test_workbook_with_all_four_columns_carries_the_values_through(self):
        path = self.tmp_dir / "with_extra_cols.xlsx"
        wb = openpyxl.Workbook()
        ws = wb.active
        extra_cols = ["Lost Reason", "Lost Sub Reason", "Enrolment Confirmed Date", "Offer Accepted Date"]
        columns = REQUIRED_IMPORT_COLUMNS + extra_cols
        ws.append(columns)
        row_values = self._base_row("PES-EXTRA-001")
        row_values["Lost Reason"] = "StudentWithdrew"
        row_values["Lost Sub Reason"] = "ChangedMind"
        row_values["Enrolment Confirmed Date"] = "15/09/2026"
        row_values["Offer Accepted Date"] = "10/09/2026"
        ws.append([row_values.get(col, "") for col in columns])
        wb.save(path)

        rows, _ = self._upload(path, "with_extra_cols.xlsx")
        student = next(r for r in rows if r["Student Code"] == "PES-EXTRA-001")
        self.assertEqual(student["Lost Reason"], "StudentWithdrew")
        self.assertEqual(student["Lost Sub Reason"], "ChangedMind")
        self.assertEqual(student["Enrolled Date"], "2026-09-15")
        self.assertEqual(student["Offer Accepted Date"], "2026-09-10")


class LocationAndEmailOptionalColumnTests(_IsolatedDatasetTestCase):
    """Location and Email are optional (read from the raw "Location" and
    "Email ID" columns - a workbook missing either still uploads fine) and
    ARE in COLUMNS, same convention as Lost Reason/Enrolled Date/etc."""

    def test_both_fields_are_in_columns(self):
        self.assertIn("Location", COLUMNS)
        self.assertIn("Email", COLUMNS)

    def test_neither_field_is_a_date_column(self):
        self.assertNotIn("Location", DATE_COLUMNS)
        self.assertNotIn("Email", DATE_COLUMNS)

    def test_workbook_without_either_column_still_uploads(self):
        path = self._make_workbook("no_location_email.xlsx", [self._base_row("PES-NOLOCEMAIL-001")])
        rows, _ = self._upload(path, "no_location_email.xlsx")
        student = next(r for r in rows if r["Student Code"] == "PES-NOLOCEMAIL-001")
        self.assertEqual(student["Location"], "")
        self.assertEqual(student["Email"], "")

    def test_workbook_with_both_columns_carries_the_values_through(self):
        path = self.tmp_dir / "with_location_email.xlsx"
        wb = openpyxl.Workbook()
        ws = wb.active
        columns = REQUIRED_IMPORT_COLUMNS + ["Location", "Email ID"]
        ws.append(columns)
        row_values = self._base_row("PES-LOCEMAIL-001")
        row_values["Location"] = "Oxford"
        row_values["Email ID"] = "student@example.com"
        ws.append([row_values.get(col, "") for col in columns])
        wb.save(path)

        rows, _ = self._upload(path, "with_location_email.xlsx")
        student = next(r for r in rows if r["Student Code"] == "PES-LOCEMAIL-001")
        self.assertEqual(student["Location"], "Oxford")
        self.assertEqual(student["Email"], "student@example.com")


class BuildExportWorkbookTests(unittest.TestCase):
    def test_export_includes_the_new_columns_with_date_formatting(self):
        rows = [
            {
                "Student Code": "PES-EXPORT-001",
                "Lost Reason": "StudentWithdrew",
                "Lost Sub Reason": "ChangedMind",
                "Enrolled Date": "2026-09-15",
                "Offer Accepted Date": "2026-09-10",
            }
        ]
        buffer = build_export_workbook(rows)
        wb = openpyxl.load_workbook(buffer)
        ws = wb.active
        header = [cell.value for cell in ws[1]]
        self.assertIn("Lost Reason", header)
        self.assertIn("Lost Sub Reason", header)
        self.assertIn("Enrolled Date", header)
        self.assertIn("Offer Accepted Date", header)

        enrolled_col = header.index("Enrolled Date") + 1
        enrolled_cell = ws.cell(row=2, column=enrolled_col)
        # openpyxl reads a date-formatted cell back as a datetime, not a
        # date, on reopen - compare the calendar date itself.
        self.assertEqual(enrolled_cell.value.date(), date(2026, 9, 15))
        self.assertEqual(enrolled_cell.number_format, "DD/MM/YYYY")

    def test_formula_looking_student_name_is_not_stored_as_a_formula(self):
        # Confirms build_export_workbook() is actually wired to
        # excel_export_helpers.safe_append_row() (Finding 11).
        rows = [{"Student Code": "PES-001", "Student Name": "=SUM(1,1)"}]
        buffer = build_export_workbook(rows)
        wb = openpyxl.load_workbook(buffer)
        ws = wb.active
        header = [cell.value for cell in ws[1]]
        name_col = header.index("Student Name") + 1
        cell = ws.cell(row=2, column=name_col)
        self.assertEqual(cell.value, "=SUM(1,1)")
        self.assertNotEqual(cell.data_type, "f")


class ActiveDatasetReplacementTests(_IsolatedDatasetTestCase):
    """Protects that a successful upload is a full replacement - no record
    from a previous upload can survive into the new active dataset."""

    def test_second_upload_completely_replaces_first(self):
        file_a = self._make_workbook("file_a.xlsx", [
            self._base_row("TEST-OLD-001"),
            self._base_row("TEST-OLD-002"),
        ])
        self._upload(file_a, "file_a.xlsx")
        _, rows_after_a = load_active_dataset(self.conn)
        self.assertEqual(
            sorted(r["Student Code"] for r in rows_after_a), ["TEST-OLD-001", "TEST-OLD-002"]
        )

        file_b = self._make_workbook("file_b.xlsx", [self._base_row("TEST-NEW-001")])
        self._upload(file_b, "file_b.xlsx")
        _, rows_after_b = load_active_dataset(self.conn)

        codes_after_b = {r["Student Code"] for r in rows_after_b}
        self.assertEqual(codes_after_b, {"TEST-NEW-001"})
        self.assertNotIn("TEST-OLD-001", codes_after_b)
        self.assertNotIn("TEST-OLD-002", codes_after_b)

    def test_healthcheck_does_not_evaluate_records_from_a_replaced_upload(self):
        file_a = self._make_workbook("file_a.xlsx", [
            self._base_row("TEST-OLD-001", **{
                "Submission Complete": "Approved", "Uni Submission Done": "",
            }),
        ])
        self._upload(file_a, "file_a.xlsx")

        file_b = self._make_workbook("file_b.xlsx", [self._base_row("TEST-NEW-001")])
        self._upload(file_b, "file_b.xlsx")

        _, current_rows = load_active_dataset(self.conn)
        issues = run_healthcheck(current_rows)
        self.assertFalse(any(i["student_code"] == "TEST-OLD-001" for i in issues))

    def test_correcting_a_record_and_reuploading_clears_its_healthcheck_issue(self):
        broken = self._make_workbook("broken.xlsx", [
            self._base_row("TEST-FIX-001", **{
                "Submission Complete": "Approved", "Uni Submission Done": "",
            }),
        ])
        self._upload(broken, "broken.xlsx")
        _, rows_broken = load_active_dataset(self.conn)
        issues_broken = run_healthcheck(rows_broken)
        self.assertTrue(any(
            i["student_code"] == "TEST-FIX-001" and i["rule_id"] == "approved_missing_submitted_to_uni"
            for i in issues_broken
        ))

        corrected = self._make_workbook("corrected.xlsx", [
            self._base_row("TEST-FIX-001", **{
                "Submission Complete": "Approved", "Uni Submission Done": "15/08/2026",
            }),
        ])
        self._upload(corrected, "corrected.xlsx")
        _, rows_corrected = load_active_dataset(self.conn)
        issues_corrected = run_healthcheck(rows_corrected)
        self.assertFalse(any(
            i["student_code"] == "TEST-FIX-001" and i["rule_id"] == "approved_missing_submitted_to_uni"
            for i in issues_corrected
        ))

    def test_reprocessing_the_same_source_file_does_not_resurrect_older_uploads(self):
        file_a = self._make_workbook("file_a.xlsx", [self._base_row("TEST-OLD-001")])
        self._upload(file_a, "file_a.xlsx")

        file_b = self._make_workbook("file_b.xlsx", [self._base_row("TEST-NEW-001")])
        self._upload(file_b, "file_b.xlsx")

        # Simulates the reprocess route: re-run process_workbook against the
        # SAME stored file backing the current active dataset.
        current_dataset = get_active_dataset_row(self.conn)
        self.assertEqual(current_dataset["original_filename"], "file_b.xlsx")
        reprocess_path = self.tmp_dir / current_dataset["stored_filename"]
        self._upload(reprocess_path, current_dataset["original_filename"])

        _, rows_final = load_active_dataset(self.conn)
        codes_final = {r["Student Code"] for r in rows_final}
        self.assertEqual(codes_final, {"TEST-NEW-001"})


class SaveActiveDatasetRetentionTests(_IsolatedDatasetTestCase):
    """save_active_dataset()'s automatic pruning (Finding 6) exercised
    through the real upload path - prune_active_dataset_table() itself is
    covered directly in test_db.py; these confirm it's correctly wired in
    and that the normal upload-reading behaviour (load_active_dataset
    still returning the newest snapshot) is unaffected."""

    def _row_count(self):
        return self.conn.execute("SELECT COUNT(*) AS c FROM active_dataset").fetchone()["c"]

    def test_table_never_exceeds_the_retention_limit_across_repeated_uploads(self):
        for i in range(ACTIVE_DATASET_RETENTION_LIMIT + 3):
            path = self._make_workbook(f"file_{i}.xlsx", [self._base_row(f"TEST-{i:03d}")])
            self._upload(path, f"file_{i}.xlsx")
            self.assertLessEqual(self._row_count(), ACTIVE_DATASET_RETENTION_LIMIT)

    def test_current_dataset_loading_still_returns_the_newest_snapshot(self):
        for i in range(ACTIVE_DATASET_RETENTION_LIMIT + 3):
            path = self._make_workbook(f"file_{i}.xlsx", [self._base_row(f"TEST-{i:03d}")])
            self._upload(path, f"file_{i}.xlsx")

        dataset, rows = load_active_dataset(self.conn)
        self.assertEqual(dataset["original_filename"], f"file_{ACTIVE_DATASET_RETENTION_LIMIT + 2}.xlsx")
        self.assertEqual([r["Student Code"] for r in rows], [f"TEST-{ACTIVE_DATASET_RETENTION_LIMIT + 2:03d}"])

    def test_pruning_failure_rolls_back_the_insert_too(self):
        file_a = self._make_workbook("file_a.xlsx", [self._base_row("TEST-A")])
        self._upload(file_a, "file_a.xlsx")
        self.assertEqual(self._row_count(), 1)

        file_b = self._make_workbook("file_b.xlsx", [self._base_row("TEST-B")])
        rows, _ = process_workbook(file_b, self.conn, "2026-08-02T10:00:00")
        with mock.patch("processing.prune_active_dataset_table", side_effect=RuntimeError("boom")):
            with self.assertRaises(RuntimeError):
                save_active_dataset(self.conn, "file_b.xlsx", file_b.name, "2026-08-02T10:00:00", rows, self.tmp_dir)

        # The failed insert must not have been committed - the table is
        # exactly as it was before the failed save, not left with a
        # dangling unpruned row.
        self.assertEqual(self._row_count(), 1)
        dataset, _ = load_active_dataset(self.conn)
        self.assertEqual(dataset["original_filename"], "file_a.xlsx")


class SaveActiveDatasetFileCleanupTests(_IsolatedDatasetTestCase):
    """Finding 7's filesystem cleanup (db.cleanup_orphaned_uploads()),
    exercised through the real save_active_dataset() path with filenames
    that actually match the managed-upload naming pattern
    (\\d{14}_...xlsx) - cleanup_orphaned_uploads() itself is covered
    directly in test_db.py; these confirm it's correctly wired into the
    real upload path and that a cleanup problem can never surface as a
    failed upload."""

    def _managed_name(self, i, suffix="test"):
        return f"202609{i:02d}090000_{suffix}.xlsx"

    def test_repeated_uploads_keep_filesystem_aligned_with_retained_snapshots(self):
        # This is about which files are orphans, not how old they are (the
        # minimum-age guard is covered in test_upload_cleanup_age.py), and the
        # files here are all created moments ago.
        patcher = mock.patch.object(db, "ORPHAN_MIN_AGE_SECONDS", 0)
        patcher.start()
        self.addCleanup(patcher.stop)
        for i in range(1, ACTIVE_DATASET_RETENTION_LIMIT + 4):
            name = self._managed_name(i)
            path = self._make_workbook(name, [self._base_row(f"TEST-{i:03d}")])
            self._upload(path, name)

        on_disk = {p.name for p in self.tmp_dir.iterdir()}
        retained_filenames = {
            row["stored_filename"] for row in self.conn.execute("SELECT stored_filename FROM active_dataset")
        }
        self.assertEqual(len(retained_filenames), ACTIVE_DATASET_RETENTION_LIMIT)
        # Every file still on disk that matches the managed-upload naming
        # pattern must be exactly the retained set - nothing orphaned left
        # behind, nothing retained missing.
        managed_on_disk = {n for n in on_disk if n.startswith("202609")}
        self.assertEqual(managed_on_disk, retained_filenames)

    def test_reprocess_still_finds_the_current_source_file_after_cleanup(self):
        for i in range(1, ACTIVE_DATASET_RETENTION_LIMIT + 4):
            name = self._managed_name(i)
            path = self._make_workbook(name, [self._base_row(f"TEST-{i:03d}")])
            self._upload(path, name)

        # Simulates exactly what app.py's reprocess() route does: look up
        # the current row's stored_filename and confirm the file is still
        # there to be re-parsed.
        current = get_active_dataset_row(self.conn)
        reprocess_path = self.tmp_dir / current["stored_filename"]
        self.assertTrue(reprocess_path.exists())
        self.assertTrue(reprocess_path.is_file())

    def test_cleanup_failure_does_not_undo_a_successful_database_save_or_raise(self):
        # An orphan from a previous save, so there's something for the
        # (mocked, failing) cleanup pass to have tried to act on.
        orphan_name = self._managed_name(0, suffix="orphan")
        (self.tmp_dir / orphan_name).write_text("")

        name = self._managed_name(1)
        path = self._make_workbook(name, [self._base_row("TEST-001")])
        rows, _ = process_workbook(path, self.conn, "2026-09-01T09:00:00")

        with mock.patch("processing.cleanup_orphaned_uploads", side_effect=RuntimeError("disk error")):
            # Must not raise - a cleanup failure must never look like a
            # failed upload to the caller.
            save_active_dataset(self.conn, name, path.name, "2026-09-01T09:00:00", rows, self.tmp_dir)

        # The database save itself must still have gone through untouched.
        dataset, loaded_rows = load_active_dataset(self.conn)
        self.assertEqual(dataset["original_filename"], name)
        self.assertEqual([r["Student Code"] for r in loaded_rows], ["TEST-001"])

        # The orphan is still there too, since the (mocked) cleanup never
        # actually ran - nothing about this failure silently deleted it
        # some other way.
        self.assertTrue((self.tmp_dir / orphan_name).exists())


class SeedLookupTablesCaseDuplicateTests(_IsolatedDatasetTestCase):
    """Regression: add_lookup()/update_lookup() both reject a source_value
    that already exists case-insensitively for a table, but seeding (which
    reads straight from the source workbook's own Lookups sheet) used to
    skip that check entirely - two rows differing only by case could both
    get inserted, and _load_lookup_dict() would then silently pick
    whichever one SQLite happened to return last."""

    def _make_lookups_workbook(self, filename, status_pairs):
        path = self.tmp_dir / filename
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.append(REQUIRED_IMPORT_COLUMNS)
        lookups = wb.create_sheet("Lookups")
        for i, (key, value) in enumerate(status_pairs, start=2):
            lookups[f"A{i}"] = key
            lookups[f"B{i}"] = value
        wb.save(path)
        return path

    def test_case_duplicate_rows_in_the_source_sheet_are_not_both_seeded(self):
        path = self._make_lookups_workbook(
            "lookups.xlsx",
            [("John", "EG"), ("john", "UK")],
        )
        workbook = openpyxl.load_workbook(path)
        now_iso = datetime.utcnow().isoformat(timespec="seconds")

        seed_lookup_tables_if_empty(self.conn, workbook, now_iso)

        count = self.conn.execute(
            "SELECT COUNT(*) AS c FROM lookup_tables WHERE table_name = 'status' AND lower(source_value) = 'john'"
        ).fetchone()["c"]
        self.assertEqual(count, 1)

    def test_first_occurrence_in_the_sheet_wins(self):
        path = self._make_lookups_workbook(
            "lookups.xlsx",
            [("John", "EG"), ("john", "UK")],
        )
        workbook = openpyxl.load_workbook(path)
        now_iso = datetime.utcnow().isoformat(timespec="seconds")

        seed_lookup_tables_if_empty(self.conn, workbook, now_iso)

        lookup = _load_lookup_dict(self.conn, "status")
        self.assertEqual(lookup["john"], "EG")

    def test_distinct_keys_are_unaffected(self):
        path = self._make_lookups_workbook(
            "lookups.xlsx",
            [("John", "EG"), ("Jane", "UK")],
        )
        workbook = openpyxl.load_workbook(path)
        now_iso = datetime.utcnow().isoformat(timespec="seconds")

        seed_lookup_tables_if_empty(self.conn, workbook, now_iso)

        lookup = _load_lookup_dict(self.conn, "status")
        self.assertEqual(lookup["john"], "EG")
        self.assertEqual(lookup["jane"], "UK")


class UnmappedConsultantDefaultsToOtherTests(_IsolatedDatasetTestCase):
    """A Consultant not in the sales_office Lookup table still counts
    toward the Consultant Pipeline, under a generic "Other" Sales Office,
    rather than being silently excluded the way a blank group would be
    (build_pipeline_report() drops any row whose group is blank)."""

    def _seed_sales_office_mapping(self, consultant, sales_office):
        self.conn.execute(
            "INSERT INTO lookup_tables (table_name, source_value, mapped_value, created_at) "
            "VALUES ('sales_office', ?, ?, ?)",
            (consultant, sales_office, datetime.utcnow().isoformat()),
        )
        self.conn.commit()

    def test_unmapped_consultant_gets_sales_office_other(self):
        path = self._make_workbook("unmapped.xlsx", [self._base_row("PES1", Counsellor="Newperson")])
        rows, _ = self._upload(path, "unmapped.xlsx")
        self.assertEqual(rows[0]["Sales Office"], "Other")

    def test_unmapped_consultant_is_still_recorded_for_admin_review(self):
        path = self._make_workbook("unmapped.xlsx", [self._base_row("PES1", Counsellor="Newperson")])
        self._upload(path, "unmapped.xlsx")
        recorded = self.conn.execute(
            "SELECT value FROM unmapped_lookup_values WHERE table_name = 'sales_office'"
        ).fetchall()
        self.assertEqual([r["value"] for r in recorded], ["Newperson"])

    def test_a_mapped_consultant_keeps_their_real_sales_office_not_other(self):
        self._seed_sales_office_mapping("Raneen", "OXF")
        path = self._make_workbook("mapped.xlsx", [self._base_row("PES1", Counsellor="Raneen Ali")])
        rows, _ = self._upload(path, "mapped.xlsx")
        self.assertEqual(rows[0]["Sales Office"], "OXF")

    def test_a_blank_consultant_stays_blank_not_other(self):
        # No Consultant at all is a different case to "a named Consultant
        # we haven't mapped yet" - there's nothing to attribute, so it
        # stays excluded rather than being folded into "Other".
        path = self._make_workbook("blank.xlsx", [self._base_row("PES1", Counsellor="")])
        rows, _ = self._upload(path, "blank.xlsx")
        self.assertEqual(rows[0]["Sales Office"], "")


if __name__ == "__main__":
    unittest.main()
