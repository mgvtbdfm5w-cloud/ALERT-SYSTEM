"""Tests for the one-time data restore (data_restore.py + /admin/restore)."""

import io
import os
import sqlite3
import tarfile
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from tests.flask_test_support import IsolatedAppTestCase, extract_token, app_module, db_module  # noqa: F401

import data_restore
from data_restore import RestoreError, restore_bundle

WORKBOOK = "20261006070039_Application_List.xlsx"


def _make_db(path, marker="restored"):
    conn = sqlite3.connect(path)
    conn.execute("CREATE TABLE marker (value TEXT)")
    conn.execute("INSERT INTO marker VALUES (?)", (marker,))
    conn.commit()
    conn.close()


def _bundle(members):
    """members: list of (name, bytes) or (name, tarinfo-modifier)."""
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        for name, data in members:
            info = tarfile.TarInfo(name)
            if isinstance(data, bytes):
                info.size = len(data)
                tar.addfile(info, io.BytesIO(data))
            else:
                data(info)
                tar.addfile(info)
    buf.seek(0)
    return buf


def _db_bytes(marker="restored"):
    with tempfile.TemporaryDirectory() as d:
        p = Path(d) / "x.db"
        _make_db(p, marker)
        return p.read_bytes()


class RestoreBundleUnitTests(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())
        self.db = self.dir / "data" / "app.db"
        self.uploads = self.dir / "uploads"
        self.db.parent.mkdir()
        _make_db(self.db, "original")

    def _marker(self):
        conn = sqlite3.connect(self.db)
        try:
            return conn.execute("SELECT value FROM marker").fetchone()[0]
        finally:
            conn.close()

    def test_valid_bundle_replaces_db_and_adds_workbooks(self):
        n = restore_bundle(_bundle([("app.db", _db_bytes()), (f"uploads/{WORKBOOK}", b"xlsx")]), self.db, self.uploads)
        self.assertEqual(n, 1)
        self.assertEqual(self._marker(), "restored")
        self.assertEqual((self.uploads / WORKBOOK).read_bytes(), b"xlsx")

    def test_missing_db_is_rejected_and_nothing_changes(self):
        with self.assertRaises(RestoreError):
            restore_bundle(_bundle([(f"uploads/{WORKBOOK}", b"x")]), self.db, self.uploads)
        self.assertEqual(self._marker(), "original")
        self.assertFalse((self.uploads / WORKBOOK).exists())

    def test_unexpected_file_or_traversal_is_rejected(self):
        for bad in ("../evil.db", "uploads/../app.py", "notes.txt", "uploads/random.xlsx", "/etc/passwd"):
            with self.subTest(bad=bad):
                with self.assertRaises(RestoreError):
                    restore_bundle(_bundle([("app.db", _db_bytes()), (bad, b"x")]), self.db, self.uploads)
                self.assertEqual(self._marker(), "original")

    def test_links_are_rejected(self):
        def symlink(info):
            info.type = tarfile.SYMTYPE
            info.linkname = "/etc/passwd"
        with self.assertRaises(RestoreError):
            restore_bundle(_bundle([("app.db", _db_bytes()), (f"uploads/{WORKBOOK}", symlink)]), self.db, self.uploads)
        self.assertEqual(self._marker(), "original")

    def test_corrupt_database_is_rejected(self):
        with self.assertRaises(RestoreError):
            restore_bundle(_bundle([("app.db", b"not a database" * 100)]), self.db, self.uploads)
        self.assertEqual(self._marker(), "original")
        self.assertEqual([p.name for p in self.db.parent.iterdir()], ["app.db"])

    def test_not_a_tarball_is_rejected(self):
        with self.assertRaises(RestoreError):
            restore_bundle(io.BytesIO(b"hello"), self.db, self.uploads)


class RestoreRouteTests(IsolatedAppTestCase):
    def test_route_is_404_when_disabled(self):
        client = self._client_logged_in_as("full")
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop("ENABLE_DATA_RESTORE", None)
            self.assertEqual(client.get("/admin/restore").status_code, 404)

    def test_non_full_roles_are_denied_even_when_enabled(self):
        with mock.patch.dict(os.environ, {"ENABLE_DATA_RESTORE": "1"}):
            for role in ("admissions", "consultants", "marketing"):
                with self.subTest(role=role):
                    client = self._client_logged_in_as(role)
                    self.assertEqual(client.get("/admin/restore").status_code, 403)

    def test_full_can_restore_when_enabled(self):
        with mock.patch.dict(os.environ, {"ENABLE_DATA_RESTORE": "1"}):
            client = self._client_logged_in_as("full")
            page = client.get("/admin/restore")
            self.assertEqual(page.status_code, 200)
            token = extract_token(page.get_data(as_text=True))
            bundle = _bundle([("app.db", _db_bytes()), (f"uploads/{WORKBOOK}", b"xlsx")])
            resp = client.post("/admin/restore", data={"csrf_token": token, "bundle": (bundle, "b.tar.gz")},
                               content_type="multipart/form-data")
            self.assertEqual(resp.status_code, 302)
        self.assertEqual(self._query("SELECT value FROM marker")[0]["value"], "restored")
        self.assertTrue((app_module.UPLOAD_FOLDER / WORKBOOK).exists())

    def test_bad_bundle_changes_nothing(self):
        with mock.patch.dict(os.environ, {"ENABLE_DATA_RESTORE": "1"}):
            client = self._client_logged_in_as("full")
            token = extract_token(client.get("/admin/restore").get_data(as_text=True))
            resp = client.post("/admin/restore", data={"csrf_token": token, "bundle": (io.BytesIO(b"junk"), "b.tar.gz")},
                               content_type="multipart/form-data")
            self.assertEqual(resp.status_code, 302)
        self.assertEqual(self._query("SELECT name FROM sqlite_master WHERE name='marker'"), [])

    def test_post_without_csrf_is_rejected(self):
        with mock.patch.dict(os.environ, {"ENABLE_DATA_RESTORE": "1"}):
            client = self._client_logged_in_as("full")
            bundle = _bundle([("app.db", _db_bytes())])
            resp = client.post("/admin/restore", data={"bundle": (bundle, "b.tar.gz")}, content_type="multipart/form-data")
            self.assertEqual(resp.status_code, 400)
        self.assertEqual(self._query("SELECT name FROM sqlite_master WHERE name='marker'"), [])
