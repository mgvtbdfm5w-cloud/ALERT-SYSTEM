"""The University Pipeline pop-up window in a REAL browser (headless Chrome).

The other test files check the page's markup and the records endpoint; this one
actually clicks a piece of the chart and looks at the window that opens. It is
skipped when no Chrome/Chromium is installed (set CHROME_BIN to point at one).

How: the Flask app is served on a local port, a tiny stand-in server in front
of it (which holds the login) serves the page with a short driver script added
at the bottom, and headless Chrome loads that page and reports what it saw."""

import http.cookiejar
from datetime import date
import http.server
import io
import os
import re
import shutil
import subprocess
import tempfile
import threading
import unittest
import urllib.parse
import urllib.request
from html import unescape
from pathlib import Path

from werkzeug.serving import make_server

from tests.flask_test_support import FULL_PASSWORD, IsolatedAppTestCase, app_module, extract_token
from tests.test_university_pipeline_export import ROWS, STATUS_LOOKUP, app_row
from tests.test_upload_atomicity import book
from tests.test_just_jon_records import LOOKUPS as JUST_JON_LOOKUPS, ROWS as JUST_JON_ROWS
from tests.test_allocation import lead, leads_book
from tests.test_dashboard_records import ALL_ROWS as DASHBOARD_ROWS
from tests.test_incentives import STATUS_LOOKUP as INCENTIVE_STATUS_LOOKUP, workbook_rows as incentive_workbook_rows
from tests.test_bonus import LOOKUPS as BONUS_LOOKUPS, workbook_rows as bonus_workbook_rows
from tests.test_consultants_records import LOOKUPS as CONSULTANT_LOOKUPS, ROWS as CONSULTANT_ROWS
from tests.test_loss_reasons_chart import EXTRA as LOSS_EXTRA, LOOKUPS as LOSS_LOOKUPS, ROWS as LOSS_ROWS, app_row as loss_row

JJ_LEADS = [lead("J1", "Mel X", "03/08/2026", "New Lead", "Staff Referral/Jon Daniels TT"),
            lead("J2", "Mel X", "04/09/2026", "New Lead", "Agent/Just Jon")]
INCENTIVE_ROWS = incentive_workbook_rows()
BONUS_ROWS = bonus_workbook_rows()
EVIL = "<img src=x onerror=alert(1)>"
ALL_ROWS = ROWS + [app_row("H1", "September 2026", "Assessment", "Mo Y", "Uni A", name=EVIL, consultant="Mel M")]


def find_chrome():
    candidates = [os.environ.get("CHROME_BIN"), "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"]
    candidates += [shutil.which(name) for name in ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser")]
    return next((c for c in candidates if c and Path(c).exists()), None)


DRIVER_TEMPLATE = r"""
window.addEventListener('load', function () {
  var log = [];
  Object.defineProperty(navigator, 'clipboard', {value: {writeText: function (t) { window.__copied = t; return Promise.resolve(); }}});
  var piece = document.querySelector('__PIECE__');
  var dlg = document.getElementById('chart-records');
  log.push('open-before=' + dlg.open);
  piece.click();
  setTimeout(function () {
    log.push('open=' + dlg.open);
    log.push('title=' + document.getElementById('chart-records-title').textContent);
    log.push('sub=' + document.getElementById('chart-records-sub').textContent);
    log.push('headers=' + Array.prototype.map.call(dlg.querySelectorAll('thead th'), function (t) { return t.textContent; }).join('|'));
    var rows = dlg.querySelectorAll('tbody tr');
    log.push('rows=' + rows.length);
    Array.prototype.forEach.call(rows, function (tr, i) {
      log.push('row' + i + '=' + Array.prototype.map.call(tr.querySelectorAll('td'), function (t) { return t.textContent; }).join('|'));
    });
    log.push('window-is-wide=' + dlg.classList.contains('chart-records-wide'));
    log.push('images-in-window=' + dlg.querySelectorAll('img').length);
    var ne = document.querySelector('.chart-columns-header .chart-col-bonus-not-eligible');
    var nr = document.querySelector('.chart-row .chart-col-bonus-not-eligible');
    log.push('not-eligible-heading=' + (ne && nr ? (ne.scrollWidth <= ne.clientWidth && ne.getBoundingClientRect().width === nr.getBoundingClientRect().width ? 'fits and lines up' : 'does not fit or line up') : 'none'));
    var scroller = document.getElementById('chart-records-body');
    log.push('scrolls-sideways=' + (scroller.scrollWidth > scroller.clientWidth) + ' (' + scroller.scrollWidth + ' of ' + scroller.clientWidth + ')');
    var rect = dlg.getBoundingClientRect();
    log.push('window-fits-the-screen=' + (rect.left >= 0 && rect.right <= window.innerWidth) + ' (' + Math.round(rect.left) + '-' + Math.round(rect.right) + ' of ' + window.innerWidth + ')');
    var loss = document.querySelector('.chart-scroll-loss');
    log.push('loss-chart-scrolls-sideways=' + (loss ? (loss.scrollWidth > loss.clientWidth) + ' (' + loss.scrollWidth + ' of ' + loss.clientWidth + ')' : 'none'));
    log.push('code-cells-are-copy-buttons=' + (dlg.querySelectorAll('tbody tr td:first-child button.copy-btn').length === rows.length));
    var btn = dlg.querySelector('tbody .copy-btn');
    var code = btn.getAttribute('data-code');
    btn.click();
    setTimeout(function () {
      log.push('clipboard=' + (window.__copied === code ? 'the PES Code ' + code : window.__copied));
      log.push('button-says=' + btn.textContent.trim());
      window.dispatchEvent(new Event('resize'));
      document.body.click();
      setTimeout(function () {
        log.push('still-open-later=' + dlg.open);
        dlg.querySelector('.chart-records-x').click();
        log.push('closed-by-cross=' + (!dlg.open));
        piece.click();
        setTimeout(function () {
          log.push('reopened=' + dlg.open);
          dlg.querySelector('.chart-records-close').click();
          log.push('closed-by-button=' + (!dlg.open));
          piece.dispatchEvent(new KeyboardEvent('keydown', {key: 'Enter', bubbles: true}));
          setTimeout(function () {
            log.push('opened-by-enter-key=' + dlg.open);
            dlg.querySelector('.chart-records-close').click();
            piece.dispatchEvent(new KeyboardEvent('keydown', {key: ' ', bubbles: true}));
            setTimeout(function () {
              log.push('opened-by-space-key=' + dlg.open);
              dlg.querySelector('.chart-records-close').click();
              piece.dispatchEvent(new KeyboardEvent('keydown', {key: 'a', bubbles: true}));
              setTimeout(function () {
                log.push('other-keys-do-nothing=' + (!dlg.open));
                var other = '__OTHER__' ? document.querySelector('__OTHER__') : null;
                if (other) { other.click(); }
                setTimeout(function () {
                  log.push('window-is-wide-for-the-other-piece=' + (other ? dlg.classList.contains('chart-records-wide') : 'none'));
                  var pre = document.createElement('pre'); pre.id = 'result'; pre.textContent = log.join('\n'); document.body.appendChild(pre);
                }, 600);
              }, 300);
            }, 800);
          }, 800);
        }, 800);
      }, 700);
    }, 300);
  }, 1500);
});
"""


@unittest.skipUnless(find_chrome(), "needs Chrome or Chromium (set CHROME_BIN)")
class PopUpWindowInARealBrowserTests(IsolatedAppTestCase):
    PAGE = "/university-pipeline"
    PIECE = '.chart-segment-clickable[data-records-params="university=Uni+A&group=pending_assessment"]'
    DATA = ALL_ROWS
    LOOKUPS = {"status": STATUS_LOOKUP}
    LEADS = None            # a leads workbook to upload as well, if the page needs one
    EXTRA_COLUMNS = ()      # optional Applications columns the data uses
    TODAY = None            # pin "today" in the app (a date), if the page depends on it
    WINDOW = "1280,900"     # the browser window's size
    OTHER_PIECE = ""        # a second piece of the page to click last, to see which window it opens

    def setUp(self):
        super().setUp()
        full = self._client_logged_in_as("full")
        token = extract_token(full.get("/login").get_data(as_text=True))
        data = book(self.DATA, lookups=self.LOOKUPS, extra_columns=self.EXTRA_COLUMNS)
        self.assertEqual(full.post("/upload", data={"csrf_token": token, "excel_file": (io.BytesIO(data), "f.xlsx")},
                                   content_type="multipart/form-data").status_code, 302)

        if self.LEADS:
            token = extract_token(full.get("/login").get_data(as_text=True))
            self.assertEqual(full.post("/leads/upload", data={"csrf_token": token, "excel_file": (io.BytesIO(self.LEADS), "l.xlsx")},
                                       content_type="multipart/form-data").status_code, 302)

        if self.TODAY:
            from unittest import mock
            patcher = mock.patch.object(app_module, "today_uk", return_value=self.TODAY)
            patcher.start()
            self.addCleanup(patcher.stop)

        self.app_server = make_server("127.0.0.1", 0, app_module.app, threaded=True)
        threading.Thread(target=self.app_server.serve_forever, daemon=True).start()
        self.addCleanup(self.app_server.shutdown)
        base = f"http://127.0.0.1:{self.app_server.server_port}"

        opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
        token = extract_token(opener.open(base + "/login").read().decode())
        opener.open(base + "/login", urllib.parse.urlencode({"csrf_token": token, "password": FULL_PASSWORD}).encode())

        page = self.PAGE
        driver = DRIVER_TEMPLATE.replace("__PIECE__", self.PIECE).replace("__OTHER__", self.OTHER_PIECE)

        class Forward(http.server.BaseHTTPRequestHandler):
            def do_GET(handler):
                try:
                    response = opener.open(base + handler.path)
                except Exception:
                    handler.send_response(404)
                    handler.end_headers()
                    return
                body = response.read()
                if handler.path.startswith(page + "?"):
                    body = body.decode().replace("</body>", "<script>" + driver + "</script></body>").encode()
                handler.send_response(200)
                handler.send_header("Content-Type", response.headers.get("Content-Type", "text/html"))
                handler.end_headers()
                handler.wfile.write(body)

            def log_message(handler, *args):
                pass

        self.front = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Forward)
        threading.Thread(target=self.front.serve_forever, daemon=True).start()
        self.addCleanup(self.front.shutdown)

    def run_browser(self, query):
        profile = tempfile.mkdtemp(prefix="gsp_chrome_")
        self.addCleanup(shutil.rmtree, profile, True)
        url = f"http://127.0.0.1:{self.front.server_port}{self.PAGE}?{query}"
        result = subprocess.run(
            [find_chrome(), "--headless=new", "--disable-gpu", "--no-sandbox", f"--user-data-dir={profile}", f"--window-size={self.WINDOW}", "--virtual-time-budget=12000", "--dump-dom", url],
            capture_output=True, text=True, timeout=90,
        )
        match = re.search(r'<pre id="result">(.*?)</pre>', result.stdout, re.S)
        self.assertIsNotNone(match, "the driver did not finish: " + result.stderr[-300:])
        return dict(line.split("=", 1) for line in unescape(match.group(1)).split("\n"))

    def test_clicking_a_piece_of_the_chart_opens_a_window_that_stays_until_closed(self):
        seen = self.run_browser("year=2026")
        self.assertEqual(seen["open-before"], "false")
        self.assertEqual(seen["open"], "true")
        self.assertEqual(seen["title"], "Uni A — Pending Assessment")
        self.assertEqual(seen["sub"], "3 applications — click a PES Code to copy it")
        self.assertEqual(seen["headers"], "PES Code|Student|University|Intake|Consultant|Application Manager")
        self.assertEqual(seen["rows"], "3")
        self.assertEqual(seen["row0"], f"H1|{EVIL}|Uni A|September 2026|Mel|Mo")        # sorted by student; shown as text
        self.assertEqual(seen["row1"], "A1|A1|Uni A|August 2026|Raneen|Nouran")
        self.assertEqual(seen["row2"], "A6|A6|Uni A|November 2026|Hannah|Nouran")
        self.assertEqual(seen["images-in-window"], "0", "a student name that looks like HTML is text, not markup")
        self.assertEqual(seen["still-open-later"], "true", "it stays open until it is closed")
        self.assertEqual(seen["closed-by-cross"], "true")
        self.assertEqual(seen["reopened"], "true")
        self.assertEqual(seen["closed-by-button"], "true")

    def test_the_pieces_can_be_opened_from_the_keyboard(self):
        seen = self.run_browser("year=2026")
        self.assertEqual(seen["opened-by-enter-key"], "true")
        self.assertEqual(seen["opened-by-space-key"], "true")
        self.assertEqual(seen["other-keys-do-nothing"], "true")

    def test_each_pes_code_is_a_copy_button_that_puts_the_code_on_the_clipboard(self):
        seen = self.run_browser("year=2026")
        self.assertEqual(seen["code-cells-are-copy-buttons"], "true")
        self.assertEqual(seen["clipboard"], "the PES Code H1")
        self.assertEqual(seen["button-says"], "Copied")

    def test_the_window_lists_what_the_filters_leave_in_the_clicked_piece(self):
        seen = self.run_browser("year=2026&manager=Nouran&consultant=Hannah")
        self.assertEqual(seen["sub"], "1 application — click a PES Code to copy it")
        self.assertEqual(seen["rows"], "1")
        self.assertEqual(seen["row0"], "A6|A6|Uni A|November 2026|Hannah|Nouran")


@unittest.skipUnless(find_chrome(), "needs Chrome or Chromium (set CHROME_BIN)")
class JustJonPopUpInARealBrowserTests(PopUpWindowInARealBrowserTests):
    """The same window on the Just Jon page (click a bar of its Application Manager chart)."""

    PAGE = "/dashboard/just-jon"
    PIECE = '.chart-segment-clickable[data-records-params="chart=manager&name=Mo&stage=06-Decision"]'
    DATA = JUST_JON_ROWS
    LOOKUPS = JUST_JON_LOOKUPS

    def test_clicking_a_piece_of_the_chart_opens_a_window_that_stays_until_closed(self):
        seen = self.run_browser("year=2026")
        self.assertEqual((seen["open-before"], seen["open"]), ("false", "true"))
        self.assertEqual(seen["title"], "Mo \u2014 06-Decision")
        self.assertEqual(seen["sub"], "2 applications \u2014 click a PES Code to copy it")
        self.assertEqual(seen["headers"], "PES Code|Student|University|Intake|Consultant|Application Manager")
        self.assertEqual(seen["rows"], "2")
        self.assertEqual(seen["row0"], "J1|Student J1|Uni B|August 2026|Raneen|Mo")
        self.assertEqual(seen["row1"], "J4|Student J4|Uni C|October 2026|Hannah|Mo")
        self.assertEqual(seen["still-open-later"], "true")
        self.assertEqual((seen["closed-by-cross"], seen["reopened"], seen["closed-by-button"]), ("true", "true", "true"))

    def test_each_pes_code_is_a_copy_button_that_puts_the_code_on_the_clipboard(self):
        seen = self.run_browser("year=2026")
        self.assertEqual(seen["code-cells-are-copy-buttons"], "true")
        self.assertEqual(seen["clipboard"], "the PES Code J1")
        self.assertEqual(seen["button-says"], "Copied")

    def test_the_year_tab_is_sent_along(self):
        seen = self.run_browser("year=2027")
        self.assertEqual(seen["title"], "Mo \u2014 06-Decision")
        self.assertEqual(seen["rows"], "1")
        self.assertEqual(seen["row0"], "J10|Student J10|Uni C|February 2027|Mel|Mo")

    def test_the_pieces_can_be_opened_from_the_keyboard(self):
        seen = self.run_browser("year=2026")
        self.assertEqual((seen["opened-by-enter-key"], seen["opened-by-space-key"], seen["other-keys-do-nothing"]), ("true", "true", "true"))

    def test_the_window_lists_what_the_filters_leave_in_the_clicked_piece(self):
        self.skipTest("the Just Jon page has no filters beyond the year tab")


@unittest.skipUnless(find_chrome(), "needs Chrome or Chromium (set CHROME_BIN)")
class JustJonLeadsPopUpInARealBrowserTests(PopUpWindowInARealBrowserTests):
    """The window from the Just Jon Leads-by-Office-and-Consultant chart (a LEAD list, with its own columns)."""

    PAGE = "/dashboard/just-jon"
    PIECE = '.chart-segment-clickable[data-records-url="/dashboard/just-jon/lead-records"][data-records-params="office=MAN&name=Mel&stage=01+-+New+Lead"]'
    DATA = JUST_JON_ROWS
    LOOKUPS = JUST_JON_LOOKUPS
    LEADS = leads_book(JJ_LEADS)

    def test_clicking_a_piece_of_the_chart_opens_a_window_that_stays_until_closed(self):
        seen = self.run_browser("year=2026")
        self.assertEqual((seen["open-before"], seen["open"]), ("false", "true"))
        self.assertEqual(seen["title"], "Mel (MAN) \u2014 01 - New Lead")
        self.assertEqual(seen["sub"], "2 leads \u2014 click a PES Code to copy it")
        self.assertEqual(seen["headers"], "PES Code|Name|Lead Source|Sub Source|Lead Status|Consultant|Created")
        self.assertEqual(seen["rows"], "2")
        self.assertEqual(seen["row0"], "J1|J1|Staff Referral|Jon Daniels TT|New Lead|Mel|03/08/2026")
        self.assertEqual(seen["row1"], "J2|J2|Agent|Just Jon|New Lead|Mel|04/09/2026")
        self.assertEqual(seen["still-open-later"], "true")
        self.assertEqual((seen["closed-by-cross"], seen["reopened"], seen["closed-by-button"]), ("true", "true", "true"))

    def test_each_pes_code_is_a_copy_button_that_puts_the_code_on_the_clipboard(self):
        seen = self.run_browser("year=2026")
        self.assertEqual(seen["code-cells-are-copy-buttons"], "true")
        self.assertEqual(seen["clipboard"], "the PES Code J1")
        self.assertEqual(seen["button-says"], "Copied")

    def test_the_month_chosen_for_the_chart_is_sent_along(self):
        seen = self.run_browser("year=2026&lead_month=2026-08")
        self.assertEqual(seen["rows"], "1")
        self.assertEqual(seen["row0"], "J1|J1|Staff Referral|Jon Daniels TT|New Lead|Mel|03/08/2026")

    def test_the_pieces_can_be_opened_from_the_keyboard(self):
        seen = self.run_browser("year=2026")
        self.assertEqual((seen["opened-by-enter-key"], seen["opened-by-space-key"], seen["other-keys-do-nothing"]), ("true", "true", "true"))

    def test_the_window_lists_what_the_filters_leave_in_the_clicked_piece(self):
        self.skipTest("the Just Jon page has no filters beyond the year tab and the month")


@unittest.skipUnless(find_chrome(), "needs Chrome or Chromium (set CHROME_BIN)")
class DashboardPopUpInARealBrowserTests(PopUpWindowInARealBrowserTests):
    """The same window on the Application Manager Pipeline (Dashboard) page."""

    PAGE = "/dashboard"
    PIECE = '.chart-segment-clickable[data-records-params="manager=Mo&group=pending_offer"]'
    DATA = DASHBOARD_ROWS
    LOOKUPS = JUST_JON_LOOKUPS

    def test_clicking_a_piece_of_the_chart_opens_a_window_that_stays_until_closed(self):
        seen = self.run_browser("year=2026")
        self.assertEqual((seen["open-before"], seen["open"]), ("false", "true"))
        self.assertEqual(seen["title"], "Mo \u2014 Pending Offer")
        self.assertEqual(seen["sub"], "3 applications \u2014 click a PES Code to copy it")
        self.assertEqual(seen["headers"], "PES Code|Student|University|Intake|Consultant|Application Manager|Days")
        self.assertEqual(seen["rows"], "3")
        self.assertEqual(seen["row0"], "J1|Student J1|Uni B|August 2026|Raneen|Mo|")      # Days is blank: no dates in this data
        self.assertEqual(seen["row1"], "J4|Student J4|Uni C|October 2026|Hannah|Mo|")
        self.assertEqual(seen["row2"], "K1|Student K1|Uni D|September 2026|Hannah|Mo|")
        self.assertEqual(seen["still-open-later"], "true")
        self.assertEqual((seen["closed-by-cross"], seen["reopened"], seen["closed-by-button"]), ("true", "true", "true"))

    def test_each_pes_code_is_a_copy_button_that_puts_the_code_on_the_clipboard(self):
        seen = self.run_browser("year=2026")
        self.assertEqual(seen["code-cells-are-copy-buttons"], "true")
        self.assertEqual(seen["clipboard"], "the PES Code J1")
        self.assertEqual(seen["button-says"], "Copied")

    def test_the_year_tab_is_sent_along(self):
        seen = self.run_browser("year=2027")
        self.assertEqual(seen["rows"], "1")
        self.assertEqual(seen["row0"], "J10|Student J10|Uni C|February 2027|Mel|Mo|")

    def test_the_pieces_can_be_opened_from_the_keyboard(self):
        seen = self.run_browser("year=2026")
        self.assertEqual((seen["opened-by-enter-key"], seen["opened-by-space-key"], seen["other-keys-do-nothing"]), ("true", "true", "true"))

    def test_the_window_lists_what_the_filters_leave_in_the_clicked_piece(self):
        self.skipTest("the Dashboard page has no filters beyond the year tab")


@unittest.skipUnless(find_chrome(), "needs Chrome or Chromium (set CHROME_BIN)")
class IncentivesPopUpInARealBrowserTests(PopUpWindowInARealBrowserTests):
    """The same window on the Incentives page."""

    PAGE = "/incentives"
    PIECE = '.chart-segment-clickable[data-records-params="incentive=incentive_1&consultant=Mel&group=enrolled_this_intake"]'
    DATA = INCENTIVE_ROWS
    LOOKUPS = {"status": INCENTIVE_STATUS_LOOKUP}

    def test_clicking_a_piece_of_the_chart_opens_a_window_that_stays_until_closed(self):
        seen = self.run_browser("")
        self.assertEqual((seen["open-before"], seen["open"]), ("false", "true"))
        self.assertEqual(seen["title"], "Mel \u2014 Enrolled This Intake")
        self.assertEqual(seen["sub"], "5 applications \u2014 click a PES Code to copy it")
        self.assertEqual(seen["headers"], "PES Code|Student|University|Intake|Consultant|Application Manager")
        self.assertEqual(seen["rows"], "5")
        self.assertEqual(seen["row0"], "M0|Student M0|LSC|November 2026|Mel|Mo")
        self.assertEqual(seen["row4"], "M4|Student M4|LSC|November 2026|Mel|Mo")
        self.assertEqual(seen["still-open-later"], "true")
        self.assertEqual((seen["closed-by-cross"], seen["reopened"], seen["closed-by-button"]), ("true", "true", "true"))

    def test_each_pes_code_is_a_copy_button_that_puts_the_code_on_the_clipboard(self):
        seen = self.run_browser("")
        self.assertEqual(seen["code-cells-are-copy-buttons"], "true")
        self.assertEqual(seen["clipboard"], "the PES Code M0")
        self.assertEqual(seen["button-says"], "Copied")

    def test_the_pieces_can_be_opened_from_the_keyboard(self):
        seen = self.run_browser("")
        self.assertEqual((seen["opened-by-enter-key"], seen["opened-by-space-key"], seen["other-keys-do-nothing"]), ("true", "true", "true"))

    def test_the_window_lists_what_the_filters_leave_in_the_clicked_piece(self):
        self.skipTest("the Incentives page has no filters")


@unittest.skipUnless(find_chrome(), "needs Chrome or Chromium (set CHROME_BIN)")
class BonusChartPopUpInARealBrowserTests(PopUpWindowInARealBrowserTests):
    """The window from the 30 Days page's Bonus Eligibility chart (its own columns, dates and days)."""

    PAGE = "/thirty-days"
    PIECE = '.chart-segment-clickable[data-records-params="manager=Alice&status=eligible"]'
    DATA = BONUS_ROWS
    LOOKUPS = BONUS_LOOKUPS
    EXTRA_COLUMNS = ["Offer Accepted Date"]
    TODAY = date(2027, 1, 15)

    def test_clicking_a_piece_of_the_chart_opens_a_window_that_stays_until_closed(self):
        seen = self.run_browser("")
        self.assertEqual((seen["open-before"], seen["open"]), ("false", "true"))
        self.assertEqual(seen["title"], "Alice \u2014 Eligible")
        self.assertEqual(seen["sub"], "2 applications \u2014 click a PES Code to copy it")
        self.assertEqual(seen["headers"], "PES Code|Student|University|Intake|Consultant|Submitted To Uni|Offer Accepted|Days to Offer|Days Waiting")
        self.assertEqual(seen["rows"], "2")
        self.assertEqual(seen["row0"], "A1|Student A1|Uni A|September 2027|Gina|29/12/2026|13/01/2027|15|")
        self.assertEqual(seen["row1"], "A6|Student A6|Uni A|September 2027|Gina|24/11/2026|24/12/2026|30|")
        self.assertEqual(seen["still-open-later"], "true")
        self.assertEqual((seen["closed-by-cross"], seen["reopened"], seen["closed-by-button"]), ("true", "true", "true"))

    def test_the_window_is_wide_enough_to_show_every_column_without_scrolling_sideways(self):
        seen = self.run_browser("")
        self.assertTrue(seen["scrolls-sideways"].startswith("false"), seen["scrolls-sideways"])

    def test_the_not_eligible_column_heading_fits_and_lines_up_with_its_numbers(self):
        seen = self.run_browser("")
        self.assertEqual(seen["not-eligible-heading"], "fits and lines up")

    def test_each_pes_code_is_a_copy_button_that_puts_the_code_on_the_clipboard(self):
        seen = self.run_browser("")
        self.assertEqual(seen["code-cells-are-copy-buttons"], "true")
        self.assertEqual(seen["clipboard"], "the PES Code A1")
        self.assertEqual(seen["button-says"], "Copied")

    def test_the_month_chosen_for_the_chart_is_sent_along(self):
        seen = self.run_browser("sub_month=2026-12")
        self.assertEqual(seen["rows"], "1")
        self.assertEqual(seen["row0"], "A1|Student A1|Uni A|September 2027|Gina|29/12/2026|13/01/2027|15|")

    def test_the_pieces_can_be_opened_from_the_keyboard(self):
        seen = self.run_browser("")
        self.assertEqual((seen["opened-by-enter-key"], seen["opened-by-space-key"], seen["other-keys-do-nothing"]), ("true", "true", "true"))

    def test_the_window_lists_what_the_filters_leave_in_the_clicked_piece(self):
        self.skipTest("covered by the month test above")


# One application with the long names real data has: the window has to fit them without scrolling sideways.
LONG_LOSS_ROWS = LOSS_ROWS + [loss_row(
    "L10", "April 2027", "Cancelled", "Mo Y", "Mel M", "Student Withdrew",
    "Unable to commit to the study hours required around work and family life",
    university="The University of Wolverhampton Business School Online", name="Alexandra Montgomery-Featherstonehaugh")]


@unittest.skipUnless(find_chrome(), "needs Chrome or Chromium (set CHROME_BIN)")
class LossReasonPopUpInARealBrowserTests(PopUpWindowInARealBrowserTests):
    """The window from the Application Manager Pipeline page's Loss Reasons by Application Manager chart."""

    PAGE = "/dashboard"
    PIECE = '.chart-segment-clickable[data-records-url="/dashboard/loss-records"][data-records-params="manager=Mo&reason=Student+Withdrew"]'
    DATA = LONG_LOSS_ROWS
    LOOKUPS = LOSS_LOOKUPS
    EXTRA_COLUMNS = LOSS_EXTRA
    OTHER_PIECE = '.chart-segment-clickable[data-records-params="manager=Mo&group=lost"]'

    def test_clicking_a_piece_of_the_chart_opens_a_window_that_stays_until_closed(self):
        seen = self.run_browser("year=2027")
        self.assertEqual((seen["open-before"], seen["open"]), ("false", "true"))
        self.assertEqual(seen["title"], "Mo \u2014 Student Withdrew")
        self.assertEqual(seen["sub"], "3 applications \u2014 click a PES Code to copy it")
        self.assertEqual(seen["headers"], "PES Code|Student|Application Manager|Consultant|University|Loss Reason|Sub Reason")
        self.assertEqual(seen["rows"], "3")
        self.assertEqual(seen["row0"], "L10|Alexandra Montgomery-Featherstonehaugh|Mo|Mel|The University of Wolverhampton Business School Online|Student Withdrew|"
                                       "Unable to commit to the study hours required around work and family life")
        self.assertEqual(seen["row1"], "L1|Student L1|Mo|Mel|Uni A|Student Withdrew|Changed mind")
        self.assertEqual(seen["row2"], "L4|Student L4|Mo|Hannah|Uni A|Student Withdrew|Changed mind")
        self.assertEqual(seen["still-open-later"], "true")
        self.assertEqual((seen["closed-by-cross"], seen["reopened"], seen["closed-by-button"]), ("true", "true", "true"))

    def test_the_window_and_the_chart_fit_across_without_scrolling_sideways(self):
        seen = self.run_browser("year=2027")
        self.assertTrue(seen["scrolls-sideways"].startswith("false"), seen["scrolls-sideways"])
        self.assertTrue(seen["window-fits-the-screen"].startswith("true"), seen["window-fits-the-screen"])
        self.assertTrue(seen["loss-chart-scrolls-sideways"].startswith("false"), seen["loss-chart-scrolls-sideways"])

    def test_it_is_the_wide_window_but_the_pipeline_health_pieces_keep_their_usual_one(self):
        seen = self.run_browser("year=2027")
        self.assertEqual(seen["window-is-wide"], "true")
        self.assertEqual(seen["window-is-wide-for-the-other-piece"], "false", "a Pipeline Health piece clicked after it opens the usual window again")

    def test_the_window_still_fits_on_a_smaller_screen(self):
        self.WINDOW = "1024,768"
        seen = self.run_browser("year=2027")
        self.assertTrue(seen["scrolls-sideways"].startswith("false"), seen["scrolls-sideways"])
        self.assertTrue(seen["window-fits-the-screen"].startswith("true"), seen["window-fits-the-screen"])

    def test_each_pes_code_is_a_copy_button_that_puts_the_code_on_the_clipboard(self):
        seen = self.run_browser("year=2027")
        self.assertEqual(seen["code-cells-are-copy-buttons"], "true")
        self.assertEqual(seen["clipboard"], "the PES Code L10")
        self.assertEqual(seen["button-says"], "Copied")

    def test_the_intake_month_chosen_for_the_page_is_sent_along(self):
        seen = self.run_browser("year=2027&intake_month=3")        # L10 is an April intake, L4 a September one
        self.assertEqual(seen["sub"], "1 application \u2014 click a PES Code to copy it")
        self.assertEqual(seen["row0"], "L1|Student L1|Mo|Mel|Uni A|Student Withdrew|Changed mind")

    def test_the_pieces_can_be_opened_from_the_keyboard(self):
        seen = self.run_browser("year=2027")
        self.assertEqual((seen["opened-by-enter-key"], seen["opened-by-space-key"], seen["other-keys-do-nothing"]), ("true", "true", "true"))

    def test_the_window_lists_what_the_filters_leave_in_the_clicked_piece(self):
        self.skipTest("covered by the intake month test above")


if __name__ == "__main__":
    unittest.main()


@unittest.skipUnless(find_chrome(), "needs Chrome or Chromium (set CHROME_BIN)")
class ConsultantsPopUpInARealBrowserTests(PopUpWindowInARealBrowserTests):
    """The same window on the Consultants page (click a bar of its Application Manager chart)."""

    PAGE = "/consultants"
    PIECE = '.chart-segment-clickable[data-records-params="chart=manager&name=Mo&stage=06-Decision"]'
    DATA = CONSULTANT_ROWS
    LOOKUPS = CONSULTANT_LOOKUPS

    def test_clicking_a_piece_of_the_chart_opens_a_window_that_stays_until_closed(self):
        seen = self.run_browser("consultant=Mel&year=2026")
        self.assertEqual((seen["open-before"], seen["open"]), ("false", "true"))
        self.assertEqual(seen["title"], "Mo \u2014 06-Decision")
        self.assertEqual(seen["sub"], "2 applications \u2014 click a PES Code to copy it")
        self.assertEqual(seen["headers"], "PES Code|Student|University|Intake|Consultant|Application Manager")
        self.assertEqual(seen["rows"], "2")
        self.assertEqual(seen["row0"], "M1|Student M1|Uni B|August 2026|Mel|Mo")
        self.assertEqual(seen["row1"], "M4|Student M4|Uni C|October 2026|Mel|Mo")
        self.assertEqual(seen["window-is-wide"], "false")
        self.assertEqual(seen["still-open-later"], "true")
        self.assertEqual((seen["closed-by-cross"], seen["reopened"], seen["closed-by-button"]), ("true", "true", "true"))

    def test_each_pes_code_is_a_copy_button_that_puts_the_code_on_the_clipboard(self):
        seen = self.run_browser("consultant=Mel&year=2026")
        self.assertEqual(seen["code-cells-are-copy-buttons"], "true")
        self.assertEqual(seen["clipboard"], "the PES Code M1")
        self.assertEqual(seen["button-says"], "Copied")

    def test_the_picked_consultant_is_sent_along_so_only_their_applications_are_listed(self):
        seen = self.run_browser("consultant=Hannah&year=2027&intake=intake_01")
        self.assertEqual(seen["rows"], "1")
        self.assertEqual(seen["row0"], "H3|Student H3|Uni A|February 2027|Hannah|Mo")

    def test_the_year_tab_is_sent_along(self):
        seen = self.run_browser("consultant=Mel&year=2027&intake=intake_01")
        self.assertEqual(seen["rows"], "1")
        self.assertEqual(seen["row0"], "M8|Student M8|Uni C|February 2027|Mel|Mo")

    def test_the_pieces_can_be_opened_from_the_keyboard(self):
        seen = self.run_browser("consultant=Mel&year=2026")
        self.assertEqual((seen["opened-by-enter-key"], seen["opened-by-space-key"], seen["other-keys-do-nothing"]), ("true", "true", "true"))

    def test_the_window_lists_what_the_filters_leave_in_the_clicked_piece(self):
        self.skipTest("the Consultants page filters are covered by the consultant and year tests above")


@unittest.skipUnless(find_chrome(), "needs Chrome or Chromium (set CHROME_BIN)")
class ConsultantsUniversityPopUpInARealBrowserTests(ConsultantsPopUpInARealBrowserTests):
    """The same window from a bar of the Consultants page's University chart."""

    PIECE = '.chart-segment-clickable[data-records-params="chart=university&name=Uni+A&stage=05-Assessment"]'

    def test_clicking_a_piece_of_the_chart_opens_a_window_that_stays_until_closed(self):
        seen = self.run_browser("consultant=Mel&year=2026")
        self.assertEqual((seen["open-before"], seen["open"]), ("false", "true"))
        self.assertEqual(seen["title"], "Uni A \u2014 05-Assessment")
        self.assertEqual(seen["sub"], "3 applications \u2014 click a PES Code to copy it")
        self.assertEqual(seen["rows"], "3")
        self.assertEqual(seen["row0"], "M1|Student M1|Uni A|August 2026|Mel|Mo")
        self.assertEqual(seen["row1"], "M5|Student M5|Uni A|August 2026|Mel|Unassigned")
        self.assertEqual(seen["row2"], "M6|Student M6|Uni A|October 2026|Mel|Admission")
        self.assertEqual((seen["closed-by-cross"], seen["reopened"], seen["closed-by-button"]), ("true", "true", "true"))

    def test_each_pes_code_is_a_copy_button_that_puts_the_code_on_the_clipboard(self):
        seen = self.run_browser("consultant=Mel&year=2026")
        self.assertEqual((seen["clipboard"], seen["button-says"]), ("the PES Code M1", "Copied"))

    def test_the_picked_consultant_is_sent_along_so_only_their_applications_are_listed(self):
        seen = self.run_browser("consultant=Hannah&year=2026")
        self.assertEqual((seen["rows"], seen["row0"]), ("1", "H1|Student H1|Uni A|August 2026|Hannah|Mo"))

    def test_the_year_tab_is_sent_along(self):
        self.skipTest("covered by the Application Manager chart's test")
