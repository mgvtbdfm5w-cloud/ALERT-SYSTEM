import unittest

from submissions import (
    build_daily_matrix,
    count_hold,
    count_pending_submission,
    list_available_months,
)


def _row(status=None, sub_status=None, submitted=None, support=None):
    return {
        "Status": status,
        "Sub Status": sub_status,
        "Submitted To Uni": submitted,
        "Support": support,
    }


class MonthLogicTests(unittest.TestCase):
    def test_valid_months_are_detected(self):
        rows = [_row(submitted="2026-08-01"), _row(submitted="2026-07-15")]
        self.assertEqual(list_available_months(rows), [(2026, 8), (2026, 7)])

    def test_duplicate_dates_do_not_duplicate_month_options(self):
        rows = [_row(submitted="2026-08-01"), _row(submitted="2026-08-15"), _row(submitted="2026-08-30")]
        self.assertEqual(list_available_months(rows), [(2026, 8)])

    def test_months_sort_newest_first(self):
        rows = [
            _row(submitted="2026-01-05"),
            _row(submitted="2026-08-05"),
            _row(submitted="2025-12-05"),
        ]
        self.assertEqual(list_available_months(rows), [(2026, 8), (2026, 1), (2025, 12)])

    def test_invalid_and_blank_dates_are_ignored(self):
        rows = [_row(submitted=None), _row(submitted=""), _row(submitted="not-a-date")]
        self.assertEqual(list_available_months(rows), [])

    def test_most_recent_month_is_first_and_usable_as_default(self):
        rows = [_row(submitted="2026-06-01"), _row(submitted="2026-08-01")]
        months = list_available_months(rows)
        default = months[0]
        self.assertEqual(default, (2026, 8))


class PendingSubmissionTests(unittest.TestCase):
    def test_pending_submission_counts(self):
        rows = [_row(status="03-PendingSubmission"), _row(status="03-PendingSubmission")]
        self.assertEqual(count_pending_submission(rows), 2)

    def test_other_statuses_do_not_count(self):
        rows = [_row(status="04-Onboarding"), _row(status="10-Lost"), _row(status=None)]
        self.assertEqual(count_pending_submission(rows), 0)

    def test_comparison_is_case_and_whitespace_safe(self):
        rows = [_row(status="  03-pendingsubmission  ")]
        self.assertEqual(count_pending_submission(rows), 1)

    def test_pending_submission_is_not_affected_by_submitted_to_uni_month(self):
        # This count is current-state only - a Submitted To Uni date (or
        # lack of one) must never influence it.
        rows = [
            _row(status="03-PendingSubmission", submitted="2020-01-01"),
            _row(status="03-PendingSubmission", submitted=None),
        ]
        self.assertEqual(count_pending_submission(rows), 2)


class HoldTests(unittest.TestCase):
    def test_pending_submission_with_non_blank_sub_status_counts_as_hold(self):
        rows = [_row(status="03-PendingSubmission", sub_status="Awaiting Docs")]
        self.assertEqual(count_hold(rows), 1)

    def test_any_non_blank_wording_counts_no_specific_text_required(self):
        rows = [_row(status="03-PendingSubmission", sub_status="Hold")]
        self.assertEqual(count_hold(rows), 1)

    def test_pending_submission_with_blank_sub_status_does_not_count(self):
        rows = [_row(status="03-PendingSubmission", sub_status=None)]
        self.assertEqual(count_hold(rows), 0)

    def test_non_pending_status_with_non_blank_sub_status_does_not_count(self):
        rows = [_row(status="04-Onboarding", sub_status="Awaiting Docs")]
        self.assertEqual(count_hold(rows), 0)

    def test_whitespace_only_sub_status_does_not_count(self):
        rows = [_row(status="03-PendingSubmission", sub_status="   ")]
        self.assertEqual(count_hold(rows), 0)

    def test_hold_is_a_subset_of_pending_submission(self):
        rows = [
            _row(status="03-PendingSubmission", sub_status="Awaiting Docs"),
            _row(status="03-PendingSubmission", sub_status=None),
        ]
        self.assertEqual(count_pending_submission(rows), 2)
        self.assertEqual(count_hold(rows), 1)


class DailyMatrixTests(unittest.TestCase):
    def test_records_are_grouped_by_submitted_to_uni_day(self):
        rows = [
            _row(submitted="2026-08-01", support="Alex"),
            _row(submitted="2026-08-01", support="Alex"),
            _row(submitted="2026-08-02", support="Alex"),
        ]
        matrix = build_daily_matrix(rows, 2026, 8)
        labels = [d["label"] for d in matrix["day_rows"]]
        self.assertEqual(labels, ["01 Aug", "02 Aug"])
        self.assertEqual(matrix["day_rows"][0]["total"], 2)
        self.assertEqual(matrix["day_rows"][1]["total"], 1)

    def test_records_are_grouped_by_support(self):
        rows = [
            _row(submitted="2026-08-01", support="Alex"),
            _row(submitted="2026-08-01", support="John"),
        ]
        matrix = build_daily_matrix(rows, 2026, 8)
        self.assertEqual(matrix["support_people"], ["Alex", "John"])
        self.assertEqual(matrix["day_rows"][0]["counts"], [1, 1])

    def test_blank_support_becomes_unassigned(self):
        rows = [
            _row(submitted="2026-08-01", support=""),
            _row(submitted="2026-08-01", support=None),
            _row(submitted="2026-08-01", support="   "),
        ]
        matrix = build_daily_matrix(rows, 2026, 8)
        self.assertEqual(matrix["support_people"], ["Unassigned"])
        self.assertEqual(matrix["day_rows"][0]["total"], 3)

    def test_support_columns_sort_alphabetically(self):
        rows = [
            _row(submitted="2026-08-01", support="Zed"),
            _row(submitted="2026-08-01", support="Amy"),
            _row(submitted="2026-08-01", support="mike"),
        ]
        matrix = build_daily_matrix(rows, 2026, 8)
        self.assertEqual(matrix["support_people"], ["Amy", "mike", "Zed"])

    def test_days_sort_ascending(self):
        rows = [
            _row(submitted="2026-08-15", support="Alex"),
            _row(submitted="2026-08-02", support="Alex"),
            _row(submitted="2026-08-30", support="Alex"),
        ]
        matrix = build_daily_matrix(rows, 2026, 8)
        labels = [d["label"] for d in matrix["day_rows"]]
        self.assertEqual(labels, ["02 Aug", "15 Aug", "30 Aug"])

    def test_days_with_no_submissions_are_omitted(self):
        rows = [
            _row(submitted="2026-08-01", support="Alex"),
            _row(submitted="2026-08-03", support="Alex"),
        ]
        matrix = build_daily_matrix(rows, 2026, 8)
        labels = [d["label"] for d in matrix["day_rows"]]
        self.assertEqual(labels, ["01 Aug", "03 Aug"])  # 02 Aug omitted

    def test_daily_totals_are_correct(self):
        rows = [
            _row(submitted="2026-08-01", support="Alex"),
            _row(submitted="2026-08-01", support="John"),
            _row(submitted="2026-08-01", support="John"),
        ]
        matrix = build_daily_matrix(rows, 2026, 8)
        self.assertEqual(matrix["day_rows"][0]["total"], 3)

    def test_support_month_totals_are_correct(self):
        rows = [
            _row(submitted="2026-08-01", support="Alex"),
            _row(submitted="2026-08-15", support="Alex"),
            _row(submitted="2026-08-01", support="John"),
        ]
        matrix = build_daily_matrix(rows, 2026, 8)
        totals = dict(zip(matrix["support_people"], matrix["support_totals"]))
        self.assertEqual(totals["Alex"], 2)
        self.assertEqual(totals["John"], 1)

    def test_month_total_equals_grand_total(self):
        rows = [
            _row(submitted="2026-08-01", support="Alex"),
            _row(submitted="2026-08-02", support="John"),
            _row(submitted="2026-08-03", support="Alex"),
        ]
        matrix = build_daily_matrix(rows, 2026, 8)
        self.assertEqual(sum(matrix["support_totals"]), matrix["grand_total"])
        self.assertEqual(matrix["grand_total"], 3)

    def test_each_record_counts_exactly_once(self):
        rows = [
            _row(submitted="2026-08-01", support="Alex"),
            _row(submitted="2026-08-02", support="John"),
            _row(submitted="2026-08-01", support=None),
        ]
        matrix = build_daily_matrix(rows, 2026, 8)
        total_from_days = sum(d["total"] for d in matrix["day_rows"])
        total_from_support = sum(matrix["support_totals"])
        self.assertEqual(total_from_days, len(rows))
        self.assertEqual(total_from_support, len(rows))
        self.assertEqual(matrix["grand_total"], len(rows))

    def test_records_outside_the_selected_month_are_excluded(self):
        rows = [
            _row(submitted="2026-08-01", support="Alex"),
            _row(submitted="2026-07-31", support="Alex"),
            _row(submitted="2026-09-01", support="Alex"),
        ]
        matrix = build_daily_matrix(rows, 2026, 8)
        self.assertEqual(matrix["grand_total"], 1)

    def test_invalid_dates_are_excluded_and_do_not_crash(self):
        rows = [
            _row(submitted="2026-08-01", support="Alex"),
            _row(submitted=None, support="Alex"),
            _row(submitted="not-a-date", support="Alex"),
        ]
        matrix = build_daily_matrix(rows, 2026, 8)
        self.assertEqual(matrix["grand_total"], 1)

    def test_empty_month_returns_no_day_rows_and_zero_total(self):
        matrix = build_daily_matrix([], 2026, 8)
        self.assertEqual(matrix["day_rows"], [])
        self.assertEqual(matrix["support_people"], [])
        self.assertEqual(matrix["grand_total"], 0)
        self.assertEqual(matrix["max_cell"], 0)
        self.assertEqual(matrix["support_colors"], [])


class ChartDataTests(unittest.TestCase):
    """The daily submissions chart is one horizontal bar per Support person,
    split into per-day segments - built entirely from the same
    day_support_counts the table renders, so the two can never disagree."""

    def test_busiest_person_gets_full_bar_length(self):
        rows = (
            [_row(submitted="2026-08-01", support="Alex")] * 5
            + [_row(submitted="2026-08-12", support="Esraa")] * 100
            + [_row(submitted="2026-08-13", support="Wessam")] * 10
        )
        matrix = build_daily_matrix(rows, 2026, 8)
        by_name = {p["name"]: p for p in matrix["person_rows"]}
        self.assertEqual(sum(s["width_pct"] for s in by_name["Esraa"]["segments"]), 100.0)
        self.assertAlmostEqual(sum(s["width_pct"] for s in by_name["Alex"]["segments"]), 5.0)
        self.assertAlmostEqual(sum(s["width_pct"] for s in by_name["Wessam"]["segments"]), 10.0)

    def test_bar_length_is_relative_to_the_busiest_person_not_absolute(self):
        rows = (
            [_row(submitted="2026-08-01", support="Alex")] * 20
            + [_row(submitted="2026-08-02", support="John")] * 10
        )
        matrix = build_daily_matrix(rows, 2026, 8)
        by_name = {p["name"]: p for p in matrix["person_rows"]}
        self.assertEqual(sum(s["width_pct"] for s in by_name["Alex"]["segments"]), 100.0)
        self.assertEqual(sum(s["width_pct"] for s in by_name["John"]["segments"]), 50.0)

    def test_person_total_equals_sum_of_own_segment_counts(self):
        rows = [
            _row(submitted="2026-08-01", support="Alex"),
            _row(submitted="2026-08-05", support="Alex"),
            _row(submitted="2026-08-12", support="Alex"),
        ]
        matrix = build_daily_matrix(rows, 2026, 8)
        alex = matrix["person_rows"][0]
        self.assertEqual(alex["total"], 3)
        self.assertEqual(sum(s["count"] for s in alex["segments"]), alex["total"])

    def test_segment_counts_match_the_tables_day_rows_exactly(self):
        rows = [
            _row(submitted="2026-08-01", support="Alex"),
            _row(submitted="2026-08-01", support="John"),
            _row(submitted="2026-08-01", support="John"),
            _row(submitted="2026-08-12", support="Alex"),
        ]
        matrix = build_daily_matrix(rows, 2026, 8)
        for day in matrix["day_rows"]:
            for idx, support in enumerate(matrix["support_people"]):
                table_count = day["counts"][idx]
                person = next(p for p in matrix["person_rows"] if p["name"] == support)
                seg = next((s for s in person["segments"] if s["day"] == day["day"]), None)
                chart_count = seg["count"] if seg else 0
                self.assertEqual(chart_count, table_count, msg=(support, day["label"]))

    def test_segments_within_a_bar_are_sorted_chronologically(self):
        rows = [
            _row(submitted="2026-08-15", support="Alex"),
            _row(submitted="2026-08-02", support="Alex"),
            _row(submitted="2026-08-30", support="Alex"),
        ]
        matrix = build_daily_matrix(rows, 2026, 8)
        alex = matrix["person_rows"][0]
        labels = [s["label"] for s in alex["segments"]]
        self.assertEqual(labels, ["02 Aug", "15 Aug", "30 Aug"])

    def test_every_segment_in_a_bar_uses_that_persons_own_colour(self):
        rows = [
            _row(submitted="2026-08-01", support="Alex"),
            _row(submitted="2026-08-05", support="Alex"),
        ]
        matrix = build_daily_matrix(rows, 2026, 8)
        alex = matrix["person_rows"][0]
        self.assertEqual(len(alex["segments"]), 2)
        # Colour lives once on the row, not per-segment - confirms the
        # template will render every segment in this bar identically.
        self.assertTrue(alex["color"].startswith("#"))

    def test_unassigned_gets_its_own_distinct_colour(self):
        rows = [
            _row(submitted="2026-08-01", support="Alex"),
            _row(submitted="2026-08-01", support=None),
        ]
        matrix = build_daily_matrix(rows, 2026, 8)
        by_name = {p["name"]: p["color"] for p in matrix["person_rows"]}
        self.assertIn("Unassigned", by_name)
        self.assertNotEqual(by_name["Unassigned"], by_name["Alex"])

    def test_every_support_person_has_exactly_one_colour(self):
        rows = [
            _row(submitted="2026-08-01", support=name)
            for name in ["Alex", "John", "Sarah", "Mo", "Zoe", "Anum", "Omar", "Wessam", "Yumna"]
        ]
        matrix = build_daily_matrix(rows, 2026, 8)
        self.assertEqual(len(matrix["person_rows"]), len(matrix["support_people"]))
        self.assertTrue(all(p["color"].startswith("#") for p in matrix["person_rows"]))

    def test_person_rows_ordered_alphabetically_matching_the_table(self):
        rows = [
            _row(submitted="2026-08-01", support="Zed"),
            _row(submitted="2026-08-01", support="Amy"),
        ]
        matrix = build_daily_matrix(rows, 2026, 8)
        names = [p["name"] for p in matrix["person_rows"]]
        self.assertEqual(names, matrix["support_people"])
        self.assertEqual(names, ["Amy", "Zed"])

    def test_empty_month_produces_no_person_rows_and_does_not_crash(self):
        matrix = build_daily_matrix([], 2026, 8)
        self.assertEqual(matrix["person_rows"], [])


class GenericDateAndPersonFieldTests(unittest.TestCase):
    """Doc Check reuses list_available_months()/build_daily_matrix() with
    date_field="Docs Approved"/person_field="QA" instead of Submissions'
    defaults - these tests protect that generalisation directly, using
    Doc Check's own field names rather than Submissions'."""

    def _row(self, docs_approved=None, qa=None):
        return {"Docs Approved": docs_approved, "QA": qa}

    def test_list_available_months_honours_a_different_date_field(self):
        rows = [
            self._row(docs_approved="2026-08-01"),
            self._row(docs_approved="2026-07-15"),
            # Submitted To Uni is absent entirely - must be irrelevant here.
        ]
        self.assertEqual(
            list_available_months(rows, date_field="Docs Approved"), [(2026, 8), (2026, 7)]
        )

    def test_build_daily_matrix_honours_a_different_date_and_person_field(self):
        rows = [
            self._row(docs_approved="2026-08-01", qa="Alex"),
            self._row(docs_approved="2026-08-01", qa="Alex"),
            self._row(docs_approved="2026-08-02", qa="John"),
        ]
        matrix = build_daily_matrix(rows, 2026, 8, date_field="Docs Approved", person_field="QA")
        self.assertEqual(matrix["support_people"], ["Alex", "John"])
        self.assertEqual(matrix["grand_total"], 3)
        totals = dict(zip(matrix["support_people"], matrix["support_totals"]))
        self.assertEqual(totals, {"Alex": 2, "John": 1})

    def test_blank_qa_officer_becomes_unassigned(self):
        rows = [self._row(docs_approved="2026-08-01", qa="")]
        matrix = build_daily_matrix(rows, 2026, 8, date_field="Docs Approved", person_field="QA")
        self.assertEqual(matrix["support_people"], ["Unassigned"])

    def test_defaults_still_match_submissions_behaviour(self):
        # Omitting date_field/person_field must behave exactly as before -
        # Submissions' own tests above are the real regression coverage,
        # this just confirms the default arguments themselves are correct.
        rows = [_row(submitted="2026-08-01", support="Alex")]
        matrix = build_daily_matrix(rows, 2026, 8)
        self.assertEqual(matrix["support_people"], ["Alex"])


if __name__ == "__main__":
    unittest.main()
