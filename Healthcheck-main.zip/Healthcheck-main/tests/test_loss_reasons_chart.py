"""Application Manager Pipeline page: the Loss Reasons by Application Manager chart under the
Pipeline Health chart - the page's Lost applications by Application Manager and main Lost
Reason, from the 2027 intakes onwards, with a click-through window listing them."""

import io
import unittest
from contextlib import contextmanager
from urllib.parse import parse_qs, urlencode

from flask import template_rendered

from colors import UNASSIGNED_COLOR, CATEGORICAL_PALETTE
from loss_reasons_chart import LOSS_RECORD_COLUMNS, build_loss_reason_chart, in_scope, loss_reason_records, lost_rows, spaced
from tests.flask_test_support import IsolatedAppTestCase, app_module, extract_token
from tests.test_just_jon_records import LOOKUPS as BASE_LOOKUPS
from tests.test_upload_atomicity import book, row

LOOKUPS = {**BASE_LOOKUPS, "status": BASE_LOOKUPS["status"] + [("Rejected", "10-Lost")]}
EXTRA = ["Lost Reason", "Lost Sub Reason"]
EVIL = "<img src=x onerror=alert(1)>"


def app_row(code, intake, status, officer, consultant, reason="", sub_reason="", university="Uni A", name=None):
    return row(**{"Student Code": code, "Student Name": name or f"Student {code}", "Application Status": status, "Intake": intake,
                  "Admission Officer": officer, "Counsellor": consultant, "University Name": university,
                  "Lost Reason": reason, "Lost Sub Reason": sub_reason})


ROWS = [
    app_row("L1", "March 2027", "Cancelled", "Mo Y", "Mel M", "Student Withdrew", "Changed mind"),
    app_row("L2", "March 2027", "Cancelled", "Nouran X", "Mel M", "Student Withdrew", "Financial", university="Uni B"),
    app_row("L3", "April 2027", "Cancelled", "Mo Y", "Hannah H", "Course Issue", "Wrong course"),
    app_row("L4", "September 2027", "Cancelled", "Mo Y", "Hannah H", "Student Withdrew", "Changed mind"),
    app_row("L5", "March 2027", "Cancelled", "Nouran X", "Raneen R"),                                  # no reason recorded
    app_row("L6", "March 2027", "Cancelled", "Mo Y", "", "Course Issue", "Other", name=EVIL),          # no Consultant
    app_row("L7", "March 2027", "Cancelled", "Admission X", "Mel M", "Course Issue", "Other"),         # "Admission" is not a real manager
    app_row("L8", "March 2027", "Cancelled", "Mo Y", "Mel M", "Course Issue", "Other"),                # lost ... but alive next year
    app_row("L8", "January 2028", "Assessment", "Mo Y", "Mel M"),
    app_row("L9", "March 2027", "Rejected", "Mo Y", "Mel M", "Course Issue", "Other"),                 # not a Cancelled, so the Pipeline drops it
    app_row("L11", "March 2027", "Cancelled", "", "Mel M", "Course Issue", "Other"),                   # no Application Manager: not on the Pipeline chart
    app_row("L12", "March 2027", "Cancelled", "Nouran X", "Raneen R", "StudentWithdrew", "ChangedMind"),   # the system runs the words together
    app_row("A1", "March 2027", "Assessment", "Mo Y", "Mel M"),                                        # not lost
    app_row("A2", "May 2027", "Assessment", "Mo Y", "Mel M"),                                          # a month with nothing lost
    app_row("Z1", "October 2026", "Cancelled", "Mo Y", "Mel M", "Course Issue", "Other"),              # a 2026 intake
]


@contextmanager
def captured():
    rendered = []

    def record(sender, template, context, **extra):
        rendered.append((template.name, dict(context)))

    template_rendered.connect(record, app_module.app)
    try:
        yield rendered
    finally:
        template_rendered.disconnect(record, app_module.app)


def lost(manager, reason, sub="", code="X", consultant="Gina", university="Uni A", student=""):
    return {"Application": manager, "Lost Reason": reason, "Lost Sub Reason": sub, "Student Code": code, "Student Name": student or f"Student {code}",
            "Consultant": consultant, "University Name": university}


class ChartTests(unittest.TestCase):
    ROWS = [lost("Mel", "Withdrew", code="1"), lost("Mel", "Withdrew", code="2"), lost("Mel", "Course", code="3"),
            lost("Hannah", "Course", code="4"), lost("Hannah", "Course", code="5"), lost("Abby", "Course", code="6"),
            lost("", "Withdrew", code="7"), lost("Gina", "", code="8"), lost("Gina", "  ", code="9"), lost("Zed", "Other", code="10")]

    def setUp(self):
        self.chart = build_loss_reason_chart(self.ROWS)

    def test_the_legend_lists_each_reason_most_first_with_a_colour_each(self):
        self.assertEqual([(r["name"], r["count"]) for r in self.chart["reasons"]], [("Course", 4), ("Withdrew", 3), ("Unassigned", 2), ("Other", 1)])
        self.assertEqual([r["color"] for r in self.chart["reasons"]], [CATEGORICAL_PALETTE[0], CATEGORICAL_PALETTE[1], UNASSIGNED_COLOR, CATEGORICAL_PALETTE[2]])
        self.assertEqual(self.chart["total"], 10)

    def test_a_blank_reason_is_unassigned_and_grey(self):
        gina = next(r for r in self.chart["rows"] if r["name"] == "Gina")
        self.assertEqual([(s["reason"], s["count"], s["color"]) for s in gina["segments"]], [("Unassigned", 2, UNASSIGNED_COLOR)])

    def test_managers_run_most_first_then_a_to_z_with_unassigned_last(self):
        self.assertEqual([(r["name"], r["total"]) for r in self.chart["rows"]],
                         [("Mel", 3), ("Gina", 2), ("Hannah", 2), ("Abby", 1), ("Zed", 1), ("Unassigned", 1)])

    def test_the_order_is_by_total_then_name_without_regard_to_case_and_unassigned_is_last(self):
        chart = build_loss_reason_chart([lost("bea", "R", code="1"), lost("Amy", "R", code="2"), lost("", "R", code="3"), lost("", "R", code="4"),
                                         lost("", "R", code="5"), lost("Cal", "R", code="6"), lost("Cal", "R", code="7")])
        self.assertEqual([(r["name"], r["total"]) for r in chart["rows"]], [("Cal", 2), ("Amy", 1), ("bea", 1), ("Unassigned", 3)])

    def test_each_managers_segments_follow_the_legend_order_and_the_main_reason_is_the_biggest(self):
        mel = next(r for r in self.chart["rows"] if r["name"] == "Mel")
        self.assertEqual([(s["reason"], s["count"]) for s in mel["segments"]], [("Course", 1), ("Withdrew", 2)])
        self.assertEqual(mel["main_reason"], "Withdrew")
        self.assertEqual(next(r for r in self.chart["rows"] if r["name"] == "Abby")["main_reason"], "Course")

    def test_a_tie_for_main_reason_goes_to_the_reason_with_more_applications_overall(self):
        chart = build_loss_reason_chart([lost("Amy", "Rare", code="1"), lost("Amy", "Common", code="2"), lost("Bo", "Common", code="3")])
        self.assertEqual(next(r for r in chart["rows"] if r["name"] == "Amy")["main_reason"], "Common")

    def test_bar_widths_are_a_share_of_the_busiest_manager(self):
        mel = next(r for r in self.chart["rows"] if r["name"] == "Mel")
        self.assertAlmostEqual(sum(s["width_pct"] for s in mel["segments"]), 100)
        self.assertEqual([round(s["width_pct"], 2) for s in mel["segments"]], [33.33, 66.67])
        abby = next(r for r in self.chart["rows"] if r["name"] == "Abby")
        self.assertAlmostEqual(abby["segments"][0]["width_pct"], 100 / 3)

    def test_the_numbers_add_up(self):
        self.assertEqual(sum(r["total"] for r in self.chart["rows"]), 10)
        self.assertEqual(sum(s["count"] for r in self.chart["rows"] for s in r["segments"]), 10)
        self.assertEqual(sum(r["count"] for r in self.chart["reasons"]), 10)

    def test_nothing_lost_is_an_empty_chart(self):
        self.assertEqual(build_loss_reason_chart([]), {"reasons": [], "rows": [], "total": 0})

    def test_reasons_and_managers_are_trimmed_and_matched_whole(self):
        chart = build_loss_reason_chart([lost(" Mel ", " Withdrew ", code="1"), lost("Mel", "Withdrew", code="2")])
        self.assertEqual([(r["name"], r["total"]) for r in chart["rows"]], [("Mel", 2)])
        self.assertEqual([r["name"] for r in chart["reasons"]], ["Withdrew"])

    def test_the_colours_repeat_rather_than_run_out(self):
        chart = build_loss_reason_chart([lost("Mel", f"R{i:02}", code=str(i)) for i in range(len(CATEGORICAL_PALETTE) + 3)])
        self.assertEqual(len(chart["reasons"]), len(CATEGORICAL_PALETTE) + 3)
        self.assertTrue(all(r["color"] for r in chart["reasons"]))

    def test_words_the_system_ran_together_are_split_so_they_group_with_the_spaced_ones(self):
        chart = build_loss_reason_chart([lost("Mel", "StudentWithdrew", code="1"), lost("Mel", "Student Withdrew", code="2"), lost("Amy", "student_withdrew", code="3")])
        self.assertEqual([(r["name"], r["count"]) for r in chart["reasons"]], [("Student Withdrew", 2), ("student withdrew", 1)])

    def test_only_2027_and_later(self):
        self.assertEqual([in_scope(y) for y in (2026, 2027, 2028)], [False, True, True])


class SpacedTests(unittest.TestCase):
    def test_a_space_goes_in_where_a_capital_starts_a_new_word(self):
        for raw, shown in (("StudentWithdrew", "Student Withdrew"), ("ChangedMind", "Changed Mind"), ("CourseNotRightForMe", "Course Not Right For Me"),
                           ("QAFailed", "QA Failed")):
            self.assertEqual(spaced(raw), shown, raw)

    def test_words_already_apart_are_left_alone(self):
        for text in ("Student Withdrew", "Changed mind", "Other", "Unassigned", "Course not right", "QA", "N/A", ""):
            self.assertEqual(spaced(text), text)

    def test_underscores_become_spaces_and_extra_spaces_go(self):
        self.assertEqual(spaced("student_withdrew"), "student withdrew")
        self.assertEqual(spaced("  Student   Withdrew "), "Student Withdrew")
        self.assertEqual(spaced(None), "")

    def test_the_reason_and_sub_reason_in_the_window_are_spaced(self):
        record = loss_reason_records([lost("Mo", "StudentWithdrew", "ChangedMind", code="1")], "Mo", "Student Withdrew")[0]
        self.assertEqual((record["reason"], record["sub_reason"]), ("Student Withdrew", "Changed Mind"))
        self.assertEqual(loss_reason_records([lost("Mo", "StudentWithdrew", code="1")], "Mo", "StudentWithdrew"), [])    # asked for as the chart names it


class RecordsTests(unittest.TestCase):
    ROWS = [lost("Mel", "Withdrew", "Changed mind", code="2", consultant="Mo", university="Uni A", student="bea"),
            lost("Mel", "Withdrew", "", code="1", consultant="", university="", student="Amy"),
            lost("Mel", "Course", "Wrong", code="3"), lost("Gina", "Withdrew", "x", code="4"), lost("", "Withdrew", "y", code="5"), lost("Mel", "", "z", code="6")]

    def test_the_records_hold_one_managers_applications_for_one_reason(self):
        records = loss_reason_records(self.ROWS, "Mel", "Withdrew")
        self.assertEqual([r["code"] for r in records], ["1", "2"])
        self.assertEqual(records[1], {"code": "2", "student": "bea", "university": "Uni A", "intake": "", "consultant": "Mo", "manager": "Mel",
                                      "reason": "Withdrew", "sub_reason": "Changed mind"})

    def test_blanks_read_unassigned_as_on_the_chart(self):
        first = loss_reason_records(self.ROWS, "Mel", "Withdrew")[0]
        self.assertEqual((first["consultant"], first["university"], first["sub_reason"]), ("Unassigned", "Unassigned", "Unassigned"))
        self.assertEqual([r["code"] for r in loss_reason_records(self.ROWS, "Unassigned", "Withdrew")], ["5"])
        self.assertEqual([r["code"] for r in loss_reason_records(self.ROWS, "Mel", "Unassigned")], ["6"])

    def test_nothing_for_a_manager_or_reason_that_is_not_there(self):
        self.assertEqual(loss_reason_records(self.ROWS, "Nobody", "Withdrew"), [])
        self.assertEqual(loss_reason_records(self.ROWS, "Mel", "withdrew"), [])
        self.assertEqual(loss_reason_records(self.ROWS, "", ""), [])

    def test_the_columns_are_the_ones_asked_for_in_order(self):
        self.assertEqual([c[0] for c in LOSS_RECORD_COLUMNS],
                         ["PES Code", "Student", "Application Manager", "Consultant", "University", "Loss Reason", "Sub Reason"])
        record = loss_reason_records(self.ROWS, "Mel", "Course")[0]
        self.assertTrue(all(key in record for _, key in LOSS_RECORD_COLUMNS))

    def test_lost_rows_reads_the_lost_bar_off_a_report(self):
        report = {"office_groups": [{"managers": [{"rows_by_stage": {"10-Lost": [1, 2], "09-Enrolled": [9]}}, {"rows_by_stage": {"10-Lost": [3]}}, {}]},
                                    {"managers": [{"rows_by_stage": {}}]}]}
        self.assertEqual(lost_rows(report), [1, 2, 3])


class PageBase(IsolatedAppTestCase):
    DATA = ROWS

    def setUp(self):
        super().setUp()
        self.full = self._client_logged_in_as("full")
        token = extract_token(self.full.get("/login").get_data(as_text=True))
        data = book(self.DATA, lookups=LOOKUPS, extra_columns=EXTRA)
        self.assertEqual(self.full.post("/upload", data={"csrf_token": token, "excel_file": (io.BytesIO(data), "f.xlsx")}, content_type="multipart/form-data").status_code, 302)

    def page(self, query="year=2027", client=None):
        with captured() as rendered:
            r = (client or self.full).get("/dashboard?" + query)
        self.assertEqual(r.status_code, 200, query)
        return r.get_data(as_text=True), next(c for name, c in rendered if name == "dashboard.html")

    def records(self, query, manager, reason, client=None):
        return (client or self.full).get("/dashboard/loss-records?" + query + "&" + urlencode({"manager": manager, "reason": reason}))

    def section(self, html):
        start = html.index("<h2>Loss Reasons by Application Manager</h2>")
        return html[start:html.index("</section>", start)]


class PageTests(PageBase):
    def test_the_chart_is_under_the_pipeline_health_chart(self):
        html, _ = self.page()
        self.assertEqual(html.count("<h2>Loss Reasons by Application Manager</h2>"), 1)
        self.assertLess(html.index("<h2>Application Manager Pipeline Health</h2>"), html.index("<h2>Loss Reasons by Application Manager</h2>"))
        self.assertLess(html.index("chart-legend"), html.index("<h2>Loss Reasons by Application Manager</h2>"))

    def test_it_counts_the_pages_lost_applications_by_application_manager_and_main_reason(self):
        _, context = self.page()
        chart = context["loss_reason_chart"]
        self.assertEqual([(r["name"], r["total"], r["main_reason"]) for r in chart["rows"]], [("Mo", 4, "Student Withdrew"), ("Nouran", 3, "Student Withdrew")])
        self.assertEqual([(r["name"], r["count"]) for r in chart["reasons"]], [("Student Withdrew", 4), ("Course Issue", 2), ("Unassigned", 1)])
        self.assertEqual({r["name"]: [(s["reason"], s["count"]) for s in r["segments"]] for r in chart["rows"]},
                         {"Mo": [("Student Withdrew", 2), ("Course Issue", 2)], "Nouran": [("Student Withdrew", 2), ("Unassigned", 1)]})

    def test_it_agrees_with_the_lost_bar_of_the_pipeline_health_chart(self):
        _, context = self.page()
        lost_bar = sum(seg["count"] for g in context["pending_stage_chart_groups"] for row in g["rows"] for seg in row["segments"] if seg["key"] == "lost")
        self.assertEqual(lost_bar, 7)
        self.assertEqual(context["loss_reason_chart"]["total"], lost_bar)
        for row in context["pending_stage_chart_groups"][0]["rows"] + context["pending_stage_chart_groups"][1]["rows"]:
            lost_piece = sum(seg["count"] for seg in row["segments"] if seg["key"] == "lost")
            self.assertEqual({r["name"]: r["total"] for r in context["loss_reason_chart"]["rows"]}[row["name"]], lost_piece, row["name"])

    def test_an_application_with_no_manager_is_left_out_as_it_is_from_the_pipeline_chart(self):
        _, context = self.page()
        self.assertNotIn("Unassigned", [r["name"] for r in context["loss_reason_chart"]["rows"]])

    def test_it_follows_the_intake_tabs(self):
        for query, expected in (("year=2027&intake_month=3", {"Mo": 2, "Nouran": 3}), ("year=2027&intake=intake_03", {"Mo": 1}),
                                ("year=2027&intake=intake_01", {"Mo": 2, "Nouran": 3}), ("year=2027&intake=intake_02", {"Mo": 1})):
            _, context = self.page(query)
            self.assertEqual({r["name"]: r["total"] for r in context["loss_reason_chart"]["rows"]}, expected, query)

    def test_the_2026_page_does_not_have_it(self):
        html, context = self.page("year=2026")
        self.assertIsNone(context["loss_reason_chart"])
        self.assertNotIn("Loss Reasons by", html)
        self.assertIn("Application Manager Pipeline Health", html)

    def test_a_2027_page_with_nothing_lost_says_so(self):
        html, context = self.page("year=2027&intake_month=5")
        self.assertEqual(context["loss_reason_chart"], {"reasons": [], "rows": [], "total": 0})
        self.assertIn("No lost applications.", self.section(html))
        self.assertNotIn("chart-segment-clickable", self.section(html))

    def test_each_bar_piece_opens_the_loss_records_window_for_its_manager_and_reason(self):
        html, context = self.page()
        section = self.section(html)
        pieces = section.count("chart-segment-clickable")
        self.assertEqual(pieces, sum(len(r["segments"]) for r in context["loss_reason_chart"]["rows"]))
        self.assertEqual(section.count('data-records-url="/dashboard/loss-records"'), pieces)
        self.assertIn('data-records-params="manager=Mo&amp;reason=Student+Withdrew"', section)
        self.assertIn('data-records-title="Mo &mdash; Student Withdrew"', section)
        self.assertIn('data-count="2"', section)
        self.assertEqual(section.count(" data-records-wide"), pieces)      # a wider window than the Pipeline Health one: more columns, longer text
        self.assertIn('<dialog id="chart-records" class="chart-records"', html)
        self.assertIn('data-url="/dashboard/records"', html)             # the Pipeline Health chart keeps its own list and window

    def test_the_pipeline_health_pieces_are_unchanged(self):
        html, _ = self.page()
        health = html[html.index("<h2>Application Manager Pipeline Health</h2>"):html.index("<h2>Loss Reasons by Application Manager</h2>")]
        self.assertNotIn("loss-records", health)
        self.assertNotIn("data-records-wide", health)
        self.assertIn("data-records-params=\"manager=Mo&amp;group=lost\"", health)

    def test_the_legend_names_every_reason_with_its_count(self):
        html, _ = self.page()
        legend = self.section(html)
        legend = legend[legend.index("chart-legend"):]
        for text in ("Student Withdrew (4)", "Course Issue (2)", "Unassigned (1)"):
            self.assertIn(text, legend)

    def test_the_words_the_system_ran_together_are_spaced_on_the_page(self):
        html, _ = self.page()
        self.assertNotIn("StudentWithdrew", html)
        self.assertIn("Student Withdrew (4)", html)           # L12's "StudentWithdrew" is counted with the spaced ones

    def test_the_table_has_application_manager_total_and_main_reason_columns(self):
        html, _ = self.page()
        header = self.section(html)
        header = header[header.index("chart-columns-header"):header.index("chart-office-group")]
        for text in ("Application Manager", "Total", "Main Reason"):
            self.assertIn(text, header)
        self.assertIn('class="chart-col-main-reason" title="Student Withdrew">Student Withdrew', self.section(html))


class EscapingTests(PageBase):
    DATA = ROWS + [app_row("E1", "March 2027", "Cancelled", "Mo Y", "Mel M", EVIL, EVIL)]

    def test_a_reason_that_looks_like_html_is_text_on_the_page_and_in_the_window(self):
        html, _ = self.page()
        self.assertNotIn(EVIL, html)
        self.assertIn("&lt;img src=x onerror=alert(1)&gt;", self.section(html))
        data = self.records("year=2027", "Mo", EVIL).get_json()
        self.assertEqual([(r["code"], r["reason"], r["sub_reason"]) for r in data["records"]], [("E1", EVIL, EVIL)])


class RecordsEndpointTests(PageBase):
    def get(self, query, manager, reason):
        r = self.records(query, manager, reason)
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.headers["Cache-Control"], "no-store")
        return r.get_json()

    def test_it_lists_one_managers_applications_for_one_reason(self):
        data = self.get("year=2027", "Mo", "Student Withdrew")
        self.assertEqual((data["manager"], data["reason"], data["count"]), ("Mo", "Student Withdrew", 2))
        self.assertEqual(data["columns"], LOSS_RECORD_COLUMNS)
        self.assertEqual(data["records"][0]["code"], "L1")
        self.assertEqual(data["records"][1], {"code": "L4", "student": "Student L4", "university": "Uni A", "intake": "September 2027", "consultant": "Hannah",
                                              "manager": "Mo", "reason": "Student Withdrew", "sub_reason": "Changed mind"})

    def test_the_window_shows_the_manager_and_the_consultant(self):
        record = self.get("year=2027", "Mo", "Course Issue")["records"][1]
        self.assertEqual((record["code"], record["manager"], record["consultant"]), ("L3", "Mo", "Hannah"))

    def test_words_the_system_ran_together_are_spaced_in_the_window(self):
        data = self.get("year=2027", "Nouran", "Student Withdrew")
        self.assertEqual([(r["code"], r["reason"], r["sub_reason"]) for r in data["records"]], [("L12", "Student Withdrew", "Changed Mind"), ("L2", "Student Withdrew", "Financial")])

    def test_every_piece_of_the_chart_lists_exactly_the_number_it_shows(self):
        for query in ("year=2027", "year=2027&intake_month=3", "year=2027&intake=intake_03", "year=2027&intake=intake_01", "year=2027&intake_month=9"):
            _, context = self.page(query)
            for row in context["loss_reason_chart"]["rows"]:
                for seg in row["segments"]:
                    data = self.get(query, row["name"], seg["reason"])
                    self.assertEqual(data["count"], seg["count"], (query, row["name"], seg["reason"]))
                    self.assertEqual(len(data["records"]), seg["count"])

    def test_a_blank_reason_is_asked_for_as_unassigned(self):
        data = self.get("year=2027", "Nouran", "Unassigned")
        self.assertEqual([(r["code"], r["reason"], r["sub_reason"], r["consultant"]) for r in data["records"]], [("L5", "Unassigned", "Unassigned", "Raneen")])

    def test_a_blank_consultant_reads_unassigned_and_the_name_is_data_not_markup(self):
        data = self.get("year=2027", "Mo", "Course Issue")
        self.assertEqual([(r["code"], r["consultant"]) for r in data["records"]], [("L6", "Unassigned"), ("L3", "Hannah")])
        self.assertEqual(data["records"][0]["student"], EVIL)

    def test_the_tabs_in_the_address_narrow_the_list(self):
        self.assertEqual([r["code"] for r in self.get("year=2027", "Mo", "Student Withdrew")["records"]], ["L1", "L4"])
        self.assertEqual([r["code"] for r in self.get("year=2027&intake_month=3", "Mo", "Student Withdrew")["records"]], ["L1"])
        self.assertEqual([r["code"] for r in self.get("year=2027&intake_month=9", "Mo", "Student Withdrew")["records"]], ["L4"])
        self.assertEqual(self.get("year=2027&intake_month=9", "Nouran", "Student Withdrew")["records"], [])

    def test_the_applications_the_chart_leaves_out_are_not_listed(self):
        codes = {r["code"] for reason in ("Course Issue", "Student Withdrew", "Unassigned") for manager in ("Mo", "Nouran", "Unassigned", "Admission")
                 for r in self.get("year=2027", manager, reason)["records"]}
        self.assertEqual(codes, {"L1", "L2", "L3", "L4", "L5", "L6", "L12"})      # not L7 (Admission), L8, L9, L11 (no manager) or Z1 (2026)

    def test_2026_has_nothing_to_list(self):
        self.assertEqual(self.get("year=2026", "Mo", "Course Issue")["records"], [])

    def test_an_unknown_manager_reason_or_no_query_lists_nothing(self):
        for manager, reason in (("Nobody", "Course Issue"), ("Mo", "Nonsense"), ("", ""), ("mo", "Student Withdrew"), ("Mo", "StudentWithdrew")):
            self.assertEqual(self.get("year=2027", manager, reason)["records"], [], (manager, reason))
        r = self.full.get("/dashboard/loss-records")
        self.assertEqual((r.status_code, r.get_json()["records"]), (200, []))

    def test_you_have_to_be_logged_in(self):
        anonymous = app_module.app.test_client()
        r = anonymous.get("/dashboard/loss-records?year=2027&manager=Mo&reason=Student+Withdrew")
        self.assertEqual(r.status_code, 302)
        self.assertIn("/login", r.headers["Location"])

    def test_every_role_can_use_it_as_they_can_the_chart(self):
        for role in ("full", "admissions", "consultants", "marketing"):
            client = self._client_logged_in_as(role)
            self.assertEqual(self.records("year=2027", "Mo", "Student Withdrew", client).status_code, 200, role)
            self.assertEqual(client.get("/dashboard?year=2027").status_code, 200, role)

    def test_the_query_string_params_are_read_not_trusted_as_markup(self):
        data = self.get("year=2027", EVIL, EVIL)
        self.assertEqual(data["manager"], EVIL)
        self.assertEqual(data["records"], [])


if __name__ == "__main__":
    unittest.main()
