import unittest

from pipeline import (
    DEFERRED_STATUS,
    ENROLLED_CHART_STAGES,
    ENROLLED_STAGE_COLORS,
    ENROLLED_STAGES,
    INTAKE_BUCKET_KEYS,
    INTAKE_BUCKET_LABELS,
    INTAKE_MONTH_GROUPING_FROM_YEAR,
    JUST_JON_SUB_SOURCES,
    PIPELINE_INTAKE_YEAR,
    PIPELINE_INTAKE_YEARS,
    QA_REJECTED_STATUS,
    STAGE_COLORS,
    STAGES,
    build_chart_groups,
    build_chart_scale_markers,
    build_consultant_enrolled_chart,
    build_pipeline_report,
    build_stage_subset_chart_groups,
    build_summary_cards,
    drop_carried_forward_losses,
    filter_by_intake_bucket,
    filter_by_intake_year,
    filter_by_sub_source,
    intake_buckets_available_for_year,
    resolve_pipeline_rows_by_student,
    round_half_up,
)


def _zero_percentages():
    return {stage: 0 for stage in STAGES}


class RoundHalfUpTests(unittest.TestCase):
    def test_rounds_half_up_not_half_to_even(self):
        # Python's built-in round() would give round(0.5) == 0 (banker's
        # rounding) - this app's convention is "0.5 always rounds up".
        self.assertEqual(round_half_up(0.5), 1)
        self.assertEqual(round_half_up(1.5), 2)
        self.assertEqual(round_half_up(2.5), 3)

    def test_rounds_down_below_half(self):
        self.assertEqual(round_half_up(2.49), 2)

    def test_rounds_up_above_half(self):
        self.assertEqual(round_half_up(2.51), 3)

    def test_decimals_zero_still_returns_a_plain_int(self):
        # The default must stay exactly as before for every existing
        # caller (Forecast/Conversion figures all expect an int).
        result = round_half_up(2.5)
        self.assertIsInstance(result, int)
        self.assertEqual(result, 3)

    def test_decimals_one_rounds_half_up_to_one_decimal_place(self):
        # 0.25 is the exact boundary case that motivated this: Python's
        # round(0.25, 1) gives 0.2 (round-half-to-even), but this app's
        # "0.5 always rounds up" convention says 0.3.
        self.assertEqual(round_half_up(0.25, decimals=1), 0.3)
        self.assertEqual(round_half_up(3.0, decimals=1), 3.0)
        self.assertEqual(round_half_up(0.24, decimals=1), 0.2)


class BuildPipelineReportBasicsTests(unittest.TestCase):
    def setUp(self):
        self.percentages = _zero_percentages()
        self.percentages["02-PendingQA"] = 0
        self.percentages["09-Enrolled"] = 100

        self.rows = [
            {"Application": "Alice", "Office": "EG", "Status": "02-PendingQA"},
            {"Application": "Alice", "Office": "EG", "Status": "09-Enrolled"},
            {"Application": "Bob", "Office": "EG", "Status": "02-PendingQA"},
            {"Application": "Carol", "Office": "UK", "Status": "10-Lost"},
        ]
        self.report = build_pipeline_report(
            self.rows,
            self.percentages,
            person_field="Application",
            group_field="Office",
            group_priority=("EG", "UK"),
        )

    def test_stage_counts_by_person(self):
        alice = self._manager("EG", "Alice")
        self.assertEqual(alice["counts"]["02-PendingQA"], 1)
        self.assertEqual(alice["counts"]["09-Enrolled"], 1)
        self.assertEqual(alice["total"], 2)

    def test_grouping_by_office(self):
        offices = [g["office"] for g in self.report["office_groups"]]
        self.assertEqual(offices, ["EG", "UK"])

    def test_group_priority_ordering_falls_back_alphabetically_for_unlisted(self):
        rows = self.rows + [{"Application": "Dan", "Office": "ZZ", "Status": "02-PendingQA"}]
        report = build_pipeline_report(
            rows, self.percentages, person_field="Application", group_field="Office",
            group_priority=("EG", "UK"),
        )
        offices = [g["office"] for g in report["office_groups"]]
        self.assertEqual(offices, ["EG", "UK", "ZZ"])

    def test_group_totals(self):
        eg = self._group("EG")
        self.assertEqual(eg["total"], 3)
        self.assertEqual(eg["counts"]["02-PendingQA"], 2)
        self.assertEqual(eg["counts"]["09-Enrolled"], 1)

    def test_grand_total(self):
        self.assertEqual(self.report["grand_total_records"], 4)
        self.assertEqual(self.report["grand_total_counts"]["02-PendingQA"], 2)
        self.assertEqual(self.report["grand_total_counts"]["10-Lost"], 1)

    def test_forecast_calculation(self):
        # Alice: 1 record at 0% + 1 record at 100% -> raw 1.0 -> forecast 1
        alice = self._manager("EG", "Alice")
        self.assertEqual(alice["forecast"], 1)
        # Bob: 1 record at 0% -> forecast 0
        bob = self._manager("EG", "Bob")
        self.assertEqual(bob["forecast"], 0)

    def test_conversion_calculation(self):
        alice = self._manager("EG", "Alice")
        # forecast 1 / total 2 * 100 = 50
        self.assertEqual(alice["conversion"], 50)

    def test_grand_total_forecast_and_conversion(self):
        # Grand total forecast = Alice(1) + Bob(0) + Carol(0) = 1
        self.assertEqual(self.report["grand_total_forecast"], 1)
        # 1 / 4 * 100 = 25
        self.assertEqual(self.report["grand_total_conversion"], 25)

    def _group(self, office_name):
        return next(g for g in self.report["office_groups"] if g["office"] == office_name)

    def _manager(self, office_name, name):
        group = self._group(office_name)
        return next(m for m in group["managers"] if m["name"] == name)


class QaRejectedAndDeferredTrackingTests(unittest.TestCase):
    """build_pipeline_report()'s separate qa_rejected_count/deferred_count
    tracking (Finding 8's hybrid fix) - these two statuses are still never
    counted in counts/total/forecast (neither is in STAGES), matching every
    existing Pipeline report's behaviour unchanged, but are tallied
    separately so the University Pipeline (which doesn't pre-filter
    EXCLUDED_PIPELINE_STATUSES the way the Application Manager/Consultant
    Pipeline does) can surface their existence. Uses person_field="University
    Name", group_field=None - the same shape university_pipeline() actually
    calls this with."""

    def setUp(self):
        self.percentages = _zero_percentages()
        self.percentages["09-Enrolled"] = 100

    def _report(self, rows):
        return build_pipeline_report(
            rows,
            self.percentages,
            person_field="University Name",
            group_field=None,
        )

    def _university(self, report, name):
        group = report["office_groups"][0]
        return next(u for u in group["managers"] if u["name"] == name)

    def test_one_of_each_status_leaves_total_unchanged_and_excludes_newapp(self):
        rows = [
            {"University Name": "TSD", "Status": "09-Enrolled"},
            {"University Name": "TSD", "Status": QA_REJECTED_STATUS},
            {"University Name": "TSD", "Status": DEFERRED_STATUS},
            {"University Name": "TSD", "Status": "01-NewApp"},
        ]
        report = self._report(rows)
        tsd = self._university(report, "TSD")

        # Existing Total: only the one real tracked-stage record counts -
        # 01-NewApp, QA-Rejected and Deferred must not inflate it.
        self.assertEqual(tsd["total"], 1)
        self.assertEqual(tsd["counts"]["09-Enrolled"], 1)

        # The two newly-tracked counts - 01-NewApp is deliberately not
        # tracked anywhere by this fix, so it must not inflate either one.
        self.assertEqual(tsd["qa_rejected_count"], 1)
        self.assertEqual(tsd["deferred_count"], 1)

        self.assertEqual(report["grand_total_records"], 1)
        self.assertEqual(report["grand_total_qa_rejected"], 1)
        self.assertEqual(report["grand_total_deferred"], 1)

    def test_qa_rejected_only_university_still_appears_with_zero_total(self):
        # The confirmed live-data edge case (UKCBC): a university whose only
        # record is QA-Rejected must still appear in the report - not be
        # dropped entirely - showing Total 0 and qa_rejected_count 1.
        rows = [{"University Name": "UKCBC", "Status": QA_REJECTED_STATUS}]
        report = self._report(rows)
        ukcbc = self._university(report, "UKCBC")

        self.assertEqual(ukcbc["total"], 0)
        self.assertEqual(ukcbc["qa_rejected_count"], 1)
        self.assertEqual(ukcbc["deferred_count"], 0)
        self.assertEqual(report["grand_total_records"], 0)
        self.assertEqual(report["grand_total_qa_rejected"], 1)
        self.assertEqual(report["grand_total_deferred"], 0)

    def test_no_qa_rejected_or_deferred_records_gives_zero_counts(self):
        rows = [
            {"University Name": "Arden", "Status": "09-Enrolled"},
            {"University Name": "Arden", "Status": "10-Lost"},
        ]
        report = self._report(rows)
        arden = self._university(report, "Arden")

        self.assertEqual(arden["total"], 2)
        self.assertEqual(arden["qa_rejected_count"], 0)
        self.assertEqual(arden["deferred_count"], 0)
        self.assertEqual(report["grand_total_qa_rejected"], 0)
        self.assertEqual(report["grand_total_deferred"], 0)

    def test_grand_totals_sum_across_multiple_universities(self):
        rows = [
            {"University Name": "TSD", "Status": QA_REJECTED_STATUS},
            {"University Name": "TSD", "Status": QA_REJECTED_STATUS},
            {"University Name": "Arden", "Status": QA_REJECTED_STATUS},
            {"University Name": "Arden", "Status": DEFERRED_STATUS},
        ]
        report = self._report(rows)
        self.assertEqual(report["grand_total_qa_rejected"], 3)
        self.assertEqual(report["grand_total_deferred"], 1)


class FinalOnlyRoundingTests(unittest.TestCase):
    def test_forecast_is_rounded_once_at_the_end_not_per_stage(self):
        # Two stages, each contributing a raw 0.33 - summed first (0.66,
        # rounds up to 1) rather than rounded per-stage-then-summed
        # (0 + 0 = 0). This protects the "final-only rounding" convention
        # documented in pipeline.py.
        percentages = _zero_percentages()
        percentages["02-PendingQA"] = 33
        percentages["03-PendingSubmission"] = 33

        rows = [
            {"Application": "Alice", "Status": "02-PendingQA"},
            {"Application": "Alice", "Status": "03-PendingSubmission"},
        ]
        report = build_pipeline_report(
            rows, percentages, person_field="Application", group_field=None, group_priority=None,
        )
        alice = report["office_groups"][0]["managers"][0]
        self.assertEqual(alice["forecast"], 1)


class ZeroTotalHandlingTests(unittest.TestCase):
    def test_empty_dataset_does_not_raise_and_totals_are_zero(self):
        report = build_pipeline_report(
            [], _zero_percentages(), person_field="Application", group_field="Office",
        )
        self.assertEqual(report["office_groups"], [])
        self.assertEqual(report["grand_total_records"], 0)
        self.assertEqual(report["grand_total_forecast"], 0)
        self.assertEqual(report["grand_total_conversion"], 0)


class ExcludedAndHiddenPersonsTests(unittest.TestCase):
    def test_excluded_persons_are_dropped_entirely(self):
        rows = [
            {"Application": "admission", "Office": "EG", "Status": "02-PendingQA"},
            {"Application": "Alice", "Office": "EG", "Status": "02-PendingQA"},
        ]
        report = build_pipeline_report(
            rows, _zero_percentages(), person_field="Application", group_field="Office",
            excluded_persons={"admission"},
        )
        self.assertEqual(report["grand_total_records"], 1)
        self.assertEqual(report["excluded_record_count"], 1)
        names = [m["name"] for m in report["office_groups"][0]["managers"]]
        self.assertNotIn("admission", names)

    def test_hidden_persons_still_count_but_have_no_own_row(self):
        rows = [
            {"Application": "Daniel", "Office": "EG", "Status": "02-PendingQA"},
            {"Application": "Alice", "Office": "EG", "Status": "02-PendingQA"},
        ]
        report = build_pipeline_report(
            rows, _zero_percentages(), person_field="Application", group_field="Office",
            hidden_persons={"daniel"},
        )
        eg = report["office_groups"][0]
        # Group total still includes Daniel's record.
        self.assertEqual(eg["total"], 2)
        names = [m["name"] for m in eg["managers"]]
        self.assertNotIn("Daniel", names)
        self.assertIn("Alice", names)

    def test_blank_group_is_excluded_when_group_field_set(self):
        rows = [{"Application": "Alice", "Office": "", "Status": "02-PendingQA"}]
        report = build_pipeline_report(
            rows, _zero_percentages(), person_field="Application", group_field="Office",
        )
        self.assertEqual(report["office_groups"], [])
        self.assertEqual(report["excluded_record_count"], 1)

    def test_same_person_with_conflicting_groups_excludes_the_later_row(self):
        # person_field is often a first-token of a longer name while
        # group_field is looked up from the full name, so two different
        # real people (e.g. two Admission Officers who share a first name)
        # can collapse to the same person string here but genuinely belong
        # to different offices. The first-seen group must win - the
        # conflicting row must never be silently folded into it.
        rows = [
            {"Application": "John", "Office": "EG", "Status": "02-PendingQA"},
            {"Application": "John", "Office": "UK", "Status": "02-PendingQA"},
        ]
        report = build_pipeline_report(
            rows, _zero_percentages(), person_field="Application", group_field="Office",
            group_priority=None,
        )
        self.assertEqual(len(report["office_groups"]), 1)
        eg = report["office_groups"][0]
        self.assertEqual(eg["office"], "EG")
        self.assertEqual(eg["total"], 1)
        self.assertEqual(report["excluded_record_count"], 1)
        self.assertEqual(report["grand_total_records"], 1)


class NoGroupingTests(unittest.TestCase):
    def test_group_field_none_produces_single_implicit_group(self):
        rows = [
            {"Application": "Uni A", "Status": "02-PendingQA"},
            {"Application": "Uni B", "Status": "02-PendingQA"},
        ]
        report = build_pipeline_report(
            rows, _zero_percentages(), person_field="Application", group_field=None,
            group_priority=None,
        )
        self.assertEqual(len(report["office_groups"]), 1)
        self.assertIsNone(report["office_groups"][0]["office"])
        self.assertEqual(len(report["office_groups"][0]["managers"]), 2)


class BlankPersonLabelAndRankByTotalTests(unittest.TestCase):
    def test_blank_person_is_folded_into_label_instead_of_dropped(self):
        rows = [{"Application": "", "Status": "02-PendingQA"}]
        report = build_pipeline_report(
            rows, _zero_percentages(), person_field="Application", group_field=None,
            group_priority=None, blank_person_label="Unassigned",
        )
        names = [m["name"] for m in report["office_groups"][0]["managers"]]
        self.assertEqual(names, ["Unassigned"])
        self.assertEqual(report["excluded_record_count"], 0)

    def test_without_blank_person_label_blank_person_is_excluded(self):
        rows = [{"Application": "", "Status": "02-PendingQA"}]
        report = build_pipeline_report(
            rows, _zero_percentages(), person_field="Application", group_field=None,
            group_priority=None,
        )
        self.assertEqual(report["office_groups"], [])
        self.assertEqual(report["excluded_record_count"], 1)

    def test_rank_by_total_orders_by_total_descending_then_name_ascending(self):
        # University Pipeline's ranking behaviour: highest total first, ties
        # broken alphabetically.
        rows = (
            [{"Application": "Beth Uni", "Status": "02-PendingQA"}] * 5
            + [{"Application": "Zed Uni", "Status": "02-PendingQA"}] * 3
            + [{"Application": "Amy Uni", "Status": "02-PendingQA"}] * 3
        )
        report = build_pipeline_report(
            rows, _zero_percentages(), person_field="Application", group_field=None,
            group_priority=None, blank_person_label="Unassigned", rank_by_total=True,
        )
        names = [m["name"] for m in report["office_groups"][0]["managers"]]
        self.assertEqual(names, ["Beth Uni", "Amy Uni", "Zed Uni"])

    def test_default_ordering_is_alphabetical_not_by_total(self):
        rows = (
            [{"Application": "Zed", "Office": "EG", "Status": "02-PendingQA"}] * 5
            + [{"Application": "Amy", "Office": "EG", "Status": "02-PendingQA"}] * 1
        )
        report = build_pipeline_report(
            rows, _zero_percentages(), person_field="Application", group_field="Office",
            group_priority=("EG", "UK"),
        )
        names = [m["name"] for m in report["office_groups"][0]["managers"]]
        self.assertEqual(names, ["Amy", "Zed"])


class BuildSummaryCardsAndChartGroupsTests(unittest.TestCase):
    def test_summary_cards_include_one_per_office_plus_overall(self):
        rows = [
            {"Application": "Alice", "Office": "EG", "Status": "02-PendingQA"},
            {"Application": "Carol", "Office": "UK", "Status": "10-Lost"},
        ]
        report = build_pipeline_report(
            rows, _zero_percentages(), person_field="Application", group_field="Office",
            group_priority=("EG", "UK"),
        )
        cards = build_summary_cards(report)
        labels = [c["label"] for c in cards]
        self.assertEqual(labels, ["EG", "UK", "Overall"])
        overall = cards[-1]
        self.assertEqual(overall["total"], report["grand_total_records"])

    def test_chart_segment_widths_are_relative_to_the_largest_managers_total(self):
        rows = (
            [{"Application": "Alice", "Office": "EG", "Status": "02-PendingQA"}] * 2
            + [{"Application": "Bob", "Office": "EG", "Status": "02-PendingQA"}] * 1
        )
        report = build_pipeline_report(
            rows, _zero_percentages(), person_field="Application", group_field="Office",
            group_priority=("EG", "UK"),
        )
        chart_groups = build_chart_groups(report)
        eg_rows = {r["name"]: r for r in chart_groups[0]["rows"]}
        # Alice has the largest total (2) -> her segment(s) sum to 100%.
        alice_width = sum(s["width_pct"] for s in eg_rows["Alice"]["segments"])
        bob_width = sum(s["width_pct"] for s in eg_rows["Bob"]["segments"])
        self.assertAlmostEqual(alice_width, 100.0)
        self.assertAlmostEqual(bob_width, 50.0)


class BuildStageSubsetChartGroupsTests(unittest.TestCase):
    """The Enrolled Dashboard's own subset-of-STAGES chart - same
    reshaping idea as build_chart_groups(), but scoped to ENROLLED_STAGES
    (08-Pre-Enrolled/09-Enrolled) rather than every stage."""

    def _report(self, rows):
        return build_pipeline_report(
            rows, _zero_percentages(), person_field="Application", group_field="Office",
            group_priority=("EG", "UK"),
        )

    def test_pre_enrolled_is_grey_only_in_the_enrolled_override_not_shared_stage_colors(self):
        self.assertEqual(ENROLLED_STAGE_COLORS["08-Pre-Enrolled"], "#9aa4b2")
        self.assertEqual(ENROLLED_STAGE_COLORS["09-Enrolled"], STAGE_COLORS["09-Enrolled"])
        # The shared STAGE_COLORS used by every other Pipeline chart must
        # be untouched by this override.
        self.assertEqual(STAGE_COLORS["08-Pre-Enrolled"], "#189a61")

    def test_enrolled_chart_stages_excludes_pre_enrolled(self):
        self.assertEqual(ENROLLED_CHART_STAGES, ["09-Enrolled"])

    def test_chart_groups_built_from_chart_stages_never_segment_pre_enrolled(self):
        rows = [
            {"Application": "Alice", "Office": "EG", "Status": "08-Pre-Enrolled"},
            {"Application": "Alice", "Office": "EG", "Status": "09-Enrolled"},
        ]
        report = self._report(rows)
        chart_groups = build_stage_subset_chart_groups(report, ENROLLED_CHART_STAGES)
        alice = chart_groups[0]["rows"][0]
        stages_present = {seg["stage"] for seg in alice["segments"]}
        self.assertEqual(stages_present, {"09-Enrolled"})
        self.assertEqual(alice["total"], 1)  # only Enrolled counted, not Pre-Enrolled

    def test_chart_row_total_only_counts_the_given_stages(self):
        rows = [
            {"Application": "Alice", "Office": "EG", "Status": "08-Pre-Enrolled"},
            {"Application": "Alice", "Office": "EG", "Status": "05-Assessment"},
            {"Application": "Alice", "Office": "EG", "Status": "05-Assessment"},
        ]
        report = self._report(rows)
        chart_groups = build_stage_subset_chart_groups(report, ENROLLED_STAGES)
        alice = chart_groups[0]["rows"][0]
        self.assertEqual(alice["total"], 1)  # only the Pre-Enrolled row counts

    def test_chart_segments_only_cover_the_given_stages(self):
        rows = [
            {"Application": "Alice", "Office": "EG", "Status": "08-Pre-Enrolled"},
            {"Application": "Alice", "Office": "EG", "Status": "09-Enrolled"},
            {"Application": "Alice", "Office": "EG", "Status": "05-Assessment"},
        ]
        report = self._report(rows)
        chart_groups = build_stage_subset_chart_groups(report, ENROLLED_STAGES)
        alice = chart_groups[0]["rows"][0]
        stages_present = {seg["stage"] for seg in alice["segments"]}
        self.assertEqual(stages_present, {"08-Pre-Enrolled", "09-Enrolled"})

    def test_width_scales_against_the_busiest_managers_subset_total_not_grand_total(self):
        rows = (
            [{"Application": "Alice", "Office": "EG", "Status": "05-Assessment"}] * 10
            + [{"Application": "Alice", "Office": "EG", "Status": "09-Enrolled"}] * 2
            + [{"Application": "Bob", "Office": "EG", "Status": "09-Enrolled"}] * 2
        )
        report = self._report(rows)
        chart_groups = build_stage_subset_chart_groups(report, ENROLLED_STAGES)
        by_name = {r["name"]: r for r in chart_groups[0]["rows"]}
        # Alice's Grand Total (12) dwarfs Bob's (2), but their ENROLLED_STAGES
        # subset totals are equal (2 each) - so both bars should be full width.
        alice_width = sum(s["width_pct"] for s in by_name["Alice"]["segments"])
        bob_width = sum(s["width_pct"] for s in by_name["Bob"]["segments"])
        self.assertAlmostEqual(alice_width, 100.0)
        self.assertAlmostEqual(bob_width, 100.0)

    def test_zero_matching_rows_does_not_divide_by_zero(self):
        rows = [{"Application": "Alice", "Office": "EG", "Status": "05-Assessment"}]
        report = self._report(rows)
        chart_groups = build_stage_subset_chart_groups(report, ENROLLED_STAGES)
        alice = chart_groups[0]["rows"][0]
        self.assertEqual(alice["segments"], [])
        self.assertEqual(alice["total"], 0)


class FilterByIntakeYearTests(unittest.TestCase):
    def test_keeps_only_rows_matching_the_given_year(self):
        rows = [
            {"Intake": "September 2026"},
            {"Intake": "January 2027"},
            {"Intake": "August 2026"},
        ]
        filtered = filter_by_intake_year(rows, 2026)
        self.assertEqual(len(filtered), 2)
        self.assertTrue(all(r["Intake"].endswith("2026") for r in filtered))

    def test_excludes_the_configured_cutoff_year_by_default(self):
        # PIPELINE_INTAKE_YEAR is the constant the /dashboard route actually
        # uses - protects that it's still 2026 unless deliberately changed.
        self.assertEqual(PIPELINE_INTAKE_YEAR, 2026)

    def test_available_years_includes_the_default_and_2027_tab(self):
        # PIPELINE_INTAKE_YEARS drives the Dashboard page's year tabs - the
        # /dashboard route falls back to PIPELINE_INTAKE_YEAR for any
        # ?year= value outside this set.
        self.assertEqual(PIPELINE_INTAKE_YEARS, (2026, 2027))
        self.assertIn(PIPELINE_INTAKE_YEAR, PIPELINE_INTAKE_YEARS)

    def test_blank_intake_is_excluded_not_assumed_to_match(self):
        rows = [{"Intake": ""}, {"Intake": None}]
        self.assertEqual(filter_by_intake_year(rows, 2026), [])

    def test_malformed_intake_is_excluded_safely_without_raising(self):
        rows = [{"Intake": "not a real intake"}, {"Intake": "September"}]
        self.assertEqual(filter_by_intake_year(rows, 2026), [])

    def test_bare_year_string_is_still_recognised(self):
        # The parser only looks at the last whitespace-separated token, so
        # a value that's just the year on its own is reasonably treated as
        # a match rather than rejected as malformed.
        self.assertEqual(filter_by_intake_year([{"Intake": "2026"}], 2026), [{"Intake": "2026"}])

    def test_other_years_are_excluded(self):
        rows = [{"Intake": "March 2027"}, {"Intake": "February 2025"}]
        self.assertEqual(filter_by_intake_year(rows, 2026), [])

    def test_empty_input_returns_empty_list(self):
        self.assertEqual(filter_by_intake_year([], 2026), [])


class IntakeMonthBucketTests(unittest.TestCase):
    """The Intake 01/02/03 month sub-tabs, available from 2027 onwards
    (INTAKE_MONTH_GROUPING_FROM_YEAR) on every Intake-year-scoped page:
    Jan-Mar is Intake 01, Apr-Jun is Intake 02, Jul-Dec is Intake 03."""

    def test_grouping_starts_at_2027(self):
        self.assertEqual(INTAKE_MONTH_GROUPING_FROM_YEAR, 2027)

    def test_buckets_unavailable_for_2026(self):
        self.assertFalse(intake_buckets_available_for_year(2026))

    def test_buckets_available_for_2027_and_beyond(self):
        self.assertTrue(intake_buckets_available_for_year(2027))
        self.assertTrue(intake_buckets_available_for_year(2028))

    def test_buckets_unavailable_for_none(self):
        self.assertFalse(intake_buckets_available_for_year(None))

    def test_jan_feb_march_are_intake_01(self):
        rows = [{"Intake": "January 2027"}, {"Intake": "February 2027"}, {"Intake": "March 2027"}]
        self.assertEqual(filter_by_intake_bucket(rows, "intake_01"), rows)

    def test_april_may_june_are_intake_02(self):
        rows = [{"Intake": "April 2027"}, {"Intake": "May 2027"}, {"Intake": "June 2027"}]
        self.assertEqual(filter_by_intake_bucket(rows, "intake_02"), rows)

    def test_the_rest_of_the_year_is_intake_03(self):
        rows = [
            {"Intake": "July 2027"},
            {"Intake": "August 2027"},
            {"Intake": "September 2027"},
            {"Intake": "October 2027"},
            {"Intake": "November 2027"},
            {"Intake": "December 2027"},
        ]
        self.assertEqual(filter_by_intake_bucket(rows, "intake_03"), rows)

    def test_excludes_other_buckets(self):
        rows = [{"Intake": "January 2027"}]
        self.assertEqual(filter_by_intake_bucket(rows, "intake_02"), [])
        self.assertEqual(filter_by_intake_bucket(rows, "intake_03"), [])

    def test_matches_a_3_letter_month_abbreviation(self):
        rows = [{"Intake": "Sep 2027"}]
        self.assertEqual(filter_by_intake_bucket(rows, "intake_03"), rows)

    def test_is_case_insensitive(self):
        rows = [{"Intake": "january 2027"}, {"Intake": "JANUARY 2027"}]
        self.assertEqual(filter_by_intake_bucket(rows, "intake_01"), rows)

    def test_blank_intake_is_excluded(self):
        rows = [{"Intake": ""}, {"Intake": None}]
        self.assertEqual(filter_by_intake_bucket(rows, "intake_01"), [])

    def test_malformed_intake_is_excluded_safely_without_raising(self):
        rows = [{"Intake": "not a real intake"}, {"Intake": "2027"}]
        self.assertEqual(filter_by_intake_bucket(rows, "intake_01"), [])

    def test_empty_input_returns_empty_list(self):
        self.assertEqual(filter_by_intake_bucket([], "intake_01"), [])

    def test_bucket_keys_and_labels(self):
        self.assertEqual(INTAKE_BUCKET_KEYS, ("intake_01", "intake_02", "intake_03"))
        self.assertEqual(
            INTAKE_BUCKET_LABELS,
            {"intake_01": "Intake 01", "intake_02": "Intake 02", "intake_03": "Intake 03"},
        )


class FilterBySubSourceTests(unittest.TestCase):
    """Backs the Just Jon Dashboard copy, which shows only records whose
    Sub-Source matches any of JUST_JON_SUB_SOURCES."""

    def test_default_just_jon_sub_sources(self):
        self.assertEqual(JUST_JON_SUB_SOURCES, ("Jon Daniels TT", "Jon Daniels", "Just Jon"))

    def test_matches_case_insensitively(self):
        # The source workbook isn't consistent about capitalisation (e.g.
        # "Jon Daniels Tt" vs "Jon Daniels TT").
        rows = [{"Sub-Source": "Jon Daniels Tt"}, {"Sub-Source": "JON DANIELS TT"}]
        self.assertEqual(filter_by_sub_source(rows, JUST_JON_SUB_SOURCES), rows)

    def test_matches_jon_daniels_without_tt(self):
        rows = [{"Sub-Source": "Jon Daniels"}, {"Sub-Source": "jon daniels"}]
        self.assertEqual(filter_by_sub_source(rows, JUST_JON_SUB_SOURCES), rows)

    def test_matches_just_jon(self):
        rows = [{"Sub-Source": "Just Jon"}, {"Sub-Source": "JUST JON"}]
        self.assertEqual(filter_by_sub_source(rows, JUST_JON_SUB_SOURCES), rows)

    def test_excludes_other_sub_sources(self):
        rows = [{"Sub-Source": "Website"}, {"Sub-Source": "General London 2"}]
        self.assertEqual(filter_by_sub_source(rows, JUST_JON_SUB_SOURCES), [])

    def test_blank_sub_source_is_excluded_not_assumed_to_match(self):
        rows = [{"Sub-Source": ""}, {"Sub-Source": None}]
        self.assertEqual(filter_by_sub_source(rows, JUST_JON_SUB_SOURCES), [])

    def test_empty_input_returns_empty_list(self):
        self.assertEqual(filter_by_sub_source([], JUST_JON_SUB_SOURCES), [])


class DashboardIntakeYearFilteringTests(unittest.TestCase):
    """Protects that the intake-year filter is applied consistently to all
    3 Pipeline reports (Application Manager, Consultant, University),
    using the exact same generic build_pipeline_report() - no separate
    filtering logic per report."""

    def setUp(self):
        rows_2026 = [
            {"Application": "Alice", "Office": "EG", "Consultant": "Con1",
             "Sales Office": "OXF", "University Name": "Uni A",
             "Status": "02-PendingQA", "Intake": "September 2026"},
            {"Application": "Bob", "Office": "EG", "Consultant": "Con2",
             "Sales Office": "OXF", "University Name": "Uni B",
             "Status": "02-PendingQA", "Intake": "August 2026"},
        ]
        rows_2027 = [
            {"Application": "Carol", "Office": "EG", "Consultant": "Con3",
             "Sales Office": "OXF", "University Name": "Uni C",
             "Status": "02-PendingQA", "Intake": "January 2027"},
        ]
        self.rows = rows_2026 + rows_2027
        self.pipeline_rows = filter_by_intake_year(self.rows, PIPELINE_INTAKE_YEAR)
        self.percentages = _zero_percentages()

    def test_2027_intake_excluded_from_application_manager_report(self):
        report = build_pipeline_report(
            self.pipeline_rows, self.percentages, person_field="Application", group_field="Office",
        )
        names = [m["name"] for g in report["office_groups"] for m in g["managers"]]
        self.assertIn("Alice", names)
        self.assertIn("Bob", names)
        self.assertNotIn("Carol", names)
        self.assertEqual(report["grand_total_records"], 2)

    def test_2027_intake_excluded_from_consultant_report(self):
        report = build_pipeline_report(
            self.pipeline_rows, self.percentages, person_field="Consultant", group_field="Sales Office",
        )
        names = [m["name"] for g in report["office_groups"] for m in g["managers"]]
        self.assertNotIn("Con3", names)
        self.assertEqual(report["grand_total_records"], 2)

    def test_2027_intake_excluded_from_university_report(self):
        report = build_pipeline_report(
            self.pipeline_rows, self.percentages, person_field="University Name", group_field=None,
            blank_person_label="Unassigned", rank_by_total=True,
        )
        names = [m["name"] for g in report["office_groups"] for m in g["managers"]]
        self.assertNotIn("Uni C", names)
        self.assertEqual(report["grand_total_records"], 2)

    def test_unfiltered_rows_still_contain_the_2027_record_for_other_pages(self):
        # The filter only ever produces a separate list for the Pipeline
        # reports - it must never mutate or drop rows from the original
        # `rows` list other pages (KPI, Offer Days, etc.) go on to use.
        self.assertEqual(len(self.rows), 3)
        self.assertTrue(any(r["Application"] == "Carol" for r in self.rows))


class ResolvePipelineRowsByStudentTests(unittest.TestCase):
    """The Application Manager/Consultant Pipeline reports' one-row-per-
    Student-Code rule - see resolve_pipeline_rows_by_student()'s own
    docstring for the full rule."""

    def _row(self, student_code, status, created="2026-08-01", raw_application_status="", **overrides):
        row = {
            "Student Code": student_code,
            "Status": status,
            "Created": created,
            "_raw": {"Application Status": raw_application_status},
        }
        row.update(overrides)
        return row

    def test_a_single_row_per_student_passes_through_unchanged(self):
        rows = [self._row("PES1", "05-Assessment")]
        self.assertEqual(resolve_pipeline_rows_by_student(rows), rows)

    def test_excluded_statuses_are_dropped_entirely(self):
        for status in ("00-QARejected", "01-NewApp", "02-PendingQA", "11-Deferred"):
            rows = [self._row("PES1", status)]
            self.assertEqual(resolve_pipeline_rows_by_student(rows), [])

    def test_an_open_row_wins_over_a_lost_sibling(self):
        lost = self._row("PES1", "10-Lost", raw_application_status="Cancelled")
        open_row = self._row("PES1", "05-Assessment")
        result = resolve_pipeline_rows_by_student([lost, open_row])
        self.assertEqual(result, [open_row])

    def test_the_most_recently_created_open_row_wins_when_several_are_open(self):
        older = self._row("PES1", "05-Assessment", created="2026-08-01")
        newer = self._row("PES1", "06-Decision", created="2026-08-15")
        result = resolve_pipeline_rows_by_student([older, newer])
        self.assertEqual(result, [newer])

    def test_a_student_lost_more_than_once_keeps_only_the_most_recent_lost_row(self):
        older = self._row("PES1", "10-Lost", created="2026-08-01", raw_application_status="Cancelled")
        newer = self._row("PES1", "10-Lost", created="2026-08-20", raw_application_status="Cancelled")
        result = resolve_pipeline_rows_by_student([older, newer])
        self.assertEqual(result, [newer])

    def test_a_surviving_lost_row_only_counts_if_the_raw_reason_is_cancelled(self):
        rows = [self._row("PES1", "10-Lost", raw_application_status="App Rejected")]
        self.assertEqual(resolve_pipeline_rows_by_student(rows), [])

    def test_a_surviving_lost_row_counts_when_the_raw_reason_is_cancelled(self):
        rows = [self._row("PES1", "10-Lost", raw_application_status="Cancelled")]
        self.assertEqual(resolve_pipeline_rows_by_student(rows), rows)

    def test_an_unsubmitted_sibling_never_rescues_a_non_cancelled_lost_row(self):
        lost = self._row("PES1", "10-Lost", raw_application_status="App Rejected")
        rejected = self._row("PES1", "00-QARejected")
        self.assertEqual(resolve_pipeline_rows_by_student([lost, rejected]), [])

    def test_a_deferred_sibling_never_masks_a_lost_row(self):
        # Same failure mode as QA-Rejected above: a Deferred sibling isn't
        # a genuinely "open" application, so it must not cause a Lost row
        # to be silently dropped as if it were rescued by an open one.
        lost = self._row("PES1", "10-Lost", raw_application_status="Cancelled")
        deferred = self._row("PES1", "11-Deferred")
        self.assertEqual(resolve_pipeline_rows_by_student([lost, deferred]), [lost])

    def test_blank_student_code_rows_are_never_collapsed_together(self):
        rows = [self._row("", "05-Assessment"), self._row("", "06-Decision")]
        self.assertEqual(resolve_pipeline_rows_by_student(rows), rows)

    def test_different_students_are_independent(self):
        rows = [
            self._row("PES1", "10-Lost", raw_application_status="Cancelled"),
            self._row("PES2", "05-Assessment"),
        ]
        self.assertEqual(resolve_pipeline_rows_by_student(rows), rows)

    def test_a_tie_on_created_date_still_returns_exactly_one_row(self):
        a = self._row("PES1", "05-Assessment", created="2026-08-01")
        b = self._row("PES1", "06-Decision", created="2026-08-01")
        result = resolve_pipeline_rows_by_student([a, b])
        self.assertEqual(len(result), 1)
        self.assertIn(result[0], [a, b])


class DropCarriedForwardLossesTests(unittest.TestCase):
    """A student's 2026 Lost row shouldn't count if they also have a live
    application in a later Intake year - see drop_carried_forward_losses()'s
    own docstring for the full rule."""

    def _row(self, student_code, status, intake, **overrides):
        row = {"Student Code": student_code, "Status": status, "Intake": intake}
        row.update(overrides)
        return row

    def test_a_lost_row_is_dropped_when_the_student_has_a_live_row_next_year(self):
        lost_2026 = self._row("PES1", "10-Lost", "September 2026")
        live_2027 = self._row("PES1", "03-PendingSubmission", "September 2027")
        result = drop_carried_forward_losses([lost_2026], [lost_2026, live_2027], 2026)
        self.assertEqual(result, [])

    def test_a_lost_row_is_kept_when_the_student_has_no_later_row_at_all(self):
        lost_2026 = self._row("PES1", "10-Lost", "September 2026")
        result = drop_carried_forward_losses([lost_2026], [lost_2026], 2026)
        self.assertEqual(result, [lost_2026])

    def test_a_lost_row_is_kept_when_the_later_row_is_also_lost(self):
        lost_2026 = self._row("PES1", "10-Lost", "September 2026")
        also_lost_2027 = self._row("PES1", "10-Lost", "September 2027")
        result = drop_carried_forward_losses([lost_2026], [lost_2026, also_lost_2027], 2026)
        self.assertEqual(result, [lost_2026])

    def test_a_lost_row_is_kept_when_the_later_row_is_unsubmitted(self):
        lost_2026 = self._row("PES1", "10-Lost", "September 2026")
        rejected_2027 = self._row("PES1", "00-QARejected", "September 2027")
        result = drop_carried_forward_losses([lost_2026], [lost_2026, rejected_2027], 2026)
        self.assertEqual(result, [lost_2026])

    def test_a_lost_row_is_kept_when_the_later_row_is_deferred(self):
        lost_2026 = self._row("PES1", "10-Lost", "September 2026")
        deferred_2027 = self._row("PES1", "11-Deferred", "September 2027")
        result = drop_carried_forward_losses([lost_2026], [lost_2026, deferred_2027], 2026)
        self.assertEqual(result, [lost_2026])

    def test_an_earlier_year_live_row_does_not_drop_the_loss(self):
        lost_2026 = self._row("PES1", "10-Lost", "September 2026")
        live_2025 = self._row("PES1", "05-Assessment", "September 2025")
        result = drop_carried_forward_losses([lost_2026], [lost_2026, live_2025], 2026)
        self.assertEqual(result, [lost_2026])

    def test_a_non_lost_row_is_never_dropped_regardless_of_later_years(self):
        open_2026 = self._row("PES1", "05-Assessment", "September 2026")
        live_2027 = self._row("PES1", "03-PendingSubmission", "September 2027")
        result = drop_carried_forward_losses([open_2026], [open_2026, live_2027], 2026)
        self.assertEqual(result, [open_2026])

    def test_other_students_lost_rows_are_unaffected(self):
        lost_2026_a = self._row("PES1", "10-Lost", "September 2026")
        lost_2026_b = self._row("PES2", "10-Lost", "September 2026")
        live_2027_a = self._row("PES1", "05-Assessment", "September 2027")
        result = drop_carried_forward_losses(
            [lost_2026_a, lost_2026_b], [lost_2026_a, lost_2026_b, live_2027_a], 2026
        )
        self.assertEqual(result, [lost_2026_b])


class BuildConsultantEnrolledChartTests(unittest.TestCase):
    """The Enrolled Dashboard's Consultant chart - a flat, ranked list (no
    Sales Office grouping) of live 09-Enrolled counts (Intake 03) combined
    with manual Intake 01/02 backfill totals from the Consultant Lookup
    table."""

    def _row(self, consultant, status="09-Enrolled", sales_office="OXF"):
        return {"Consultant": consultant, "Status": status, "Sales Office": sales_office}

    def _manual(self, consultant, sales_office="OXF", intake_01=0, intake_02=0):
        return {"consultant": consultant, "sales_office": sales_office, "intake_01": intake_01, "intake_02": intake_02}

    def test_a_consultant_with_only_live_rows(self):
        rows = [self._row("Raneen")] * 3
        chart_rows = build_consultant_enrolled_chart(rows)
        raneen = chart_rows[0]
        self.assertEqual(raneen["name"], "Raneen")
        self.assertEqual(raneen["intake_03"], 3)
        self.assertEqual(raneen["intake_01"], 0)
        self.assertEqual(raneen["intake_02"], 0)
        self.assertEqual(raneen["total"], 3)

    def test_a_consultant_with_only_manual_backfill_and_no_live_rows(self):
        # e.g. someone who left before the CRM migration - no rows at all
        # in the current dataset, only a manual backfill total.
        manual = [self._manual("Daniel", intake_01=8, intake_02=4)]
        chart_rows = build_consultant_enrolled_chart([], manual)
        daniel = chart_rows[0]
        self.assertEqual(daniel["name"], "Daniel")
        self.assertEqual(daniel["intake_01"], 8)
        self.assertEqual(daniel["intake_02"], 4)
        self.assertEqual(daniel["intake_03"], 0)
        self.assertEqual(daniel["total"], 12)

    def test_live_and_manual_combine_for_the_same_consultant(self):
        rows = [self._row("Raneen")] * 3
        manual = [self._manual("Raneen", intake_01=2, intake_02=3)]
        chart_rows = build_consultant_enrolled_chart(rows, manual)
        raneen = chart_rows[0]
        self.assertEqual(raneen["intake_03"], 3)
        self.assertEqual(raneen["intake_01"], 2)
        self.assertEqual(raneen["intake_02"], 3)
        self.assertEqual(raneen["total"], 8)

    def test_non_enrolled_status_rows_are_ignored(self):
        rows = [self._row("Raneen", status="08-Pre-Enrolled")]
        chart_rows = build_consultant_enrolled_chart(rows)
        self.assertEqual(chart_rows, [])

    def test_blank_consultant_rows_are_skipped(self):
        rows = [self._row("")]
        chart_rows = build_consultant_enrolled_chart(rows)
        self.assertEqual(chart_rows, [])

    def test_blank_manual_consultant_is_skipped(self):
        manual = [self._manual("", intake_01=5)]
        chart_rows = build_consultant_enrolled_chart([], manual)
        self.assertEqual(chart_rows, [])

    def test_result_is_a_flat_list_not_grouped_by_office(self):
        rows = [self._row("Raneen", sales_office="OXF"), self._row("Mustapha", sales_office="CAR")]
        chart_rows = build_consultant_enrolled_chart(rows)
        names = {r["name"] for r in chart_rows}
        self.assertEqual(names, {"Raneen", "Mustapha"})
        for row in chart_rows:
            self.assertNotIn("office", row)

    def test_sorted_by_total_descending(self):
        rows = [self._row("Raneen")] * 2 + [self._row("Mustapha")] * 5 + [self._row("Mo")] * 3
        chart_rows = build_consultant_enrolled_chart(rows)
        self.assertEqual([r["name"] for r in chart_rows], ["Mustapha", "Mo", "Raneen"])

    def test_tied_totals_break_by_name_ascending(self):
        rows = [self._row("Zed")] * 2 + [self._row("Amy")] * 2
        chart_rows = build_consultant_enrolled_chart(rows)
        self.assertEqual([r["name"] for r in chart_rows], ["Amy", "Zed"])

    def test_width_scales_against_the_busiest_consultants_combined_total(self):
        rows = [self._row("Raneen")] * 2
        manual = [self._manual("Daniel", intake_01=8)]
        chart_rows = build_consultant_enrolled_chart(rows, manual)
        by_name = {r["name"]: r["width_pct"] for r in chart_rows}
        self.assertAlmostEqual(by_name["Daniel"], 100.0)
        self.assertAlmostEqual(by_name["Raneen"], 25.0)  # 2/8 * 100

    def test_empty_input_gives_empty_chart(self):
        self.assertEqual(build_consultant_enrolled_chart([], []), [])
        self.assertEqual(build_consultant_enrolled_chart([]), [])

    def test_segments_omit_a_zero_kind(self):
        rows = [self._row("Raneen")] * 3
        chart_rows = build_consultant_enrolled_chart(rows)
        raneen = chart_rows[0]
        self.assertEqual(len(raneen["segments"]), 1)
        self.assertEqual(raneen["segments"][0]["kind"], "intake_03")
        self.assertEqual(raneen["segments"][0]["count"], 3)

    def test_segments_include_all_three_kinds_when_all_are_present(self):
        rows = [self._row("Raneen")] * 3
        manual = [self._manual("Raneen", intake_01=2, intake_02=4)]
        chart_rows = build_consultant_enrolled_chart(rows, manual)
        raneen = chart_rows[0]
        by_kind = {seg["kind"]: seg["count"] for seg in raneen["segments"]}
        self.assertEqual(by_kind, {"intake_01": 2, "intake_02": 4, "intake_03": 3})

    def test_segments_are_ordered_intake_01_then_02_then_03(self):
        rows = [self._row("Raneen")] * 3
        manual = [self._manual("Raneen", intake_01=2, intake_02=4)]
        chart_rows = build_consultant_enrolled_chart(rows, manual)
        raneen = chart_rows[0]
        self.assertEqual([seg["kind"] for seg in raneen["segments"]], ["intake_01", "intake_02", "intake_03"])

    def test_segment_widths_sum_to_the_rows_total_width(self):
        rows = [self._row("Raneen")] * 3
        manual = [
            self._manual("Raneen", intake_01=2, intake_02=3),
            self._manual("Mo", intake_01=2),
        ]
        chart_rows = build_consultant_enrolled_chart(rows, manual)
        raneen = next(r for r in chart_rows if r["name"] == "Raneen")
        segment_width_total = sum(seg["width_pct"] for seg in raneen["segments"])
        self.assertAlmostEqual(segment_width_total, raneen["width_pct"])


class ConsultantEnrolledChartMonthBucketTests(unittest.TestCase):
    """From 2027 onwards there's no manual CRM-migration backfill, so
    use_month_buckets=True buckets each live row into Intake 01/02/03 by
    its own Intake month instead of always landing in Intake 03."""

    def _row(self, consultant, intake, status="09-Enrolled"):
        return {"Consultant": consultant, "Status": status, "Intake": intake}

    def test_rows_are_bucketed_by_intake_month(self):
        rows = [
            self._row("Raneen", "January 2027"),
            self._row("Raneen", "May 2027"),
            self._row("Raneen", "September 2027"),
        ]
        chart_rows = build_consultant_enrolled_chart(rows, use_month_buckets=True)
        raneen = chart_rows[0]
        self.assertEqual(raneen["intake_01"], 1)
        self.assertEqual(raneen["intake_02"], 1)
        self.assertEqual(raneen["intake_03"], 1)
        self.assertEqual(raneen["total"], 3)

    def test_without_the_flag_everything_still_lands_in_intake_03(self):
        # Default/2026 behavior is unchanged - only explicitly asking for
        # month buckets changes how a row is classified.
        rows = [self._row("Raneen", "January 2027")]
        chart_rows = build_consultant_enrolled_chart(rows)
        self.assertEqual(chart_rows[0]["intake_01"], 0)
        self.assertEqual(chart_rows[0]["intake_03"], 1)

    def test_a_row_with_an_unrecognised_intake_month_is_dropped(self):
        rows = [self._row("Raneen", "not a real intake"), self._row("Raneen", "January 2027")]
        chart_rows = build_consultant_enrolled_chart(rows, use_month_buckets=True)
        self.assertEqual(chart_rows[0]["total"], 1)

    def test_a_consultant_with_only_unrecognised_intake_months_is_excluded(self):
        rows = [self._row("Raneen", ""), self._row("Raneen", "bogus")]
        chart_rows = build_consultant_enrolled_chart(rows, use_month_buckets=True)
        self.assertEqual(chart_rows, [])

    def test_month_buckets_combine_with_manual_adjustments(self):
        # Not a realistic combination in practice (manual backfill is only
        # ever passed for 2026), but the two mechanisms shouldn't conflict.
        rows = [self._row("Daniel", "February 2027")]
        manual = [{"consultant": "Daniel", "intake_01": 5}]
        chart_rows = build_consultant_enrolled_chart(rows, manual, use_month_buckets=True)
        daniel = chart_rows[0]
        self.assertEqual(daniel["intake_01"], 6)
        self.assertEqual(daniel["total"], 6)

    def test_group_as_other_still_excludes_the_consultant_with_month_buckets(self):
        rows = [self._row("Daniel", "January 2027")]
        chart_rows = build_consultant_enrolled_chart(rows, group_as_other={"Daniel"}, use_month_buckets=True)
        self.assertEqual(chart_rows, [])


class ConsultantEnrolledChartGroupAsOtherTests(unittest.TestCase):
    """The Consultant Lookup table's "Group as Other" checkbox - a flagged
    Consultant is left off the Consultant chart entirely (this view is
    scoped to live team members only), not shown under their own name or
    folded into a shared "Other" row."""

    def _row(self, consultant, sales_office="OXF"):
        return {"Consultant": consultant, "Status": "09-Enrolled", "Sales Office": sales_office}

    def _manual(self, consultant, sales_office="OXF", intake_01=0, intake_02=0):
        return {"consultant": consultant, "sales_office": sales_office, "intake_01": intake_01, "intake_02": intake_02}

    def test_a_flagged_consultants_live_rows_are_excluded(self):
        rows = [self._row("Daniel")] * 3
        chart_rows = build_consultant_enrolled_chart(rows, group_as_other={"Daniel"})
        self.assertEqual(chart_rows, [])

    def test_match_is_case_insensitive(self):
        rows = [self._row("Daniel")] * 2
        chart_rows = build_consultant_enrolled_chart(rows, group_as_other={"daniel"})
        self.assertEqual(chart_rows, [])

    def test_multiple_flagged_consultants_are_all_excluded(self):
        rows = [self._row("Daniel")] * 2 + [self._row("Ahmed")] * 3
        chart_rows = build_consultant_enrolled_chart(rows, group_as_other={"Daniel", "Ahmed"})
        self.assertEqual(chart_rows, [])

    def test_an_unflagged_consultant_keeps_their_own_name(self):
        rows = [self._row("Raneen")] * 2
        chart_rows = build_consultant_enrolled_chart(rows, group_as_other={"Daniel"})
        self.assertEqual(chart_rows[0]["name"], "Raneen")

    def test_flagged_and_unflagged_consultants_mix(self):
        rows = [self._row("Daniel")] * 2 + [self._row("Raneen")] * 5
        chart_rows = build_consultant_enrolled_chart(rows, group_as_other={"Daniel"})
        self.assertEqual([r["name"] for r in chart_rows], ["Raneen"])

    def test_manual_backfill_for_a_flagged_consultant_is_also_excluded(self):
        manual = [self._manual("Daniel", intake_01=5)]
        chart_rows = build_consultant_enrolled_chart([], manual, group_as_other={"Daniel"})
        self.assertEqual(chart_rows, [])

    def test_no_group_as_other_leaves_everyone_under_their_own_name(self):
        rows = [self._row("Daniel")] * 2
        chart_rows = build_consultant_enrolled_chart(rows)
        self.assertEqual(chart_rows[0]["name"], "Daniel")


class BuildChartScaleMarkersTests(unittest.TestCase):
    """Vertical scale-reference lines for a chart whose bars are sized
    relative to the busiest row's total - only values that fit within the
    current max total are included."""

    def _rows(self, *totals):
        return [{"total": total} for total in totals]

    def test_only_values_at_or_below_the_max_total_appear(self):
        markers = build_chart_scale_markers(self._rows(90), values=[40, 60, 80, 100, 150, 200])
        self.assertEqual([m["value"] for m in markers], [40, 60, 80])

    def test_a_value_exactly_equal_to_the_max_total_appears(self):
        markers = build_chart_scale_markers(self._rows(100), values=[40, 100, 150])
        self.assertEqual([m["value"] for m in markers], [40, 100])

    def test_position_is_value_over_max_total(self):
        markers = build_chart_scale_markers(self._rows(200), values=[40, 100])
        by_value = {m["value"]: m["pct"] for m in markers}
        self.assertAlmostEqual(by_value[40], 20.0)
        self.assertAlmostEqual(by_value[100], 50.0)

    def test_max_total_taken_across_all_rows(self):
        markers = build_chart_scale_markers(self._rows(10, 200, 50), values=[100])
        self.assertEqual(markers[0]["pct"], 50.0)

    def test_empty_rows_gives_no_markers(self):
        self.assertEqual(build_chart_scale_markers([], values=[40, 100]), [])

    def test_all_zero_totals_gives_no_markers(self):
        self.assertEqual(build_chart_scale_markers(self._rows(0, 0), values=[40, 100]), [])

    def test_default_values_are_used_when_not_specified(self):
        markers = build_chart_scale_markers(self._rows(250))
        self.assertEqual([m["value"] for m in markers], [40, 60, 80, 100, 150, 200])


if __name__ == "__main__":
    unittest.main()
