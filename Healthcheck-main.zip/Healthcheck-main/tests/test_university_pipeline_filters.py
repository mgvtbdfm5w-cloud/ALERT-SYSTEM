"""University Pipeline: the Application Manager and Intake Month filters.

Pure helper tests, then route tests through the real upload route. The
options offered are always the ones relevant to the year tab (and Intake
01/02/03 tab) being viewed."""

import io
import re
import unittest
from contextlib import contextmanager

from flask import template_rendered

from pipeline import (
    filter_by_intake_months,
    intake_month_number,
    list_application_managers,
    list_consultants,
    list_intake_months,
    list_sales_offices,
    list_statuses,
)
from tests.flask_test_support import IsolatedAppTestCase, app_module, extract_token
from tests.test_upload_atomicity import book, row


class HelperTests(unittest.TestCase):
    def test_intake_month_number_reads_full_and_short_month_names_in_any_case(self):
        self.assertEqual([intake_month_number(v) for v in ("January 2027", "sep 2026", "DECEMBER 2026", " march  2027 ", "May 2027", "Sept 2026")],
                         [1, 9, 12, 3, 5, None])        # "Sept" is not a recognised spelling (same as the Intake 01/02/03 tabs)

    def test_intake_month_number_is_none_for_blank_or_unreadable_values(self):
        self.assertEqual([intake_month_number(v) for v in (None, "", "   ", "2026", "Smarch 2026", 5)], [None] * 6)

    def test_list_intake_months_is_the_months_present_in_calendar_order(self):
        rows = [{"Intake": v} for v in ("November 2026", "August 2026", "Sep 2026", "November 2026", "", None, "junk")]
        self.assertEqual(list_intake_months(rows), [8, 9, 11])
        self.assertEqual(list_intake_months([]), [])

    def test_filter_by_intake_months_takes_one_or_several_months(self):
        rows = [{"Intake": "September 2026", "n": 1}, {"Intake": "Sep 2027", "n": 2}, {"Intake": "October 2026", "n": 3}, {"Intake": "", "n": 4},
                {"Intake": "November 2026", "n": 5}]
        self.assertEqual([r["n"] for r in filter_by_intake_months(rows, [9])], [1, 2])
        self.assertEqual([r["n"] for r in filter_by_intake_months(rows, [9, 10])], [1, 2, 3])
        self.assertEqual([r["n"] for r in filter_by_intake_months(rows, {11, 10, 9})], [1, 2, 3, 5])
        self.assertEqual(filter_by_intake_months(rows, [12]), [])
        self.assertEqual(filter_by_intake_months(rows, []), [], "an empty selection is not a filter here - the caller skips filtering")

    def test_list_statuses_is_the_pipeline_statuses_present_in_pipeline_order(self):
        rows = [{"Status": v} for v in ("09-Enrolled", "05-Assessment", "10-Lost", "05-Assessment", "00-QARejected", "", None, "weird", " 04-Onboarding ")]
        self.assertEqual(list_statuses(rows), ["04-Onboarding", "05-Assessment", "09-Enrolled", "10-Lost"])
        self.assertEqual(list_statuses([]), [])

    def test_list_sales_offices_is_lon_car_man_oxf_then_others_then_unassigned(self):
        rows = [{"Sales Office": v} for v in ("OXF", "LON", "Other", "MAN", "", "CAR", "Zed", None, "oxf")]
        self.assertEqual(list_sales_offices(rows), ["LON", "CAR", "MAN", "OXF", "Other", "oxf", "Zed", "Unassigned"])
        self.assertEqual(list_sales_offices([{"Sales Office": "OXF"}, {"Sales Office": "MAN"}]), ["MAN", "OXF"], "only the offices that are there")
        self.assertEqual(list_sales_offices([{"Sales Office": ""}]), ["Unassigned"])
        self.assertEqual(list_sales_offices([]), [])
        self.assertEqual(list_sales_offices([{"Consultant": "Mel"}]), ["Unassigned"], "reads Sales Office, not Consultant")

    def test_list_consultants_is_alphabetical_with_blank_as_unassigned(self):
        rows = [{"Consultant": v} for v in ("raneen", "Mel", "Raneen", " Mel ", "", None, "  ", "Hannah")]
        self.assertEqual(list_consultants(rows), ["Hannah", "Mel", "Raneen", "raneen", "Unassigned"])
        self.assertEqual(list_consultants([]), [])
        self.assertEqual(list_consultants([{"Application": "Mo"}]), ["Unassigned"], "reads Consultant, not Application Manager")

    def test_list_application_managers_is_alphabetical_with_blank_as_unassigned(self):
        rows = [{"Application": v} for v in ("nouran", "Mo", "Nouran", " Mo ", "", None, "  ")]
        self.assertEqual(list_application_managers(rows), ["Mo", "Nouran", "nouran", "Unassigned"])
        self.assertEqual(list_application_managers([]), [])


def app_row(code, intake, manager="", university="Uni A", consultant=""):
    return row(**{"Student Code": code, "Student Name": code, "Application Status": "Assessment", "Intake": intake,
                  "University Name": university, "Admission Officer": manager, "Counsellor": consultant})


ROWS = [
    app_row("A1", "August 2026", "Nouran X"),
    app_row("A2", "September 2026", "Nouran X", "Uni B"),
    app_row("A3", "September 2026", "Mo Y"),
    app_row("A4", "September 2026", ""),                     # no Application Manager
    app_row("A5", "October 2026", "Mo Y", "Uni B"),
    app_row("A6", "November 2026", "Nouran X"),
    app_row("B1", "January 2027", "Mo Y"),
    app_row("B2", "February 2027", "Nouran X"),
    app_row("B3", "September 2027", "Nouran X"),
]


@contextmanager
def captured():
    rendered = []

    def record(sender, template, context, **extra):
        rendered.append((template.name, dict(context)))

    template_rendered.connect(record, app_module.app)
    try:
        yield rendered
    finally:
        template_rendered.disconnect(record, app_module.app)


class FilterRouteTests(IsolatedAppTestCase):
    ROWS = ROWS
    LOOKUPS = {"status": [("Assessment", "05-Assessment")]}

    def setUp(self):
        super().setUp()
        self.full = self._client_logged_in_as("full")
        token = extract_token(self.full.get("/login").get_data(as_text=True))
        data = book(self.ROWS, lookups=self.LOOKUPS)
        self.assertEqual(self.full.post("/upload", data={"csrf_token": token, "excel_file": (io.BytesIO(data), "f.xlsx")},
                                        content_type="multipart/form-data").status_code, 302)

    def page(self, query="?year=2026", client=None):
        with captured() as rendered:
            r = (client or self.full).get("/university-pipeline" + query)
        self.assertEqual(r.status_code, 200, query)
        context = next(c for name, c in rendered if name == "university_pipeline.html")
        return r.get_data(as_text=True), context

    def total(self, query):
        _, context = self.page(query)
        return context["university_summary_cards"][0]["total"]

    def options(self, html, select):
        block = html[html.index(f'<select name="{select}"'):]
        block = block[:block.index("</select>")]
        return re.findall(r'<option value="([^"]*)"', block), re.findall(r'<option value="([^"]*)" selected', block)

    def apply_button_outside_noscript(self, html):
        form = self.filter_form(html)
        return len(re.findall(r"<button[^>]*>Apply filters</button>", re.sub(r"<noscript>.*?</noscript>", "", form, flags=re.S)))

    def filter_form(self, html):
        start = html.index('<form method="GET" action="/university-pipeline"')
        return html[start:html.index("</form>", start)]

    def checkboxes(self, html, name):
        """(values of every check box called `name`, values of the ticked ones)."""
        boxes = re.findall(rf'<input type="checkbox" name="{name}" value="([^"]+)"\s*(checked)?\s*>', html)
        return [value for value, _ in boxes], [value for value, checked in boxes if checked]

    def months(self, html):
        return self.checkboxes(html, "intake_month")

    def statuses(self, html):
        return self.checkboxes(html, "status")

    def test_with_nobody_named_as_consultant_the_only_option_is_unassigned(self):
        self.assertEqual(self.options(self.page("?year=2026")[0], "office")[0], ["", "Unassigned"])
        self.assertEqual(self.total("?year=2026&office=Unassigned"), 6)
        self.assertEqual(self.options(self.page("?year=2026")[0], "consultant")[0], ["", "Unassigned"])
        self.assertEqual(self.total("?year=2026&consultant=Unassigned"), 6)

    def test_with_no_filter_everything_for_the_year_is_shown_as_before(self):
        self.assertEqual(self.total("?year=2026"), 6)
        self.assertEqual(self.total("?year=2027"), 3)

    def test_the_manager_filter_narrows_the_whole_page_to_that_application_manager(self):
        self.assertEqual(self.total("?year=2026&manager=Nouran"), 3)        # A1 A2 A6
        self.assertEqual(self.total("?year=2026&manager=Mo"), 2)            # A3 A5
        self.assertEqual(self.total("?year=2026&manager=Unassigned"), 1)    # A4
        _, context = self.page("?year=2026&manager=Mo")
        names = {r["name"] for g in context["pending_stage_chart_groups"] for r in g["rows"]}
        self.assertEqual(names, {"Uni A", "Uni B"})
        self.assertEqual(sum(r["total"] for g in context["pending_stage_chart_groups"] for r in g["rows"]), 2)

    def test_the_intake_month_filter_narrows_to_that_month(self):
        self.assertEqual(self.total("?year=2026&intake_month=9"), 3)
        self.assertEqual(self.total("?year=2026&intake_month=8"), 1)
        self.assertEqual(self.total("?year=2026&intake_month=11"), 1)

    def test_both_filters_together(self):
        self.assertEqual(self.total("?year=2026&manager=Nouran&intake_month=9"), 1)
        self.assertEqual(self.total("?year=2026&manager=Mo&intake_month=9"), 1)
        self.assertEqual(self.total("?year=2026&manager=Unassigned&intake_month=9"), 1)
        self.assertEqual(self.total("?year=2026&manager=Mo&intake_month=8"), 0)

    def test_the_options_are_the_ones_relevant_to_the_year_tab(self):
        html, context = self.page("?year=2026")
        self.assertEqual(self.months(html)[0], ["8", "9", "10", "11"])
        self.assertEqual(self.options(html, "manager")[0], ["", "Mo", "Nouran", "Unassigned"])
        self.assertEqual([o["label"] for o in context["intake_month_options"]], ["August 2026", "September 2026", "October 2026", "November 2026"])
        html, context = self.page("?year=2027")
        self.assertEqual(self.months(html)[0], ["1", "2", "9"])
        self.assertEqual(self.options(html, "manager")[0], ["", "Mo", "Nouran"], "no Unassigned in 2027, nobody is")
        self.assertEqual([o["label"] for o in context["intake_month_options"]], ["January 2027", "February 2027", "September 2027"])
        self.assertIn("September 2027", html)

    def test_the_options_follow_the_intake_01_02_03_tab(self):
        html, _ = self.page("?year=2027&intake=intake_01")
        self.assertEqual(self.months(html)[0], ["1", "2"])
        self.assertEqual(self.options(html, "manager")[0], ["", "Mo", "Nouran"])
        html, _ = self.page("?year=2027&intake=intake_03")
        self.assertEqual(self.months(html)[0], ["9"])
        self.assertEqual(self.options(html, "manager")[0], ["", "Nouran"])
        self.assertIn('<input type="hidden" name="intake" value="intake_03">', html)
        self.assertEqual(self.total("?year=2027&intake=intake_01&manager=Mo"), 1)
        self.assertEqual(self.total("?year=2027&intake=intake_01&intake_month=2"), 1)
        self.assertEqual(self.total("?year=2027&intake=intake_03&intake_month=2"), 3 - 2, "a month outside the tab is ignored, so the whole Intake 03 tab shows")

    def test_a_filter_value_that_is_not_an_option_is_ignored(self):
        for query in ("&manager=Nobody", "&manager=", "&intake_month=12", "&intake_month=1", "&intake_month=abc", "&intake_month=9.5",
                      "&intake_month=%3Cscript%3E", "&manager=%3Cscript%3E", "&intake_month=0", "&intake_month=-9", "&intake_month=99999999999999999999"):
            self.assertEqual(self.total("?year=2026" + query), 6, query)
        html, _ = self.page("?year=2026&manager=%3Cscript%3Ealert(1)%3C/script%3E&intake_month=%3Cb%3E")
        self.assertNotIn("<script>alert", html)

    def test_the_selected_options_are_marked_and_the_selects_submit_on_change(self):
        html, _ = self.page("?year=2026&manager=Nouran&intake_month=9")
        self.assertEqual(self.options(html, "manager")[1], ["Nouran"])
        self.assertEqual(self.months(html)[1], ["9"])
        html, _ = self.page("?year=2026")
        self.assertEqual(self.options(html, "manager")[1], [""])
        self.assertEqual(self.months(html)[1], [])
        self.assertIn("Application Manager</label>", html)
        self.assertIn("Intake Month</span>", html)
        self.assertEqual(self.apply_button_outside_noscript(html), 0, "no Apply button to click when JavaScript is on")
        self.assertIn("<noscript><button type=\"submit\" class=\"btn-primary uni-apply\">Apply filters</button></noscript>", html)

    def test_clear_filters_only_shows_when_something_is_filtered_and_goes_back_to_the_unfiltered_year(self):
        self.assertNotIn("Clear filters", self.page("?year=2026")[0])
        html, _ = self.page("?year=2026&manager=Mo")
        self.assertIn("Clear filters", html)
        self.assertIn('href="/university-pipeline?year=2026"', html.split("Clear filters")[0].rsplit("<a", 1)[1])
        html, _ = self.page("?year=2027&intake=intake_01&intake_month=1")
        self.assertIn('href="/university-pipeline?year=2027&amp;intake=intake_01"', html.split("Clear filters")[0].rsplit("<a", 1)[1])

    def test_switching_year_or_intake_tab_keeps_the_manager_but_drops_the_month(self):
        html, _ = self.page("?year=2026&manager=Nouran&intake_month=9")
        year_tab = re.search(r'<a href="([^"]+)"\s+class="tab-link">2027</a>', html).group(1)
        self.assertIn("manager=Nouran", year_tab)
        self.assertNotIn("intake_month", year_tab)
        html, _ = self.page("?year=2027&manager=Nouran&intake_month=9")
        for href in re.findall(r'href="([^"]*intake=intake_0\d[^"]*)"', html):
            self.assertIn("manager=Nouran", href)
            self.assertNotIn("intake_month", href)

    def test_when_nothing_matches_the_page_says_so(self):
        html, context = self.page("?year=2026&manager=Mo&intake_month=8")
        self.assertEqual(context["university_summary_cards"][0]["total"], 0)
        self.assertFalse(context["chart_has_data"])
        self.assertIn("No applications match these filters.", html)
        self.assertNotIn('class="chart-row"', html)

    def test_the_cards_and_chart_both_follow_the_filters(self):
        _, unfiltered = self.page("?year=2026")
        _, filtered = self.page("?year=2026&manager=Nouran")
        card = filtered["university_summary_cards"][0]
        self.assertEqual(card["total"], 3)
        self.assertLess(card["forecast"], unfiltered["university_summary_cards"][0]["forecast"] + 1)
        self.assertEqual(sum(r["total"] for g in filtered["pending_stage_chart_groups"] for r in g["rows"]), 3)

    def test_every_role_can_use_the_filters(self):
        for role in ("admissions", "consultants", "marketing"):
            _, context = self.page("?year=2026&manager=Mo", client=self._client_logged_in_as(role))
            self.assertEqual(context["university_summary_cards"][0]["total"], 2, role)

    def test_the_other_pages_are_unaffected(self):
        for path in ("/university-report?year=2026&manager=Mo&intake_month=9", "/dashboard?year=2026&manager=Mo"):
            html = self.full.get(path).get_data(as_text=True)
            self.assertNotIn('name="intake_month"', html, path)


STATUS_LOOKUP = [("QA", "02-PendingQA"), ("Assessment", "05-Assessment"), ("Decision", "06-Decision"),
                 ("Enrolled", "09-Enrolled"), ("Lost", "10-Lost"), ("Rejected", "00-QARejected")]


def status_row(code, intake, status, manager="", university="Uni A", consultant=""):
    return app_row(code, intake, manager, university, consultant) | {"Application Status": status}


ROWS_S = [
    status_row("S1", "August 2026", "Assessment", "Nouran X", consultant="Raneen R"),
    status_row("S2", "September 2026", "Decision", "Nouran X", "Uni B", "Mel M"),
    status_row("S3", "September 2026", "Enrolled", "Mo Y", consultant="Raneen R"),
    status_row("S4", "September 2026", "QA", "", consultant="Mel M"),
    status_row("S5", "October 2026", "Lost", "Mo Y", "Uni B", "Mel M"),
    status_row("S6", "November 2026", "Assessment", "Nouran X", consultant="Hannah H"),
    status_row("S7", "September 2026", "Rejected", "Mo Y", consultant="Raneen R"),   # outside the pipeline stages: never counted, never offered
    status_row("S8", "October 2026", "Enrolled", "Nouran X", "Uni B", "Raneen R"),
    status_row("T1", "January 2027", "Assessment", "Mo Y", "Uni C", "Mel M"),
    status_row("T2", "February 2027", "Decision", "Nouran X", "Uni C", "Hannah H"),
    status_row("T3", "September 2027", "Enrolled", "Nouran X", "Uni C", "Raneen R"),
]


class StatusAndMonthsRouteTests(FilterRouteTests):
    """Status filter and the multi-select Intake Month check boxes (the
    inherited tests run again on this data, which has the same shape but
    more Statuses). Raneen is in OXF, Mel in MAN, Hannah in LON."""

    ROWS = ROWS_S
    LOOKUPS = {"status": STATUS_LOOKUP, "sales_office": [("Raneen", "OXF"), ("Mel", "MAN"), ("Hannah", "LON")]}

    def test_with_no_filter_everything_for_the_year_is_shown_as_before(self):
        self.assertEqual(self.total("?year=2026"), 7)      # S1-S6 and S8; S7 is outside the pipeline stages
        self.assertEqual(self.total("?year=2027"), 3)

    # the inherited tests assume the all-Assessment data set; these re-state their expectations for this one
    def test_the_manager_filter_narrows_the_whole_page_to_that_application_manager(self):
        self.assertEqual(self.total("?year=2026&manager=Nouran"), 4)        # S1 S2 S6 S8
        self.assertEqual(self.total("?year=2026&manager=Mo"), 2)            # S3 S5 (S7 not counted)
        self.assertEqual(self.total("?year=2026&manager=Unassigned"), 1)    # S4

    def test_the_intake_month_filter_narrows_to_that_month(self):
        self.assertEqual(self.total("?year=2026&intake_month=9"), 3)        # S2 S3 S4
        self.assertEqual(self.total("?year=2026&intake_month=8"), 1)
        self.assertEqual(self.total("?year=2026&intake_month=11"), 1)

    def test_both_filters_together(self):
        self.assertEqual(self.total("?year=2026&manager=Nouran&intake_month=9"), 1)
        self.assertEqual(self.total("?year=2026&manager=Mo&intake_month=9"), 1)
        self.assertEqual(self.total("?year=2026&manager=Unassigned&intake_month=9"), 1)
        self.assertEqual(self.total("?year=2026&manager=Mo&intake_month=8"), 0)

    def test_the_options_are_the_ones_relevant_to_the_year_tab(self):
        html, context = self.page("?year=2026")
        self.assertEqual(self.months(html)[0], ["8", "9", "10", "11"])
        self.assertEqual(self.options(html, "manager")[0], ["", "Mo", "Nouran", "Unassigned"])
        html, context = self.page("?year=2027")
        self.assertEqual(self.months(html)[0], ["1", "2", "9"])
        self.assertEqual(self.options(html, "manager")[0], ["", "Mo", "Nouran"], "no Unassigned in 2027, nobody is")

    def test_a_filter_value_that_is_not_an_option_is_ignored(self):
        for query in ("&manager=Nobody", "&manager=", "&intake_month=12", "&intake_month=1", "&intake_month=abc", "&intake_month=9.5",
                      "&intake_month=%3Cscript%3E", "&manager=%3Cscript%3E", "&intake_month=0", "&intake_month=-9", "&intake_month=99999999999999999999",
                      "&status=Nope", "&status=00-QARejected", "&status=%3Cscript%3E", "&status=", "&status=05-assessment"):
            self.assertEqual(self.total("?year=2026" + query), 7, query)
        html, _ = self.page("?year=2026&status=%3Cscript%3Ealert(1)%3C/script%3E")
        self.assertNotIn("<script>alert", html)

    def test_the_cards_and_chart_both_follow_the_filters(self):
        _, filtered = self.page("?year=2026&manager=Nouran")
        self.assertEqual(filtered["university_summary_cards"][0]["total"], 4)

    def test_the_intake_tab_cases(self):
        self.assertEqual(self.total("?year=2027&intake=intake_01&manager=Mo"), 1)
        self.assertEqual(self.total("?year=2027&intake=intake_01&intake_month=2"), 1)
        self.assertEqual(self.total("?year=2027&intake=intake_03&intake_month=2"), 1, "a month outside the tab is ignored, so the whole Intake 03 tab shows")

    def test_every_role_can_use_the_filters(self):
        for role in ("admissions", "consultants", "marketing"):
            _, context = self.page("?year=2026&manager=Mo", client=self._client_logged_in_as(role))
            self.assertEqual(context["university_summary_cards"][0]["total"], 2, role)

    def test_when_nothing_matches_the_page_says_so(self):
        html, context = self.page("?year=2026&manager=Mo&intake_month=8")
        self.assertEqual(context["university_summary_cards"][0]["total"], 0)
        self.assertEqual(context["pending_stage_chart_groups"], [])
        self.assertIn("No applications match these filters.", html)

    def test_clear_filters_only_shows_when_something_is_filtered_and_goes_back_to_the_unfiltered_year(self):
        self.assertNotIn("Clear filters", self.page("?year=2026")[0])
        for query in ("&manager=Mo", "&status=05-Assessment", "&intake_month=9", "&intake_month=9&intake_month=10"):
            self.assertIn("Clear filters", self.page("?year=2026" + query)[0], query)

    # ---- Status
    def test_the_status_options_are_the_pipeline_statuses_in_this_year_in_pipeline_order(self):
        html, _ = self.page("?year=2026")
        self.assertEqual(self.statuses(html)[0], ["02-PendingQA", "05-Assessment", "06-Decision", "09-Enrolled", "10-Lost"])
        html, _ = self.page("?year=2027")
        self.assertEqual(self.statuses(html)[0], ["05-Assessment", "06-Decision", "09-Enrolled"])
        html, _ = self.page("?year=2027&intake=intake_03")
        self.assertEqual(self.statuses(html)[0], ["09-Enrolled"])
        self.assertIn("Status</span>", html)
        self.assertNotIn("All Statuses", html)
        self.assertNotIn('<select name="status"', html, "Status is tick boxes now, not a dropdown")

    def test_the_status_filter_narrows_the_whole_page(self):
        self.assertEqual(self.total("?year=2026&status=05-Assessment"), 2)     # S1 S6
        self.assertEqual(self.total("?year=2026&status=09-Enrolled"), 2)       # S3 S8
        self.assertEqual(self.total("?year=2026&status=10-Lost"), 1)           # S5
        self.assertEqual(self.total("?year=2026&status=06-Decision"), 1)       # S2
        _, context = self.page("?year=2026&status=09-Enrolled")
        self.assertEqual({r["name"] for g in context["pending_stage_chart_groups"] for r in g["rows"]}, {"Uni A", "Uni B"})
        self.assertEqual({seg["key"] for g in context["pending_stage_chart_groups"] for r in g["rows"] for seg in r["segments"]}, {"enrolled_this_intake"})

    def test_the_status_filter_combines_with_manager_and_months(self):
        self.assertEqual(self.total("?year=2026&status=09-Enrolled&manager=Mo"), 1)                    # S3
        self.assertEqual(self.total("?year=2026&status=09-Enrolled&manager=Nouran"), 1)                # S8
        self.assertEqual(self.total("?year=2026&status=05-Assessment&manager=Nouran"), 2)              # S1 S6
        self.assertEqual(self.total("?year=2026&status=05-Assessment&intake_month=8"), 1)              # S1
        self.assertEqual(self.total("?year=2026&status=09-Enrolled&intake_month=9&intake_month=10"), 2)   # S3 S8
        self.assertEqual(self.total("?year=2026&status=10-Lost&manager=Nouran"), 0)

    def test_the_selected_status_is_marked(self):
        html, _ = self.page("?year=2026&status=06-Decision")
        self.assertEqual(self.statuses(html)[1], ["06-Decision"])
        self.assertEqual(self.statuses(self.page("?year=2026")[0])[1], [])
        html, _ = self.page("?year=2026&status=09-Enrolled&status=10-Lost")
        self.assertEqual(self.statuses(html)[1], ["09-Enrolled", "10-Lost"])

    def test_a_status_the_chart_does_not_draw_is_explained_not_blank(self):
        html, context = self.page("?year=2026&status=02-PendingQA")
        self.assertEqual(context["university_summary_cards"][0]["total"], 1)
        self.assertFalse(context["chart_has_data"])
        self.assertIn("The chart doesn't draw 02-PendingQA", html)
        self.assertNotIn("No applications match", html)
        self.assertNotIn('class="chart-row"', html, "no empty bars")

    def test_year_and_intake_tabs_keep_the_status_too(self):
        html, _ = self.page("?year=2026&manager=Nouran&status=05-Assessment&intake_month=9")
        year_tab = re.search(r'<a href="([^"]+)"\s+class="tab-link">2027</a>', html).group(1)
        self.assertIn("status=05-Assessment", year_tab)
        self.assertIn("manager=Nouran", year_tab)
        self.assertNotIn("intake_month", year_tab)
        html, _ = self.page("?year=2027&status=05-Assessment")
        for href in re.findall(r'href="([^"]*intake=intake_0\d[^"]*)"', html):
            self.assertIn("status=05-Assessment", href)

    # ---- Office
    def test_the_office_options_are_the_ones_relevant_to_the_year_and_intake_tab_in_lon_car_man_oxf_order(self):
        self.assertEqual(self.options(self.page("?year=2026")[0], "office")[0], ["", "LON", "MAN", "OXF"], "CAR has no applications here, so it is not offered")
        self.assertEqual(self.options(self.page("?year=2027")[0], "office")[0], ["", "LON", "MAN", "OXF"])
        self.assertEqual(self.options(self.page("?year=2027&intake=intake_01")[0], "office")[0], ["", "LON", "MAN"])
        self.assertEqual(self.options(self.page("?year=2027&intake=intake_03")[0], "office")[0], ["", "OXF"])
        self.assertIn("All Offices", self.page("?year=2026")[0])

    def test_the_office_filter_narrows_the_whole_page(self):
        self.assertEqual(self.total("?year=2026&office=OXF"), 3)       # S1 S3 S8 (S7 is outside the pipeline stages)
        self.assertEqual(self.total("?year=2026&office=MAN"), 3)       # S2 S4 S5
        self.assertEqual(self.total("?year=2026&office=LON"), 1)       # S6
        _, context = self.page("?year=2026&office=MAN")
        self.assertEqual({r["name"] for g in context["pending_stage_chart_groups"] for r in g["rows"]}, {"Uni A", "Uni B"})
        self.assertEqual(self.total("?year=2027&office=LON"), 1)       # T2

    def test_the_office_filter_combines_with_every_other_filter(self):
        self.assertEqual(self.total("?year=2026&office=OXF&manager=Nouran"), 2)                 # S1 S8
        self.assertEqual(self.total("?year=2026&office=OXF&consultant=Raneen"), 3)
        self.assertEqual(self.total("?year=2026&office=OXF&consultant=Mel"), 0, "the filters are independent: Mel is not in OXF")
        self.assertEqual(self.total("?year=2026&office=MAN&status=10-Lost"), 1)                 # S5
        self.assertEqual(self.total("?year=2026&office=LON&intake_month=11"), 1)                # S6
        self.assertEqual(self.total("?year=2026&office=LON&intake_month=9"), 0)
        self.assertEqual(self.total("?year=2026&office=OXF&manager=Mo&status=09-Enrolled&intake_month=9"), 1)   # S3
        self.assertEqual(self.total("?year=2027&intake=intake_01&office=MAN"), 1)               # T1

    def test_an_office_that_is_not_an_option_is_ignored(self):
        for query in ("&office=Nope", "&office=", "&office=oxf", "&office=CAR", "&office=%3Cscript%3E", "&office=Unassigned", "&office=%00"):
            self.assertEqual(self.total("?year=2026" + query), 7, query)
        html, _ = self.page("?year=2026&office=%3Cscript%3Ealert(1)%3C/script%3E")
        self.assertNotIn("<script>alert", html)

    def test_the_selected_office_is_marked_and_sits_between_application_manager_and_consultant(self):
        html, _ = self.page("?year=2026&office=MAN&consultant=Mel&manager=Mo")
        self.assertEqual(self.options(html, "office")[1], ["MAN"])
        self.assertEqual(self.options(self.page("?year=2026")[0], "office")[1], [""])
        form = self.filter_form(html)
        row = form[form.index('<div class="uni-filter-row">'):]
        row = row[:row.index("Status</span>")]
        self.assertLess(row.index('name="manager"'), row.index('name="office"'))
        self.assertLess(row.index('name="office"'), row.index('name="consultant"'))
        self.assertIn("Office</label>", row)
        self.assertNotIn("onchange=", form)

    def test_office_is_kept_by_the_tabs_the_clear_link_and_the_download(self):
        html, _ = self.page("?year=2026&office=MAN")
        self.assertIn("office=MAN", re.search(r'<a href="([^"]+)"\s+class="tab-link">2027</a>', html).group(1))
        self.assertIn("Clear filters", html)
        self.assertIn("office=MAN", re.search(r'<a class="uni-download" href="([^"]+)"', html).group(1))
        html, _ = self.page("?year=2027&office=MAN")
        for href in re.findall(r'href="([^"]*intake=intake_0\d[^"]*)"', html):
            self.assertIn("office=MAN", href)

    def test_the_office_filter_alone_can_leave_nothing(self):
        html, context = self.page("?year=2026&office=LON&status=10-Lost")
        self.assertEqual(context["university_summary_cards"][0]["total"], 0)
        self.assertIn("No applications match these filters.", html)

    # ---- Consultant
    def test_with_nobody_named_as_consultant_the_only_option_is_unassigned(self):
        # (re-stated for this data set, where everyone is named: no "Unassigned" option)
        self.assertNotIn("Unassigned", self.options(self.page("?year=2026")[0], "consultant")[0])
        self.assertEqual(self.total("?year=2026&consultant=Unassigned"), 7, "not an option, so ignored")

    def test_the_consultant_options_are_the_ones_relevant_to_the_year_and_intake_tab(self):
        self.assertEqual(self.options(self.page("?year=2026")[0], "consultant")[0], ["", "Hannah", "Mel", "Raneen"])
        self.assertEqual(self.options(self.page("?year=2027")[0], "consultant")[0], ["", "Hannah", "Mel", "Raneen"])
        self.assertEqual(self.options(self.page("?year=2027&intake=intake_01")[0], "consultant")[0], ["", "Hannah", "Mel"])
        self.assertEqual(self.options(self.page("?year=2027&intake=intake_03")[0], "consultant")[0], ["", "Raneen"])
        self.assertIn("All Consultants", self.page("?year=2026")[0])

    def test_the_consultant_filter_narrows_the_whole_page(self):
        self.assertEqual(self.total("?year=2026&consultant=Raneen"), 3)       # S1 S3 S8 (S7 is outside the pipeline stages)
        self.assertEqual(self.total("?year=2026&consultant=Mel"), 3)          # S2 S4 S5
        self.assertEqual(self.total("?year=2026&consultant=Hannah"), 1)       # S6
        _, context = self.page("?year=2026&consultant=Mel")
        self.assertEqual({r["name"] for g in context["pending_stage_chart_groups"] for r in g["rows"]}, {"Uni A", "Uni B"})

    def test_the_consultant_filter_combines_with_every_other_filter(self):
        self.assertEqual(self.total("?year=2026&consultant=Raneen&manager=Nouran"), 2)          # S1 S8
        self.assertEqual(self.total("?year=2026&consultant=Raneen&manager=Mo"), 1)              # S3
        self.assertEqual(self.total("?year=2026&consultant=Raneen&status=09-Enrolled"), 2)      # S3 S8
        self.assertEqual(self.total("?year=2026&consultant=Mel&intake_month=9"), 2)             # S2 S4
        self.assertEqual(self.total("?year=2026&consultant=Mel&status=05-Assessment"), 0)
        self.assertEqual(self.total("?year=2026&consultant=Raneen&manager=Nouran&status=09-Enrolled&intake_month=10"), 1)   # S8
        self.assertEqual(self.total("?year=2027&intake=intake_01&consultant=Mel"), 1)           # T1

    def test_a_consultant_that_is_not_an_option_is_ignored(self):
        for query in ("&consultant=Nobody", "&consultant=", "&consultant=raneen", "&consultant=%3Cscript%3E", "&consultant=Unassigned", "&consultant=Hannah&consultant=x"[:0] or "&consultant=%00"):
            self.assertEqual(self.total("?year=2026" + query), 7, query)
        html, _ = self.page("?year=2026&consultant=%3Cscript%3Ealert(1)%3C/script%3E")
        self.assertNotIn("<script>alert", html)

    def test_the_selected_consultant_is_marked_and_sits_next_to_the_application_manager(self):
        html, _ = self.page("?year=2026&consultant=Mel&manager=Mo")
        self.assertEqual(self.options(html, "consultant")[1], ["Mel"])
        self.assertEqual(self.options(self.page("?year=2026")[0], "consultant")[1], [""])
        form = self.filter_form(html)
        row = form[form.index('<div class="uni-filter-row">'):]
        row = row[:row.index("Status</span>")]
        self.assertLess(row.index('name="manager"'), row.index('name="consultant"'), "Consultant comes straight after Application Manager, in the same row")
        self.assertIn("Consultant</label>", row)

    def test_consultant_is_kept_by_the_year_and_intake_tabs_and_the_clear_link_and_download(self):
        html, _ = self.page("?year=2026&consultant=Mel")
        year_tab = re.search(r'<a href="([^"]+)"\s+class="tab-link">2027</a>', html).group(1)
        self.assertIn("consultant=Mel", year_tab)
        self.assertIn("Clear filters", html)
        self.assertIn("consultant=Mel", re.search(r'<a class="uni-download" href="([^"]+)"', html).group(1))
        html, _ = self.page("?year=2027&consultant=Mel")
        for href in re.findall(r'href="([^"]*intake=intake_0\d[^"]*)"', html):
            self.assertIn("consultant=Mel", href)

    def test_the_consultant_filter_alone_shows_the_no_match_message_when_nothing_is_left(self):
        html, context = self.page("?year=2026&consultant=Hannah&status=10-Lost")
        self.assertEqual(context["university_summary_cards"][0]["total"], 0)
        self.assertIn("No applications match these filters.", html)

    def test_the_apply_free_script_sends_the_consultant_too(self):
        html, _ = self.page("?year=2026")
        self.assertIn('<select name="consultant" id="consultant">', html)
        self.assertNotIn("onchange=", self.filter_form(html))

    # ---- several statuses
    def test_several_statuses_can_be_ticked_at_once(self):
        self.assertEqual(self.total("?year=2026&status=05-Assessment&status=09-Enrolled"), 4)        # S1 S6 + S3 S8
        self.assertEqual(self.total("?year=2026&status=10-Lost&status=06-Decision"), 2)              # S5 + S2
        self.assertEqual(self.total("?year=2026&status=09-Enrolled&status=05-Assessment"), 4, "order in the address does not matter")
        self.assertEqual(self.total("?year=2026&status=02-PendingQA&status=05-Assessment&status=06-Decision&status=09-Enrolled&status=10-Lost"), 7)
        self.assertEqual(self.total("?year=2026&status=05-Assessment&status=09-Enrolled&manager=Nouran"), 3)   # S1 S6 S8
        self.assertEqual(self.total("?year=2026&status=05-Assessment&status=09-Enrolled&intake_month=9&intake_month=10"), 2)  # S3 S8

    def test_statuses_that_are_not_options_are_dropped_but_the_valid_ones_still_apply(self):
        self.assertEqual(self.total("?year=2026&status=05-Assessment&status=Nope&status=00-QARejected&status=%3Cb%3E"), 2)
        self.assertEqual(self.total("?year=2026&status=05-Assessment&status=05-Assessment"), 2)
        self.assertEqual(self.total("?year=2026&status=Nope&status=00-QARejected"), 7, "nothing valid means no status filter")
        html, _ = self.page("?year=2026&status=05-Assessment&status=Nope")
        self.assertEqual(self.statuses(html)[1], ["05-Assessment"])

    def test_a_chart_with_nothing_to_draw_is_explained_for_several_statuses_too(self):
        html, context = self.page("?year=2026&status=02-PendingQA&status=10-Lost")
        self.assertTrue(context["chart_has_data"], "Lost is drawn")
        self.assertEqual(context["university_summary_cards"][0]["total"], 2)

    def test_each_status_chip_carries_its_stage_colour_and_every_month_is_a_plain_chip(self):
        from pipeline import STAGE_COLORS
        html, _ = self.page("?year=2026")
        for status in ("02-PendingQA", "05-Assessment", "10-Lost"):
            self.assertRegex(html, rf'value="{status}"[^>]*>\s*<span><i class="uni-chip-dot" style="background-color: {STAGE_COLORS[status]};"></i>{status}</span>')
        self.assertEqual(html.count('class="uni-chip"'), 5 + 4)
        self.assertEqual(html.count('class="uni-chip-dot"'), 5, "months have no colour dot")

    # ---- several months
    def test_several_months_can_be_ticked_at_once(self):
        self.assertEqual(self.total("?year=2026&intake_month=9&intake_month=10"), 5)       # S2 S3 S4 + S5 S8
        self.assertEqual(self.total("?year=2026&intake_month=8&intake_month=11"), 2)       # S1 S6
        self.assertEqual(self.total("?year=2026&intake_month=8&intake_month=9&intake_month=10&intake_month=11"), 7)
        self.assertEqual(self.total("?year=2026&intake_month=9&intake_month=10&manager=Mo"), 2)    # S3 S5
        self.assertEqual(self.total("?year=2026&intake_month=10&intake_month=9"), 5, "order in the address does not matter")

    def test_the_month_check_boxes_show_every_ticked_month(self):
        html, _ = self.page("?year=2026&intake_month=9&intake_month=11")
        self.assertEqual(self.months(html), (["8", "9", "10", "11"], ["9", "11"]))
        self.assertEqual(self.months(self.page("?year=2026")[0])[1], [])

    def test_months_that_are_not_options_are_dropped_but_the_valid_ones_still_apply(self):
        self.assertEqual(self.total("?year=2026&intake_month=9&intake_month=99&intake_month=abc&intake_month=1"), 3)
        self.assertEqual(self.total("?year=2026&intake_month=9&intake_month=9&intake_month=09"), 3)
        html, _ = self.page("?year=2026&intake_month=9&intake_month=99")
        self.assertEqual(self.months(html)[1], ["9"])
        self.assertEqual(self.total("?year=2026&intake_month=99&intake_month=abc"), 7, "nothing valid means no month filter")

    def test_the_apply_button_submits_the_check_boxes_together_with_the_other_filters(self):
        html, _ = self.page("?year=2026&manager=Nouran&status=05-Assessment&intake_month=9")
        form = self.filter_form(html)
        for fragment in ('<input type="hidden" name="year" value="2026">', 'name="manager"', 'name="status"', 'name="intake_month"'):
            self.assertIn(fragment, form)
        self.assertIn("<noscript>", form, "the no-JavaScript fallback is the Apply button")
        self.assertEqual(form.count('type="checkbox"'), 5 + 4, "5 statuses and 4 months")

    def test_the_filters_apply_as_you_pick_them(self):
        html, _ = self.page("?year=2026")
        script = html[html.index("var form = document.querySelector('.uni-filter-form');"):]
        script = script[:script.index("})();")]
        self.assertIn("window.location.replace(", script, "replaces the page, so Back still leaves it")
        self.assertIn("new FormData(form)", script, "sends every filter, ticked or not")
        self.assertIn("params.delete('manager')", script, "no empty manager= in the address")
        self.assertIn("setTimeout(apply, 500)", script, "tick boxes wait a moment so several can be ticked")
        self.assertRegex(script, r"tagName === 'SELECT'\) \{\s*apply\(\);", "the dropdown applies straight away")
        self.assertNotIn(".submit()", script)

    def test_the_selected_months_stay_ticked_when_manager_or_status_is_changed(self):
        # the dropdowns submit the whole form, so a ticked month is part of every submission
        html, _ = self.page("?year=2026&intake_month=9&intake_month=10")
        form = self.filter_form(html)
        self.assertEqual(re.findall(r'name="intake_month" value="(\d+)"\s*checked', form), ["9", "10"])
        self.assertNotIn("onchange=", form, "the page's script applies the filters, not an inline handler")

    def test_the_other_pages_are_unaffected(self):
        for path in ("/university-report?year=2026&manager=Mo&intake_month=9&status=05-Assessment", "/dashboard?year=2026&manager=Mo"):
            html = self.full.get(path).get_data(as_text=True)
            self.assertNotIn('name="intake_month"', html, path)


if __name__ == "__main__":
    unittest.main()
