"""Deterministic connection-lifecycle instrumentation for tests.

ConnectionTracker replaces db.get_connection (the one factory behind
db.db_connection()) so that EVERY connection the app opens is

- created from FaultyConnection, a sqlite3.Connection subclass that can be
  told to fail execute() or commit() on demand (to simulate "database is
  locked" / I/O errors after a connection is open), and
- held in a list with a STRONG reference.

The strong reference is the point: a leaked connection cannot be silently
cleaned up by garbage collection mid-test, so "was it closed?" has a single
deterministic answer - no gc.collect(), no sleeping, no timing.
"""

import sqlite3
from contextlib import contextmanager


class FaultyConnection(sqlite3.Connection):
    fail_execute = False
    fail_commit = False

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.rollback_calls = 0
        self.commit_calls = 0

    def execute(self, *args, **kwargs):
        if FaultyConnection.fail_execute:
            raise sqlite3.OperationalError("database is locked")
        return super().execute(*args, **kwargs)

    def commit(self):
        self.commit_calls += 1
        if FaultyConnection.fail_commit:
            raise sqlite3.OperationalError("database is locked")
        return super().commit()

    def rollback(self):
        self.rollback_calls += 1
        return super().rollback()


def is_closed(conn):
    """True once conn.close() has run. Uses the BASE-class execute so the
    probe itself can never be hit by an injected fault."""
    try:
        sqlite3.Connection.execute(conn, "SELECT 1")
        return False
    except sqlite3.ProgrammingError:
        return True


class ConnectionTracker:
    def __init__(self, db_module):
        self.db = db_module
        self.connections = []
        self.max_open = 0
        self._original = None

    # --- install / remove -------------------------------------------------
    def install(self):
        self._original = self.db.get_connection
        self.db.get_connection = self._factory

    def uninstall(self):
        FaultyConnection.fail_execute = False
        FaultyConnection.fail_commit = False
        if self._original is not None:
            self.db.get_connection = self._original
            self._original = None

    def _factory(self):
        conn = sqlite3.connect(self.db.DB_PATH, factory=FaultyConnection)
        conn.row_factory = sqlite3.Row
        self.connections.append(conn)
        self.max_open = max(self.max_open, self.open_count())
        return conn

    # --- observations -------------------------------------------------------
    def reset(self):
        self.connections.clear()
        self.max_open = 0

    @property
    def opened(self):
        return len(self.connections)

    def open_count(self):
        return sum(1 for c in self.connections if not is_closed(c))

    def leaked(self):
        return [c for c in self.connections if not is_closed(c)]

    def force_close_leaks(self):
        """Test hygiene only: close whatever a failing test left open."""
        for conn in self.leaked():
            try:
                conn.rollback()
            except sqlite3.Error:
                pass
            conn.close()

    # --- fault injection ----------------------------------------------------
    @contextmanager
    def failing(self, what):
        """with tracker.failing("execute"): ... - every connection's
        execute() (or commit()) raises sqlite3.OperationalError inside."""
        assert what in ("execute", "commit")
        attr = f"fail_{what}"
        setattr(FaultyConnection, attr, True)
        try:
            yield
        finally:
            setattr(FaultyConnection, attr, False)
