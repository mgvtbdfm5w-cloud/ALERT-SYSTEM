import unittest
from datetime import date

import openpyxl

from enrolled_export import EXPORT_COLUMNS, build_enrolled_export, export_filename


def _row(university, **overrides):
    row = {
        "Consultant": "Zara",
        "Student Code": "S000",
        "Student Name": "Student",
        "Student Number": "N000",
        "Location": "Oxford",
        "Sub-Source": "Website",
        "Phone Number": "07123456789",
        "Email": "student@example.com",
        "Course Name": "Course A",
        "Enrolled Date": "2026-09-01",
        "University Name": university,
    }
    row.update(overrides)
    return row


class BuildEnrolledExportTests(unittest.TestCase):
    """One worksheet per University Name (see enrolled_export.py's module
    docstring - same one-tab-per-group convention as Offer Days' Total
    download)."""

    def setUp(self):
        self.rows = [
            _row("Uni A", **{"Student Code": "S001", "Student Name": "Nina", "Consultant": "Zara"}),
            _row("Uni A", **{"Student Code": "S002", "Student Name": "Owen", "Consultant": "Amir"}),
            _row("Uni B", **{"Student Code": "S003", "Student Name": "Pat", "Consultant": "Zara"}),
            _row("", **{"Student Code": "S004", "Student Name": "Ray", "Consultant": "Amir"}),
            _row(None, **{"Student Code": "S005", "Student Name": "Sam", "Consultant": "Amir"}),
        ]
        self.buffer = build_enrolled_export(self.rows)
        self.workbook = openpyxl.load_workbook(self.buffer)

    def test_one_worksheet_per_university(self):
        self.assertEqual(set(self.workbook.sheetnames), {"Uni A", "Uni B", "Unassigned"})

    def test_tabs_are_alphabetical_with_unassigned_last(self):
        self.assertEqual(self.workbook.sheetnames, ["Uni A", "Uni B", "Unassigned"])

    def test_each_tab_contains_only_that_universitys_rows(self):
        for sheet_name, expected_codes in [
            ("Uni A", {"S001", "S002"}),
            ("Uni B", {"S003"}),
            ("Unassigned", {"S004", "S005"}),
        ]:
            ws = self.workbook[sheet_name]
            codes = {row[1] for row in ws.iter_rows(min_row=2, values_only=True)}
            self.assertEqual(codes, expected_codes, msg=sheet_name)

    def test_column_order_matches_the_requested_format(self):
        self.assertEqual(
            EXPORT_COLUMNS,
            [
                "Consultant Name",
                "PES Code",
                "Student Name",
                "Student Number",
                "Location",
                "Sub Source",
                "Phone Number",
                "Email",
                "Course",
                "Enrolled Date",
            ],
        )
        for sheet_name in self.workbook.sheetnames:
            header = [c.value for c in self.workbook[sheet_name][1]]
            self.assertEqual(header, EXPORT_COLUMNS, msg=sheet_name)

    def test_row_values_map_to_the_right_columns(self):
        ws = self.workbook["Uni B"]
        values = list(ws.iter_rows(min_row=2, max_row=2, values_only=True))[0]
        self.assertEqual(values[0], "Zara")  # Consultant Name
        self.assertEqual(values[1], "S003")  # PES Code (Student Code)
        self.assertEqual(values[2], "Pat")  # Student Name
        self.assertEqual(values[3], "N000")  # Student Number
        self.assertEqual(values[4], "Oxford")  # Location
        self.assertEqual(values[5], "Website")  # Sub Source
        self.assertEqual(values[6], "07123456789")  # Phone Number (straight before Email)
        self.assertEqual(values[7], "student@example.com")  # Email
        self.assertEqual(values[8], "Course A")  # Course
        self.assertEqual(values[9].date(), date(2026, 9, 1))  # Enrolled Date

    def test_sorting_within_each_tab_is_consultant_then_student_name(self):
        ws = self.workbook["Uni A"]
        names_in_order = [row[2] for row in ws.iter_rows(min_row=2, values_only=True)]
        self.assertEqual(names_in_order, ["Owen", "Nina"])  # Amir before Zara

    def test_date_formatting(self):
        date_col_idx = EXPORT_COLUMNS.index("Enrolled Date") + 1
        for sheet_name in self.workbook.sheetnames:
            ws = self.workbook[sheet_name]
            for r in range(2, ws.max_row + 1):
                self.assertEqual(ws.cell(row=r, column=date_col_idx).number_format, "DD/MM/YYYY")

    def test_header_bold_frozen_filterable_on_every_tab(self):
        for sheet_name in self.workbook.sheetnames:
            ws = self.workbook[sheet_name]
            self.assertTrue(all(c.font.bold for c in ws[1]))
            self.assertEqual(ws.freeze_panes, "A2")
            self.assertIsNotNone(ws.auto_filter.ref)

    def test_total_rows_across_all_tabs_equals_input_count(self):
        total_rows = sum(self.workbook[name].max_row - 1 for name in self.workbook.sheetnames)
        self.assertEqual(total_rows, len(self.rows))

    def test_no_row_duplicated_or_omitted_across_tabs(self):
        all_codes = []
        for name in self.workbook.sheetnames:
            all_codes.extend(row[1] for row in self.workbook[name].iter_rows(min_row=2, values_only=True))
        self.assertEqual(len(all_codes), len(set(all_codes)))
        self.assertEqual(set(all_codes), {r["Student Code"] for r in self.rows})

    def test_empty_input_still_produces_a_valid_openable_workbook(self):
        buffer = build_enrolled_export([])
        workbook = openpyxl.load_workbook(buffer)
        self.assertEqual(len(workbook.sheetnames), 1)
        ws = workbook.active
        self.assertEqual(ws.max_row, 1)  # header row only

    def test_missing_values_do_not_raise_and_leave_the_cell_blank(self):
        # openpyxl reads a written "" cell back as None on reload - both
        # read as "blank" in Excel, so this just asserts nothing raises and
        # the cell isn't some other stray value.
        rows = [_row("Uni C", **{"Consultant": None, "Location": None, "Phone Number": None, "Email": None, "Enrolled Date": None})]
        buffer = build_enrolled_export(rows)
        wb = openpyxl.load_workbook(buffer)
        ws = wb["Uni C"]
        values = list(ws.iter_rows(min_row=2, max_row=2, values_only=True))[0]
        self.assertIsNone(values[0])
        self.assertIsNone(values[4])
        self.assertIsNone(values[6])
        self.assertIsNone(values[7])
        self.assertIsNone(values[9])

    def test_sheet_name_collision_after_sanitisation_is_resolved_uniquely(self):
        rows = [
            _row("Anna:Marie", **{"Student Code": "C001", "Student Name": "A"}),
            _row("Anna?Marie", **{"Student Code": "C002", "Student Name": "B"}),
        ]
        buffer = build_enrolled_export(rows)
        workbook = openpyxl.load_workbook(buffer)
        self.assertEqual(len(workbook.sheetnames), 2)
        self.assertEqual(len(set(workbook.sheetnames)), 2)
        all_codes = []
        for name in workbook.sheetnames:
            all_codes.extend(row[1] for row in workbook[name].iter_rows(min_row=2, values_only=True))
        self.assertEqual(sorted(all_codes), ["C001", "C002"])

    def test_worksheet_title_truncated_to_31_characters(self):
        long_name = "A" * 50
        rows = [_row(long_name, **{"Student Code": "L001", "Student Name": "Long"})]
        buffer = build_enrolled_export(rows)
        workbook = openpyxl.load_workbook(buffer)
        self.assertTrue(all(len(name) <= 31 for name in workbook.sheetnames))


class ExportFilenameTests(unittest.TestCase):
    def test_basic_filename(self):
        self.assertEqual(export_filename(date(2026, 8, 13)), "Enrolled_13-08-2026.xlsx")

    def test_filename_includes_intake_year_when_given(self):
        self.assertEqual(
            export_filename(date(2026, 8, 13), intake_year=2026), "Enrolled_2026_13-08-2026.xlsx"
        )

    def test_filename_includes_intake_bucket_label_when_given(self):
        self.assertEqual(
            export_filename(date(2026, 8, 13), intake_year=2027, intake_bucket_label="Intake 03"),
            "Enrolled_2027_Intake03_13-08-2026.xlsx",
        )


class FormulaInjectionProtectionTests(unittest.TestCase):
    """Confirms build_enrolled_export() is actually wired to
    excel_export_helpers.safe_append_row() (Finding 11), not just that
    the helper itself works in isolation (covered in
    test_excel_export_helpers.py)."""

    def test_formula_looking_student_name_is_not_stored_as_a_formula(self):
        rows = [_row("Uni A", **{"Student Name": "=SUM(1,1)"})]
        workbook = openpyxl.load_workbook(build_enrolled_export(rows))
        ws = workbook["Uni A"]
        cell = ws.cell(row=2, column=EXPORT_COLUMNS.index("Student Name") + 1)
        self.assertEqual(cell.value, "=SUM(1,1)")
        self.assertNotEqual(cell.data_type, "f")


if __name__ == "__main__":
    unittest.main()
