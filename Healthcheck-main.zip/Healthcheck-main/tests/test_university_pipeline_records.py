"""University Pipeline: clicking a piece of the chart lists the applications in
it (PES Code, Student, University, Intake, Consultant, Application Manager).

The records endpoint behind the pop-up window, and the markup that opens it.
(The window itself is browser JavaScript; tests/ can only check its wiring.)"""

import io
import re
import unittest
from pathlib import Path
from urllib.parse import parse_qs, urlencode

from flask import template_rendered

from pipeline import PIPELINE_HEALTH_STAGE_GROUPS, chart_segment_records
from tests.flask_test_support import IsolatedAppTestCase, app_module, extract_token
from tests.test_university_pipeline_export import LOOKUPS, ROWS, app_row, captured
from tests.test_upload_atomicity import book

STAGES_OF = {g["key"]: g["stages"] for g in PIPELINE_HEALTH_STAGE_GROUPS}
EVIL = "<img src=x onerror=alert(1)>"
ALL_ROWS = ROWS + [app_row("H1", "September 2026", "Assessment", "Mo Y", "Uni A", name=EVIL, consultant="Mel M")]

QUERIES = ["year=2026", "year=2026&manager=Nouran", "year=2026&consultant=Mel", "year=2026&status=05-Assessment&status=09-Enrolled",
           "year=2026&intake_month=9&intake_month=10", "year=2026&manager=Mo&consultant=Raneen&status=09-Enrolled&intake_month=9",
           "year=2026&office=OXF", "year=2026&office=MAN&consultant=Mel", "year=2027", "year=2027&intake=intake_03", "year=2026&manager=Nobody&consultant=Nobody&status=Nope&intake_month=99"]


class RecordHelperTests(unittest.TestCase):
    def rows(self):
        return [
            {"Student Code": "P2", "Student Name": "zed", "University Name": "Uni A", "Intake": "September 2026", "Consultant": "Mel", "Application": "Mo", "Status": "05-Assessment"},
            {"Student Code": "P1", "Student Name": "Amy", "University Name": "Uni A", "Intake": "October 2026", "Consultant": "", "Application": "", "Status": "04-Onboarding"},
            {"Student Code": "P3", "Student Name": "Bob", "University Name": "Uni A", "Intake": "x", "Consultant": "Mel", "Application": "Mo", "Status": "06-Decision"},
            {"Student Code": "P4", "Student Name": "Cat", "University Name": "Uni B", "Intake": "x", "Consultant": "Mel", "Application": "Mo", "Status": "05-Assessment"},
            {"Student Code": "P5", "Student Name": "Dan", "University Name": "", "Intake": "x", "Consultant": "Mel", "Application": "Mo", "Status": "05-Assessment"},
            {"Student Code": "P6", "Student Name": "Eve", "University Name": "Uni A", "Intake": "x", "Consultant": "Mel", "Application": "Mo", "Status": "00-QARejected"},
        ]

    def test_only_that_university_and_those_stages_sorted_by_student_then_code(self):
        records = chart_segment_records(self.rows(), "Uni A", ("04-Onboarding", "05-Assessment"))
        self.assertEqual([r["code"] for r in records], ["P1", "P2"])
        self.assertEqual(records[1], {"code": "P2", "student": "zed", "university": "Uni A", "intake": "September 2026", "consultant": "Mel", "manager": "Mo"})

    def test_blank_consultant_manager_and_university_read_unassigned_like_the_chart(self):
        self.assertEqual(chart_segment_records(self.rows(), "Uni A", ("04-Onboarding",))[0]["consultant"], "Unassigned")
        self.assertEqual(chart_segment_records(self.rows(), "Uni A", ("04-Onboarding",))[0]["manager"], "Unassigned")
        unassigned = chart_segment_records(self.rows(), "Unassigned", ("05-Assessment",))
        self.assertEqual([(r["code"], r["university"]) for r in unassigned], [("P5", "Unassigned")])

    def test_statuses_outside_the_stages_and_other_universities_never_appear(self):
        codes = {r["code"] for r in chart_segment_records(self.rows(), "Uni A", ("04-Onboarding", "05-Assessment", "06-Decision"))}
        self.assertEqual(codes, {"P1", "P2", "P3"})
        self.assertEqual(chart_segment_records(self.rows(), "Nowhere", ("05-Assessment",)), [])
        self.assertEqual(chart_segment_records([], "Uni A", ("05-Assessment",)), [])
        self.assertEqual(chart_segment_records(self.rows(), "Uni A", ()), [])

    def test_ties_on_student_name_are_broken_by_code(self):
        rows = [{"Student Code": c, "Student Name": "Sam", "University Name": "U", "Status": "05-Assessment"} for c in ("B", "A", "C")]
        self.assertEqual([r["code"] for r in chart_segment_records(rows, "U", ("05-Assessment",))], ["A", "B", "C"])


class RecordsBase(IsolatedAppTestCase):
    def setUp(self):
        super().setUp()
        self.full = self._client_logged_in_as("full")
        token = extract_token(self.full.get("/login").get_data(as_text=True))
        data = book(ALL_ROWS, lookups=LOOKUPS)
        self.assertEqual(self.full.post("/upload", data={"csrf_token": token, "excel_file": (io.BytesIO(data), "f.xlsx")},
                                        content_type="multipart/form-data").status_code, 302)

    def page(self, query, client=None):
        with captured() as rendered:
            r = (client or self.full).get("/university-pipeline?" + query)
        self.assertEqual(r.status_code, 200, query)
        return r.get_data(as_text=True), next(c for name, c in rendered if name == "university_pipeline.html")

    def records(self, query, university, group, client=None):
        r = (client or self.full).get("/university-pipeline/records?" + query + "&" + urlencode({"university": university, "group": group}))
        return r

    def segments(self, context):
        return [(row["name"], seg["key"], seg["count"]) for g in context["pending_stage_chart_groups"] for row in g["rows"] for seg in row["segments"]]



class RecordsRouteTests(RecordsBase):
    def test_every_piece_of_the_chart_lists_exactly_the_number_of_records_it_shows(self):
        checked = 0
        for query in QUERIES:
            _, context = self.page(query)
            for university, group, count in self.segments(context):
                r = self.records(query, university, group)
                self.assertEqual(r.status_code, 200, (query, university, group))
                data = r.get_json()
                self.assertEqual(data["count"], count, (query, university, group))
                self.assertEqual(len(data["records"]), count, (query, university, group))
                self.assertEqual({rec["university"] for rec in data["records"]}, {university})
                checked += 1
        self.assertGreater(checked, 20, "the data gives plenty of pieces to check")

    def test_the_records_of_every_piece_of_one_bar_add_up_to_the_bar(self):
        for query in QUERIES:
            _, context = self.page(query)
            for g in context["pending_stage_chart_groups"]:
                for row in g["rows"]:
                    codes = []
                    for seg in row["segments"]:
                        codes += [rec["code"] for rec in self.records(query, row["name"], seg["key"]).get_json()["records"]]
                    self.assertEqual(len(codes), row["total"], (query, row["name"]))
                    self.assertEqual(len(codes), len(set(codes)), "no application in two pieces")

    def test_each_record_has_the_six_fields(self):
        data = self.records("year=2026", "Uni A", "pending_assessment").get_json()
        self.assertEqual(data["university"], "Uni A")
        self.assertEqual(data["group"], "Pending Assessment")
        self.assertEqual(sorted(data["records"][0]), ["code", "consultant", "intake", "manager", "student", "university"])
        by_code = {r["code"]: r for r in data["records"]}
        self.assertEqual(by_code["A1"], {"code": "A1", "student": "A1", "university": "Uni A", "intake": "August 2026", "consultant": "Raneen", "manager": "Nouran"})
        self.assertEqual(by_code["A6"]["consultant"], "Hannah")
        self.assertEqual(set(by_code), {"A1", "A6", "H1"})

    def test_the_records_are_sorted_by_student_name_then_code(self):
        data = self.records("year=2026", "Uni A", "pending_assessment").get_json()
        keys = [(r["student"].lower(), r["code"]) for r in data["records"]]
        self.assertEqual(keys, sorted(keys))

    def test_the_pages_filters_narrow_the_records_the_same_way_they_narrow_the_chart(self):
        everything = {r["code"] for r in self.records("year=2026", "Uni A", "pending_assessment").get_json()["records"]}
        self.assertEqual(everything, {"A1", "A6", "H1"})
        for query, expected in (("year=2026&manager=Nouran", {"A1", "A6"}), ("year=2026&manager=Mo", {"H1"}), ("year=2026&consultant=Hannah", {"A6"}),
                                ("year=2026&consultant=Raneen", {"A1"}), ("year=2026&intake_month=8", {"A1"}), ("year=2026&intake_month=8&intake_month=11", {"A1", "A6"}),
                                ("year=2026&office=OXF", {"A1"}), ("year=2026&office=MAN", {"H1"}), ("year=2026&office=LON", {"A6"}), ("year=2026&office=LON&manager=Mo", set()),
                                ("year=2026&status=06-Decision", set()), ("year=2026&status=05-Assessment&manager=Nouran&intake_month=11", {"A6"})):
            got = {r["code"] for r in self.records(query, "Uni A", "pending_assessment").get_json()["records"]}
            self.assertEqual(got, expected, query)

    def test_the_other_stage_groups(self):
        self.assertEqual({r["code"] for r in self.records("year=2026", "Uni B", "pending_offer").get_json()["records"]}, {"A2"})
        self.assertEqual({r["code"] for r in self.records("year=2026", "Uni B", "lost").get_json()["records"]}, {"A5"})
        self.assertEqual({r["code"] for r in self.records("year=2026", "Uni A", "enrolled_this_intake").get_json()["records"]}, {"A3"})
        self.assertEqual({r["code"] for r in self.records("year=2026", "Unassigned", "enrolled_this_intake").get_json()["records"]}, {"A8"})
        self.assertEqual(self.records("year=2026", "Uni A", "pending_enrolment").get_json()["records"], [])

    def test_applications_at_stages_the_chart_does_not_draw_are_in_no_piece(self):
        every = {r["code"] for group in STAGES_OF for r in self.records("year=2026", "Uni A", group).get_json()["records"]}
        self.assertNotIn("A4", every, "A4 is 02-PendingQA")
        self.assertNotIn("A7", every, "A7 is 00-QARejected")

    def test_an_unknown_or_missing_group_is_a_400_with_a_message(self):
        for query in ("university=Uni+A", "university=Uni+A&group=", "university=Uni+A&group=nope", "university=Uni+A&group=PENDING_OFFER"):
            r = self.full.get("/university-pipeline/records?year=2026&" + query)
            self.assertEqual(r.status_code, 400, query)
            self.assertEqual(r.get_json(), {"error": "Unknown chart group."})

    def test_an_unknown_or_missing_university_is_an_empty_list_not_an_error(self):
        for university in ("Nowhere", "", "uni a", "Uni A "):
            r = self.full.get("/university-pipeline/records?year=2026&group=pending_assessment&" + urlencode({"university": university}))
            self.assertEqual((r.status_code, r.get_json()["count"], r.get_json()["records"]), (200, 0, []), repr(university))
        r = self.full.get("/university-pipeline/records?year=2026&group=pending_assessment")
        self.assertEqual(r.get_json()["count"], 0)

    def test_names_come_back_as_plain_json_text_and_the_page_script_never_writes_html(self):
        data = self.records("year=2026", "Uni A", "pending_assessment").get_json()
        self.assertIn(EVIL, [r["student"] for r in data["records"]])
        r = self.records("year=2026", "Uni A", "pending_assessment")
        self.assertEqual(r.mimetype, "application/json")
        script = (Path(app_module.app.static_folder) / "chart-records.js").read_text()
        self.assertNotIn("innerHTML", script)
        self.assertNotIn("insertAdjacentHTML", script)
        self.assertNotIn("document.write", script)
        self.assertNotIn("eval(", script)

    def test_the_response_is_not_cached(self):
        self.assertEqual(self.records("year=2026", "Uni A", "lost").headers["Cache-Control"], "no-store")

    def test_login_is_required_and_every_role_can_use_it(self):
        r = app_module.app.test_client().get("/university-pipeline/records?year=2026&university=Uni+A&group=lost")
        self.assertEqual(r.status_code, 302)
        self.assertIn("/login", r.headers["Location"])
        for role in ("admissions", "consultants", "marketing"):
            r = self.records("year=2026", "Uni A", "pending_assessment", client=self._client_logged_in_as(role))
            self.assertEqual(r.get_json()["count"], 3, role)

    def test_with_no_dataset_it_is_an_empty_list(self):
        import sqlite3
        from tests.flask_test_support import db_module
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute("DELETE FROM active_dataset")
        conn.commit()
        conn.close()
        r = self.records("year=2026", "Uni A", "pending_assessment")
        self.assertEqual((r.status_code, r.get_json()["count"]), (200, 0))


class PageMarkupTests(RecordsBase):
    """The chart pieces are clickable and the window is on the page. (Inherits the data set, not the tests.)"""

    def test_every_chart_piece_is_a_keyboard_reachable_button_that_says_what_it_opens(self):
        html, context = self.page("year=2026")
        pieces = re.findall(r'<div class="chart-segment chart-segment-clickable" role="button" tabindex="0"\s+style="[^"]*"\s+data-tooltip="([^"]*)"\s+'
                            r'data-records-title="([^"]*)"\s+data-records-params="([^"]*)"\s+data-count="(\d+)"', html)
        parsed = []
        for tooltip, title, params, count in pieces:
            query = parse_qs(params.replace("&amp;", "&"))
            university, group = query["university"][0], query["group"][0]
            self.assertEqual(sorted(query), ["group", "university"])
            self.assertEqual(tooltip, f"{university} - {title.split(' &mdash; ')[1]}: {count}", "the hover tooltip is unchanged")
            self.assertTrue(title.startswith(f"{university} &mdash; "), title)
            parsed.append((university, group, int(count)))
        self.assertEqual(parsed, self.segments(context))
        self.assertEqual(html.count("chart-segment-clickable"), len(pieces))

    def test_the_window_and_its_script_are_on_the_page_once(self):
        html, _ = self.page("year=2026")
        self.assertEqual(html.count('<dialog id="chart-records"'), 1)
        self.assertIn('data-url="/university-pipeline/records"', html)
        self.assertEqual(html.count("chart-records.js"), 1)
        self.assertEqual(html.count("data-close"), 2, "a cross and a Close button")
        self.assertIn("Click a bar to list its applications.", html)
        self.assertEqual(self.full.get("/static/chart-records.js").status_code, 200)

    def test_with_nothing_drawn_there_is_no_window(self):
        html, context = self.page("year=2026&status=02-PendingQA")
        self.assertFalse(context["chart_has_data"])
        self.assertNotIn('<dialog id="chart-records"', html)

    def test_the_script_wires_the_copy_buttons_close_and_the_filters(self):
        script = (Path(app_module.app.static_folder) / "chart-records.js").read_text()
        for needle in ("'copy-btn'", "data-code", "navigator.clipboard.writeText", "showCopied", "fallbackCopy", "window.location.search",
                       "data-records-title", "data-records-params", "params.set(key, value)", "showModal", "dialog.close()", "textContent",
                       "'PES Code'", "'Student'", "'University'", "'Intake'", "'Consultant'", "'Application Manager'"):
            self.assertIn(needle, script, needle)
        self.assertNotIn("backdrop", script.lower(), "clicking outside the window does not close it")
        self.assertLess(script.index("'PES Code'"), script.index("'Student'"))
        self.assertLess(script.index("'Student'"), script.index("'University'"))
        self.assertLess(script.index("'University'"), script.index("'Intake'"))
        self.assertLess(script.index("'Intake'"), script.index("'Consultant'"))
        self.assertLess(script.index("'Consultant'"), script.index("'Application Manager'"))


if __name__ == "__main__":
    unittest.main()
