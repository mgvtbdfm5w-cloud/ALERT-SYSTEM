import json
import shutil
import sqlite3
import tempfile
import unittest
from datetime import date
from pathlib import Path
from unittest import mock

import openpyxl

import db
from db import ACTIVE_DATASET_RETENTION_LIMIT, load_active_leads_dataset
from leads import (
    LEAD_STAGE_LOOKUP,
    LEADS_COLUMNS,
    REQUIRED_LEADS_SOURCE_COLUMNS,
    LeadsProcessingError,
    build_leads_export_workbook,
    lookup_stage,
    process_leads_workbook,
    save_active_leads_dataset,
)

_ALL_SOURCE_COLUMNS = [
    "Name",
    "Student Id",
    "Mobile No",
    "Phone Number",
    "Location",
    "Lead Status",
    "Lead Source",
    "Call Attempt",
    "Campaign Name",
    "Counsellor",
    "Agency Name",
    "Creation Date",
    "Stage Length",
    "Last Updated",
    "Status",
]


class ProcessLeadsWorkbookTests(unittest.TestCase):
    """Leads Generated maps the source workbook's raw columns onto the
    fixed LEADS_COLUMNS presentation shape (see leads.py's module
    docstring) - PES Code first, phone/campaign/Status dropped, Counsellor
    -> Consultant (first name only), Lead Source split into Lead
    Source/Sub Source."""

    def setUp(self):
        self.tmp_dir = Path(tempfile.mkdtemp(prefix="gsp_leads_test_"))

    def tearDown(self):
        shutil.rmtree(self.tmp_dir, ignore_errors=True)

    def _make_workbook(self, filename, header_row, data_rows):
        path = self.tmp_dir / filename
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.append(header_row)
        for row in data_rows:
            ws.append(row)
        wb.save(path)
        return path

    def _base_row(self, **overrides):
        row = {
            "Name": "Jo Bloggs",
            "Student Id": "PES1234567",
            "Mobile No": "+44 7000000000",
            "Phone Number": "+44 7000000000",
            "Location": "London",
            "Lead Status": "New Lead",
            "Lead Source": "Inbound Call / Website",
            "Call Attempt": "1",
            "Campaign Name": "Autumn Push",
            "Counsellor": "Hassan Mannan",
            "Agency Name": "",
            "Creation Date": "11-09-2026",
            "Stage Length": "0 Day ago",
            "Last Updated": "11-09-2026 07:12",
            "Status": "Active",
        }
        row.update(overrides)
        return row

    def _make_and_process(self, rows_data):
        path = self._make_workbook(
            "leads.xlsx",
            _ALL_SOURCE_COLUMNS,
            [[r[col] for col in _ALL_SOURCE_COLUMNS] for r in rows_data],
        )
        return process_leads_workbook(path)

    def test_returns_leads_columns_in_the_fixed_order(self):
        columns, rows = self._make_and_process([self._base_row()])
        self.assertEqual(columns, LEADS_COLUMNS)
        self.assertEqual(list(rows[0].keys()), LEADS_COLUMNS)

    def test_student_id_becomes_pes_code_and_is_first(self):
        columns, rows = self._make_and_process([self._base_row(**{"Student Id": "PES9999999"})])
        self.assertEqual(columns[0], "PES Code")
        self.assertEqual(rows[0]["PES Code"], "PES9999999")

    def test_phone_columns_and_campaign_name_and_status_are_dropped(self):
        columns, rows = self._make_and_process([self._base_row()])
        for dropped in ("Mobile No", "Phone Number", "Campaign Name", "Status"):
            self.assertNotIn(dropped, columns)
            self.assertNotIn(dropped, rows[0])

    def test_counsellor_becomes_consultant_first_name_only(self):
        columns, rows = self._make_and_process([self._base_row(Counsellor="Mel Imonhimi")])
        self.assertIn("Consultant", columns)
        self.assertNotIn("Counsellor", columns)
        self.assertEqual(rows[0]["Consultant"], "Mel")

    def test_lead_source_splits_on_slash(self):
        columns, rows = self._make_and_process(
            [self._base_row(**{"Lead Source": "Staff Referral / Kesh Boodhoo"})]
        )
        self.assertEqual(rows[0]["Lead Source"], "Staff Referral")
        self.assertEqual(rows[0]["Sub Source"], "Kesh Boodhoo")

    def test_lead_source_with_no_slash_has_blank_sub_source(self):
        columns, rows = self._make_and_process([self._base_row(**{"Lead Source": "Website"})])
        self.assertEqual(rows[0]["Lead Source"], "Website")
        self.assertEqual(rows[0]["Sub Source"], "")

    def test_lead_status_is_kept_unchanged(self):
        columns, rows = self._make_and_process([self._base_row(**{"Lead Status": "Contacted"})])
        self.assertIn("Lead Status", columns)
        self.assertEqual(rows[0]["Lead Status"], "Contacted")

    def test_stage_is_inserted_directly_before_lead_status(self):
        columns, rows = self._make_and_process([self._base_row()])
        self.assertEqual(columns.index("Stage") + 1, columns.index("Lead Status"))
        self.assertIn("Stage", rows[0])

    def test_stage_is_looked_up_from_lead_status(self):
        columns, rows = self._make_and_process([self._base_row(**{"Lead Status": "Qualified"})])
        self.assertEqual(rows[0]["Stage"], "02 - Qualified")

    def test_several_disqualification_reasons_all_map_to_the_same_stage(self):
        for status in ("Location Issue", "Residency Issue", "SFE Issue", "International",
                       "Disqualified", "English Classes", "Number Invalid", "Unsubscribe",
                       "Health or Family Issue"):
            columns, rows = self._make_and_process([self._base_row(**{"Lead Status": status})])
            self.assertEqual(rows[0]["Stage"], "10 - Disqualified", status)

    def test_stage_lookup_is_case_and_whitespace_insensitive(self):
        columns, rows = self._make_and_process([self._base_row(**{"Lead Status": "  qualified  "})])
        self.assertEqual(rows[0]["Stage"], "02 - Qualified")

    def test_an_unrecognised_lead_status_gets_a_blank_stage(self):
        columns, rows = self._make_and_process([self._base_row(**{"Lead Status": "Something New"})])
        self.assertEqual(rows[0]["Stage"], "")

    def test_extenuating_circumstances_is_disqualified(self):
        for spelling in ("Extenuating Circumstances", "  extenuating CIRCUMSTANCES ", "EXTENUATING CIRCUMSTANCES"):
            columns, rows = self._make_and_process([self._base_row(**{"Lead Status": spelling})])
            self.assertEqual(rows[0]["Stage"], "10 - Disqualified", spelling)
            self.assertEqual(lookup_stage(spelling), "10 - Disqualified", spelling)

    def test_marketing_campaign_is_treated_as_non_responsive(self):
        for spelling in ("Marketing Campaign", "  marketing CAMPAIGN ", "MARKETING CAMPAIGN"):
            columns, rows = self._make_and_process([self._base_row(**{"Lead Status": spelling})])
            self.assertEqual(rows[0]["Stage"], "09 - Non-Responsive", spelling)
            self.assertEqual(lookup_stage(spelling), "09 - Non-Responsive", spelling)

    def test_marketing_campaign_in_another_column_is_not_a_lead_status(self):
        # only the Lead Status column decides the Stage: a lead whose Campaign Name (or Lead Source) says
        # "Marketing Campaign" keeps the Stage its own Lead Status gives it
        columns, rows = self._make_and_process([self._base_row(**{"Lead Status": "Qualified", "Campaign Name": "Marketing Campaign",
                                                                  "Lead Source": "Marketing Campaign / Email"})])
        self.assertEqual(rows[0]["Stage"], "02 - Qualified")
        self.assertEqual(lookup_stage("Marketing Campaigns"), "", "only the exact status")
        self.assertEqual(lookup_stage("Marketing"), "")

    def test_a_marketing_campaign_lead_is_drawn_as_non_responsive_not_unassigned(self):
        from leads_dashboard import build_allocation_report
        columns, rows = self._make_and_process([self._base_row(**{"Lead Status": "Marketing Campaign", "Counsellor": "Raneen R"})])
        segments = build_allocation_report(rows, {"raneen": "OXF"})["groups"][0]["rows"][0]["segments"]
        self.assertEqual([(s["stage"], s["count"]) for s in segments], [("09 - Non-Responsive", 1)])

    def test_every_lead_status_seen_in_the_crm_export_has_a_stage(self):
        # the distinct Lead Status values in the 11 Oct 2026 export - none may fall through to a blank ("Unassigned") Stage
        seen = ["New Lead", "Not Interested", "Non-Responsive", "Disqualified", "Applied", "Future Intake", "Qualified", "Number Invalid",
                "Location Issue", "Applied Lost", "Residency Issue", "Unsubscribe", "SFE Issue", "Awaiting Documents", "Uploaded",
                "Enrolled Student", "International", "English Classes", "Extenuating Circumstances", "Health or Family Issue", "Marketing Campaign"]
        self.assertEqual([status for status in seen if not lookup_stage(status)], [])

    def test_an_extenuating_circumstances_lead_is_drawn_as_disqualified_not_unassigned(self):
        from leads_dashboard import build_allocation_report
        columns, rows = self._make_and_process([self._base_row(**{"Lead Status": "Extenuating Circumstances", "Counsellor": "Raneen R"})])
        segments = build_allocation_report(rows, {"raneen": "OXF"})["groups"][0]["rows"][0]["segments"]
        self.assertEqual([(s["stage"], s["count"]) for s in segments], [("10 - Disqualified", 1)])

    def test_lookup_stage_covers_every_entry_in_lead_stage_lookup(self):
        for raw_status, expected_stage in LEAD_STAGE_LOOKUP.items():
            self.assertEqual(lookup_stage(raw_status), expected_stage)

    def test_lookup_stage_handles_blank_input(self):
        self.assertEqual(lookup_stage(""), "")
        self.assertEqual(lookup_stage(None), "")

    def test_row_with_blank_pes_code_and_name_is_skipped(self):
        columns, rows = self._make_and_process(
            [self._base_row(), self._base_row(**{"Student Id": "", "Name": ""})]
        )
        self.assertEqual(len(rows), 1)

    def test_a_real_excel_date_cell_is_stored_as_an_iso_string(self):
        path = self.tmp_dir / "leads.xlsx"
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.append(_ALL_SOURCE_COLUMNS)
        row = self._base_row()
        row["Creation Date"] = date(2026, 9, 11)
        ws.append([row[col] for col in _ALL_SOURCE_COLUMNS])
        wb.save(path)

        columns, rows = process_leads_workbook(path)
        self.assertEqual(rows[0]["Creation Date"], "2026-09-11")

    def test_creation_date_text_in_dd_mm_yyyy_is_parsed_to_iso(self):
        # The real Leads workbook has Creation Date as plain "DD-MM-YYYY"
        # text, not a real Excel date cell - this must still end up ISO
        # like every other date field, so the Leads Dashboard's month
        # filter (dateutils.safe_date) can actually read it.
        columns, rows = self._make_and_process([self._base_row(**{"Creation Date": "11-09-2026"})])
        self.assertEqual(rows[0]["Creation Date"], "2026-09-11")

    def test_blank_creation_date_is_none(self):
        columns, rows = self._make_and_process([self._base_row(**{"Creation Date": ""})])
        self.assertIsNone(rows[0]["Creation Date"])

    def test_missing_required_source_column_raises(self):
        source_columns = [c for c in _ALL_SOURCE_COLUMNS if c != "Counsellor"]
        path = self._make_workbook(
            "leads.xlsx",
            source_columns,
            [[self._base_row()[col] for col in source_columns]],
        )
        with self.assertRaises(LeadsProcessingError):
            process_leads_workbook(path)

    def test_no_data_rows_raises(self):
        path = self._make_workbook("leads.xlsx", _ALL_SOURCE_COLUMNS, [])
        with self.assertRaises(LeadsProcessingError):
            process_leads_workbook(path)

    def test_unreadable_file_raises_leads_processing_error(self):
        path = self.tmp_dir / "not-a-workbook.xlsx"
        path.write_text("this is not a real xlsx file")
        with self.assertRaises(LeadsProcessingError):
            process_leads_workbook(path)

    def test_uses_the_first_sheet(self):
        path = self.tmp_dir / "leads.xlsx"
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.append(_ALL_SOURCE_COLUMNS)
        row = self._base_row()
        ws.append([row[col] for col in _ALL_SOURCE_COLUMNS])
        wb.create_sheet("Notes")
        wb.save(path)

        columns, rows = process_leads_workbook(path)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["Name"], "Jo Bloggs")


class BuildLeadsExportWorkbookTests(unittest.TestCase):
    def test_header_row_matches_leads_columns(self):
        buffer = build_leads_export_workbook([])
        wb = openpyxl.load_workbook(buffer)
        ws = wb.active
        header = [cell.value for cell in ws[1]]
        self.assertEqual(header, LEADS_COLUMNS)

    def test_data_rows_are_written_in_column_order(self):
        rows = [{"PES Code": "PES1234567", "Name": "Jo Bloggs", "Lead Source": "Website"}]
        buffer = build_leads_export_workbook(rows)
        wb = openpyxl.load_workbook(buffer)
        ws = wb.active
        self.assertEqual(ws.cell(row=2, column=1).value, "PES1234567")
        self.assertEqual(ws.cell(row=2, column=2).value, "Jo Bloggs")

    def test_a_missing_field_is_written_as_a_blank_cell(self):
        rows = [{"PES Code": "PES1234567"}]
        buffer = build_leads_export_workbook(rows)
        wb = openpyxl.load_workbook(buffer)
        ws = wb.active
        name_col = LEADS_COLUMNS.index("Name") + 1
        # openpyxl round-trips a written "" as None on read-back, same as a
        # genuinely blank cell - both mean "nothing here" for this column.
        self.assertIn(ws.cell(row=2, column=name_col).value, (None, ""))

    def test_creation_date_is_written_as_a_real_date_with_ddmmyyyy_format(self):
        rows = [{"PES Code": "PES1234567", "Creation Date": "2026-09-11"}]
        buffer = build_leads_export_workbook(rows)
        wb = openpyxl.load_workbook(buffer)
        ws = wb.active
        date_col_letter = openpyxl.utils.get_column_letter(LEADS_COLUMNS.index("Creation Date") + 1)
        cell = ws[f"{date_col_letter}2"]
        # openpyxl reads a written date back as a datetime, not a date.
        self.assertEqual(cell.value.date(), date(2026, 9, 11))
        self.assertEqual(cell.number_format, "DD/MM/YYYY")

    def test_formula_looking_name_is_not_stored_as_a_formula(self):
        # Confirms build_leads_export_workbook() is actually wired to
        # excel_export_helpers.safe_append_row() (Finding 11).
        rows = [{"PES Code": "PES1234567", "Name": "=SUM(1,1)"}]
        buffer = build_leads_export_workbook(rows)
        wb = openpyxl.load_workbook(buffer)
        ws = wb.active
        name_col = LEADS_COLUMNS.index("Name") + 1
        cell = ws.cell(row=2, column=name_col)
        self.assertEqual(cell.value, "=SUM(1,1)")
        self.assertNotEqual(cell.data_type, "f")


class SaveActiveLeadsDatasetTests(unittest.TestCase):
    def setUp(self):
        self.tmp_dir = Path(tempfile.mkdtemp(prefix="gsp_leads_test_"))
        self.conn = sqlite3.connect(":memory:")
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(
            """
            CREATE TABLE active_leads_dataset (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                original_filename TEXT NOT NULL,
                stored_filename TEXT NOT NULL,
                uploaded_at TEXT NOT NULL,
                row_count INTEGER,
                columns_json TEXT,
                data_json TEXT
            );
            CREATE TABLE active_dataset (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                original_filename TEXT NOT NULL,
                stored_filename TEXT NOT NULL,
                uploaded_at TEXT NOT NULL,
                row_count INTEGER,
                data_json TEXT
            );
            """
        )
        self.conn.commit()

    def tearDown(self):
        self.conn.close()
        shutil.rmtree(self.tmp_dir, ignore_errors=True)

    def test_round_trips_columns_and_rows(self):
        columns = ["PES Code", "Name"]
        rows = [{"PES Code": "PES1234567", "Name": "Jo Bloggs"}]
        save_active_leads_dataset(
            self.conn, "leads.xlsx", "20260911_leads.xlsx", "2026-09-11T09:00:00", columns, rows, self.tmp_dir
        )

        stored = self.conn.execute("SELECT * FROM active_leads_dataset").fetchone()
        self.assertEqual(stored["row_count"], 1)
        self.assertEqual(json.loads(stored["columns_json"]), columns)
        self.assertEqual(json.loads(stored["data_json"]), rows)

    def test_a_later_upload_becomes_the_active_row(self):
        save_active_leads_dataset(self.conn, "a.xlsx", "a.xlsx", "2026-09-10T09:00:00", ["X"], [{"X": 1}], self.tmp_dir)
        save_active_leads_dataset(self.conn, "b.xlsx", "b.xlsx", "2026-09-11T09:00:00", ["Y"], [{"Y": 2}], self.tmp_dir)

        latest = self.conn.execute(
            "SELECT * FROM active_leads_dataset ORDER BY id DESC LIMIT 1"
        ).fetchone()
        self.assertEqual(latest["original_filename"], "b.xlsx")

    def test_table_never_exceeds_the_retention_limit_across_repeated_saves(self):
        for i in range(ACTIVE_DATASET_RETENTION_LIMIT + 3):
            save_active_leads_dataset(
                self.conn, f"file_{i}.xlsx", f"file_{i}.xlsx", f"2026-09-{i + 1:02d}T09:00:00",
                ["X"], [{"X": i}], self.tmp_dir,
            )
            count = self.conn.execute("SELECT COUNT(*) AS c FROM active_leads_dataset").fetchone()["c"]
            self.assertLessEqual(count, ACTIVE_DATASET_RETENTION_LIMIT)

    def test_current_dataset_loading_still_returns_the_newest_snapshot(self):
        for i in range(ACTIVE_DATASET_RETENTION_LIMIT + 3):
            save_active_leads_dataset(
                self.conn, f"file_{i}.xlsx", f"file_{i}.xlsx", f"2026-09-{i + 1:02d}T09:00:00",
                ["X"], [{"X": i}], self.tmp_dir,
            )

        dataset, columns, rows = load_active_leads_dataset(self.conn)
        last_i = ACTIVE_DATASET_RETENTION_LIMIT + 2
        self.assertEqual(dataset["original_filename"], f"file_{last_i}.xlsx")
        self.assertEqual(rows, [{"X": last_i}])

    def test_pruning_failure_rolls_back_the_insert_too(self):
        save_active_leads_dataset(self.conn, "a.xlsx", "a.xlsx", "2026-09-10T09:00:00", ["X"], [{"X": 1}], self.tmp_dir)

        with mock.patch("leads.prune_active_dataset_table", side_effect=RuntimeError("boom")):
            with self.assertRaises(RuntimeError):
                save_active_leads_dataset(
                    self.conn, "b.xlsx", "b.xlsx", "2026-09-11T09:00:00", ["Y"], [{"Y": 2}], self.tmp_dir
                )

        count = self.conn.execute("SELECT COUNT(*) AS c FROM active_leads_dataset").fetchone()["c"]
        self.assertEqual(count, 1)
        dataset, _, _ = load_active_leads_dataset(self.conn)
        self.assertEqual(dataset["original_filename"], "a.xlsx")

    def test_repeated_uploads_keep_filesystem_aligned_with_retained_snapshots(self):
        # This is about which files are orphans, not how old they are (the
        # minimum-age guard is covered in test_upload_cleanup_age.py), and the
        # files here are all created moments ago.
        patcher = mock.patch.object(db, "ORPHAN_MIN_AGE_SECONDS", 0)
        patcher.start()
        self.addCleanup(patcher.stop)
        # Managed-upload-shaped filenames (leads_<14 digits>_name.xlsx), the
        # same convention leads_upload() actually constructs, so cleanup
        # actually has something to act on.
        for i in range(1, ACTIVE_DATASET_RETENTION_LIMIT + 4):
            name = f"leads_202609{i:02d}090000_test.xlsx"
            (self.tmp_dir / name).write_text("")
            save_active_leads_dataset(
                self.conn, name, name, f"2026-09-{i:02d}T09:00:00", ["X"], [{"X": i}], self.tmp_dir,
            )

        on_disk = {p.name for p in self.tmp_dir.iterdir()}
        retained_filenames = {
            row["stored_filename"]
            for row in self.conn.execute("SELECT stored_filename FROM active_leads_dataset")
        }
        self.assertEqual(len(retained_filenames), ACTIVE_DATASET_RETENTION_LIMIT)
        managed_on_disk = {n for n in on_disk if n.startswith("leads_")}
        self.assertEqual(managed_on_disk, retained_filenames)


if __name__ == "__main__":
    unittest.main()
