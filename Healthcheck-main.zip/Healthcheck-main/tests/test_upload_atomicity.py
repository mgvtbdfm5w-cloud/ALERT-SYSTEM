"""Applications upload / reprocess are ONE database transaction.

Everything an upload changes in the database - the first-ever seeding of
`lookup_tables` from the workbook's Lookups sheet, the per-row
`unmapped_lookup_values` bookkeeping, the new `active_dataset` snapshot and
the retention pruning - is committed ONCE, in save_active_dataset(). Before,
process_workbook() committed the lookup/bookkeeping part on its own first, so
a later failure left those changes behind (inflated counts; lookups seeded
from a workbook whose upload had failed). Now a failure at any point before
the final commit rolls ALL of it back, and nothing after the commit (upload
file cleanup) can undo or be reached by a failure.

Failures are injected at the three places the save step can fail: the
retention prune, the snapshot INSERT (an aborting trigger stands in for a full
disk), and the final COMMIT itself. Temp databases and uploads
folders only; connections are tracked so cleanup and locks are checked
deterministically.
"""

import ast
import html
import inspect
import io
import re
import sqlite3
import unittest
from contextlib import contextmanager
from unittest import mock

import openpyxl

import processing
from processing import REQUIRED_IMPORT_COLUMNS, process_workbook, save_active_dataset
from tests.connection_tracking import ConnectionTracker
from tests.flask_test_support import IsolatedAppTestCase, app_module, db_module, extract_token

UNMAPPED_SQL = "SELECT table_name, value, occurrence_count, resolved FROM unmapped_lookup_values ORDER BY table_name, value"
LOOKUPS_SQL = "SELECT table_name, source_value, mapped_value FROM lookup_tables ORDER BY id"
SUCCESS_UPLOAD = "Upload succeeded. 2 rows processed, 3 unmapped lookup value(s) found."
SUCCESS_REPROCESS = "Reprocessing succeeded. 2 rows processed, 3 unmapped lookup value(s) found."
FAILURE_KINDS = ("prune", "insert", "commit")


def row(**fields):
    r = {c: "" for c in REQUIRED_IMPORT_COLUMNS}
    r.update(fields)
    return r


def book(rows, lookups=None, extra_columns=()):
    """An Applications workbook; `lookups` fills a Lookups sheet
    ({'status': [(key, mapped)], ...}) which seeds lookup_tables on the
    first-ever upload; `extra_columns` are optional source columns (such as
    "Offer Accepted Date") written after the required ones."""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Import"
    columns = list(REQUIRED_IMPORT_COLUMNS) + list(extra_columns)
    ws.append(columns)
    for r in rows:
        ws.append([r.get(c, "") for c in columns])
    if lookups:
        sheet = wb.create_sheet("Lookups")
        sheet.append(["Status", "Mapped", None, "Office", "Mapped", None, "SalesOffice", "Mapped"])
        for column, key in ((1, "status"), (4, "office"), (7, "sales_office")):
            for i, (k, v) in enumerate(lookups.get(key, []), start=2):
                sheet.cell(i, column, k)
                sheet.cell(i, column + 1, v)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


# 2 rows with an unmapped Application Status, 1 with an unmapped Counsellor and Admission Officer:
# one clean pass records status x2, sales_office x1, office x1 -> "3 unmapped value(s)".
BOOK = book([
    row(**{"Student Code": "P1", "Student Name": "A", "Application Status": "Weird Status", "Counsellor": "Newbie X", "Admission Officer": "Nobody Y"}),
    row(**{"Student Code": "P2", "Student Name": "B", "Application Status": "Weird Status"}),
])
CLEAN_COUNTS = [("office", "Nobody Y", 1, 0), ("sales_office", "Newbie", 1, 0), ("status", "Weird Status", 2, 0)]
AFTER_UPLOAD_AND_REPROCESS = [("office", "Nobody Y", 2, 0), ("sales_office", "Newbie", 2, 0), ("status", "Weird Status", 4, 0)]


class AtomicityTestCase(IsolatedAppTestCase):
    def setUp(self):
        super().setUp()
        self.tracker = ConnectionTracker(db_module)
        self.tracker.install()
        self.addCleanup(self.tracker.uninstall)
        self.addCleanup(self.tracker.force_close_leaks)
        self.client = self._client_logged_in_as("full")

    # ------------------------------------------------------------ helpers
    def token(self):
        return extract_token(self.client.get("/login").get_data(as_text=True))

    def upload(self, data, name="t.xlsx"):
        return self.client.post(
            "/upload", data={"csrf_token": self.token(), "excel_file": (io.BytesIO(data), name)},
            content_type="multipart/form-data",
        )

    def reprocess(self):
        return self.client.post("/admin/reprocess", data={"csrf_token": self.token()})

    def flashes(self, response):
        page = self.client.get(response.headers["Location"]).get_data(as_text=True)
        return [(k, html.unescape(v)) for k, v in re.findall(r'class="flash (\w+)">([^<]+)<', page)]

    def query(self, sql, params=()):
        conn = sqlite3.connect(db_module.DB_PATH)
        try:
            return [tuple(r) for r in conn.execute(sql, params).fetchall()]
        finally:
            conn.close()

    def state(self):
        return {
            "datasets": self.query("SELECT id, stored_filename FROM active_dataset ORDER BY id"),
            "lookups": self.query(LOOKUPS_SQL),
            "unmapped": self.query(UNMAPPED_SQL),
        }

    def add_existing_lookup(self):
        """A non-empty lookup table, so seeding does not happen (the live
        situation)."""
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute("INSERT INTO lookup_tables (table_name, source_value, mapped_value, created_at) VALUES ('status','Known','01-Known','2026-01-01T00:00:00')")
        conn.commit()
        conn.close()

    @contextmanager
    def failing(self, kind):
        """The three ways the save step can fail AFTER processing."""
        if kind == "prune":
            with mock.patch("processing.prune_active_dataset_table", side_effect=sqlite3.OperationalError("disk I/O error")):
                yield
        elif kind == "insert":
            conn = sqlite3.connect(db_module.DB_PATH)
            conn.execute("CREATE TRIGGER fail_insert BEFORE INSERT ON active_dataset BEGIN SELECT RAISE(ABORT, 'database or disk is full'); END")
            conn.commit()
            conn.close()
            try:
                yield
            finally:
                conn = sqlite3.connect(db_module.DB_PATH)
                conn.execute("DROP TRIGGER fail_insert")
                conn.commit()
                conn.close()
        elif kind == "commit":
            with self.tracker.failing("commit"):
                yield
        else:  # pragma: no cover
            raise AssertionError(kind)

    def assert_closed_and_unlocked(self):
        self.assertEqual(self.tracker.leaked(), [], "every connection closed")
        probe = sqlite3.connect(db_module.DB_PATH, timeout=0, isolation_level=None)
        try:
            probe.execute("BEGIN IMMEDIATE")      # fails instantly if a leaked connection still holds the write lock
            probe.execute("ROLLBACK")
        finally:
            probe.close()


# =========================================================================
# 1. Failed Applications upload: nothing at all persists
# =========================================================================
class FailedUploadRollsBackEverythingTests(AtomicityTestCase):
    def test_failed_upload_leaves_unmapped_bookkeeping_unchanged(self):
        self.add_existing_lookup()
        for kind in FAILURE_KINDS:
            with self.subTest(failure=kind):
                before = self.state()
                with self.failing(kind):
                    response = self.upload(BOOK)
                self.assertEqual(self.flashes(response), [("error", "Upload failed due to an unexpected error. Please try again or contact support.")])
                self.assertEqual(self.state()["unmapped"], before["unmapped"])
                self.assertEqual(self.state()["unmapped"], [])

    def test_failed_upload_leaves_no_snapshot(self):
        self.add_existing_lookup()
        for kind in FAILURE_KINDS:
            with self.subTest(failure=kind):
                with self.failing(kind):
                    self.upload(BOOK)
                self.assertEqual(self.state()["datasets"], [])

    def test_failed_first_ever_upload_leaves_lookup_tables_unchanged(self):
        workbook = book([row(**{"Student Code": "P1", "Student Name": "A", "Application Status": "Alpha"})], lookups={"status": [("Alpha", "01-Seed")], "office": [("Bob", "UK")], "sales_office": [("Cat", "OXF")]})
        for kind in FAILURE_KINDS:
            with self.subTest(failure=kind):
                self.assertEqual(self.state()["lookups"], [])
                with self.failing(kind):
                    self.upload(workbook)
                self.assertEqual(self.state()["lookups"], [], "the seeded lookups were rolled back with the rest")
                self.assertEqual(self.state()["datasets"], [])

    def test_pruning_failure_rolls_back_the_insert_the_seeding_and_the_bookkeeping_together(self):
        self.assert_all_three_roll_back("prune")

    def test_snapshot_insert_failure_rolls_back_the_seeding_and_the_bookkeeping(self):
        self.assert_all_three_roll_back("insert")

    def test_final_commit_failure_rolls_back_all_three(self):
        self.assert_all_three_roll_back("commit")

    def assert_all_three_roll_back(self, kind):
        """A first-ever upload that would write all three kinds of state:
        seeded lookups, unmapped bookkeeping and the snapshot."""
        workbook = book(
            [row(**{"Student Code": "P1", "Student Name": "A", "Application Status": "Unseeded Status", "Counsellor": "Unseeded Consultant"})],
            lookups={"status": [("Alpha", "01-Seed")]},
        )
        before = self.state()
        with self.failing(kind):
            self.upload(workbook)
        self.assertEqual(self.state(), before)
        self.assertEqual(before, {"datasets": [], "lookups": [], "unmapped": []})
        self.assert_closed_and_unlocked()

    def test_connections_are_closed_and_no_lock_remains_after_every_failure(self):
        self.add_existing_lookup()
        for kind in FAILURE_KINDS:
            with self.subTest(failure=kind):
                self.tracker.reset()
                with self.failing(kind):
                    self.upload(BOOK)
                self.assertEqual(self.tracker.leaked(), [])
                self.assertEqual(self.tracker.max_open, 1)
                self.assert_closed_and_unlocked()

    def test_a_processing_error_still_rolls_back_the_seeding(self):
        """Workbook with a Lookups sheet but no data rows: a ProcessingError
        after seeding has already written - it must not leave lookups behind."""
        data = book([], lookups={"status": [("Alpha", "01-Seed")]})
        response = self.upload(data)
        self.assertEqual(self.flashes(response), [("error", "Upload failed: No data rows were found in the 'Import' sheet.")])
        self.assertEqual(self.state(), {"datasets": [], "lookups": [], "unmapped": []})

    def test_a_row_processing_failure_rolls_back_whatever_was_already_recorded(self):
        self.add_existing_lookup()
        calls = {"n": 0}
        real = processing._record_unmapped

        def fail_on_third_call(conn, table, value, now):
            calls["n"] += 1
            if calls["n"] == 3:
                raise RuntimeError("bug in the middle of the loop")
            return real(conn, table, value, now)

        with mock.patch("processing._record_unmapped", side_effect=fail_on_third_call):
            self.upload(BOOK)
        self.assertGreaterEqual(calls["n"], 3)
        self.assertEqual(self.state()["unmapped"], [], "the two already-recorded values were rolled back")
        self.assertEqual(self.state()["datasets"], [])


# =========================================================================
# 2. Failed Reprocess
# =========================================================================
class FailedReprocessRollsBackEverythingTests(AtomicityTestCase):
    def setUp(self):
        super().setUp()
        self.add_existing_lookup()
        self.upload(BOOK)
        self.after_upload = self.state()

    def test_failed_reprocess_leaves_unmapped_bookkeeping_and_snapshots_unchanged(self):
        self.assertEqual(self.after_upload["unmapped"], CLEAN_COUNTS)
        for kind in FAILURE_KINDS:
            with self.subTest(failure=kind):
                with self.failing(kind):
                    response = self.reprocess()
                self.assertEqual(self.flashes(response), [("error", "Reprocessing failed due to an unexpected error. Please try again or contact support.")])
                self.assertEqual(self.state(), self.after_upload, "unmapped counts, lookups AND snapshots all unchanged")
                self.assert_closed_and_unlocked()

    def test_a_row_processing_failure_during_reprocess_rolls_back(self):
        with mock.patch("processing._lookup", side_effect=RuntimeError("bug")):
            self.reprocess()
        self.assertEqual(self.state(), self.after_upload)


# =========================================================================
# 3. Fail-then-retry equals one clean run
# =========================================================================
class RetryDoesNotDoubleCountTests(AtomicityTestCase):
    def clean_control_counts(self, reprocess_times=0):
        self.add_existing_lookup()
        self.upload(BOOK)
        for _ in range(reprocess_times):
            self.reprocess()
        return self.state()["unmapped"]

    def test_upload_fail_then_retry_equals_one_clean_upload(self):
        for kind in FAILURE_KINDS:
            with self.subTest(failure=kind):
                self.add_existing_lookup()
                with self.failing(kind):
                    self.upload(BOOK)
                self.upload(BOOK)
                self.assertEqual(self.state()["unmapped"], CLEAN_COUNTS, "same as a single clean run")
                self.assertEqual(len(self.state()["datasets"]), 1)
                self.client = self._client_logged_in_as("full")
                self.reset_database()

    def test_several_failures_before_the_retry_still_equal_one_clean_run(self):
        self.add_existing_lookup()
        for kind in FAILURE_KINDS * 2:
            with self.failing(kind):
                self.upload(BOOK)
        self.upload(BOOK)
        self.assertEqual(self.state()["unmapped"], CLEAN_COUNTS)

    def test_reprocess_fail_then_retry_equals_a_clean_upload_plus_one_reprocess(self):
        self.add_existing_lookup()
        self.upload(BOOK)
        for kind in FAILURE_KINDS:
            with self.failing(kind):
                self.reprocess()
        self.reprocess()
        self.assertEqual(self.state()["unmapped"], AFTER_UPLOAD_AND_REPROCESS)
        self.assertEqual(len(self.state()["datasets"]), 2)

    def test_first_upload_fail_then_retry_with_a_different_lookups_sheet_uses_the_retry_workbooks_mappings(self):
        failed = book([row(**{"Student Code": "P1", "Student Name": "A", "Application Status": "Alpha"})], lookups={"status": [("Alpha", "01-From-Failed-Upload")]})
        retry = book([row(**{"Student Code": "P1", "Student Name": "A", "Application Status": "Alpha"})], lookups={"status": [("Alpha", "09-From-Retry-Upload")]})
        for kind in FAILURE_KINDS:
            with self.subTest(failure=kind):
                with self.failing(kind):
                    self.upload(failed)
                self.assertEqual(self.state()["lookups"], [])
                self.upload(retry)
                self.assertEqual(self.state()["lookups"], [("status", "Alpha", "09-From-Retry-Upload")])
                import json
                saved = json.loads(self.query("SELECT data_json FROM active_dataset")[0][0])
                self.assertEqual(saved[0]["Status"], "09-From-Retry-Upload", "the retry's own mapping applied")
                self.reset_database()

    def reset_database(self):
        conn = sqlite3.connect(db_module.DB_PATH)
        for table in ("active_dataset", "lookup_tables", "unmapped_lookup_values"):
            conn.execute(f"DELETE FROM {table}")
        conn.commit()
        conn.close()
        for p in list(self.tmp_uploads_dir.iterdir()):
            p.unlink()


# =========================================================================
# 4. Success behaviour is unchanged
# =========================================================================
class SuccessUnchangedTests(AtomicityTestCase):
    def test_a_successful_upload_records_everything(self):
        self.add_existing_lookup()
        response = self.upload(BOOK)
        self.assertEqual(response.headers["Location"].rsplit("/", 1)[-1], "admin")
        self.assertEqual(self.flashes(response), [("success", SUCCESS_UPLOAD)])
        self.assertEqual(self.state()["unmapped"], CLEAN_COUNTS)
        self.assertEqual(len(self.state()["datasets"]), 1)

    def test_a_successful_first_upload_still_seeds_the_lookups(self):
        workbook = book([row(**{"Student Code": "P1", "Student Name": "A", "Application Status": "Alpha"})], lookups={"status": [("Alpha", "01-Seed")], "sales_office": [("Cat", "OXF")]})
        self.assertEqual(self.flashes(self.upload(workbook))[0][0], "success")
        self.assertEqual(self.state()["lookups"], [("status", "Alpha", "01-Seed"), ("sales_office", "Cat", "OXF")])
        self.assertEqual(self.state()["unmapped"], [], "everything was mapped")

    def test_a_successful_reprocess_keeps_the_cumulative_count_behaviour(self):
        self.add_existing_lookup()
        self.upload(BOOK)
        response = self.reprocess()
        self.assertEqual(response.headers["Location"].rsplit("/", 1)[-1], "admin")
        self.assertEqual(self.flashes(response), [("success", SUCCESS_REPROCESS)])
        self.assertEqual(self.state()["unmapped"], AFTER_UPLOAD_AND_REPROCESS, "counts keep accumulating per pass, as designed")
        self.assertEqual(len(self.state()["datasets"]), 2)

    def test_repeated_successes_keep_accumulating_exactly_as_before(self):
        self.add_existing_lookup()
        for n in range(1, 5):
            self.upload(BOOK)
            self.assertEqual([r[2] for r in self.state()["unmapped"]], [n, n, 2 * n])

    def test_retention_still_keeps_only_the_latest_snapshots(self):
        self.add_existing_lookup()
        for _ in range(7):
            self.upload(BOOK)
        self.assertEqual(len(self.state()["datasets"]), 5)

    def test_pruning_failure_still_rolls_back_the_snapshot_when_older_ones_exist(self):
        self.add_existing_lookup()
        for _ in range(5):
            self.upload(BOOK)
        before = self.state()
        with self.failing("prune"):
            self.upload(BOOK)
        self.assertEqual(self.state(), before)

    def test_connections_and_locks_after_a_success(self):
        self.add_existing_lookup()
        self.tracker.reset()
        self.upload(BOOK)
        self.assertEqual(self.tracker.opened, 1, "one connection for the whole upload; nothing else is opened afterwards")
        self.assertEqual(self.tracker.leaked(), [])
        self.assertEqual(self.tracker.max_open, 1)

    def test_upload_file_cleanup_still_runs_after_the_commit(self):
        # About which files are orphans, not how old they are: uploads here
        # are all moments old (the minimum-age guard is covered in
        # test_upload_cleanup_age.py).
        patcher = mock.patch.object(db_module, "ORPHAN_MIN_AGE_SECONDS", 0)
        patcher.start()
        self.addCleanup(patcher.stop)
        self.add_existing_lookup()
        for i in range(8):
            self.upload(BOOK, name=f"upload{i}.xlsx")
        remaining = sorted(p.name for p in self.tmp_uploads_dir.iterdir())
        referenced = sorted(r[1] for r in self.state()["datasets"])
        self.assertEqual(len(referenced), 5)
        self.assertEqual(remaining, referenced, "only files still referenced by a retained snapshot are kept")

    def test_a_cleanup_failure_after_the_commit_does_not_undo_the_upload(self):
        self.add_existing_lookup()
        with mock.patch("processing.cleanup_orphaned_uploads", side_effect=RuntimeError("disk error")):
            response = self.upload(BOOK)
        self.assertEqual(self.flashes(response), [("success", SUCCESS_UPLOAD)])
        self.assertEqual(self.state()["unmapped"], CLEAN_COUNTS)
        self.assertEqual(len(self.state()["datasets"]), 1)


# =========================================================================
# 5. The contract of the two functions, used directly
# =========================================================================
class TransactionContractTests(AtomicityTestCase):
    def setUp(self):
        super().setUp()
        self.add_existing_lookup()
        self.path = self.tmp_uploads_dir / "20260101000000_direct.xlsx"
        self.path.write_bytes(BOOK)

    def run_process(self, conn):
        return process_workbook(self.path, conn, "2026-01-01T00:00:00")

    def test_process_workbook_alone_leaves_its_writes_uncommitted_and_invisible_to_another_connection(self):
        conn = db_module.get_connection()
        try:
            rows, unmapped_count = self.run_process(conn)
            self.assertEqual((len(rows), unmapped_count), (2, 3))
            self.assertTrue(conn.in_transaction, "the writes are pending in the caller's transaction")
            self.assertEqual(len(conn.execute("SELECT * FROM unmapped_lookup_values").fetchall()), 3, "visible to its own connection")
            self.assertEqual(self.query(UNMAPPED_SQL), [], "...but NOT to any other connection")
            conn.rollback()
        finally:
            conn.close()
        self.assertEqual(self.query(UNMAPPED_SQL), [], "closing without a commit discards them")

    def test_process_workbook_alone_does_not_commit_lookup_seeding_either(self):
        self.path.write_bytes(book([row(**{"Student Code": "P1", "Student Name": "A"})], lookups={"status": [("Alpha", "01-Seed")]}))
        conn = db_module.get_connection()
        try:
            conn.execute("DELETE FROM lookup_tables")
            conn.commit()
            self.run_process(conn)
            self.assertEqual(len(conn.execute("SELECT * FROM lookup_tables").fetchall()), 1)
            self.assertEqual(self.query(LOOKUPS_SQL), [], "seeded rows are not visible elsewhere until the save commits")
        finally:
            conn.close()

    def test_save_active_dataset_commits_the_pending_processing_writes(self):
        conn = db_module.get_connection()
        try:
            rows, _ = self.run_process(conn)
            save_active_dataset(conn, "direct.xlsx", self.path.name, "2026-01-01T00:00:00", rows, self.tmp_uploads_dir)
            self.assertFalse(conn.in_transaction)
        finally:
            conn.close()
        self.assertEqual(self.query(UNMAPPED_SQL), CLEAN_COUNTS)
        self.assertEqual(len(self.query("SELECT * FROM active_dataset")), 1)

    def test_a_failing_save_rolls_back_the_pending_processing_writes_too(self):
        conn = db_module.get_connection()
        try:
            rows, _ = self.run_process(conn)
            with mock.patch("processing.prune_active_dataset_table", side_effect=sqlite3.OperationalError("boom")):
                with self.assertRaises(sqlite3.OperationalError):
                    save_active_dataset(conn, "direct.xlsx", self.path.name, "2026-01-01T00:00:00", rows, self.tmp_uploads_dir)
            self.assertFalse(conn.in_transaction)
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM unmapped_lookup_values").fetchone()[0], 0, "even on the SAME connection")
        finally:
            conn.close()
        self.assertEqual(self.query(UNMAPPED_SQL), [])
        self.assertEqual(self.query("SELECT * FROM active_dataset"), [])

    def test_a_processing_error_rolls_the_pending_writes_back_itself(self):
        self.path.write_bytes(book([], lookups={"status": [("Alpha", "01-Seed")]}))
        conn = db_module.get_connection()
        try:
            conn.execute("DELETE FROM lookup_tables")
            conn.commit()
            with self.assertRaises(processing.ProcessingError):
                self.run_process(conn)
            self.assertFalse(conn.in_transaction)
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM lookup_tables").fetchone()[0], 0)
        finally:
            conn.close()

    def test_only_save_active_dataset_commits_in_the_upload_path(self):
        tree = ast.parse(inspect.getsource(processing))
        commits = {
            fn.name: sum(1 for c in ast.walk(fn) if isinstance(c, ast.Call) and getattr(c.func, "attr", "") == "commit")
            for fn in ast.walk(tree) if isinstance(fn, ast.FunctionDef)
        }
        self.assertEqual(commits.get("process_workbook", 0), 0)
        self.assertEqual(commits.get("_record_unmapped", 0), 0)
        self.assertEqual(commits.get("seed_lookup_tables_if_empty", 0), 0)
        self.assertEqual(commits.get("save_active_dataset"), 1, "exactly one commit point")

    def test_the_contract_is_documented_on_both_functions(self):
        self.assertIn("never commits", process_workbook.__doc__)
        self.assertIn("MUST", process_workbook.__doc__)
        self.assertIn("ONE commit", save_active_dataset.__doc__)


# =========================================================================
# 6. Leads is unchanged (already atomic)
# =========================================================================
class LeadsStillAtomicTests(AtomicityTestCase):
    def test_a_failed_leads_save_changes_nothing_else(self):
        from leads import REQUIRED_LEADS_SOURCE_COLUMNS
        from tests.flask_test_support import make_xlsx
        lead = {c: "" for c in REQUIRED_LEADS_SOURCE_COLUMNS}
        lead.update({"Student Id": "L1", "Name": "N"})
        data = make_xlsx(REQUIRED_LEADS_SOURCE_COLUMNS, [lead]).getvalue()
        before = (self.state(), self.query("SELECT id FROM active_leads_dataset"))
        with mock.patch("leads.prune_active_dataset_table", side_effect=sqlite3.OperationalError("disk I/O error")):
            self.client.post("/leads/upload", data={"csrf_token": self.token(), "excel_file": (io.BytesIO(data), "l.xlsx")}, content_type="multipart/form-data")
        self.assertEqual((self.state(), self.query("SELECT id FROM active_leads_dataset")), before)
        self.assert_closed_and_unlocked()


if __name__ == "__main__":
    unittest.main()
