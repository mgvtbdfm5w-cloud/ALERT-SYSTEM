"""Just Jon Lead Allocates: the Excel download beside the "Leads created in" dropdown.

The leads behind the chart, with the click-through window's columns, one
print-ready worksheet per Consultant."""

import io
import re
import unittest
from datetime import date

import openpyxl

import just_jon_leads_export as export
from leads_dashboard import LEAD_RECORD_COLUMNS
from tests.flask_test_support import app_module, extract_token
from tests.test_allocation import lead, leads_book
from tests.test_just_jon_leads_chart import LEADS, LeadsChartBase
from tests.test_just_jon_records import LOOKUPS as APP_LOOKUPS, ROWS as APP_ROWS
from tests.test_role_access import AccessRouteTestCase
from tests.test_upload_atomicity import book

TODAY = date(2026, 10, 18)
HEADERS = ["PES Code", "Name", "Lead Source", "Sub Source", "Lead Status", "Consultant", "Created"]


def sample_rows():
    def row(code, name, consultant, stage, created="2026-08-03", source="Agent", sub="Just Jon", status="New Lead"):
        return {"PES Code": code, "Name": name, "Consultant": consultant, "Stage": stage, "Creation Date": created,
                "Lead Source": source, "Sub Source": sub, "Lead Status": status}
    return [
        row("C", "Zed", "Mel", "04 - Applied", status="Applied"),
        row("A", "Bob", "Mel", "01 - New Lead"),
        row("B", "Amy", "mel", "01 - New Lead", created="2026-09-01"),                  # same person, different capitals
        row("D", "Cat", "Hannah", "02 - Qualified", status="Qualified"),
        row("E", "Dan", "", "01 - New Lead", created="not a date"),
        row("F", "=SUM(1,1)", "Kian", "", status="Strange Status"),                     # grey piece; formula-looking name
        row("G", "Eve", "Raymond/Other: /*?[]", "01 - New Lead"),                       # a name Excel would not allow as a tab title
    ]


class GroupingTests(unittest.TestCase):
    def test_one_group_per_consultant_a_to_z_with_unassigned_last(self):
        groups = export.group_by_consultant(sample_rows())
        self.assertEqual([name for name, _ in groups], ["Hannah", "Kian", "Mel", "Raymond/Other: /*?[]", "Unassigned"])
        self.assertEqual({name: len(rows) for name, rows in groups}, {"Hannah": 1, "Kian": 1, "Mel": 3, "Raymond/Other: /*?[]": 1, "Unassigned": 1})

    def test_unassigned_is_last_even_when_a_consultant_sorts_after_it(self):
        rows = [{"PES Code": "1", "Name": "a", "Consultant": "Zoe", "Stage": ""}, {"PES Code": "2", "Name": "b", "Consultant": "", "Stage": ""},
                {"PES Code": "3", "Name": "c", "Consultant": "Adam", "Stage": ""}]
        self.assertEqual([name for name, _ in export.group_by_consultant(rows)], ["Adam", "Zoe", "Unassigned"])
        self.assertEqual(self.sheet_order(rows), ["Adam", "Zoe", "Unassigned"])

    def sheet_order(self, rows):
        return openpyxl.load_workbook(export.build_just_jon_leads_export(rows, "All months", TODAY)).sheetnames

    def test_names_that_differ_only_in_capitals_are_one_person_first_spelling_wins(self):
        groups = dict(export.group_by_consultant(sample_rows()))
        self.assertEqual(sorted(r["PES Code"] for r in groups["Mel"]), ["A", "B", "C"])
        self.assertNotIn("mel", groups)

    def test_within_a_consultant_lead_stage_order_then_name_then_code(self):
        rows = dict(export.group_by_consultant(sample_rows()))["Mel"]
        self.assertEqual([r["PES Code"] for r in rows], ["B", "A", "C"], "01 New Lead (Amy, Bob) before 04 Applied (Zed)")

    def test_an_unrecognised_stage_sorts_last(self):
        rows = [{"PES Code": "1", "Name": "A", "Consultant": "X", "Stage": ""}, {"PES Code": "2", "Name": "B", "Consultant": "X", "Stage": "10 - Disqualified"},
                {"PES Code": "3", "Name": "C", "Consultant": "X", "Stage": "01 - New Lead"}]
        self.assertEqual([r["PES Code"] for r in dict(export.group_by_consultant(rows))["X"]], ["3", "2", "1"])

    def test_filename(self):
        self.assertEqual(export.export_filename(TODAY), "Just_Jon_Lead_Allocates_18-10-2026.xlsx")
        self.assertEqual(export.export_filename(TODAY, "September 2026"), "Just_Jon_Lead_Allocates_Sep-2026_18-10-2026.xlsx")
        self.assertEqual(export.export_filename(TODAY, "August 2026"), "Just_Jon_Lead_Allocates_Aug-2026_18-10-2026.xlsx")


class WorkbookTests(unittest.TestCase):
    def workbook(self, rows=None, scope="All months"):
        return openpyxl.load_workbook(export.build_just_jon_leads_export(sample_rows() if rows is None else rows, scope, TODAY))

    def test_one_tab_per_consultant_with_safe_titles(self):
        wb = self.workbook()
        self.assertEqual(wb.sheetnames, ["Hannah", "Kian", "Mel", "RaymondOther", "Unassigned"])
        self.assertNotRegex(wb.sheetnames[3], r"[\\/?*\[\]:]")
        self.assertLessEqual(max(len(n) for n in wb.sheetnames), 31)

    def test_two_consultants_that_clean_to_the_same_title_get_different_tabs(self):
        rows = [{"PES Code": "1", "Name": "a", "Consultant": "A/B", "Stage": ""}, {"PES Code": "2", "Name": "b", "Consultant": "A?B", "Stage": ""}]
        self.assertEqual(self.workbook(rows).sheetnames, ["AB", "AB (2)"])
        long = [{"PES Code": "1", "Name": "a", "Consultant": "X" * 40, "Stage": ""}, {"PES Code": "2", "Name": "b", "Consultant": "X" * 40 + "y", "Stage": ""}]
        names = self.workbook(long).sheetnames
        self.assertEqual(len(set(names)), 2)
        self.assertTrue(all(len(n) <= 31 for n in names))

    def test_the_columns_are_the_pop_up_windows_columns_in_the_same_order(self):
        ws = self.workbook()["Mel"]
        self.assertEqual([c.value for c in ws[export.HEADER_ROW]], HEADERS)
        self.assertEqual([c[0] for c in LEAD_RECORD_COLUMNS], HEADERS)
        self.assertEqual(export.HEADERS, HEADERS)

    def test_heading_lines_say_whose_leads_which_months_and_how_many(self):
        ws = self.workbook(scope="September 2026")["Mel"]
        self.assertEqual(ws["A1"].value, "Just Jon Lead Allocates - Mel")
        self.assertEqual(ws["A2"].value, "Leads created: September 2026  |  3 leads  |  Downloaded 18/10/2026")
        self.assertIn("1 lead  |", self.workbook()["Hannah"]["A2"].value, "singular")
        self.assertEqual(ws["A3"].value, None)

    def test_rows_are_in_stage_order_and_carry_the_pop_up_values(self):
        ws = self.workbook()["Mel"]
        rows = [[c.value for c in r] for r in ws.iter_rows(min_row=export.HEADER_ROW + 1)]
        self.assertEqual([r[0] for r in rows], ["B", "A", "C"])
        self.assertEqual(rows[1], ["A", "Bob", "Agent", "Just Jon", "New Lead", "Mel", __import__("datetime").datetime(2026, 8, 3)])
        self.assertEqual(ws.cell(row=export.HEADER_ROW + 1, column=7).number_format, "DD/MM/YYYY")
        self.assertEqual(ws.cell(row=export.HEADER_ROW + 1, column=7).value.date(), date(2026, 9, 1))

    def test_a_lead_with_no_usable_date_has_a_blank_created_cell_and_no_consultant_reads_unassigned(self):
        ws = self.workbook()["Unassigned"]
        row = [c.value for c in ws[export.HEADER_ROW + 1]]
        self.assertEqual(row[0], "E")
        self.assertIn(row[6], (None, ""))
        self.assertEqual(row[5], "Unassigned")

    def test_formula_looking_text_stays_text(self):
        ws = self.workbook()["Kian"]
        cell = ws.cell(row=export.HEADER_ROW + 1, column=2)
        self.assertEqual(cell.value, "=SUM(1,1)")
        self.assertNotEqual(cell.data_type, "f")

    def test_every_tab_is_set_up_to_print_landscape_one_page_wide_and_as_many_long_as_needed(self):
        wb = self.workbook()
        for ws in wb.worksheets:
            self.assertEqual(ws.page_setup.orientation, "landscape", ws.title)
            self.assertEqual(str(ws.page_setup.paperSize), ws.PAPERSIZE_A4, ws.title)
            self.assertEqual(ws.page_setup.fitToWidth, 1, ws.title)
            self.assertEqual(ws.page_setup.fitToHeight, 0, f"{ws.title}: 0 means as many pages long as it needs")
            self.assertTrue(ws.sheet_properties.pageSetUpPr.fitToPage, ws.title)
            self.assertEqual(ws.print_title_rows.replace("$", ""), f"{export.HEADER_ROW}:{export.HEADER_ROW}", f"{ws.title}: headings repeat on every page")
            self.assertTrue(ws.print_options.horizontalCentered, ws.title)
            self.assertEqual(ws.oddFooter.right.text, "Page &P of &N", ws.title)
            self.assertEqual(ws.oddFooter.left.text, "&A", ws.title)

    def test_headings_are_frozen_and_filterable_and_the_columns_wide_enough(self):
        ws = self.workbook()["Mel"]
        self.assertEqual(ws.freeze_panes, f"A{export.HEADER_ROW + 1}")
        self.assertEqual(ws.auto_filter.ref, f"A{export.HEADER_ROW}:G{export.HEADER_ROW + 3}")
        self.assertEqual([round(ws.column_dimensions[c].width) for c in "ABCDEFG"], [14, 32, 18, 18, 22, 14, 12])
        total = sum(ws.column_dimensions[c].width for c in "ABCDEFG")
        self.assertLess(total, 135, "narrow enough to need little shrinking when fitted to one landscape page")

    def test_a_long_list_still_prints_one_page_wide(self):
        rows = [{"PES Code": f"P{i}", "Name": f"Name {i}", "Consultant": "Mel", "Stage": "01 - New Lead", "Creation Date": "2026-08-03"} for i in range(400)]
        ws = self.workbook(rows)["Mel"]
        self.assertEqual(ws.max_row, export.HEADER_ROW + 400)
        self.assertEqual((ws.page_setup.fitToWidth, ws.page_setup.fitToHeight), (1, 0))

    def test_no_leads_gives_one_printable_note_tab(self):
        wb = self.workbook([])
        self.assertEqual(wb.sheetnames, ["No leads"])
        self.assertIn("no Just Jon leads for All months", wb["No leads"]["A1"].value)
        self.assertEqual(wb["No leads"].page_setup.orientation, "landscape")


class RouteTests(LeadsChartBase):
    def download(self, query="", client=None):
        r = (client or self.full).get("/dashboard/just-jon/leads-export" + query)
        self.assertEqual(r.status_code, 200, query)
        self.assertIn("spreadsheetml", r.mimetype)
        return r, openpyxl.load_workbook(io.BytesIO(r.data))

    def sheet_rows(self, wb):
        return {ws.title: [[c.value for c in r] for r in ws.iter_rows(min_row=export.HEADER_ROW + 1)] for ws in wb.worksheets}

    def test_one_tab_per_consultant_with_every_just_jon_lead_in_all_months(self):
        r, wb = self.download()
        rows = self.sheet_rows(wb)
        self.assertEqual(list(rows), ["Hannah", "Kian", "Mel", "Newbie", "Raymond", "Unassigned"])
        self.assertEqual({name: sorted(r_[0] for r_ in rs) for name, rs in rows.items()},
                         {"Hannah": ["J7", "J9"], "Kian": ["J2"], "Mel": ["J1", "J10", "J6", "J8"], "Newbie": ["J12"], "Raymond": ["J4"], "Unassigned": ["J5"]})
        self.assertEqual(sum(len(v) for v in rows.values()), 10, "the chart's total")
        self.assertIn("Just_Jon_Lead_Allocates_", r.headers["Content-Disposition"])

    def test_group_as_other_consultants_get_their_own_tab_not_one_other_tab(self):
        _, wb = self.download()
        self.assertIn("Raymond", wb.sheetnames)
        self.assertNotIn("Other", wb.sheetnames)

    def test_only_just_jon_leads(self):
        _, wb = self.download()
        codes = {r_[0] for rs in self.sheet_rows(wb).values() for r_ in rs}
        for other in ("J3", "N1", "N2", "N3"):
            self.assertNotIn(other, codes)

    def test_the_month_picked_above_the_chart_narrows_the_download(self):
        r, wb = self.download("?lead_month=2026-09")
        rows = self.sheet_rows(wb)
        self.assertEqual({n: [x[0] for x in rs] for n, rs in rows.items()}, {"Hannah": ["J9"], "Mel": ["J10"]})
        self.assertIn("Sep-2026", r.headers["Content-Disposition"])
        self.assertEqual(wb["Mel"]["A2"].value, "Leads created: September 2026  |  1 lead  |  Downloaded " + __import__("dateutils").today_uk().strftime("%d/%m/%Y"))
        _, wb = self.download("?lead_month=2026-08")
        self.assertEqual(sum(len(v) for v in self.sheet_rows(wb).values()), 8)

    def test_a_month_that_is_not_an_option_is_ignored(self):
        for month in ("2026-10", "garbage", "2026-13", "", "%3Cscript%3E"):
            _, wb = self.download("?lead_month=" + month)
            self.assertEqual(sum(len(v) for v in self.sheet_rows(wb).values()), 10, month)

    def test_it_matches_the_pop_up_windows_columns_and_values(self):
        import json
        _, wb = self.download()
        _, context = self.page("year=2026")
        popup = {}
        columns = None
        for office, name, stage, _count in [(g["office"], r["name"], s["stage"], s["count"]) for g in context["lead_report"]["groups"] for r in g["rows"] for s in r["segments"]]:
            data = self.records(office, name, stage).get_json()
            columns = data["columns"]
            for record in data["records"]:
                popup[record["code"]] = record
        self.assertEqual([c[0] for c in columns], [c.value for c in wb["Mel"][export.HEADER_ROW]])
        keys = [c[1] for c in columns]
        for ws in wb.worksheets:
            for r_ in ws.iter_rows(min_row=export.HEADER_ROW + 1, values_only=True):
                record = popup[r_[0]]
                expected = [record[k] for k in keys]
                got = list(r_)
                got[6] = got[6].strftime("%d/%m/%Y") if got[6] else ""
                self.assertEqual(got, expected, r_[0])
        self.assertEqual(len(popup), 10)

    def test_every_tab_is_print_ready(self):
        _, wb = self.download()
        for ws in wb.worksheets:
            self.assertEqual((ws.page_setup.orientation, ws.page_setup.fitToWidth, ws.page_setup.fitToHeight), ("landscape", 1, 0), ws.title)
            self.assertEqual(ws.print_title_rows.replace("$", ""), "4:4", ws.title)

    def test_login_is_required_and_every_role_can_download_by_default(self):
        anon = app_module.app.test_client().get("/dashboard/just-jon/leads-export")
        self.assertEqual(anon.status_code, 302)
        self.assertIn("/login", anon.headers["Location"])
        for role in ("admissions", "consultants", "marketing"):
            _, wb = self.download(client=self._client_logged_in_as(role))
            self.assertIn("Mel", wb.sheetnames, role)

    def test_with_no_leads_file_it_redirects_back_with_a_message(self):
        import sqlite3
        from tests.flask_test_support import db_module
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute("DELETE FROM active_leads_dataset")
        conn.commit()
        conn.close()
        r = self.full.get("/dashboard/just-jon/leads-export")
        self.assertEqual(r.status_code, 302)
        self.assertTrue(r.headers["Location"].endswith("/dashboard/just-jon"))

    def test_a_dataset_with_no_just_jon_leads_downloads_a_note(self):
        self.upload("/leads/upload", leads_book([lead("X1", "Mel X", "05/10/2026", source="Paid Ad/Google")]))
        _, wb = self.download()
        self.assertEqual(wb.sheetnames, ["No leads"])


class ButtonTests(LeadsChartBase):
    def test_the_button_sits_right_after_the_leads_created_in_dropdown_and_carries_the_month(self):
        html, _ = self.page("year=2026&lead_month=2026-09")
        form = html[html.index('<form method="GET" action="/dashboard/just-jon"'):]
        form = form[:form.index("</form>")]
        self.assertLess(form.index("</select>"), form.index("Download Excel"))
        link = re.search(r'<a class="btn-primary btn-link" href="([^"]+)">Download Excel</a>', form).group(1).replace("&amp;", "&")
        self.assertEqual(link, "/dashboard/just-jon/leads-export?lead_month=2026-09")
        html, _ = self.page("year=2026")
        self.assertIn('href="/dashboard/just-jon/leads-export"', html)

    def test_every_role_sees_it_by_default_and_the_other_pages_do_not_have_it(self):
        for role in ("admissions", "consultants", "marketing"):
            html, _ = self.page("year=2026", client=self._client_logged_in_as(role))
            self.assertIn("/dashboard/just-jon/leads-export", html, role)
        for path in ("/allocation?month=2026-08", "/dashboard?year=2026", "/university-pipeline?year=2026"):
            self.assertNotIn("leads-export", self.full.get(path).get_data(as_text=True), path)


class AccessGridTests(AccessRouteTestCase):
    """The button and the download follow the Admin access grid's page-export switch."""

    def setUp(self):
        super().setUp()
        for path, data in (("/upload", book(APP_ROWS, lookups=APP_LOOKUPS)), ("/leads/upload", leads_book(LEADS))):
            token = extract_token(self.full.get("/login").get_data(as_text=True))
            self.full.post(path, data={"csrf_token": token, "excel_file": (io.BytesIO(data), "f.xlsx")}, content_type="multipart/form-data")

    def test_switching_page_exports_off_hides_the_button_and_blocks_the_download(self):
        marketing = self._client_logged_in_as("marketing")
        self.assertIn("leads-export", marketing.get("/dashboard/just-jon?year=2026").get_data(as_text=True))
        self.save(self.grid_with(marketing=((), ("download_exports",))))
        page = marketing.get("/dashboard/just-jon?year=2026")
        self.assertEqual(page.status_code, 200)
        self.assertNotIn("leads-export", page.get_data(as_text=True))
        self.assertEqual(marketing.get("/dashboard/just-jon/leads-export").status_code, 403)
        self.assertEqual(self.full.get("/dashboard/just-jon/leads-export").status_code, 200)
        self.assertEqual(self._client_logged_in_as("admissions").get("/dashboard/just-jon/leads-export").status_code, 200)


if __name__ == "__main__":
    unittest.main()
