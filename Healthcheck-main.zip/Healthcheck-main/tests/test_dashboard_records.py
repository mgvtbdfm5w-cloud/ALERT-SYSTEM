"""Application Manager Pipeline (the Dashboard page): clicking a piece of the chart
lists the applications in it - the same pop-up window as the University Pipeline
and Just Jon pages.

The list is read off the report the chart was drawn from, so these tests check it
against what the page shows, including the rules that make a manager's numbers
differ from a plain filter: one row per student, a Lost record dropped when the
student has a live application next year, excluded managers."""

import io
import re
import unittest
from contextlib import contextmanager
from urllib.parse import parse_qs, urlencode

from flask import template_rendered

from pipeline import PIPELINE_HEALTH_STAGE_GROUPS, STAGES, build_pipeline_report, report_group_rows
from tests.flask_test_support import IsolatedAppTestCase, app_module, extract_token
from tests.test_just_jon_records import LOOKUPS, ROWS, app_row
from tests.test_upload_atomicity import book

# The Just Jon test data, plus a student who is NOT Just Jon (the Dashboard counts everyone).
ALL_ROWS = ROWS + [app_row("K1", "September 2026", "Decision", "Mo Y", "Hannah H", "Uni D", source="Agent/Someone Else")]
GROUP_STAGES = {g["key"]: g["stages"] for g in PIPELINE_HEALTH_STAGE_GROUPS}
QUERIES = ["year=2026", "year=2027", "year=2027&intake=intake_01", "year=2027&intake=intake_03", "year=2026&intake=intake_03", "year=2099"]


@contextmanager
def captured():
    rendered = []

    def record(sender, template, context, **extra):
        rendered.append((template.name, dict(context)))

    template_rendered.connect(record, app_module.app)
    try:
        yield rendered
    finally:
        template_rendered.disconnect(record, app_module.app)


class DashboardBase(IsolatedAppTestCase):
    def setUp(self):
        super().setUp()
        self.full = self._client_logged_in_as("full")
        token = extract_token(self.full.get("/login").get_data(as_text=True))
        data = book(ALL_ROWS, lookups=LOOKUPS)
        self.assertEqual(self.full.post("/upload", data={"csrf_token": token, "excel_file": (io.BytesIO(data), "f.xlsx")},
                                        content_type="multipart/form-data").status_code, 302)

    def page(self, query="year=2026", client=None):
        with captured() as rendered:
            r = (client or self.full).get("/dashboard?" + query)
        self.assertEqual(r.status_code, 200, query)
        return r.get_data(as_text=True), next(c for name, c in rendered if name == "dashboard.html")

    def records(self, query, manager, group, client=None):
        return (client or self.full).get("/dashboard/records?" + query + "&" + urlencode({"manager": manager, "group": group}))

    def codes(self, query, manager, group):
        return [r["code"] for r in self.records(query, manager, group).get_json()["records"]]

    def pieces(self, context):
        return [(row["name"], seg["key"], seg["count"]) for g in context["pending_stage_chart_groups"] for row in g["rows"] for seg in row["segments"]]


class RecordsTests(DashboardBase):
    def test_every_piece_of_the_chart_lists_exactly_the_number_it_shows(self):
        checked = 0
        for query in QUERIES:
            _, context = self.page(query)
            for manager, group, count in self.pieces(context):
                r = self.records(query, manager, group)
                self.assertEqual(r.status_code, 200, (query, manager, group))
                data = r.get_json()
                self.assertEqual((data["count"], len(data["records"])), (count, count), (query, manager, group))
                codes = [rec["code"] for rec in data["records"]]
                self.assertEqual(len(codes), len(set(codes)), "a student appears once")
                checked += 1
        self.assertGreater(checked, 5)

    def test_the_pieces_of_one_bar_add_up_to_the_bars_total(self):
        for query in QUERIES:
            _, context = self.page(query)
            for g in context["pending_stage_chart_groups"]:
                for row in g["rows"]:
                    codes = []
                    for seg in row["segments"]:
                        codes += self.codes(query, row["name"], seg["key"])
                    self.assertEqual(len(codes), row["total"], (query, row["name"]))
                    self.assertEqual(len(codes), len(set(codes)), "no student in two pieces")

    def test_one_row_per_student_and_the_stage_groups_known_cases(self):
        self.assertEqual(self.codes("year=2026", "Mo", "pending_offer"), ["J1", "J4", "K1"], "J1's later Decision application is the student's row; K1 is not Just Jon but counts here")
        self.assertEqual(self.codes("year=2026", "Mo", "pending_assessment"), ["J5", "J7"], "J1's earlier Assessment row is not a second prospect")
        self.assertEqual(self.codes("year=2026", "Mo", "enrolled_this_intake"), ["J9"])
        self.assertEqual(self.codes("year=2026", "Nouran", "enrolled_this_intake"), ["J2"])
        self.assertEqual(self.codes("year=2026", "Nouran", "lost"), [], "J3 has a live application in 2027, so it is not a 2026 loss")
        self.assertEqual(self.codes("year=2027", "Nouran", "pending_assessment"), ["J3"])

    def test_a_group_with_two_stages_lists_both(self):
        self.assertEqual(GROUP_STAGES["pending_assessment"], ("04-Onboarding", "05-Assessment"))
        self.assertEqual(self.codes("year=2026", "Mo", "pending_assessment"), ["J5", "J7"])

    def test_non_just_jon_students_are_included_unlike_the_just_jon_page(self):
        every = {c for q in QUERIES for g in GROUP_STAGES for m in ("Mo", "Nouran") for c in self.codes(q, m, g)}
        self.assertIn("K1", every)
        self.assertIn("J5", every)

    def test_the_excluded_manager_and_blank_manager_have_no_pieces(self):
        _, context = self.page("year=2026")
        names = {name for name, _, _ in self.pieces(context)}
        self.assertNotIn("Admission", names)
        self.assertNotIn("", names)
        for manager in ("Admission", "", "Unassigned"):
            for group in GROUP_STAGES:
                self.assertEqual(self.codes("year=2026", manager, group), [], (manager, group))

    def test_the_year_and_intake_tab_come_along(self):
        self.assertEqual(self.codes("year=2027", "Mo", "pending_offer"), ["J10"])
        self.assertEqual(self.codes("year=2027&intake=intake_01", "Mo", "pending_offer"), ["J10"])
        self.assertEqual(self.codes("year=2027&intake=intake_03", "Mo", "pending_offer"), [])
        self.assertEqual(self.codes("year=2027&intake=intake_03", "Nouran", "enrolled_this_intake"), ["J11"])

    def test_each_record_has_the_six_fields_and_days_sorted_by_student(self):
        data = self.records("year=2026", "Mo", "pending_offer").get_json()
        self.assertEqual(sorted(data["records"][0]), ["code", "consultant", "days", "intake", "manager", "student", "university"])
        by_code = {r["code"]: r for r in data["records"]}
        self.assertEqual(by_code["K1"], {"code": "K1", "student": "Student K1", "university": "Uni D", "intake": "September 2026", "consultant": "Hannah", "manager": "Mo", "days": ""})
        keys = [(r["student"].lower(), r["code"]) for r in data["records"]]
        self.assertEqual(keys, sorted(keys))
        self.assertEqual((data["manager"], data["group"]), ("Mo", "Pending Offer"))

    def test_an_unknown_group_is_a_400_and_an_unknown_manager_is_an_empty_list(self):
        for query in ("manager=Mo", "manager=Mo&group=", "manager=Mo&group=nope", "manager=Mo&group=PENDING_OFFER", "group="):
            r = self.full.get("/dashboard/records?year=2026&" + query)
            self.assertEqual((r.status_code, r.get_json()), (400, {"error": "Unknown chart group."}), query)
        for manager in ("Nobody", "mo", "Mo ", ""):
            r = self.records("year=2026", manager, "pending_offer")
            self.assertEqual((r.status_code, r.get_json()["count"], r.get_json()["records"]), (200, 0, []), repr(manager))

    def test_the_response_is_not_cached_and_is_json_login_is_required_and_every_role_can_use_it(self):
        r = self.records("year=2026", "Mo", "pending_offer")
        self.assertEqual((r.mimetype, r.headers["Cache-Control"]), ("application/json", "no-store"))
        anon = app_module.app.test_client().get("/dashboard/records?year=2026&manager=Mo&group=pending_offer")
        self.assertEqual(anon.status_code, 302)
        self.assertIn("/login", anon.headers["Location"])
        for role in ("admissions", "consultants", "marketing"):
            self.assertEqual(self.records("year=2026", "Mo", "pending_offer", client=self._client_logged_in_as(role)).get_json()["count"], 3, role)

    def test_with_no_dataset_it_is_an_empty_list(self):
        import sqlite3
        from tests.flask_test_support import db_module
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute("DELETE FROM active_dataset")
        conn.commit()
        conn.close()
        r = self.records("year=2026", "Mo", "pending_offer")
        self.assertEqual((r.status_code, r.get_json()["count"]), (200, 0))


class PageMarkupTests(DashboardBase):
    def test_every_piece_is_a_clickable_button_that_says_what_it_opens_and_the_tooltip_is_unchanged(self):
        html, context = self.page("year=2026")
        pieces = re.findall(r'<div class="chart-segment chart-segment-clickable" role="button" tabindex="0"\s+style="[^"]*"\s+data-tooltip="([^"]*)"\s+'
                            r'data-records-title="([^"]*)"\s+data-records-params="([^"]*)"\s+data-count="(\d+)"', html)
        got = []
        for tooltip, title, params, count in pieces:
            query = parse_qs(params.replace("&amp;", "&"))
            manager, group = query["manager"][0], query["group"][0]
            self.assertEqual(sorted(query), ["group", "manager"])
            label = title.split(" &mdash; ")[1]
            self.assertEqual(tooltip, f"{manager} - {label}: {count}")
            self.assertTrue(title.startswith(f"{manager} &mdash; "))
            got.append((manager, group, int(count)))
        self.assertEqual(got, self.pieces(context))
        self.assertEqual(html.count("chart-segment-clickable"), len(pieces))
        self.assertGreater(len(pieces), 3)

    def test_the_window_script_and_hint_are_on_the_page_once(self):
        html, _ = self.page("year=2026")
        self.assertEqual(html.count('<dialog id="chart-records"'), 1)
        self.assertIn('data-url="/dashboard/records"', html)
        self.assertEqual(html.count("chart-records.js"), 1)
        self.assertIn("Click a bar to list its applications.", html)

    def test_the_rest_of_the_dashboard_page_is_unchanged(self):
        html, _ = self.page("year=2026")
        for text in ("Application Manager Pipeline 2026", "Application Manager Pipeline Health", "Download Spreadsheet", "Offer Days"):
            self.assertIn(text, html, text)

    def test_just_jon_and_university_pipeline_keep_their_own_windows_and_other_pages_have_none(self):
        self.assertIn('data-url="/dashboard/just-jon/records"', self.full.get("/dashboard/just-jon?year=2026").get_data(as_text=True))
        self.assertIn('data-url="/university-pipeline/records"', self.full.get("/university-pipeline?year=2026").get_data(as_text=True))
        for path in ("/enrolled?year=2026", "/consultants"):
            self.assertNotIn("chart-segment-clickable", self.full.get(path).get_data(as_text=True), path)

    def test_with_no_dataset_there_is_no_window(self):
        import sqlite3
        from tests.flask_test_support import db_module
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute("DELETE FROM active_dataset")
        conn.commit()
        conn.close()
        self.assertNotIn('<dialog id="chart-records"', self.full.get("/dashboard?year=2026").get_data(as_text=True))


class ReportGroupRowsTests(unittest.TestCase):
    def test_a_group_is_the_union_of_its_stages_rows_and_matches_the_counts(self):
        rows = [
            {"Application": "Mo", "Office": "UK", "Status": "04-Onboarding", "Student Code": "1"},
            {"Application": "Mo", "Office": "UK", "Status": "05-Assessment", "Student Code": "2"},
            {"Application": "Mo", "Office": "UK", "Status": "05-Assessment", "Student Code": "3"},
            {"Application": "Mo", "Office": "UK", "Status": "06-Decision", "Student Code": "4"},
            {"Application": "Mo", "Office": "EG", "Status": "05-Assessment", "Student Code": "5"},        # same person, other office: not counted
        ]
        report = build_pipeline_report(rows, {}, keep_rows=True)
        group = report_group_rows(report, "Mo", ("04-Onboarding", "05-Assessment"))
        self.assertEqual(sorted(r["Student Code"] for r in group), ["1", "2", "3"])
        mo = report["office_groups"][0]["managers"][0]
        self.assertEqual(len(group), mo["counts"]["04-Onboarding"] + mo["counts"]["05-Assessment"])
        self.assertEqual(report_group_rows(report, "Mo", ()), [])
        self.assertEqual(report_group_rows(report, "Nobody", ("05-Assessment",)), [])
        self.assertEqual(report_group_rows(report, "Mo", ("not-a-stage",)), [])
        every = report_group_rows(report, "Mo", tuple(STAGES))
        self.assertEqual(len(every), mo["total"])


if __name__ == "__main__":
    unittest.main()
