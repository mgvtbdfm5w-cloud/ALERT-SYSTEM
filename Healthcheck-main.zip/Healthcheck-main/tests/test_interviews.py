import unittest
from datetime import date, timedelta

from interviews import (
    EXCLUDED_INTERVIEW_STATUSES,
    build_interview_groups,
    day_label,
    get_operational_dates,
    get_operational_days,
    interview_window_rows,
)
from pipeline import QA_REJECTED_STATUS, STAGES


class OperationalDatesTests(unittest.TestCase):
    def setUp(self):
        # A guaranteed real Monday, computed rather than hard-coded, so this
        # test never depends on memorising which weekday a given date falls
        # on.
        anchor = date(2026, 1, 5)
        self.monday = anchor - timedelta(days=anchor.weekday())
        self.tuesday = self.monday + timedelta(days=1)
        self.friday = self.monday + timedelta(days=4)
        self.saturday = self.monday + timedelta(days=5)
        self.sunday = self.monday + timedelta(days=6)
        self.next_monday = self.monday + timedelta(days=7)
        self.next_tuesday = self.monday + timedelta(days=8)

    def test_monday_rolls_to_monday_and_tuesday(self):
        self.assertEqual(get_operational_dates(self.monday), (self.monday, self.tuesday))

    def test_tuesday_wednesday_thursday_are_just_plus_one_day(self):
        wednesday = self.monday + timedelta(days=2)
        thursday = self.monday + timedelta(days=3)
        self.assertEqual(
            get_operational_dates(self.tuesday), (self.tuesday, self.tuesday + timedelta(days=1))
        )
        self.assertEqual(
            get_operational_dates(wednesday), (wednesday, wednesday + timedelta(days=1))
        )
        self.assertEqual(
            get_operational_dates(thursday), (thursday, thursday + timedelta(days=1))
        )

    def test_friday_rolls_tomorrow_to_monday(self):
        self.assertEqual(get_operational_dates(self.friday), (self.friday, self.next_monday))

    def test_saturday_rolls_to_next_monday_and_tuesday(self):
        self.assertEqual(
            get_operational_dates(self.saturday), (self.next_monday, self.next_tuesday)
        )

    def test_sunday_rolls_to_next_monday_and_tuesday(self):
        self.assertEqual(
            get_operational_dates(self.sunday), (self.next_monday, self.next_tuesday)
        )

    def test_defaults_to_todays_date_when_no_reference_given(self):
        today, tomorrow = get_operational_dates()
        expected_today, expected_tomorrow = get_operational_dates(date.today())
        self.assertEqual((today, tomorrow), (expected_today, expected_tomorrow))


class OperationalDaysTests(unittest.TestCase):
    """Always five business days: Today, Tomorrow and the three after."""

    def setUp(self):
        self.monday = date(2026, 1, 5) - timedelta(days=date(2026, 1, 5).weekday())

    def at(self, offset):
        return self.monday + timedelta(days=offset)

    def test_a_monday_gives_monday_to_friday(self):
        self.assertEqual(get_operational_days(self.monday), [self.at(n) for n in range(5)])

    def test_a_tuesday_runs_into_next_monday(self):
        self.assertEqual(get_operational_days(self.at(1)), [self.at(1), self.at(2), self.at(3), self.at(4), self.at(7)])

    def test_a_wednesday_thursday(self):
        self.assertEqual(get_operational_days(self.at(2)), [self.at(2), self.at(3), self.at(4), self.at(7), self.at(8)])
        self.assertEqual(get_operational_days(self.at(3)), [self.at(3), self.at(4), self.at(7), self.at(8), self.at(9)])

    def test_a_friday_is_followed_by_monday_tuesday_wednesday_thursday(self):
        self.assertEqual(get_operational_days(self.at(4)), [self.at(4), self.at(7), self.at(8), self.at(9), self.at(10)])

    def test_saturday_and_sunday_become_monday(self):
        week = [self.at(7), self.at(8), self.at(9), self.at(10), self.at(11)]
        self.assertEqual(get_operational_days(self.at(5)), week)
        self.assertEqual(get_operational_days(self.at(6)), week)

    def test_every_start_day_gives_five_distinct_weekdays_in_order(self):
        for offset in range(0, 21):
            days = get_operational_days(self.at(offset))
            self.assertEqual(len(days), 5, offset)
            self.assertTrue(all(d.weekday() < 5 for d in days), offset)
            self.assertEqual(days, sorted(set(days)), offset)
            self.assertEqual(len({d.weekday() for d in days}), 5, f"{offset}: Monday to Friday, each once")
            self.assertGreaterEqual(days[0], self.at(offset))
            self.assertLessEqual((days[0] - self.at(offset)).days, 2)

    def test_the_first_two_days_are_the_old_today_and_tomorrow_every_day_of_the_week(self):
        for offset in range(0, 14):
            days = get_operational_days(self.at(offset))
            self.assertEqual((days[0], days[1]), get_operational_dates(self.at(offset)), offset)

    def test_count_can_be_changed_and_defaults_to_todays_date(self):
        self.assertEqual(len(get_operational_days(self.monday, count=8)), 8)
        self.assertEqual(get_operational_days(self.monday, count=1), [self.monday])
        from unittest import mock
        with mock.patch("interviews.today_uk", return_value=self.at(5)):
            self.assertEqual(get_operational_days()[0], self.at(7))

    def test_labels_are_today_tomorrow_then_the_weekday_name(self):
        days = get_operational_days(self.at(4))          # a Friday
        self.assertEqual([day_label(i, d) for i, d in enumerate(days)], ["Today", "Tomorrow", "Tuesday", "Wednesday", "Thursday"])
        days = get_operational_days(self.at(6))          # a Sunday: today is Monday
        self.assertEqual([day_label(i, d) for i, d in enumerate(days)], ["Today", "Tomorrow", "Wednesday", "Thursday", "Friday"])


class InterviewWindowRowsTests(unittest.TestCase):
    def test_rows_on_those_days_that_are_not_excluded_statuses(self):
        days = [date(2026, 11, 2), date(2026, 11, 3)]
        rows = [
            {"n": 1, "Interview Date": "2026-11-02", "Status": "05-Assessment"},
            {"n": 2, "Interview Date": "2026-11-03", "Status": ""},
            {"n": 3, "Interview Date": "2026-11-04", "Status": "05-Assessment"},       # another day
            {"n": 4, "Interview Date": "2026-11-02", "Status": "09-Enrolled"},         # excluded status
            {"n": 5, "Interview Date": "bad", "Status": "05-Assessment"},
            {"n": 6, "Interview Date": None, "Status": "05-Assessment"},
            {"n": 7, "Interview Date": "2026-11-03", "Status": " 10-Lost "},           # excluded, whitespace
        ]
        self.assertEqual([r["n"] for r in interview_window_rows(rows, days)], [1, 2])
        self.assertEqual(interview_window_rows([], days), [])
        self.assertEqual(interview_window_rows(rows, []), [])


class BuildInterviewGroupsTests(unittest.TestCase):
    def setUp(self):
        self.target = date(2026, 8, 13)
        self.rows = [
            {"Student Name": "Zed", "Application": "Mo", "Interview Date": "2026-08-13"},
            {"Student Name": "Amy", "Application": "Mo", "Interview Date": "2026-08-13"},
            {"Student Name": "Beth", "Application": "Anum", "Interview Date": "2026-08-13"},
            {"Student Name": "Someone Else", "Application": "Mo", "Interview Date": "2026-08-14"},
            {"Student Name": "Blank Manager", "Application": "", "Interview Date": "2026-08-13"},
            {"Student Name": "Bad Date", "Application": "Mo", "Interview Date": "not-a-date"},
            {"Student Name": "No Date", "Application": "Mo", "Interview Date": None},
        ]

    def test_only_matching_date_rows_are_included(self):
        groups = build_interview_groups(self.rows, self.target)
        all_names = {student["Student Name"] for group in groups for student in group["students"]}
        self.assertNotIn("Someone Else", all_names)
        self.assertNotIn("Bad Date", all_names)
        self.assertNotIn("No Date", all_names)

    def test_groups_sorted_alphabetically_by_application(self):
        groups = build_interview_groups(self.rows, self.target)
        labels = [g["application"] for g in groups]
        self.assertEqual(labels, sorted(labels, key=str.lower))

    def test_students_within_group_sorted_alphabetically_by_name(self):
        groups = build_interview_groups(self.rows, self.target)
        mo_group = next(g for g in groups if g["application"] == "Mo")
        names = [s["Student Name"] for s in mo_group["students"]]
        self.assertEqual(names, ["Amy", "Zed"])

    def test_blank_application_grouped_as_unassigned(self):
        groups = build_interview_groups(self.rows, self.target)
        labels = [g["application"] for g in groups]
        self.assertIn("Unassigned", labels)

    def test_malformed_or_blank_dates_never_raise(self):
        try:
            build_interview_groups(self.rows, self.target)
        except Exception as exc:  # pragma: no cover - test fails loudly if this ever raises
            self.fail(f"build_interview_groups raised unexpectedly: {exc}")

    def test_no_matching_rows_returns_empty_list(self):
        self.assertEqual(build_interview_groups(self.rows, date(2099, 1, 1)), [])


class ExcludedStatusTests(unittest.TestCase):
    TARGET = date(2026, 8, 13)

    def row(self, name, status, application="Mo"):
        return {"Student Name": name, "Application": application, "Status": status, "Interview Date": "2026-08-13"}

    def names(self, rows):
        return [s["Student Name"] for g in build_interview_groups(rows, self.TARGET) for s in g["students"]]

    def test_the_excluded_statuses_are_exactly_qa_rejected_pre_enrolled_enrolled_and_lost(self):
        self.assertEqual(EXCLUDED_INTERVIEW_STATUSES, {"00-QARejected", "08-Pre-Enrolled", "09-Enrolled", "10-Lost"})

    def test_the_excluded_statuses_are_real_pipeline_statuses(self):
        self.assertEqual(QA_REJECTED_STATUS, "00-QARejected")
        self.assertTrue(EXCLUDED_INTERVIEW_STATUSES <= set(STAGES) | {QA_REJECTED_STATUS})

    def test_students_with_an_excluded_status_are_not_listed(self):
        rows = [self.row("QA", "00-QARejected"), self.row("Pre", "08-Pre-Enrolled"), self.row("Enr", "09-Enrolled"), self.row("Lost", "10-Lost")]
        self.assertEqual(self.names(rows), [])

    def test_every_other_pipeline_stage_is_still_listed(self):
        kept = [stage for stage in STAGES if stage not in EXCLUDED_INTERVIEW_STATUSES]
        self.assertEqual(kept, ["02-PendingQA", "03-PendingSubmission", "04-Onboarding", "05-Assessment", "06-Decision", "07-Ready"])
        rows = [self.row(f"S-{stage}", stage) for stage in kept]
        self.assertEqual(sorted(self.names(rows)), sorted(f"S-{stage}" for stage in kept))

    def test_blank_missing_or_unrecognised_status_is_still_listed(self):
        rows = [self.row("Blank", ""), self.row("None", None), self.row("Odd", "Something Else"), {"Student Name": "NoKey", "Application": "Mo", "Interview Date": "2026-08-13"}]
        self.assertEqual(sorted(self.names(rows)), ["Blank", "NoKey", "None", "Odd"])

    def test_surrounding_whitespace_does_not_defeat_the_exclusion(self):
        self.assertEqual(self.names([self.row("Lost", " 10-Lost ")]), [])

    def test_excluded_students_do_not_leave_an_empty_application_group(self):
        rows = [self.row("Gone", "10-Lost", application="Solo"), self.row("Here", "05-Assessment", application="Mo")]
        self.assertEqual([g["application"] for g in build_interview_groups(rows, self.TARGET)], ["Mo"])

    def test_other_excluded_style_statuses_are_still_listed(self):
        """Only the four named statuses are hidden - 01-NewApp and 11-Deferred (excluded from other pages) are not."""
        rows = [self.row("New", "01-NewApp"), self.row("Def", "11-Deferred")]
        self.assertEqual(sorted(self.names(rows)), ["Def", "New"])

    def test_the_rest_of_a_group_is_unaffected(self):
        rows = [self.row("Zed", "05-Assessment"), self.row("Amy", "04-Onboarding"), self.row("Gone", "09-Enrolled")]
        self.assertEqual(self.names(rows), ["Amy", "Zed"])


if __name__ == "__main__":
    unittest.main()
