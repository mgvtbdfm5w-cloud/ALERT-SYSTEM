"""Route-level database connection lifecycle.

Every request that touches the database must leave NO connection open and
NO lock behind - on success, and when something fails after the connection
has been opened. Proven deterministically: tests/connection_tracking.py
swaps the single connection factory so every connection the app opens is
recorded with a STRONG reference (garbage collection cannot hide a leak),
can be made to fail execute()/commit() on demand, and is then inspected.
"Writable afterwards" is checked with a second connection whose timeout is
ZERO, so an unreleased write lock fails instantly instead of waiting.

What is covered:
- every endpoint in the authorization policy (a new route that is not added
  to PLAN fails test_the_plan_covers_every_endpoint_in_the_policy);
- 20 repeated requests with no accumulation of open connections;
- injected execute() and commit() failures, a calculation error after a
  SELECT, a failure mid-save (rollback), a validation error, and a
  KeyboardInterrupt;
- the existing safe error handling (generic 500 page; uploads keep their
  "Upload failed" flash), and that nothing was persisted by a failed write;
- static guards: app.py has no raw get_connection()/close() left.

Temp databases and uploads folders only.
"""

import ast
import inspect
import json
import logging
import re
import sqlite3
import unittest
from unittest import mock

from authorization import ENDPOINT_ROLES
from leads import REQUIRED_LEADS_SOURCE_COLUMNS
from pipeline import seed_forecast_settings_if_empty
from processing import REQUIRED_IMPORT_COLUMNS
from tests.connection_tracking import ConnectionTracker
from tests.flask_test_support import (
    IsolatedAppTestCase,
    app_module,
    db_module,
    extract_token,
    make_xlsx,
)

STORED_FILENAME = "20260101000000_a.xlsx"

# How many connections each endpoint opens today. Pinned on purpose: merging
# the extra read connections (Company Dashboard / KPI) is a
# deliberately deferred decision - a change here should be a conscious one.
EXPECTED_CONNECTIONS = {
    "company_dashboard": 2, "kpi": 2,
}
WRITE_ENDPOINTS = (
    "update_kpi_target_route", "update_forecast_setting_route",
    "add_lookup_route", "edit_lookup_route", "delete_lookup_route",
    "save_paid_ad_spend_route", "delete_paid_ad_spend_route", "save_paid_ad_settings_route",
    "save_role_access_route", "reset_role_access_route",
)


class LifecycleTestCase(IsolatedAppTestCase):
    def setUp(self):
        super().setUp()
        self.tracker = ConnectionTracker(db_module)
        self.tracker.install()
        self.addCleanup(self.tracker.uninstall)
        self.addCleanup(self.tracker.force_close_leaks)
        self.delete_target = None
        self.seed()
        self.client = self._client_logged_in_as("full")
        self.tracker.reset()                    # forget the login/seed traffic
        self.token = extract_token(self.client.get("/login").get_data(as_text=True))
        self.tracker.reset()

    # ------------------------------------------------------------ fixtures
    def seed(self):
        row = {c: "" for c in REQUIRED_IMPORT_COLUMNS}
        row.update({"Student Code": "PES-1", "Student Name": "T", "Intake": "2026", "University Name": "U", "Course Name": "C"})
        (self.tmp_uploads_dir / STORED_FILENAME).write_bytes(make_xlsx(REQUIRED_IMPORT_COLUMNS, [row]).getvalue())
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.row_factory = sqlite3.Row
        conn.execute(
            "INSERT INTO active_dataset (original_filename, stored_filename, uploaded_at, row_count, data_json) "
            "VALUES ('a.xlsx', ?, '2026-01-01T00:00:00', 1, ?)",
            (STORED_FILENAME, json.dumps([{"Student Code": "PES-1", "QA Passed": "2026-08-10", "Status": "09-Enrolled", "Intake": "2026"}])),
        )
        conn.execute(
            "INSERT INTO active_leads_dataset (original_filename, stored_filename, uploaded_at, row_count, columns_json, data_json) "
            "VALUES ('l.xlsx', 'leads_20260101000000_l.xlsx', '2026-01-01T00:00:00', 0, '[]', '[]')"
        )
        conn.execute(
            "INSERT INTO lookup_tables (table_name, source_value, mapped_value, created_at) VALUES ('status', 'A', 'B', '2026-01-01T00:00:00')"
        )
        seed_forecast_settings_if_empty(conn)
        conn.commit()
        conn.close()
        self.lookup_id = self.query("SELECT id FROM lookup_tables")[0][0]

    def query(self, sql, params=()):
        conn = sqlite3.connect(db_module.DB_PATH)
        try:
            return conn.execute(sql, params).fetchall()
        finally:
            conn.close()

    def snapshot(self):
        """Everything a failed write must leave exactly as it was."""
        return {
            "datasets": self.query("SELECT id, stored_filename FROM active_dataset ORDER BY id"),
            "leads": self.query("SELECT id FROM active_leads_dataset ORDER BY id"),
            "lookups": self.query("SELECT id, table_name, source_value, mapped_value, intake_01_count, intake_02_count FROM lookup_tables ORDER BY id"),
            "forecast": self.query("SELECT stage, forecast_percent FROM forecast_settings ORDER BY stage"),
            "kpi": self.query("SELECT year, month, target_type, target_value FROM kpi_targets ORDER BY id"),
        }

    def new_lookup_row(self):
        conn = sqlite3.connect(db_module.DB_PATH)
        cur = conn.execute(
            "INSERT INTO lookup_tables (table_name, source_value, mapped_value, created_at) VALUES ('status', ?, 'x', '2026-01-01T00:00:00')",
            (f"row-{self.query('SELECT COUNT(*) FROM lookup_tables')[0][0]}-{id(object())}",),
        )
        conn.commit()
        row_id = cur.lastrowid
        conn.close()
        return row_id

    def prepare(self, endpoint):
        """Create anything an endpoint needs to ACT ON before a test takes its
        'before' snapshot (the delete route needs a row to delete)."""
        if endpoint == "delete_lookup_route" and self.delete_target is None:
            self.delete_target = self.new_lookup_row()

    def take_delete_target(self):
        target, self.delete_target = self.delete_target, None
        return target if target is not None else self.new_lookup_row()

    def assert_database_is_writable_immediately(self):
        """BEGIN IMMEDIATE takes the write lock; with timeout=0 it fails at
        once if some leaked connection is holding it."""
        probe = sqlite3.connect(db_module.DB_PATH, timeout=0, isolation_level=None)
        try:
            probe.execute("BEGIN IMMEDIATE")
            probe.execute("ROLLBACK")
        finally:
            probe.close()

    def production_error_handling(self):
        """Behave like a deployed app: an unexpected error is a generic 500
        response (TESTING would re-raise it instead)."""
        patcher = mock.patch.dict(app_module.app.config, {"TESTING": False, "PROPAGATE_EXCEPTIONS": False})
        patcher.start()
        logging.disable(logging.CRITICAL)
        self.addCleanup(patcher.stop)
        self.addCleanup(logging.disable, logging.NOTSET)

    # ---------------------------------------------------------------- plan
    def plan(self):
        c, t = self.client, self.token
        apps_xlsx = lambda: make_xlsx(REQUIRED_IMPORT_COLUMNS, [self.apps_row()])
        leads_xlsx = lambda: make_xlsx(REQUIRED_LEADS_SOURCE_COLUMNS, [self.leads_row()])
        post = lambda path, **data: c.post(path, data={"csrf_token": t, **data})
        return {
            # --- pages and exports (GET) ---
            "company_dashboard": lambda: c.get("/company-dashboard"),
            "todo": lambda: c.get("/todo"),
            "interviews": lambda: c.get("/interviews"),
            "dashboard": lambda: c.get("/dashboard"),
            "dashboard_export": lambda: c.get("/dashboard/export"),
            "university_pipeline": lambda: c.get("/university-pipeline"),
            "just_jon": lambda: c.get("/dashboard/just-jon"),
            "just_jon_export": lambda: c.get("/dashboard/just-jon/export"),
            "university_pipeline_export": lambda: c.get("/university-pipeline/export"),
            "university_pipeline_records": lambda: c.get("/university-pipeline/records?university=Uni+A&group=pending_assessment"),
            "just_jon_records": lambda: c.get("/dashboard/just-jon/records?chart=manager&name=Mo&stage=05-Assessment"),
            "dashboard_records": lambda: c.get("/dashboard/records?manager=Mo&group=pending_assessment"),
            "dashboard_loss_records": lambda: c.get("/dashboard/loss-records?year=2027&manager=Mo&reason=Withdrew"),
            "thirty_days": lambda: c.get("/thirty-days"),
            "thirty_days_records": lambda: c.get("/thirty-days/records?manager=Mo&status=eligible"),
            "thirty_days_export": lambda: c.get("/thirty-days/export"),
            "incentives": lambda: c.get("/incentives"),
            "incentives_records": lambda: c.get("/incentives/records?incentive=incentive_1&consultant=Mel&group=enrolled_this_intake"),
            "just_jon_lead_records": lambda: c.get("/dashboard/just-jon/lead-records?office=OXF&name=Mel&stage=01 - New Lead"),
            "just_jon_leads_export": lambda: c.get("/dashboard/just-jon/leads-export"),
            "faheem": lambda: c.get("/dashboard/faheem", follow_redirects=True),   # old bookmark: redirects to /consultants
            "consultants": lambda: c.get("/consultants?consultant=Faheem"),
            "consultants_records": lambda: c.get("/consultants/records?consultant=Faheem&chart=manager&name=Mo&stage=05-Assessment"),
            "enrolled": lambda: c.get("/enrolled"),
            "enrolled_export_intake_03": lambda: c.get("/enrolled/export/intake-03"),
            "enrolled_export_current_intake": lambda: c.get("/enrolled/export/current-intake"),
            "university_report": lambda: c.get("/university-report"),
            "kpi": lambda: c.get("/kpi"),
            "offer_days": lambda: c.get("/offer-days"),
            "offer_days_export": lambda: c.get("/offer-days/export/total"),
            "lost_reasons": lambda: c.get("/lost-reasons"),
            "submissions": lambda: c.get("/submissions"),
            "doc_check": lambda: c.get("/doc-check"),
            "download": lambda: c.get("/download"),
            "leads_download": lambda: c.get("/leads/download"),
            "leads_dashboard": lambda: c.get("/leads-dashboard"),
            "allocation": lambda: c.get("/allocation"),
            "split": lambda: c.get("/split"),
            "ninety_days": lambda: c.get("/ninety-days"),
            "admin": lambda: c.get("/admin"),
            "paid_ads": lambda: c.get("/paid-ads"),
            # --- writes (POST) ---
            "upload": lambda: c.post("/upload", data={"csrf_token": t, "excel_file": (apps_xlsx(), "t.xlsx")}, content_type="multipart/form-data"),
            "leads_upload": lambda: c.post("/leads/upload", data={"csrf_token": t, "excel_file": (leads_xlsx(), "t.xlsx")}, content_type="multipart/form-data"),
            "reprocess": lambda: post("/admin/reprocess"),
            "update_kpi_target_route": lambda: post("/admin/kpi-targets/__COMPANY__", month_key="2026-08", target_value="100"),
            "update_forecast_setting_route": lambda: post("/admin/forecast-settings/02-PendingQA", forecast_percent="42"),
            "save_paid_ad_spend_route": lambda: post("/admin/paid-ads/spend", month_key="2026-11", amount="123.45", status="final", budget=""),
            "delete_paid_ad_spend_route": lambda: post("/admin/paid-ads/spend/2026-08/delete"),
            "save_paid_ad_settings_route": lambda: post("/admin/paid-ads/settings", monthly_budget="16000", revenue_per_enrolled="1800"),
            "save_role_access_route": lambda: post("/admin/access", admissions__admin="on"),
            "reset_role_access_route": lambda: post("/admin/access/reset"),
            "add_lookup_route": lambda: post(f"/admin/lookups/status/add", source_value=f"new-{id(object())}", mapped_value="x"),
            "edit_lookup_route": lambda: post(f"/admin/lookups/status/{self.lookup_id}/edit", source_value="A2", mapped_value="B"),
            "delete_lookup_route": lambda: post(f"/admin/lookups/status/{self.take_delete_target()}/delete"),
            "admin_restore": lambda: self.restore_current_data(c, t),
        }

    @staticmethod
    def restore_current_data(client, token):
        """Restore a bundle of the CURRENT database (so the data the other
        plan entries rely on is unchanged), with the restore switched on."""
        import io, os, tarfile
        from unittest import mock
        data = db_module.DB_PATH.read_bytes()
        buf = io.BytesIO()
        with tarfile.open(fileobj=buf, mode="w:gz") as tar:
            info = tarfile.TarInfo("app.db")
            info.size = len(data)
            tar.addfile(info, io.BytesIO(data))
        buf.seek(0)
        with mock.patch.dict(os.environ, {"ENABLE_DATA_RESTORE": "1"}):
            return client.post("/admin/restore", data={"csrf_token": token, "bundle": (buf, "b.tar.gz")},
                               content_type="multipart/form-data")

    @staticmethod
    def apps_row():
        row = {c: "" for c in REQUIRED_IMPORT_COLUMNS}
        row.update({"Student Code": "PES-2", "Student Name": "T", "Intake": "2026", "University Name": "U", "Course Name": "C"})
        return row

    @staticmethod
    def leads_row():
        row = {c: "" for c in REQUIRED_LEADS_SOURCE_COLUMNS}
        row.update({"Student Id": "PES-L", "Name": "L"})
        return row


class EveryRouteClosesItsConnectionsTests(LifecycleTestCase):
    def test_the_plan_covers_every_endpoint_in_the_policy(self):
        self.assertEqual(set(self.plan()), set(ENDPOINT_ROLES))

    def test_every_route_opens_at_least_one_connection_and_closes_all_of_them(self):
        for endpoint, call in self.plan().items():
            with self.subTest(endpoint=endpoint):
                self.tracker.reset()
                response = call()
                self.assertLess(response.status_code, 400, endpoint)
                self.assertGreaterEqual(self.tracker.opened, 1, "the instrumentation must actually see this route's connection")
                self.assertEqual([i for i, c in enumerate(self.tracker.connections) if c in self.tracker.leaked()], [])
                self.assertEqual(self.tracker.max_open, 1, "connections are never nested or held open together")
                self.assert_database_is_writable_immediately()

    def test_the_number_of_connections_per_request_is_pinned(self):
        """Documents - and keeps deliberate - what this phase does NOT merge."""
        for endpoint, call in self.plan().items():
            with self.subTest(endpoint=endpoint):
                self.tracker.reset()
                call()
                self.assertEqual(self.tracker.opened, EXPECTED_CONNECTIONS.get(endpoint, 1))

    def test_an_upload_uses_one_connection_for_the_whole_request(self):
        """Nothing is opened after the data change: no follow-up publish step."""
        for endpoint in ("upload", "leads_upload", "reprocess"):
            with self.subTest(endpoint=endpoint):
                self.tracker.reset()
                self.plan()[endpoint]()
                self.assertEqual(self.tracker.opened, 1)
                self.assertEqual(self.tracker.leaked(), [])
                self.assertEqual(self.tracker.max_open, 1)


class RepeatedRequestTests(LifecycleTestCase):
    REPEATS = 20

    def test_twenty_repeated_requests_never_accumulate_open_connections(self):
        plan = self.plan()
        for endpoint in (
            "admin", "kpi", "company_dashboard", "download", "leads_download", "todo",
            "update_forecast_setting_route", "update_kpi_target_route", "add_lookup_route", "edit_lookup_route",
            "delete_lookup_route", "upload", "leads_upload", "reprocess",
            "paid_ads", "save_paid_ad_spend_route", "save_paid_ad_settings_route",
        ):
            with self.subTest(endpoint=endpoint):
                self.tracker.reset()
                for i in range(self.REPEATS):
                    self.assertLess(plan[endpoint]().status_code, 400, (endpoint, i))
                    self.assertEqual(self.tracker.open_count(), 0, f"{endpoint}: connection still open after call {i + 1}")
                self.assertEqual(self.tracker.opened, self.REPEATS * EXPECTED_CONNECTIONS.get(endpoint, 1))
                self.assertEqual(self.tracker.leaked(), [])
                self.assertEqual(self.tracker.max_open, 1)
        self.assert_database_is_writable_immediately()


class ExecuteFailureTests(LifecycleTestCase):
    """execute() raises "database is locked" right after the connection is
    open (the worst moment: nothing has run yet)."""

    def setUp(self):
        super().setUp()
        self.production_error_handling()

    def test_every_route_closes_its_connection_and_keeps_its_safe_error_handling(self):
        for endpoint, call in self.plan().items():
            with self.subTest(endpoint=endpoint):
                self.prepare(endpoint)
                before = self.snapshot()
                self.tracker.reset()
                with self.tracker.failing("execute"):
                    response = call()
                self.assertGreaterEqual(self.tracker.opened, 1)
                self.assertEqual(self.tracker.leaked(), [], f"{endpoint} leaked a connection")
                self.assert_database_is_writable_immediately()
                self.assertEqual(self.snapshot(), before, "a failed request changed nothing")

                body = response.get_data(as_text=True)
                if endpoint in ("upload", "leads_upload"):
                    self.assertEqual(response.status_code, 302, "uploads keep their 'Upload failed' flash-and-redirect handling")
                else:
                    self.assertEqual(response.status_code, 500)
                    for internal in ("OperationalError", "Traceback", "app.py", "sqlite"):
                        self.assertNotIn(internal, body)
                    self.assertNotIn("database is locked", body)

    def test_the_failure_does_not_poison_later_requests(self):
        with self.tracker.failing("execute"):
            self.assertEqual(self.client.get("/admin").status_code, 500)
        self.assertEqual(self.client.get("/admin").status_code, 200)
        self.assertEqual(self.tracker.leaked(), [])


class CommitFailureTests(LifecycleTestCase):
    """commit() raises after the write statement has run: the write must be
    rolled back, the connection closed, and the lock released."""

    def setUp(self):
        super().setUp()
        self.production_error_handling()

    def test_failed_commits_roll_back_close_and_release_the_lock(self):
        for endpoint in WRITE_ENDPOINTS:
            with self.subTest(endpoint=endpoint):
                self.prepare(endpoint)
                before = self.snapshot()
                self.tracker.reset()
                with self.tracker.failing("commit"):
                    response = self.plan()[endpoint]()
                self.assertEqual(response.status_code, 500)
                self.assertEqual(self.tracker.leaked(), [], f"{endpoint} leaked a connection")
                self.assertGreaterEqual(self.tracker.connections[0].rollback_calls, 1, "rolled back explicitly")
                self.assertEqual(self.snapshot(), before, "the half-done write was not persisted")
                self.assert_database_is_writable_immediately()

    def test_failed_commits_inside_uploads_and_reprocess_are_handled_and_close(self):
        for endpoint in ("upload", "leads_upload", "reprocess"):
            with self.subTest(endpoint=endpoint):
                before = self.snapshot()
                self.tracker.reset()
                with self.tracker.failing("commit"):
                    response = self.plan()[endpoint]()
                self.assertEqual(response.status_code, 302, "their existing 'failed' flash-and-redirect handling")
                self.assertEqual(self.tracker.leaked(), [])
                self.assertEqual(self.snapshot(), before)
                self.assert_database_is_writable_immediately()


class ProcessingAndValidationFailureTests(LifecycleTestCase):
    def setUp(self):
        super().setUp()
        self.production_error_handling()

    def test_a_calculation_error_after_a_select_still_closes_the_admin_connection(self):
        """/admin runs real calculations while its connection is open - the
        one read route where a non-database error could previously leak."""
        with mock.patch.object(app_module, "list_available_months", side_effect=RuntimeError("calc bug")):
            response = self.client.get("/admin")
        self.assertEqual(response.status_code, 500)
        self.assertEqual(self.tracker.opened, 1)
        self.assertEqual(self.tracker.leaked(), [])
        self.assert_database_is_writable_immediately()
        self.assertNotIn("calc bug", response.get_data(as_text=True))

    def test_an_error_while_processing_an_upload_keeps_the_existing_safe_handling_and_closes(self):
        for endpoint in ("upload", "reprocess"):
            with self.subTest(endpoint=endpoint):
                before = self.snapshot()
                self.tracker.reset()
                with mock.patch.object(app_module, "process_workbook", side_effect=RuntimeError("processing bug")):
                    response = self.plan()[endpoint]()
                self.assertEqual(response.status_code, 302)
                self.assertEqual(self.tracker.leaked(), [])
                self.assertEqual(self.snapshot(), before)
                self.assert_database_is_writable_immediately()
                flashed = self.client.get("/admin").get_data(as_text=True)
                self.assertIn("unexpected error", flashed)
                self.assertNotIn("processing bug", flashed)

    def test_a_failure_mid_save_rolls_the_new_dataset_back_and_closes(self):
        for endpoint, target in (("upload", "processing.prune_active_dataset_table"), ("leads_upload", "leads.prune_active_dataset_table")):
            with self.subTest(endpoint=endpoint):
                before = self.snapshot()
                self.tracker.reset()
                with mock.patch(target, side_effect=sqlite3.OperationalError("disk I/O error")):
                    response = self.plan()[endpoint]()
                self.assertEqual(response.status_code, 302)
                snapshot = self.snapshot()
                self.assertEqual(snapshot["datasets"], before["datasets"], "the inserted snapshot was rolled back")
                self.assertEqual(snapshot["leads"], before["leads"])
                self.assertEqual(self.tracker.leaked(), [])
                self.assert_database_is_writable_immediately()

    def test_validation_errors_close_their_connection_and_change_nothing(self):
        cases = {
            "update_kpi_target_route": dict(path="/admin/kpi-targets/__COMPANY__", data=dict(month_key="2026-08", target_value="abc")),
            "update_forecast_setting_route": dict(path="/admin/forecast-settings/02-PendingQA", data=dict(forecast_percent="abc")),
            "save_paid_ad_spend_route (bad amount)": dict(path="/admin/paid-ads/spend", data=dict(month_key="2026-11", amount="abc", status="final", budget="")),
            "save_paid_ad_settings_route (bad budget)": dict(path="/admin/paid-ads/settings", data=dict(monthly_budget="-5", revenue_per_enrolled="1800")),
            "add_lookup_route (duplicate)": dict(path="/admin/lookups/status/add", data=dict(source_value="A", mapped_value="x")),
            "add_lookup_route (empty)": dict(path="/admin/lookups/status/add", data=dict(source_value="", mapped_value="x")),
            "edit_lookup_route (duplicate)": dict(path=f"/admin/lookups/status/{self.new_lookup_row()}/edit", data=dict(source_value="A", mapped_value="x")),
        }
        for label, case in cases.items():
            with self.subTest(case=label):
                before = self.snapshot()
                self.tracker.reset()
                response = self.client.post(case["path"], data={"csrf_token": self.token, **case["data"]})
                self.assertEqual(response.status_code, 302)
                self.assertEqual(self.tracker.opened, 1)
                self.assertEqual(self.tracker.leaked(), [])
                after = self.snapshot()
                after["lookups"] = [r for r in after["lookups"] if r[0] == self.lookup_id]       # ignore the helper row added above
                before["lookups"] = [r for r in before["lookups"] if r[0] == self.lookup_id]
                self.assertEqual(after, before)

    def test_a_keyboard_interrupt_inside_a_route_still_closes_the_connection(self):
        with mock.patch.object(app_module, "load_active_dataset", side_effect=KeyboardInterrupt()):
            with self.assertRaises(KeyboardInterrupt):
                self.client.get("/todo")
        self.assertEqual(self.tracker.opened, 1)
        self.assertEqual(self.tracker.leaked(), [])
        self.assert_database_is_writable_immediately()

    def test_a_keyboard_interrupt_mid_write_rolls_back(self):
        before = self.snapshot()
        with mock.patch("lookups._parse_count", side_effect=KeyboardInterrupt()):
            with self.assertRaises(KeyboardInterrupt):
                self.client.post("/admin/lookups/status/add", data={"csrf_token": self.token, "source_value": "kb", "mapped_value": "x"})
        self.assertEqual(self.tracker.leaked(), [])
        self.assertEqual(self.snapshot(), before)


class NoRawConnectionsLeftInTheAppTests(unittest.TestCase):
    """Static guard: every connection in application code goes through
    db.db_connection(), so one added later cannot silently skip the cleanup."""

    NON_TEST_MODULES = [
        "app", "authorization", "company_dashboard", "dateutils", "enrolled_export", "enrolled_intake_export",
        "healthcheck", "interviews", "just_jon_export", "just_jon_leads_export", "university_pipeline_export", "kpi", "leads", "leads_dashboard", "lookups", "lost_reasons",
        "offer_days", "pipeline", "processing", "submissions", "application_manager_export", "thirty_days_export",
        "excel_export_helpers", "colors", "login_throttle",
    ]

    def parsed(self, name):
        import importlib
        module = importlib.import_module(name)
        return ast.parse(inspect.getsource(module))

    def test_app_py_never_calls_the_raw_factory_or_closes_a_connection_by_hand(self):
        tree = self.parsed("app")
        raw_calls = [n.lineno for n in ast.walk(tree) if isinstance(n, ast.Call) and getattr(n.func, "id", "") == "get_connection"]
        closes = [n.lineno for n in ast.walk(tree) if isinstance(n, ast.Call) and getattr(n.func, "attr", "") == "close"]
        self.assertEqual(raw_calls, [], f"raw get_connection() calls at lines {raw_calls}")
        self.assertEqual(closes, [], f"manual .close() calls at lines {closes}")

    def test_every_db_connection_call_in_app_py_is_the_context_expression_of_a_with(self):
        tree = self.parsed("app")
        all_calls = [n for n in ast.walk(tree) if isinstance(n, ast.Call) and getattr(n.func, "id", "") == "db_connection"]
        in_with = {id(item.context_expr) for w in ast.walk(tree) if isinstance(w, ast.With) for item in w.items}
        bare = [n.lineno for n in all_calls if id(n) not in in_with]
        self.assertEqual(bare, [], f"db_connection() used outside a `with` at lines {bare}")
        self.assertEqual(len(all_calls), 55, "the 37 connection sites identified in the audit, plus 4 Paid Ads routes, Allocation, Split, 90 Days, 30 Days and its download, minus the 3 the removed Weekly Report used, plus the access grid (2 routes + its loader), plus the Loss Reasons by Consultant records")

    def test_no_other_application_module_opens_a_connection(self):
        for name in self.NON_TEST_MODULES:
            with self.subTest(module=name):
                source = inspect.getsource(__import__(name))
                self.assertNotIn("sqlite3.connect", source)
                self.assertNotIn("get_connection(", source)

    def test_only_db_py_creates_connections(self):
        source = inspect.getsource(db_module)
        self.assertEqual(source.count("sqlite3.connect("), 1)


if __name__ == "__main__":
    unittest.main()
