"""Flask test-client CSRF regression suite (Finding 4).

Deliberately the FIRST route-level test coverage in this project - CSRF
protection is an HTTP/request-cycle behavior that cannot be meaningfully
verified by a pure business-logic unit test, the convention every other
test file in this suite otherwise follows. Scope is kept narrow to CSRF
behavior only; this is not a general route-coverage suite.

CSRFProtect is never disabled here - every test exercises the real
protection exactly as it runs in production.

The isolated app/database/uploads setup (and its full isolation notes,
including the one disclosed import-time residual) lives in
tests/flask_test_support.py, shared with the other route-level suites.
Nothing here ever touches the real data/app.db or the real uploads/
folder.
"""

import sqlite3
import unittest

from tests.flask_test_support import (  # noqa: E402  (must come before anything imports `app`)
    FULL_PASSWORD,
    IsolatedAppTestCase,
    app_module,
    db_module,
    extract_token,
    make_xlsx,
)
from leads import REQUIRED_LEADS_SOURCE_COLUMNS  # noqa: E402
from pipeline import seed_forecast_settings_if_empty  # noqa: E402
from processing import REQUIRED_IMPORT_COLUMNS  # noqa: E402


class LoginPageTests(IsolatedAppTestCase):
    """1. GET /login"""

    def test_returns_200(self):
        resp = self.client.get("/login")
        self.assertEqual(resp.status_code, 200)

    def test_rendered_page_contains_a_csrf_token(self):
        resp = self.client.get("/login")
        token = extract_token(resp.get_data(as_text=True))
        self.assertIsNotNone(token)
        self.assertGreater(len(token), 20)


class LoginCSRFTests(IsolatedAppTestCase):
    """2-5. POST /login under every CSRF/auth combination."""

    def test_post_without_token_is_rejected(self):
        resp = self.client.post("/login", data={"password": FULL_PASSWORD})
        self.assertEqual(resp.status_code, 400)

    def test_post_with_invalid_token_is_rejected(self):
        resp = self.client.post(
            "/login", data={"password": FULL_PASSWORD, "csrf_token": "not-a-real-token"}
        )
        self.assertEqual(resp.status_code, 400)

    def test_post_with_valid_token_and_correct_password_logs_in(self):
        token = self._get_login_token()
        resp = self.client.post("/login", data={"password": FULL_PASSWORD, "csrf_token": token})
        self.assertEqual(resp.status_code, 302)
        self.assertIn("/company-dashboard", resp.headers["Location"])
        with self.client.session_transaction() as sess:
            self.assertTrue(sess.get("logged_in"))
            self.assertEqual(sess.get("role"), "full")

    def test_post_with_valid_token_and_wrong_password_fails_authentication(self):
        """Proves CSRF passing does not bypass the app's own auth check -
        a structurally valid request (real token) with the wrong password
        must still fail login, exactly as without CSRF protection at all."""
        token = self._get_login_token()
        resp = self.client.post("/login", data={"password": "wrong-password", "csrf_token": token})
        self.assertEqual(resp.status_code, 200)
        self.assertIn("Incorrect password", resp.get_data(as_text=True))
        with self.client.session_transaction() as sess:
            self.assertFalse(sess.get("logged_in"))


class AdminMutationGenericCSRFTests(IsolatedAppTestCase):
    """6-8. A generic authenticated admin mutation (lookup add) under
    every CSRF combination - the specific routes (upload, reprocess,
    lookups, forecast, KPI targets) each get their own dedicated classes
    below; this one is the general proof using a single representative
    route."""

    def setUp(self):
        super().setUp()
        self._login()

    def test_authenticated_post_without_token_is_rejected(self):
        resp = self.client.post(
            "/admin/lookups/status/add", data={"source_value": "X", "mapped_value": "Y"}
        )
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(len(self._query("SELECT * FROM lookup_tables")), 0)

    def test_authenticated_post_with_invalid_token_is_rejected(self):
        resp = self.client.post(
            "/admin/lookups/status/add",
            data={"source_value": "X", "mapped_value": "Y", "csrf_token": "garbage"},
        )
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(len(self._query("SELECT * FROM lookup_tables")), 0)

    def test_authenticated_post_with_valid_token_reaches_the_route(self):
        token = self._get_login_token()
        # The token must come from the authenticated session's own page -
        # admin is a GET route unaffected by CSRF, just the token source.
        token = extract_token(self.client.get("/admin").get_data(as_text=True))
        resp = self.client.post(
            "/admin/lookups/status/add",
            data={"source_value": "X", "mapped_value": "Y", "csrf_token": token},
        )
        self.assertEqual(resp.status_code, 302)
        rows = self._query("SELECT * FROM lookup_tables WHERE source_value = 'X'")
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["mapped_value"], "Y")


class ApplicationsUploadCSRFTests(IsolatedAppTestCase):
    """9. Multipart Applications upload."""

    def setUp(self):
        super().setUp()
        self._login()
        row = {col: "" for col in REQUIRED_IMPORT_COLUMNS}
        row.update({
            "Student Code": "PES-CSRF-001",
            "Student Name": "Test Student",
            "Intake": "2026",
            "University Name": "Test University",
            "Course Name": "Test Course",
        })
        self.xlsx = make_xlsx(REQUIRED_IMPORT_COLUMNS, [row])

    def test_missing_token_is_rejected(self):
        resp = self.client.post(
            "/upload",
            data={"excel_file": (self.xlsx, "test.xlsx")},
            content_type="multipart/form-data",
        )
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(len(self._query("SELECT * FROM active_dataset")), 0)

    def test_valid_token_is_accepted_and_processes_the_upload(self):
        token = extract_token(self.client.get("/admin").get_data(as_text=True))
        resp = self.client.post(
            "/upload",
            data={"csrf_token": token, "excel_file": (self.xlsx, "test.xlsx")},
            content_type="multipart/form-data",
        )
        self.assertEqual(resp.status_code, 302)
        rows = self._query("SELECT * FROM active_dataset")
        self.assertEqual(len(rows), 1)
        # Confirms the file genuinely landed in the isolated temp uploads
        # directory, never the real one.
        stored_files = list(self.tmp_uploads_dir.iterdir())
        self.assertEqual(len(stored_files), 1)


class LeadsUploadCSRFTests(IsolatedAppTestCase):
    """10. Multipart Leads upload - same checks as Applications."""

    def setUp(self):
        super().setUp()
        self._login()
        row = {col: "" for col in REQUIRED_LEADS_SOURCE_COLUMNS}
        row.update({"Student Id": "PES-CSRF-LEAD-001", "Name": "Test Lead"})
        self.xlsx = make_xlsx(REQUIRED_LEADS_SOURCE_COLUMNS, [row])

    def test_missing_token_is_rejected(self):
        resp = self.client.post(
            "/leads/upload",
            data={"excel_file": (self.xlsx, "test.xlsx")},
            content_type="multipart/form-data",
        )
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(len(self._query("SELECT * FROM active_leads_dataset")), 0)

    def test_valid_token_is_accepted_and_processes_the_upload(self):
        token = extract_token(self.client.get("/admin").get_data(as_text=True))
        resp = self.client.post(
            "/leads/upload",
            data={"csrf_token": token, "excel_file": (self.xlsx, "test.xlsx")},
            content_type="multipart/form-data",
        )
        self.assertEqual(resp.status_code, 302)
        rows = self._query("SELECT * FROM active_leads_dataset")
        self.assertEqual(len(rows), 1)
        stored_files = list(self.tmp_uploads_dir.iterdir())
        self.assertEqual(len(stored_files), 1)


class ReprocessCSRFTests(IsolatedAppTestCase):
    """11. Reprocess POST."""

    def setUp(self):
        super().setUp()
        self._login()
        # A real stored file the reprocess route can actually re-parse,
        # living only in the isolated temp uploads directory.
        row = {col: "" for col in REQUIRED_IMPORT_COLUMNS}
        row.update({
            "Student Code": "PES-CSRF-002", "Student Name": "Original", "Intake": "2026",
            "University Name": "Test University", "Course Name": "Test Course",
        })
        stored_filename = "20260101000000_test.xlsx"
        wb_buffer = make_xlsx(REQUIRED_IMPORT_COLUMNS, [row])
        (self.tmp_uploads_dir / stored_filename).write_bytes(wb_buffer.getvalue())

        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute(
            "INSERT INTO active_dataset (original_filename, stored_filename, uploaded_at, row_count, data_json) "
            "VALUES (?, ?, ?, ?, ?)",
            ("test.xlsx", stored_filename, "2026-01-01T00:00:00", 1, "[]"),
        )
        conn.commit()
        conn.close()

    def test_missing_token_is_rejected(self):
        resp = self.client.post("/admin/reprocess", data={})
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(len(self._query("SELECT * FROM active_dataset")), 1)

    def test_valid_token_reaches_the_route_against_isolated_fixtures(self):
        token = extract_token(self.client.get("/admin").get_data(as_text=True))
        resp = self.client.post("/admin/reprocess", data={"csrf_token": token})
        self.assertEqual(resp.status_code, 302)
        # A successful reprocess inserts a new snapshot (same convention
        # as a fresh upload) - now 2 rows in the isolated test database.
        rows = self._query("SELECT * FROM active_dataset ORDER BY id DESC")
        self.assertEqual(len(rows), 2)


class LookupAddEditDeleteCSRFTests(IsolatedAppTestCase):
    """12. Lookup add/edit/delete."""

    def setUp(self):
        super().setUp()
        self._login()

    def _admin_token(self):
        return extract_token(self.client.get("/admin").get_data(as_text=True))

    def test_add_missing_token_rejected(self):
        resp = self.client.post("/admin/lookups/status/add", data={"source_value": "A"})
        self.assertEqual(resp.status_code, 400)

    def test_add_invalid_token_rejected(self):
        resp = self.client.post(
            "/admin/lookups/status/add", data={"source_value": "A", "csrf_token": "garbage"}
        )
        self.assertEqual(resp.status_code, 400)

    def test_add_valid_token_accepted(self):
        resp = self.client.post(
            "/admin/lookups/status/add",
            data={"source_value": "A", "mapped_value": "B", "csrf_token": self._admin_token()},
        )
        self.assertEqual(resp.status_code, 302)
        self.assertEqual(len(self._query("SELECT * FROM lookup_tables")), 1)

    def _add_row(self):
        self.client.post(
            "/admin/lookups/status/add",
            data={"source_value": "A", "mapped_value": "B", "csrf_token": self._admin_token()},
        )
        return self._query("SELECT * FROM lookup_tables")[0]["id"]

    def test_edit_missing_token_rejected(self):
        row_id = self._add_row()
        resp = self.client.post(
            f"/admin/lookups/status/{row_id}/edit", data={"source_value": "Changed"}
        )
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(self._query("SELECT * FROM lookup_tables")[0]["source_value"], "A")

    def test_edit_invalid_token_rejected(self):
        row_id = self._add_row()
        resp = self.client.post(
            f"/admin/lookups/status/{row_id}/edit",
            data={"source_value": "Changed", "csrf_token": "garbage"},
        )
        self.assertEqual(resp.status_code, 400)

    def test_edit_valid_token_accepted(self):
        row_id = self._add_row()
        resp = self.client.post(
            f"/admin/lookups/status/{row_id}/edit",
            data={"source_value": "Changed", "mapped_value": "B", "csrf_token": self._admin_token()},
        )
        self.assertEqual(resp.status_code, 302)
        self.assertEqual(self._query("SELECT * FROM lookup_tables")[0]["source_value"], "Changed")

    def test_delete_missing_token_rejected(self):
        row_id = self._add_row()
        resp = self.client.post(f"/admin/lookups/status/{row_id}/delete", data={})
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(len(self._query("SELECT * FROM lookup_tables")), 1)

    def test_delete_invalid_token_rejected(self):
        row_id = self._add_row()
        resp = self.client.post(
            f"/admin/lookups/status/{row_id}/delete", data={"csrf_token": "garbage"}
        )
        self.assertEqual(resp.status_code, 400)

    def test_delete_valid_token_accepted(self):
        row_id = self._add_row()
        resp = self.client.post(
            f"/admin/lookups/status/{row_id}/delete", data={"csrf_token": self._admin_token()}
        )
        self.assertEqual(resp.status_code, 302)
        self.assertEqual(len(self._query("SELECT * FROM lookup_tables")), 0)


class ForecastSettingCSRFTests(IsolatedAppTestCase):
    """13. Forecast setting update."""

    def setUp(self):
        super().setUp()
        self._login()
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.row_factory = sqlite3.Row
        seed_forecast_settings_if_empty(conn)
        conn.close()

    def test_missing_token_rejected(self):
        resp = self.client.post(
            "/admin/forecast-settings/02-PendingQA", data={"forecast_percent": "42"}
        )
        self.assertEqual(resp.status_code, 400)
        row = self._query(
            "SELECT forecast_percent FROM forecast_settings WHERE stage = '02-PendingQA'"
        )[0]
        self.assertNotEqual(row["forecast_percent"], 42)

    def test_invalid_token_rejected(self):
        resp = self.client.post(
            "/admin/forecast-settings/02-PendingQA",
            data={"forecast_percent": "42", "csrf_token": "garbage"},
        )
        self.assertEqual(resp.status_code, 400)

    def test_valid_token_accepted(self):
        token = extract_token(self.client.get("/admin").get_data(as_text=True))
        resp = self.client.post(
            "/admin/forecast-settings/02-PendingQA",
            data={"forecast_percent": "42", "csrf_token": token},
        )
        self.assertEqual(resp.status_code, 302)
        row = self._query(
            "SELECT forecast_percent FROM forecast_settings WHERE stage = '02-PendingQA'"
        )[0]
        self.assertEqual(row["forecast_percent"], 42.0)


class KpiTargetCSRFTests(IsolatedAppTestCase):
    """14. KPI target update."""

    def setUp(self):
        super().setUp()
        self._login()

    def test_missing_token_rejected(self):
        resp = self.client.post(
            "/admin/kpi-targets/__COMPANY__",
            data={"month_key": "2026-08", "target_value": "100"},
        )
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(len(self._query("SELECT * FROM kpi_targets")), 0)

    def test_invalid_token_rejected(self):
        resp = self.client.post(
            "/admin/kpi-targets/__COMPANY__",
            data={"month_key": "2026-08", "target_value": "100", "csrf_token": "garbage"},
        )
        self.assertEqual(resp.status_code, 400)

    def test_valid_token_accepted(self):
        token = extract_token(self.client.get("/admin").get_data(as_text=True))
        resp = self.client.post(
            "/admin/kpi-targets/__COMPANY__",
            data={"month_key": "2026-08", "target_value": "100", "csrf_token": token},
        )
        self.assertEqual(resp.status_code, 302)
        rows = self._query("SELECT * FROM kpi_targets")
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["target_value"], 100)


class SessionBindingCSRFTests(IsolatedAppTestCase):
    """15. A token minted under one session must not validate under a
    different, independent session - proves the token is genuinely bound
    to the session that issued it, not just "any non-empty token"."""

    def test_token_from_one_session_is_rejected_from_another(self):
        client_a = app_module.app.test_client()
        client_b = app_module.app.test_client()

        token_from_a = self._get_login_token(client_a)

        # client_b has never visited any page, so it has no session of its
        # own yet either - using client_a's token here must still fail,
        # since the two clients carry independent cookie jars/sessions.
        resp = client_b.post(
            "/login", data={"password": FULL_PASSWORD, "csrf_token": token_from_a}
        )
        self.assertEqual(resp.status_code, 400)

    def test_token_from_one_session_is_rejected_from_another_established_session(self):
        client_a = app_module.app.test_client()
        client_b = app_module.app.test_client()

        token_from_a = self._get_login_token(client_a)
        # Establish client_b's OWN session first (visiting the page sets
        # its session cookie), then try to use client_a's token against it.
        self._get_login_token(client_b)

        resp = client_b.post(
            "/login", data={"password": FULL_PASSWORD, "csrf_token": token_from_a}
        )
        self.assertEqual(resp.status_code, 400)


class GetRoutesUnaffectedTests(IsolatedAppTestCase):
    """16. GET routes are never subject to CSRF checks."""

    def test_get_login_succeeds_with_no_token_anywhere(self):
        resp = self.client.get("/login")
        self.assertEqual(resp.status_code, 200)

    def test_get_admin_succeeds_once_authenticated_with_no_token_needed(self):
        self._login()
        resp = self.client.get("/admin")
        self.assertEqual(resp.status_code, 200)

    def test_get_company_dashboard_succeeds_with_no_token(self):
        self._login()
        resp = self.client.get("/company-dashboard")
        self.assertEqual(resp.status_code, 200)


class CSRFErrorResponseTests(IsolatedAppTestCase):
    """17. The CSRF rejection response itself must not leak anything
    sensitive."""

    def test_rejection_is_a_400(self):
        resp = self.client.post("/login", data={"password": FULL_PASSWORD})
        self.assertEqual(resp.status_code, 400)

    def test_rejection_body_does_not_expose_a_real_token_value(self):
        # Get a real token first, then confirm it never appears in the
        # body of a REJECTED request's response.
        real_token = self._get_login_token()
        resp = self.client.post("/login", data={"password": FULL_PASSWORD})
        body = resp.get_data(as_text=True)
        self.assertNotIn(real_token, body)

    def test_rejection_body_does_not_expose_internal_exception_details(self):
        resp = self.client.post("/login", data={"password": FULL_PASSWORD})
        body = resp.get_data(as_text=True)
        # No Python traceback, no file-path leakage, no stack frame markers.
        self.assertNotIn("Traceback (most recent call last)", body)
        self.assertNotIn(".py", body)
        self.assertNotIn(str(app_module.BASE_DIR), body)


if __name__ == "__main__":
    unittest.main()
