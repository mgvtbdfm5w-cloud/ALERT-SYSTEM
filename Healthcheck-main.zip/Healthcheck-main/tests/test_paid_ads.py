"""Paid Ad spend: the calculations (paid_ads.py), the database tables and their
one-time seed (db.py), the Admin forms, the Paid Ads page, and the Leads
dashboard's Enrolled box.

Route tests use the isolated temp database; "today" is pinned to 5 Oct 2026."""

import io
import re
import sqlite3
import tempfile
import unittest
from datetime import date
from pathlib import Path
from unittest import mock

import openpyxl

import db
from leads import REQUIRED_LEADS_SOURCE_COLUMNS
from leads_dashboard import build_month_summary
from paid_ads import (
    PaidAdValidationError,
    build_paid_ads_report,
    count_paid_applications_by_month,
    count_paid_leads_by_month,
    forecast_month,
    format_gbp,
    month_progress,
    parse_money_pence,
    validate_month_key,
)
from tests.flask_test_support import IsolatedAppTestCase, app_module, db_module, extract_token
from tests.test_upload_atomicity import book, row

TODAY = date(2026, 10, 5)
SETTINGS = {"monthly_budget_pence": 1600000, "revenue_per_enrolled_pence": 180000}


# ----------------------------------------------------------------- parsing
class MoneyParsingTests(unittest.TestCase):
    def test_valid_amounts(self):
        for text, pence in (("14308.02", 1430802), ("£25,373.92", 2537392), (" 16000 ", 1600000), ("0", 0),
                            ("1800.5", 180050), ("0.01", 1), ("£ 1 234.50", 123450)):
            self.assertEqual(parse_money_pence(text, "x"), pence, text)

    def test_invalid_amounts_are_rejected_with_a_clear_message(self):
        for text in ("", "   ", None, "abc", "-5", "1.234", "1e5", "nan", "inf", "1,2,3x", "12.3.4", "£", "--1", "5%", "1/2", "٣"):
            with self.assertRaises(PaidAdValidationError, msg=repr(text)) as ctx:
                parse_money_pence(text, "Spend")
            self.assertIn("Spend", str(ctx.exception))

    def test_absurdly_large_amounts_are_rejected(self):
        with self.assertRaises(PaidAdValidationError):
            parse_money_pence("99999999999999999999", "Spend")

    def test_month_keys(self):
        self.assertEqual(validate_month_key("2026-08"), "2026-08")
        self.assertEqual(validate_month_key(" 2026-10 "), "2026-10")
        for bad in ("", None, "2026-13", "2026-00", "2026-8", "26-08", "2026/08", "1999-12", "2101-01", "abcd-ef", "2026-08-01", "٢٠٢٦-٠٨"):
            with self.assertRaises(PaidAdValidationError, msg=repr(bad)):
                validate_month_key(bad)

    def test_gbp_formatting(self):
        self.assertEqual(format_gbp(2537392), "£25,373.92")
        self.assertEqual(format_gbp(5), "£0.05")
        self.assertEqual(format_gbp(0), "£0.00")
        self.assertEqual(format_gbp(-122993), "-£1,229.93")
        self.assertEqual(format_gbp(None), "-")


# -------------------------------------------------------------- forecasting
class ForecastTests(unittest.TestCase):
    def spend(self, month, amount, final, budget=None):
        return {"month_key": month, "amount_pence": amount, "is_final": final, "budget_pence": budget}

    def test_month_progress(self):
        self.assertEqual(month_progress("2026-10", TODAY), (5, 31))
        self.assertEqual(month_progress("2026-09", TODAY), (30, 30))
        self.assertIsNone(month_progress("2026-11", TODAY))
        self.assertEqual(month_progress("2028-02", date(2028, 2, 10)), (10, 29))      # leap year

    def test_a_month_to_date_figure_is_run_rated(self):
        f = forecast_month(self.spend("2026-10", 238227, False), TODAY, 1600000)
        self.assertEqual(f["forecast_pence"], 1477007)                    # 238227 / 5 * 31 = 1,477,007.4
        self.assertEqual(f["budget_pence"], 1600000)
        self.assertEqual(f["variance_pence"], 1477007 - 1600000)

    def test_a_final_month_forecasts_exactly_its_spend(self):
        f = forecast_month(self.spend("2026-09", 1430802, True), TODAY, 1600000)
        self.assertEqual((f["forecast_pence"], f["variance_pence"]), (1430802, 1430802 - 1600000))

    def test_a_per_month_budget_overrides_the_global_one(self):
        f = forecast_month(self.spend("2026-09", 1430802, True, budget=1000000), TODAY, 1600000)
        self.assertEqual((f["budget_pence"], f["variance_pence"]), (1000000, 430802))

    def test_month_to_date_for_a_finished_month_is_taken_as_complete(self):
        self.assertEqual(forecast_month(self.spend("2026-08", 2537392, False), TODAY, 1)["forecast_pence"], 2537392)

    def test_month_to_date_for_a_month_not_started_has_no_forecast(self):
        f = forecast_month(self.spend("2026-12", 5000, False), TODAY, 1600000)
        self.assertEqual((f["forecast_pence"], f["variance_pence"]), (None, None))

    def test_rounding_is_to_the_nearest_penny_halves_up(self):
        self.assertEqual(forecast_month(self.spend("2026-10", 1, False), date(2026, 10, 3), 0)["forecast_pence"], 10)    # 1/3*31 = 10.33
        self.assertEqual(forecast_month(self.spend("2026-10", 3, False), date(2026, 10, 2), 0)["forecast_pence"], 47)    # 46.5 -> 47

    def test_first_day_of_the_month(self):
        self.assertEqual(forecast_month(self.spend("2026-10", 1000, False), date(2026, 10, 1), 0)["forecast_pence"], 31000)


# ------------------------------------------------------------------ report
def lead(source, created, stage="01 - New Lead", code="L"):
    return {"Lead Source": source, "Creation Date": created, "Stage": stage, "PES Code": code}


def app_row(code, source, created, status):
    return {"Student Code": code, "Source": source, "Created": created, "Status": status}


class ReportCountTests(unittest.TestCase):
    def test_paid_leads_by_month_ignores_case_other_sources_and_bad_dates(self):
        rows = [lead("Paid Ad", "2026-08-03"), lead(" paid ad ", "2026-08-30"), lead("Paid Ad", "2026-09-01"),
                lead("Agent", "2026-08-05"), lead("Paid Ad", ""), lead("Paid Ad", "garbage"), lead(None, "2026-08-01"),
                lead("Paid Ads", "2026-08-01")]
        self.assertEqual(count_paid_leads_by_month(rows), {"2026-08": 2, "2026-09": 1})

    def test_applications_are_one_per_student_in_the_month_first_created(self):
        rows = [app_row("S1", "Paid Ad", "2026-08-30", "05-Assessment"),
                app_row("S1", "Paid Ad", "2026-09-02", "09-Enrolled"),      # same student, later row: still August
                app_row("S2", "Paid Ad", "2026-09-10", "07-Ready"),
                app_row("S3", "Agent", "2026-09-10", "09-Enrolled")]        # not paid
        apps, enrolled = count_paid_applications_by_month(rows)
        self.assertEqual(apps, {"2026-08": 1, "2026-09": 1})
        self.assertEqual(enrolled, {"2026-08": 1})                          # S1's enrolment counts in her application month

    def test_students_with_only_unsubmitted_statuses_are_not_applications(self):
        rows = [app_row(f"S{i}", "Paid Ad", "2026-08-10", status) for i, status in enumerate(
            ("00-QARejected", "01-NewApp", "02-PendingQA", "11-Deferred"))]
        self.assertEqual(count_paid_applications_by_month(rows), ({}, {}))

    def test_lost_applications_still_count_as_applications(self):
        apps, enrolled = count_paid_applications_by_month([app_row("S1", "Paid Ad", "2026-08-10", "10-Lost")])
        self.assertEqual((apps, enrolled), ({"2026-08": 1}, {}))

    def test_rows_without_a_student_code_or_created_date_are_skipped(self):
        rows = [app_row("", "Paid Ad", "2026-08-10", "07-Ready"), app_row("S1", "Paid Ad", "", "07-Ready"),
                app_row(None, "Paid Ad", "2026-08-10", "07-Ready")]
        self.assertEqual(count_paid_applications_by_month(rows), ({}, {}))

    def test_a_student_with_one_live_and_one_rejected_row_counts_once(self):
        rows = [app_row("S1", "Paid Ad", "2026-08-10", "00-QARejected"), app_row("S1", "Paid Ad", "2026-08-12", "07-Ready")]
        self.assertEqual(count_paid_applications_by_month(rows)[0], {"2026-08": 1})


class ReportTests(unittest.TestCase):
    LEADS = [lead("Paid Ad", "2026-08-03")] * 100 + [lead("Paid Ad", "2026-09-03")] * 50 + [lead("Paid Ad", "2026-07-03")] * 7
    APPS = ([app_row(f"A{i}", "Paid Ad", "2026-08-10", "07-Ready") for i in range(20)]
            + [app_row(f"E{i}", "Paid Ad", "2026-08-10", "09-Enrolled") for i in range(5)]
            + [app_row(f"B{i}", "Paid Ad", "2026-09-10", "05-Assessment") for i in range(10)])
    SPEND = [
        {"month_key": "2026-08", "amount_pence": 250000, "is_final": True, "budget_pence": None},
        {"month_key": "2026-09", "amount_pence": 100000, "is_final": True, "budget_pence": None},
        {"month_key": "2026-10", "amount_pence": 238227, "is_final": False, "budget_pence": None},
    ]

    def report(self, spend=None):
        return build_paid_ads_report(self.LEADS, self.APPS, self.SPEND if spend is None else spend, SETTINGS, TODAY)

    def by_month(self, report):
        return {r["month_key"]: r for r in report["rows"]}

    def test_rows_are_every_month_with_spend_or_paid_leads_oldest_first(self):
        self.assertEqual([r["month_key"] for r in self.report()["rows"]], ["2026-07", "2026-08", "2026-09", "2026-10"])

    def test_august_figures(self):
        a = self.by_month(self.report())["2026-08"]
        self.assertEqual((a["paid_leads"], a["applications"], a["enrolled"], a["spend_pence"]), (100, 25, 5, 250000))
        self.assertEqual(a["cost_per_lead_pence"], 2500)               # 2,500.00 / 100 = 25.00
        self.assertEqual(a["cost_per_application_pence"], 10000)       # / 25
        self.assertEqual(a["cost_per_enrolled_pence"], 50000)          # / 5
        self.assertEqual(a["revenue_pence"], 5 * 180000)
        self.assertEqual(a["net_pence"], 5 * 180000 - 250000)

    def test_a_month_with_nothing_to_divide_by_has_no_cost(self):
        s = self.by_month(self.report())["2026-09"]
        self.assertEqual((s["applications"], s["enrolled"]), (10, 0))
        self.assertIsNone(s["cost_per_enrolled_pence"])
        self.assertEqual(s["cost_per_application_pence"], 10000)
        o = self.by_month(self.report())["2026-10"]
        self.assertEqual((o["paid_leads"], o["cost_per_lead_pence"]), (0, None))

    def test_a_month_with_leads_but_no_spend_entered_has_no_costs(self):
        j = self.by_month(self.report())["2026-07"]
        self.assertEqual((j["paid_leads"], j["spend_pence"], j["cost_per_lead_pence"], j["net_pence"]), (7, None, None, None))
        self.assertIsNone(j["is_final"])

    def test_totals_cover_only_months_with_spend(self):
        t = self.report()["totals"]
        self.assertEqual((t["paid_leads"], t["applications"], t["enrolled"], t["spend_pence"]), (150, 35, 5, 588227))
        self.assertEqual(t["cost_per_lead_pence"], round(588227 / 150))
        self.assertEqual(t["net_pence"], 5 * 180000 - 588227)

    def test_no_spend_at_all_gives_empty_totals_without_error(self):
        t = self.report(spend=[])["totals"]
        self.assertEqual((t["spend_pence"], t["cost_per_lead_pence"], t["net_pence"], t["paid_leads"]), (None, None, None, 0))

    def test_the_live_entry_is_the_month_to_date_month_in_progress_only(self):
        live = self.report()["live"]
        self.assertEqual(len(live), 1)
        self.assertEqual((live[0]["month_key"], live[0]["spend_to_date_pence"], live[0]["days_elapsed"], live[0]["days_in_month"]),
                         ("2026-10", 238227, 5, 31))
        self.assertEqual((live[0]["forecast_pence"], live[0]["budget_pence"]), (1477007, 1600000))

    def test_a_month_to_date_row_for_a_past_month_is_not_live(self):
        spend = [{"month_key": "2026-08", "amount_pence": 5, "is_final": False, "budget_pence": None}]
        self.assertEqual(self.report(spend=spend)["live"], [])

    def test_empty_inputs(self):
        report = build_paid_ads_report([], [], [], SETTINGS, TODAY)
        self.assertEqual((report["rows"], report["live"]), ([], []))

    def test_cost_rounding_is_to_the_nearest_penny_halves_up(self):
        spend = [{"month_key": "2026-08", "amount_pence": 100, "is_final": True, "budget_pence": None}]
        r = self.by_month(build_paid_ads_report([lead("Paid Ad", "2026-08-01")] * 8, [], spend, SETTINGS, TODAY))["2026-08"]
        self.assertEqual(r["cost_per_lead_pence"], 13)                 # 100/8 = 12.5 -> 13


class LeadsMonthSummaryTests(unittest.TestCase):
    ROWS = [
        lead("Paid Ad", "2026-08-01", "05 - Enrolled", "P1"),
        lead("Agent", "2026-08-01", "05 - Enrolled", "P2"),
        lead("Paid Ad", "2026-08-01", "01 - New Lead", "P3"),          # matches an enrolled application below
        lead("Paid Ad", "2026-08-01", "01 - New Lead", "P4"),
        lead("Paid Ad", "2026-08-01", "05 - Enrolled", "P3"),          # both signals: still one lead
        lead("Paid Ad", "2026-08-01", "01 - New Lead", ""),
    ]

    def test_enrolled_counts_stage_five_or_a_matching_enrolled_application(self):
        s = build_month_summary(self.ROWS, {"P3", "P9"})
        self.assertEqual(s["enrolled"], 4)                              # P1, P2, P3 (match), P3 (stage)

    def test_without_application_codes_only_the_stage_counts(self):
        s = build_month_summary(self.ROWS)
        self.assertEqual(s["enrolled"], 3)

    def test_a_blank_pes_code_never_matches(self):
        self.assertEqual(build_month_summary([lead("Paid Ad", "2026-08-01", "01 - New Lead", "")], {""})["enrolled"], 0)

    def test_enrolled_percentage_has_one_decimal_and_none_for_no_leads(self):
        rows = [lead("Paid Ad", "2026-08-01", "05 - Enrolled")] + [lead("Paid Ad", "2026-08-01")] * 399
        self.assertEqual(build_month_summary(rows)["enrolled_pct"], 0.3)         # 1/400 = 0.25% -> 0.3
        self.assertIsNone(build_month_summary([])["enrolled_pct"])

    def test_the_existing_figures_are_unchanged(self):
        s = build_month_summary(self.ROWS)
        self.assertEqual((s["total"], s["prospecting"], s["applications"]), (6, 3, 3))


# ---------------------------------------------------------------- database
class DatabaseTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="gsp_paid_db_"))
        self.addCleanup(__import__("shutil").rmtree, self.tmp, ignore_errors=True)
        self.path = self.tmp / "t.db"
        self.patch = mock.patch.object(db, "DB_PATH", self.path)
        self.patch.start()
        self.addCleanup(self.patch.stop)

    def rows(self, sql):
        conn = sqlite3.connect(self.path)
        try:
            return conn.execute(sql).fetchall()
        finally:
            conn.close()

    def test_a_fresh_database_gets_the_tables_the_seed_and_the_defaults(self):
        db.init_db()
        self.assertEqual(self.rows("SELECT month_key, amount_pence, is_final, budget_pence FROM paid_ad_spend ORDER BY month_key"),
                         [("2026-08", 2537392, 1, None), ("2026-09", 1430802, 1, None), ("2026-10", 238227, 0, None)])
        self.assertEqual(dict(self.rows("SELECT setting_key, value_pence FROM paid_ad_settings")),
                         {"monthly_budget": 1600000, "revenue_per_enrolled": 180000})

    def test_init_is_idempotent_and_never_reseeds_or_overwrites(self):
        db.init_db()
        conn = sqlite3.connect(self.path)
        conn.execute("DELETE FROM paid_ad_spend WHERE month_key = '2026-08'")
        conn.execute("UPDATE paid_ad_spend SET amount_pence = 111 WHERE month_key = '2026-09'")
        conn.execute("UPDATE paid_ad_settings SET value_pence = 5 WHERE setting_key = 'monthly_budget'")
        conn.commit()
        conn.close()
        db.init_db()
        db.init_db()
        self.assertEqual(self.rows("SELECT month_key, amount_pence FROM paid_ad_spend ORDER BY month_key"),
                         [("2026-09", 111), ("2026-10", 238227)])
        self.assertEqual(dict(self.rows("SELECT setting_key, value_pence FROM paid_ad_settings"))["monthly_budget"], 5)

    def test_an_existing_database_without_the_tables_gets_them_without_touching_its_data(self):
        db.init_db()
        conn = sqlite3.connect(self.path)
        conn.execute("INSERT INTO lookup_tables (table_name, source_value, mapped_value, created_at) VALUES ('status','A','B','x')")
        conn.execute("DROP TABLE paid_ad_spend")
        conn.execute("DROP TABLE paid_ad_settings")
        conn.commit()
        conn.close()
        before = self.rows("SELECT * FROM lookup_tables")
        db.init_db()
        self.assertEqual(self.rows("SELECT * FROM lookup_tables"), before)
        self.assertEqual(len(self.rows("SELECT * FROM paid_ad_spend")), 3)

    def test_the_database_itself_refuses_negative_money(self):
        db.init_db()
        conn = sqlite3.connect(self.path)
        for sql in ("INSERT INTO paid_ad_spend VALUES ('2026-11', -1, 1, NULL, 'x')",
                    "INSERT INTO paid_ad_spend VALUES ('2026-12', 1, 1, -5, 'x')",
                    "INSERT INTO paid_ad_settings VALUES ('x', -1)"):
            with self.assertRaises(sqlite3.IntegrityError, msg=sql):
                conn.execute(sql)
        conn.close()


# ------------------------------------------------------------------- routes
def leads_book(rows):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Leads"
    ws.append(REQUIRED_LEADS_SOURCE_COLUMNS)
    for r in rows:
        full = {c: "" for c in REQUIRED_LEADS_SOURCE_COLUMNS}
        full.update(r)
        ws.append([full[c] for c in REQUIRED_LEADS_SOURCE_COLUMNS])
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def lead_row(code, source, created, status):
    return {"Student Id": code, "Name": code, "Lead Source": source, "Creation Date": created, "Lead Status": status}


LEADS = [
    lead_row("L1", "Paid Ad/Google", "03/08/2026", "New Lead"),
    lead_row("L2", "Paid Ad/Google", "04/08/2026", "Applied"),
    lead_row("L3", "Paid Ad/Google", "05/08/2026", "Enrolled Student"),
    lead_row("L4", "Agent/X", "06/08/2026", "Enrolled Student"),
    lead_row("E1", "Paid Ad/Google", "07/08/2026", "New Lead"),         # CRM stage never moved, but E1 is an Enrolled application
    lead_row("L5", "Paid Ad/Google", "02/09/2026", "New Lead"),
    lead_row("L6", "Paid Ad/Google", "03/09/2026", "Applied"),
]
STATUS_LOOKUP = [("Enrolled", "09-Enrolled"), ("Assessment", "05-Assessment"), ("Ready", "07-Ready")]
APPS = [
    ("E1", "Enrolled", "10/08/2026"), ("E2", "Enrolled", "11/08/2026"), ("A1", "Assessment", "12/08/2026"),
    ("A2", "Ready", "13/08/2026"), ("A3", "Assessment", "05/09/2026"),
]


class PaidAdsRouteTestCase(IsolatedAppTestCase):
    def setUp(self):
        super().setUp()
        patcher = mock.patch.object(app_module, "today_uk", return_value=TODAY)
        patcher.start()
        self.addCleanup(patcher.stop)
        self.full = self._client_logged_in_as("full")

    def token(self, client):
        return extract_token(client.get("/login").get_data(as_text=True))

    def post(self, client, path, **data):
        return client.post(path, data={"csrf_token": self.token(client), **data})

    def load_data(self):
        c = self.full
        rows = [row(**{"Student Code": code, "Student Name": code, "Application Status": status, "Lead Source": "Paid Ad/Google",
                       "Applied On": created, "Counsellor": "Mel X", "Admission Officer": "Alice B"}) for code, status, created in APPS]
        self.assertEqual(c.post("/upload", data={"csrf_token": self.token(c), "excel_file": (io.BytesIO(book(rows, lookups={"status": STATUS_LOOKUP})), "a.xlsx")},
                                content_type="multipart/form-data").status_code, 302)
        self.assertEqual(c.post("/leads/upload", data={"csrf_token": self.token(c), "excel_file": (io.BytesIO(leads_book(LEADS)), "l.xlsx")},
                                content_type="multipart/form-data").status_code, 302)

    def stored(self):
        conn = sqlite3.connect(db_module.DB_PATH)
        try:
            return conn.execute("SELECT month_key, amount_pence, is_final, budget_pence FROM paid_ad_spend ORDER BY month_key").fetchall()
        finally:
            conn.close()

    def settings(self):
        conn = sqlite3.connect(db_module.DB_PATH)
        try:
            return dict(conn.execute("SELECT setting_key, value_pence FROM paid_ad_settings").fetchall())
        finally:
            conn.close()


class AdminFormTests(PaidAdsRouteTestCase):
    def test_the_seeded_figures_are_in_the_admin_section(self):
        html = self.full.get("/admin").get_data(as_text=True)
        self.assertIn('id="paid-ad-spend"', html)
        for text in ("August 2026", "£25,373.92", "September 2026", "£14,308.02", "October 2026", "£2,382.27", "Month to date"):
            self.assertIn(text, html)
        self.assertIn('value="16000.00"', html)
        self.assertIn('value="1800.00"', html)

    def test_the_forecast_for_the_month_in_progress_is_shown(self):
        html = self.full.get("/admin").get_data(as_text=True)
        self.assertIn("£14,770.07", html)             # 2,382.27 / 5 x 31
        self.assertIn("-£1,229.93", html)             # vs the £16,000 budget

    def test_saving_a_new_month_and_updating_it(self):
        r = self.post(self.full, "/admin/paid-ads/spend", month_key="2026-07", amount="£12,000.50", status="final", budget="")
        self.assertEqual(r.status_code, 302)
        self.assertIn(("2026-07", 1200050, 1, None), self.stored())
        self.post(self.full, "/admin/paid-ads/spend", month_key="2026-07", amount="13000", status="mtd", budget="15000")
        self.assertIn(("2026-07", 1300000, 0, 1500000), self.stored())
        self.assertEqual(len([s for s in self.stored() if s[0] == "2026-07"]), 1, "updated in place, not duplicated")

    def test_the_live_month_can_be_updated_with_a_new_month_to_date_figure(self):
        self.post(self.full, "/admin/paid-ads/spend", month_key="2026-10", amount="4000", status="mtd", budget="")
        self.assertIn(("2026-10", 400000, 0, None), self.stored())
        html = self.full.get("/admin").get_data(as_text=True)
        self.assertIn("£24,800.00", html)              # 4,000 / 5 x 31

    def test_invalid_input_is_refused_with_a_message_and_changes_nothing(self):
        before = self.stored()
        cases = [dict(month_key="2026-13", amount="1", status="final"), dict(month_key="", amount="1", status="final"),
                 dict(month_key="2026-07", amount="abc", status="final"), dict(month_key="2026-07", amount="-1", status="final"),
                 dict(month_key="2026-07", amount="", status="final"), dict(month_key="2026-07", amount="1", status="bogus"),
                 dict(month_key="2026-07", amount="1", status="final", budget="x"), dict(month_key="2026-07", amount="1e9", status="final")]
        for case in cases:
            case.setdefault("budget", "")
            r = self.post(self.full, "/admin/paid-ads/spend", **case)
            self.assertEqual(r.status_code, 302, case)
            page = self.full.get(r.headers["Location"]).get_data(as_text=True)
            self.assertIn('class="flash error"', page, case)
        self.assertEqual(self.stored(), before)

    def test_removing_a_month(self):
        self.assertEqual(self.post(self.full, "/admin/paid-ads/spend/2026-08/delete").status_code, 302)
        self.assertNotIn("2026-08", [s[0] for s in self.stored()])
        self.assertEqual(len(self.stored()), 2)

    def test_removing_with_a_bad_month_key_changes_nothing(self):
        before = self.stored()
        for bad in ("garbage", "2026-99", "1999-01"):
            self.assertEqual(self.post(self.full, f"/admin/paid-ads/spend/{bad}/delete").status_code, 302)
        self.assertEqual(self.stored(), before)

    def test_saving_the_budget_and_average_earning(self):
        r = self.post(self.full, "/admin/paid-ads/settings", monthly_budget="17,500.25", revenue_per_enrolled="£2,000")
        self.assertEqual(r.status_code, 302)
        self.assertEqual(self.settings(), {"monthly_budget": 1750025, "revenue_per_enrolled": 200000})

    def test_invalid_settings_change_neither_value(self):
        before = self.settings()
        # includes a VALID, DIFFERENT budget paired with a bad earning (and vice versa): neither may be saved alone
        for budget, revenue in (("abc", "1800"), ("17000", "-1"), ("", "1800"), ("17000", ""), ("-5", "x"), ("17000", "abc"), ("x", "2500")):
            self.post(self.full, "/admin/paid-ads/settings", monthly_budget=budget, revenue_per_enrolled=revenue)
        self.assertEqual(self.settings(), before)

    def test_csrf_is_required_on_every_paid_ad_form(self):
        before = (self.stored(), self.settings())
        for path, data in (("/admin/paid-ads/spend", dict(month_key="2026-07", amount="1", status="final", budget="")),
                           ("/admin/paid-ads/spend/2026-08/delete", {}),
                           ("/admin/paid-ads/settings", dict(monthly_budget="1", revenue_per_enrolled="1"))):
            self.assertEqual(self.full.post(path, data=data).status_code, 400, path)
        self.assertEqual((self.stored(), self.settings()), before)

    def test_only_full_access_can_change_anything(self):
        before = (self.stored(), self.settings())
        for role in ("admissions", "consultants", "marketing"):
            client = self._client_logged_in_as(role)
            for path, data in (("/admin/paid-ads/spend", dict(month_key="2026-07", amount="1", status="final", budget="")),
                               ("/admin/paid-ads/spend/2026-08/delete", {}),
                               ("/admin/paid-ads/settings", dict(monthly_budget="1", revenue_per_enrolled="1"))):
                self.assertEqual(self.post(client, path, **data).status_code, 403, (role, path))
        self.assertEqual((self.stored(), self.settings()), before)

    def test_login_is_required(self):
        anonymous = app_module.app.test_client()
        token = extract_token(anonymous.get("/login").get_data(as_text=True))
        for path in ("/admin/paid-ads/spend", "/admin/paid-ads/spend/2026-08/delete", "/admin/paid-ads/settings"):
            r = anonymous.post(path, data={"csrf_token": token})
            self.assertEqual(r.status_code, 302, path)
            self.assertIn("/login", r.headers["Location"])
        self.assertEqual(len(self.stored()), 3)

    def test_who_sees_the_admin_section_and_its_controls(self):
        full = self.full.get("/admin").get_data(as_text=True)
        self.assertIn("Add or update a month", full)
        self.assertIn('action="/admin/paid-ads/settings"', full)
        admissions = self._client_logged_in_as("admissions").get("/admin").get_data(as_text=True)
        self.assertIn('id="paid-ad-spend"', admissions)
        self.assertIn("£25,373.92", admissions)
        for control in ("Add or update a month", 'action="/admin/paid-ads/', "Remove"):
            self.assertNotIn(control, admissions, control)
        for role in ("consultants", "marketing"):
            page = self._client_logged_in_as(role).get("/admin").get_data(as_text=True)
            self.assertNotIn("Paid Ad Spend", page, role)
            self.assertNotIn("25,373.92", page, role)


class PaidAdsPageTests(PaidAdsRouteTestCase):
    def setUp(self):
        super().setUp()
        self.load_data()

    def page(self, client=None):
        r = (client or self.full).get("/paid-ads")
        self.assertEqual(r.status_code, 200)
        return r.get_data(as_text=True)

    def row_cells(self, html, month_label):
        m = re.search(rf"<tr>\s*<td>{month_label}.*?</tr>", html, re.S)
        self.assertTrue(m, month_label)
        return [re.sub(r"<[^>]+>|\s+", " ", c).strip() for c in re.findall(r"<td>(.*?)</td>", m.group(0), re.S)]

    def test_august_row_uses_the_agreed_counting(self):
        cells = self.row_cells(self.page(), "August 2026")
        # leads: L1,L2,L3,E1 are Paid Ad in Aug = 4; apps: E1,E2,A1,A2 created in Aug = 4 (2 enrolled)
        self.assertEqual(cells[1], "4")
        self.assertEqual(cells[2], "£25,373.92")
        self.assertEqual(cells[3], "£6,343.48")           # 25,373.92 / 4
        self.assertEqual(cells[4], "4")
        self.assertEqual(cells[5], "£6,343.48")
        self.assertEqual(cells[6], "2")
        self.assertEqual(cells[7], "£12,686.96")          # / 2 enrolled
        self.assertEqual(cells[8], "£3,600.00")           # 2 x 1,800
        self.assertEqual(cells[9], "-£21,773.92")

    def test_september_and_october_rows(self):
        html = self.page()
        sep = self.row_cells(html, "September 2026")
        self.assertEqual((sep[1], sep[2], sep[3], sep[4], sep[6], sep[7]), ("2", "£14,308.02", "£7,154.01", "1", "0", "-"))
        octo = self.row_cells(html, "October 2026")
        self.assertEqual((octo[1], octo[2], octo[3]), ("0", "£2,382.27", "-"))
        self.assertIn("(to date)", html)

    def test_the_forecast_cards_for_the_live_month(self):
        html = self.page()
        for text in ("October 2026 (day 5 of 31)", "£2,382.27", "£14,770.07", "£16,000.00", "Under budget", "£1,229.93"):
            self.assertIn(text, html)

    def test_over_budget_wording(self):
        self.post(self.full, "/admin/paid-ads/settings", monthly_budget="10000", revenue_per_enrolled="1800")
        html = self.page()
        self.assertIn("Over budget", html)
        self.assertIn("£4,770.07", html)

    def test_a_changed_average_earning_flows_through(self):
        self.post(self.full, "/admin/paid-ads/settings", monthly_budget="16000", revenue_per_enrolled="2000")
        self.assertEqual(self.row_cells(self.page(), "August 2026")[8], "£4,000.00")

    def test_a_month_with_leads_but_no_spend_is_shown_as_not_entered(self):
        self.post(self.full, "/admin/paid-ads/spend/2026-09/delete")
        html = self.page()
        self.assertIn("Not entered", html)
        self.assertEqual(self.row_cells(html, "September 2026")[3], "-")

    def test_the_total_row_is_there_and_the_explanatory_note_is_not(self):
        html = self.page()
        self.assertIn("<tfoot>", html)
        for text in ("Paid Leads are Paid Ad leads created in the month", "counted in the month their application was created",
                     "Est. Revenue is Enrolled", "The Total row covers the months that have spend entered"):
            self.assertNotIn(text, html, text)

    def test_the_no_leads_file_warning_only_shows_when_there_is_no_leads_file(self):
        self.assertNotIn("No Leads file has been uploaded yet", self.page())
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute("DELETE FROM active_leads_dataset")
        conn.commit()
        conn.close()
        self.assertIn("No Leads file has been uploaded yet, so lead counts show 0.", self.page())

    def test_access_full_and_admissions_only(self):
        self.assertIn("Paid Ad Performance by Month", self.page(self._client_logged_in_as("admissions")))
        for role in ("consultants", "marketing"):
            self.assertEqual(self._client_logged_in_as(role).get("/paid-ads").status_code, 403, role)
        self.assertEqual(app_module.app.test_client().get("/paid-ads").status_code, 302)

    def test_the_page_works_before_any_leads_or_applications_are_loaded(self):
        # a brand new database: only the seeded spend months exist
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute("DELETE FROM active_dataset")
        conn.execute("DELETE FROM active_leads_dataset")
        conn.commit()
        conn.close()
        html = self.page()
        self.assertIn("£25,373.92", html)
        self.assertNotIn("Traceback", html)

    def test_with_no_spend_and_no_data_there_is_a_friendly_message(self):
        conn = sqlite3.connect(db_module.DB_PATH)
        for table in ("paid_ad_spend", "active_dataset", "active_leads_dataset"):
            conn.execute(f"DELETE FROM {table}")
        conn.commit()
        conn.close()
        self.assertIn("No Paid Ad spend or Paid Ad leads yet.", self.page())


class LeadsDashboardBoxTests(PaidAdsRouteTestCase):
    def setUp(self):
        super().setUp()
        self.load_data()

    def dashboard(self, client=None, month="2026-08"):
        r = (client or self.full).get(f"/leads-dashboard?month={month}")
        self.assertEqual(r.status_code, 200)
        return r.get_data(as_text=True)

    def box(self, html):
        m = re.search(r'<div class="summary-card-title">Enrolled</div>(.*?)</div>\s*</div>\s*</div>\s*<section', html, re.S)
        self.assertTrue(m, "Enrolled box present")
        return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", m.group(1))).strip()

    def test_the_box_sits_next_to_prospecting_and_applications(self):
        html = self.dashboard()
        order = [html.index(t) for t in ("Prospecting</div>", "Applications</div>", "Enrolled</div>")]
        self.assertEqual(order, sorted(order))

    def test_august_enrolled_counts_the_stage_and_the_matching_enrolled_application(self):
        # L3 and L4 are at stage Enrolled; E1's lead is still "New Lead" but E1 is an Enrolled application
        text = self.box(self.dashboard())
        self.assertEqual(text, "Leads enrolled 3 % of Total 60.0%")          # 3 of the 5 August leads

    def test_a_month_without_enrolments(self):
        self.assertEqual(self.box(self.dashboard(month="2026-09")), "Leads enrolled 0 % of Total 0.0%")

    def test_the_box_shows_no_revenue_spend_or_cost_for_any_role(self):
        for client in (self.full, self._client_logged_in_as("admissions"), self._client_logged_in_as("consultants"),
                       self._client_logged_in_as("marketing")):
            for month in ("2026-08", "2026-09", "2026-10"):
                html = self.dashboard(client, month)
                for text in ("Revenue", "Paid Ad spend", "Cost per Paid Ad enrolled", "25,373.92", "14,308.02", "5,400.00"):
                    self.assertNotIn(text, html, (month, text))

    def test_the_link_to_the_paid_ads_page_is_only_for_roles_with_access(self):
        html = self.dashboard()
        self.assertIn('href="/paid-ads"', html)
        self.assertIn(">Paid Ads</a>", html)
        self.assertIn('href="/paid-ads"', self.dashboard(self._client_logged_in_as("admissions")))
        for role in ("consultants", "marketing"):
            self.assertNotIn('href="/paid-ads"', self.dashboard(self._client_logged_in_as(role)), role)

    def test_everyone_still_sees_the_enrolled_count_and_percentage(self):
        for role in ("full", "admissions", "consultants", "marketing"):
            text = self.box(self.dashboard(self._client_logged_in_as(role)))
            self.assertIn("Leads enrolled 3", text, role)
            self.assertIn("% of Total 60.0%", text, role)


if __name__ == "__main__":
    unittest.main()
