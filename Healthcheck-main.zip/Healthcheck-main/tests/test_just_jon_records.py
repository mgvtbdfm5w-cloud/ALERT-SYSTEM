"""Just Jon: clicking a piece of any of its three charts (Application Manager,
Consultant, University) lists the applications in it - the same pop-up window
as the University Pipeline page.

The list is read off the very report the chart was drawn from, so these tests
check it against what the page itself shows, across the rules that make a
chart's numbers differ from a plain filter (one row per student, a Lost record
dropped when the student has a live application next year, hidden consultants,
excluded managers)."""

import io
import unittest
from urllib.parse import urlencode

from flask import template_rendered

from pipeline import STAGES
from tests.flask_test_support import IsolatedAppTestCase, app_module, extract_token
from tests.test_upload_atomicity import book, row
from contextlib import contextmanager
import re
from pathlib import Path

LOOKUPS = {
    "status": [("Assessment", "05-Assessment"), ("Decision", "06-Decision"), ("Enrolled", "09-Enrolled"), ("Cancelled", "10-Lost")],
    "office": [("Mo Y", "UK"), ("Nouran X", "EG"), ("Admission X", "EG")],
    "sales_office": [("Raneen", "OXF"), ("Mel", "MAN"), ("Hannah", "LON"), ("Jay", "OXF")],
}


def app_row(code, intake, status, officer, consultant, university, source="Agent/Just Jon", created="", name=None):
    return row(**{"Student Code": code, "Student Name": name or f"Student {code}", "Application Status": status, "Intake": intake,
                  "Admission Officer": officer, "Counsellor": consultant, "University Name": university, "Lead Source": source,
                  "Applied On": created})


ROWS = [
    app_row("J1", "August 2026", "Assessment", "Mo Y", "Raneen R", "Uni A", created="01/08/2026"),      # J1 applied twice: the later one (Decision) is the student's row
    app_row("J1", "August 2026", "Decision", "Mo Y", "Raneen R", "Uni B", created="05/08/2026"),
    app_row("J2", "September 2026", "Enrolled", "Nouran X", "Mel M", "Uni A"),
    app_row("J3", "September 2026", "Cancelled", "Nouran X", "Raneen R", "Uni A"),                     # lost in 2026 ...
    app_row("J3", "January 2027", "Assessment", "Nouran X", "Raneen R", "Uni A"),                      # ... but alive in 2027, so not a 2026 loss
    app_row("J4", "October 2026", "Decision", "Mo Y", "Hannah H", "Uni C"),
    app_row("J5", "August 2026", "Assessment", "Mo Y", "Raneen R", "Uni A", source="Agent/Someone Else"),   # not Just Jon
    app_row("J6", "August 2026", "Assessment", "", "Hannah H", "Uni A"),                                # no Application Manager
    app_row("J7", "September 2026", "Assessment", "Mo Y", "Jay J", "Uni A"),                           # Jay has left: no consultant bar
    app_row("J8", "October 2026", "Assessment", "Admission X", "Raneen R", "Uni A"),                   # "Admission" is not a real manager
    app_row("J9", "November 2026", "Enrolled", "Mo Y", "Raneen R", "", name="=SUM(1,1)"),              # no university; formula-looking name
    app_row("J10", "February 2027", "Decision", "Mo Y", "Mel M", "Uni C"),
    app_row("J11", "September 2027", "Enrolled", "Nouran X", "Hannah H", "Uni C"),
]
CHARTS = {"manager": "am_chart_groups", "consultant": "consultant_chart_groups", "university": "university_chart_groups"}
QUERIES = ["year=2026", "year=2027", "year=2027&intake=intake_01", "year=2027&intake=intake_03", "year=2026&intake=intake_03", "year=2099"]


@contextmanager
def captured():
    rendered = []

    def record(sender, template, context, **extra):
        rendered.append((template.name, dict(context)))

    template_rendered.connect(record, app_module.app)
    try:
        yield rendered
    finally:
        template_rendered.disconnect(record, app_module.app)


class JustJonBase(IsolatedAppTestCase):
    def setUp(self):
        super().setUp()
        self.full = self._client_logged_in_as("full")
        token = extract_token(self.full.get("/login").get_data(as_text=True))
        data = book(ROWS, lookups=LOOKUPS)
        self.assertEqual(self.full.post("/upload", data={"csrf_token": token, "excel_file": (io.BytesIO(data), "f.xlsx")},
                                        content_type="multipart/form-data").status_code, 302)

    def page(self, query="year=2026", client=None):
        with captured() as rendered:
            r = (client or self.full).get("/dashboard/just-jon?" + query)
        self.assertEqual(r.status_code, 200, query)
        return r.get_data(as_text=True), next(c for name, c in rendered if name == "dashboard_just_jon.html")

    def records(self, query, chart, name, stage, client=None):
        return (client or self.full).get("/dashboard/just-jon/records?" + query + "&" + urlencode({"chart": chart, "name": name, "stage": stage}))

    def codes(self, query, chart, name, stage):
        return [r["code"] for r in self.records(query, chart, name, stage).get_json()["records"]]

    def pieces(self, context, chart):
        return [(row["name"], seg["stage"], seg["count"]) for g in context[CHARTS[chart]] for row in g["rows"] for seg in row["segments"]]


class RecordsTests(JustJonBase):
    def test_every_piece_of_every_chart_lists_exactly_the_number_it_shows(self):
        checked = 0
        for query in QUERIES:
            _, context = self.page(query)
            for chart in CHARTS:
                for name, stage, count in self.pieces(context, chart):
                    r = self.records(query, chart, name, stage)
                    self.assertEqual(r.status_code, 200, (query, chart, name, stage))
                    data = r.get_json()
                    self.assertEqual((data["count"], len(data["records"])), (count, count), (query, chart, name, stage))
                    codes = [rec["code"] for rec in data["records"]]
                    self.assertEqual(len(codes), len(set(codes)) if chart != "university" else len(codes))
                    checked += 1
        self.assertGreater(checked, 12, "the data gives plenty of pieces to check")

    def test_the_pieces_of_one_bar_add_up_to_the_bar(self):
        for query in QUERIES:
            _, context = self.page(query)
            for chart, key in CHARTS.items():
                for group in context[key]:
                    for row_ in group["rows"]:
                        total = sum(len(self.codes(query, chart, row_["name"], seg["stage"])) for seg in row_["segments"])
                        self.assertEqual(total, row_["total"], (query, chart, row_["name"]))

    def test_application_manager_chart_one_row_per_student_and_no_carried_forward_loss(self):
        self.assertEqual(self.codes("year=2026", "manager", "Mo", "06-Decision"), ["J1", "J4"], "J1's later Decision application represents the student")
        self.assertEqual(self.codes("year=2026", "manager", "Mo", "05-Assessment"), ["J7"], "J1's earlier Assessment row is not a second prospect; J5 is not Just Jon")
        self.assertEqual(self.codes("year=2026", "manager", "Mo", "09-Enrolled"), ["J9"])
        self.assertEqual(self.codes("year=2026", "manager", "Nouran", "10-Lost"), [], "J3 has a live application in 2027, so it is not a 2026 loss")
        self.assertEqual(self.codes("year=2026", "manager", "Nouran", "09-Enrolled"), ["J2"])
        self.assertEqual(self.codes("year=2027", "manager", "Nouran", "05-Assessment"), ["J3"])

    def test_consultant_chart_hidden_and_unlisted_people(self):
        self.assertEqual(self.codes("year=2026", "consultant", "Raneen", "05-Assessment"), ["J8"], "J8's manager is excluded from the manager chart, not from this one")
        self.assertEqual(self.codes("year=2026", "consultant", "Raneen", "06-Decision"), ["J1"])
        self.assertEqual(self.codes("year=2026", "consultant", "Jay", "05-Assessment"), [], "Jay has no bar of his own, so nothing to click")
        self.assertEqual(self.codes("year=2026", "consultant", "Hannah", "06-Decision"), ["J4"])
        self.assertEqual(self.codes("year=2026", "consultant", "Hannah", "05-Assessment"), ["J6"])

    def test_university_chart_counts_every_row_not_one_per_student(self):
        self.assertEqual(sorted(self.codes("year=2026", "university", "Uni A", "05-Assessment")), ["J1", "J6", "J7", "J8"], "J1's Assessment row counts here")
        self.assertEqual(self.codes("year=2026", "university", "Uni B", "06-Decision"), ["J1"])
        self.assertEqual(self.codes("year=2026", "university", "Uni A", "10-Lost"), ["J3"], "the 2026 loss still counts for the university")
        self.assertEqual(self.codes("year=2026", "university", "Unassigned", "09-Enrolled"), ["J9"])

    def test_never_includes_applications_that_are_not_just_jon(self):
        every = set()
        for query in QUERIES:
            for chart in CHARTS:
                for stage in STAGES:
                    for name in ("Mo", "Nouran", "Raneen", "Mel", "Hannah", "Uni A", "Uni B", "Uni C", "Unassigned"):
                        every |= set(self.codes(query, chart, name, stage))
        self.assertNotIn("J5", every)
        self.assertEqual(every, {"J1", "J2", "J3", "J4", "J6", "J7", "J8", "J9", "J10", "J11"})

    def test_the_year_and_intake_tab_come_along(self):
        self.assertEqual(self.codes("year=2027", "manager", "Mo", "06-Decision"), ["J10"])
        self.assertEqual(self.codes("year=2027&intake=intake_01", "manager", "Mo", "06-Decision"), ["J10"])
        self.assertEqual(self.codes("year=2027&intake=intake_03", "manager", "Mo", "06-Decision"), [])
        self.assertEqual(self.codes("year=2027&intake=intake_03", "university", "Uni C", "09-Enrolled"), ["J11"])
        self.assertEqual(self.codes("year=2026", "university", "Uni C", "06-Decision"), ["J4"])

    def test_each_record_has_the_six_fields_sorted_by_student(self):
        data = self.records("year=2026", "university", "Uni A", "05-Assessment").get_json()
        self.assertEqual(sorted(data["records"][0]), ["code", "consultant", "intake", "manager", "student", "university"])
        by_code = {r["code"]: r for r in data["records"]}
        self.assertEqual(by_code["J1"], {"code": "J1", "student": "Student J1", "university": "Uni A", "intake": "August 2026", "consultant": "Raneen", "manager": "Mo"})
        self.assertEqual(by_code["J6"]["manager"], "Unassigned")
        keys = [(r["student"].lower(), r["code"]) for r in data["records"]]
        self.assertEqual(keys, sorted(keys))
        self.assertEqual((data["chart"], data["name"], data["stage"]), ("university", "Uni A", "05-Assessment"))

    def test_an_unknown_chart_or_stage_is_a_400_and_an_unknown_name_is_an_empty_list(self):
        for params in ({"chart": "nope", "name": "Mo", "stage": "05-Assessment"}, {"chart": "", "name": "Mo", "stage": "05-Assessment"},
                       {"chart": "manager", "name": "Mo", "stage": "nope"}, {"chart": "manager", "name": "Mo"}, {"name": "Mo", "stage": "05-Assessment"},
                       {"chart": "MANAGER", "name": "Mo", "stage": "05-Assessment"}, {"chart": "manager", "name": "Mo", "stage": "00-QARejected"}):
            r = self.full.get("/dashboard/just-jon/records?year=2026&" + urlencode(params))
            self.assertEqual((r.status_code, r.get_json()), (400, {"error": "Unknown chart piece."}), params)
        for name in ("Nobody", "", "mo", "Mo "):
            r = self.records("year=2026", "manager", name, "05-Assessment")
            self.assertEqual((r.status_code, r.get_json()["count"], r.get_json()["records"]), (200, 0, []), repr(name))

    def test_names_come_back_as_plain_json_text(self):
        data = self.records("year=2026", "university", "Unassigned", "09-Enrolled").get_json()
        self.assertEqual(data["records"][0]["student"], "")        # the formula-looking name arrives as an empty cell from the workbook
        r = self.records("year=2026", "manager", "Mo", "06-Decision")
        self.assertEqual(r.mimetype, "application/json")
        self.assertEqual(r.headers["Cache-Control"], "no-store")

    def test_login_is_required_and_every_role_can_use_it(self):
        r = app_module.app.test_client().get("/dashboard/just-jon/records?year=2026&chart=manager&name=Mo&stage=06-Decision")
        self.assertEqual(r.status_code, 302)
        self.assertIn("/login", r.headers["Location"])
        for role in ("admissions", "consultants", "marketing"):
            r = self.records("year=2026", "manager", "Mo", "06-Decision", client=self._client_logged_in_as(role))
            self.assertEqual(r.get_json()["count"], 2, role)

    def test_with_no_dataset_it_is_an_empty_list(self):
        import sqlite3
        from tests.flask_test_support import db_module
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute("DELETE FROM active_dataset")
        conn.commit()
        conn.close()
        r = self.records("year=2026", "manager", "Mo", "06-Decision")
        self.assertEqual((r.status_code, r.get_json()["count"]), (200, 0))


class PageMarkupTests(JustJonBase):
    def test_every_piece_of_the_three_charts_is_a_clickable_button_that_says_what_it_opens(self):
        html, context = self.page("year=2026")
        pieces = re.findall(r'<div class="chart-segment chart-segment-clickable"\s+role="button" tabindex="0"\s+data-records-title="([^"]*)"\s+'
                            r'data-records-params="([^"]*)"\s+data-count="(\d+)"\s+aria-label="[^"]*"\s+style="[^"]*"\s+data-tooltip="([^"]*)"', html)
        expected = [(chart, name, stage, count) for chart in CHARTS for name, stage, count in self.pieces(context, chart)]
        got = []
        for title, params, count, tooltip in pieces:
            query = dict(p.split("=") for p in params.replace("&amp;", "&").split("&"))
            from urllib.parse import unquote_plus
            got.append((query["chart"], unquote_plus(query["name"]), unquote_plus(query["stage"]), int(count)))
            self.assertEqual(sorted(query), ["chart", "name", "stage"])
            self.assertEqual(tooltip, f"{unquote_plus(query['stage'])}: {count}", "the hover tooltip is unchanged")
            self.assertEqual(title, f"{unquote_plus(query['name'])} &mdash; {unquote_plus(query['stage'])}")
        self.assertEqual(got, expected)
        self.assertEqual(html.count("chart-segment-clickable"), len(pieces))
        self.assertGreater(len(pieces), 12)

    def test_the_window_script_and_hints_are_there_once_per_chart(self):
        html, _ = self.page("year=2026")
        self.assertEqual(html.count('<dialog id="chart-records"'), 1)
        self.assertIn('data-url="/dashboard/just-jon/records"', html)
        self.assertEqual(html.count("chart-records.js"), 1)
        self.assertEqual(html.count("Click a bar to list its applications."), 3)

    def test_other_pages_are_unchanged(self):
        for path in ("/enrolled?year=2026", "/consultants"):
            html = self.full.get(path).get_data(as_text=True)
            self.assertNotIn("chart-segment-clickable", html, path)
            self.assertNotIn('<dialog id="chart-records"', html, path)
            self.assertNotIn("Click a bar to list", html, path)

    def test_the_university_pipeline_page_still_has_its_own_window(self):
        html = self.full.get("/university-pipeline?year=2026").get_data(as_text=True)
        self.assertIn('data-url="/university-pipeline/records"', html)
        self.assertIn("chart-segment-clickable", html)

    def test_with_no_dataset_there_is_no_window(self):
        import sqlite3
        from tests.flask_test_support import db_module
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute("DELETE FROM active_dataset")
        conn.commit()
        conn.close()
        html = self.full.get("/dashboard/just-jon?year=2026").get_data(as_text=True)
        self.assertNotIn('<dialog id="chart-records"', html)


class ReportRowsTests(unittest.TestCase):
    """pipeline.build_pipeline_report(keep_rows=True) - the rows behind every number."""

    def test_keep_rows_lists_exactly_the_rows_counted_and_leaves_the_default_output_alone(self):
        from pipeline import build_pipeline_report, report_segment_rows
        rows = [
            {"Application": "Mo", "Office": "UK", "Status": "05-Assessment", "Student Code": "1"},
            {"Application": "Mo", "Office": "UK", "Status": "05-Assessment", "Student Code": "2"},
            {"Application": "Mo", "Office": "EG", "Status": "05-Assessment", "Student Code": "3"},      # same person, other office: excluded, not counted
            {"Application": "Mo", "Office": "UK", "Status": "00-QARejected", "Student Code": "4"},      # not a pipeline stage
            {"Application": "Admission", "Office": "UK", "Status": "05-Assessment", "Student Code": "5"},   # excluded manager
            {"Application": "", "Office": "UK", "Status": "05-Assessment", "Student Code": "6"},        # blank person
            {"Application": "Al", "Office": "UK", "Status": "09-Enrolled", "Student Code": "7"},
        ]
        plain = build_pipeline_report(rows, {}, excluded_persons={"admission"})
        kept = build_pipeline_report(rows, {}, excluded_persons={"admission"}, keep_rows=True)
        self.assertTrue(all("rows_by_stage" not in m for g in plain["office_groups"] for m in g["managers"]), "off by default")
        for g in kept["office_groups"]:
            for m in g["managers"]:
                m.pop("rows_by_stage")
        self.assertEqual(kept, plain, "apart from rows_by_stage the report is identical")
        kept = build_pipeline_report(rows, {}, excluded_persons={"admission"}, keep_rows=True)
        self.assertEqual([r["Student Code"] for r in report_segment_rows(kept, "Mo", "05-Assessment")], ["1", "2"])
        self.assertEqual([r["Student Code"] for r in report_segment_rows(kept, "Al", "09-Enrolled")], ["7"])
        self.assertEqual(report_segment_rows(kept, "Admission", "05-Assessment"), [])
        self.assertEqual(report_segment_rows(kept, "Nobody", "05-Assessment"), [])
        self.assertEqual(report_segment_rows(kept, "Mo", "not-a-stage"), [])
        self.assertEqual(report_segment_rows(plain, "Mo", "05-Assessment"), [], "a report built without keep_rows has no rows to give")

    def test_the_returned_list_is_a_copy(self):
        from pipeline import build_pipeline_report, report_segment_rows
        kept = build_pipeline_report([{"Application": "Mo", "Office": "UK", "Status": "05-Assessment"}], {}, keep_rows=True)
        report_segment_rows(kept, "Mo", "05-Assessment").clear()
        self.assertEqual(len(report_segment_rows(kept, "Mo", "05-Assessment")), 1)


if __name__ == "__main__":
    unittest.main()
