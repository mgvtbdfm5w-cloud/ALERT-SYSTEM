"""Lookup duplicate protection: the database enforces what the app checks.

Before: "no duplicate mapping" was enforced only by a SELECT in the app
followed by an INSERT/UPDATE - two requests that both passed the SELECT
before either wrote created duplicate rows (reproduced: 399 of 400 rounds
with 8 racing threads). Now a UNIQUE index on (table_name, lower(source_value))
makes the database refuse the second write, and add_lookup / update_lookup
translate that refusal - and only that - into the existing friendly
DuplicateLookupError.

Pinned here:
- the index is created idempotently at startup, and a database that ALREADY
  contains duplicates still starts (WARNING, nothing deleted or merged, no
  index) instead of failing;
- every existing duplicate rule and message is unchanged (case, whitespace,
  blank, per-table uniqueness, editing a row to its own value), and the
  pre-check still runs first;
- an exact repeat of a non-ASCII value such as "Ecole" with an accent, which
  the old check let through, is now refused safely; non-ASCII CASE variants
  keep behaving as they always did (a documented inconsistency, left alone);
- races - add/add, edit/edit, add/edit and a natural 8-thread race - leave
  exactly one row, give the loser the friendly message, and leave no open
  connection or lock;
- an integrity error that is NOT a duplicate is never disguised as one.

Temp databases only; nothing here touches the real data/app.db.
"""

import html
import logging
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import threading
import unittest
from pathlib import Path
from unittest import mock

import db
import lookups
from lookups import DuplicateLookupError, LookupValidationError, add_lookup, update_lookup
from tests.connection_tracking import ConnectionTracker
from tests.flask_test_support import IsolatedAppTestCase, app_module, db_module, extract_token

NOW = "2026-01-01T00:00:00"
ADD_MSG = "'{}' already exists in this lookup table. Edit the existing mapping instead."
EDIT_MSG = "'{}' already exists in this lookup table. Choose a different value."
INTERNAL_WORDS = ("UNIQUE", "constraint", "IntegrityError", "idx_lookup", "lookup_tables", "sqlite", "index", "Traceback")
ROOT = Path(__file__).resolve().parent.parent


def lookup_rows(path=None, table=None):
    conn = sqlite3.connect(path or db.DB_PATH)
    try:
        sql, params = "SELECT id, table_name, source_value, mapped_value FROM lookup_tables", ()
        if table:
            sql, params = sql + " WHERE table_name = ?", (table,)
        return [tuple(r) for r in conn.execute(sql + " ORDER BY id", params).fetchall()]
    finally:
        conn.close()


def index_definition(path=None):
    conn = sqlite3.connect(path or db.DB_PATH)
    try:
        row = conn.execute("SELECT sql FROM sqlite_master WHERE type='index' AND name=?", (db.LOOKUP_UNIQUE_INDEX_NAME,)).fetchone()
        return row[0] if row else None
    finally:
        conn.close()


class TempDbTestCase(unittest.TestCase):
    """A fresh temp database (built by the real init_db) per test."""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="gsp_lookup_unique_"))
        patcher = mock.patch.object(db, "DB_PATH", self.tmp / "t.db")
        patcher.start()
        self.addCleanup(patcher.stop)
        self.addCleanup(shutil.rmtree, self.tmp, True)
        db.init_db()
        self.tracker = ConnectionTracker(db)
        self.tracker.install()
        self.addCleanup(self.tracker.uninstall)
        self.addCleanup(self.tracker.force_close_leaks)

    # -- helpers --------------------------------------------------------------
    def add(self, value, table="status", mapped="m"):
        """-> 'added' | the DuplicateLookupError message | 'invalid: ...'"""
        with db.db_connection() as conn:
            try:
                add_lookup(conn, table, value, mapped, NOW)
                return "added"
            except DuplicateLookupError as exc:
                return str(exc)
            except LookupValidationError as exc:
                return f"invalid: {exc}"

    def edit(self, row_id, value, table="status"):
        with db.db_connection() as conn:
            try:
                update_lookup(conn, row_id, table, value, "m")
                return "updated"
            except DuplicateLookupError as exc:
                return str(exc)

    def row_id(self, value, table="status"):
        return next(r[0] for r in lookup_rows(table=table) if r[2] == value)

    def drop_index(self):
        conn = sqlite3.connect(db.DB_PATH)
        conn.execute(f"DROP INDEX IF EXISTS {db.LOOKUP_UNIQUE_INDEX_NAME}")
        conn.commit()
        conn.close()

    def raw(self, sql, params=()):
        conn = sqlite3.connect(db.DB_PATH)
        try:
            conn.execute(sql, params)
            conn.commit()
        finally:
            conn.close()

    def insert_raw(self, table, value, mapped="m"):
        self.raw("INSERT INTO lookup_tables (table_name, source_value, mapped_value, created_at) VALUES (?,?,?,?)", (table, value, mapped, NOW))

    def assert_database_is_writable_immediately(self):
        probe = sqlite3.connect(db.DB_PATH, timeout=0, isolation_level=None)
        try:
            probe.execute("BEGIN IMMEDIATE")
            probe.execute("ROLLBACK")
        finally:
            probe.close()


# =========================================================================
# 1. Migration
# =========================================================================
class MigrationTests(TempDbTestCase):
    def test_a_fresh_database_gets_the_unique_index(self):
        definition = index_definition()
        self.assertIsNotNone(definition)
        self.assertIn("UNIQUE", definition.upper())
        self.assertIn("lower(source_value)", definition)
        conn = sqlite3.connect(db.DB_PATH)
        listed = {r[1]: r[2] for r in conn.execute("PRAGMA index_list(lookup_tables)")}
        columns = [r[2] for r in conn.execute(f"PRAGMA index_xinfo({db.LOOKUP_UNIQUE_INDEX_NAME})") if r[5]]
        conn.close()
        self.assertEqual(listed[db.LOOKUP_UNIQUE_INDEX_NAME], 1, "unique")
        self.assertEqual(columns[0], "table_name")

    def test_an_existing_clean_database_gets_the_index_without_touching_its_data(self):
        for value in ("Alpha", "Beta"):
            self.assertEqual(self.add(value), "added")
        self.drop_index()
        before = lookup_rows()
        db.init_db()
        self.assertIsNotNone(index_definition())
        self.assertEqual(lookup_rows(), before)

    def test_the_migration_is_idempotent_and_repeated_initialisation_is_harmless(self):
        self.add("Alpha")
        before = (lookup_rows(), index_definition())
        for _ in range(5):
            db.init_db()
        self.assertEqual((lookup_rows(), index_definition()), before)
        conn = sqlite3.connect(db.DB_PATH)
        count = conn.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='index' AND name=?", (db.LOOKUP_UNIQUE_INDEX_NAME,)).fetchone()[0]
        conn.close()
        self.assertEqual(count, 1)
        with db.db_connection() as conn:
            self.assertEqual(db.ensure_lookup_unique_index(conn), "exists")

    def test_a_raw_sql_duplicate_is_rejected_once_migrated(self):
        self.insert_raw("status", "Alpha")
        for variant in ("Alpha", "alpha", "ALPHA"):
            with self.assertRaises(sqlite3.IntegrityError):
                self.insert_raw("status", variant)
        self.insert_raw("office", "Alpha")                               # a different lookup type is fine
        self.assertEqual(len(lookup_rows()), 2)

    def test_an_index_that_already_exists_is_detected_and_left_alone(self):
        self.drop_index()
        self.raw(f"CREATE INDEX {db.LOOKUP_UNIQUE_INDEX_NAME} ON lookup_tables(id)")    # someone's own, different definition
        before = index_definition()
        with db.db_connection() as conn:
            self.assertEqual(db.ensure_lookup_unique_index(conn), "exists")
        db.init_db()
        self.assertEqual(index_definition(), before)
        self.assertNotIn("UNIQUE", before.upper())


class PreExistingDuplicatesTests(TempDbTestCase):
    def make_duplicates(self):
        self.drop_index()
        for table, value in (("status", "Alpha"), ("status", "alpha"), ("status", "ALPHA"), ("office", "Alpha"), ("sales_office", "Solo")):
            self.insert_raw(table, value, mapped="SECRET-MAPPED-" + value.strip())
        return lookup_rows()

    def test_startup_still_works_logs_a_warning_keeps_every_row_and_skips_the_index(self):
        rows_before = self.make_duplicates()
        with self.assertLogs("db", level="WARNING") as logs:
            db.init_db()                                                    # must not raise
        self.assertEqual(lookup_rows(), rows_before, "nothing deleted, merged or modified")
        self.assertIsNone(index_definition(), "the index is not created")
        warning = "\n".join(logs.output)
        self.assertIn(db.LOOKUP_UNIQUE_INDEX_NAME, warning)
        self.assertIn("NOT created", warning)
        self.assertIn("'status'", warning)                                  # the affected table
        self.assertIn("ids 1,2,3", warning)                                 # the affected rows
        self.assertNotIn("SECRET-MAPPED", warning, "mapped data is not written to the log")
        self.assertNotIn("'sales_office'", warning, "only the offending groups are named")

    def test_the_return_value_reports_the_skip(self):
        self.make_duplicates()
        with db.db_connection() as conn, self.assertLogs("db", level="WARNING"):
            self.assertEqual(db.ensure_lookup_unique_index(conn), "skipped_duplicates")

    def test_the_apps_own_duplicate_check_keeps_working_without_the_index(self):
        self.make_duplicates()
        with self.assertLogs("db", level="WARNING"):
            db.init_db()
        self.assertEqual(self.add("alpha"), ADD_MSG.format("alpha"))
        self.assertEqual(self.add("Gamma"), "added")

    def test_once_the_duplicates_are_removed_the_next_start_creates_the_index(self):
        self.make_duplicates()
        with self.assertLogs("db", level="WARNING"):
            db.init_db()
        self.raw("DELETE FROM lookup_tables WHERE id IN (2, 3)")
        db.init_db()
        self.assertIsNotNone(index_definition())

    def test_the_same_value_in_different_lookup_tables_is_not_a_duplicate(self):
        self.drop_index()
        self.insert_raw("status", "Same")
        self.insert_raw("office", "Same")
        self.insert_raw("sales_office", "SAME")
        db.init_db()
        self.assertIsNotNone(index_definition())

    def test_a_duplicate_written_between_the_check_and_the_create_is_survived(self):
        self.drop_index()
        self.insert_raw("status", "Alpha")
        self.insert_raw("status", "alpha")
        with mock.patch.object(db, "find_duplicate_lookups", return_value=[]):      # the check "missed" them
            with self.assertLogs("db", level="WARNING") as logs:
                db.init_db()                                                         # IntegrityError inside: caught
        self.assertIn("could not be created", "\n".join(logs.output))
        self.assertIsNone(index_definition())
        self.assertEqual(len(lookup_rows()), 2)

    def test_an_unsupported_runtime_is_logged_and_the_app_continues(self):
        self.drop_index()
        with mock.patch.object(db, "LOOKUP_UNIQUE_INDEX_SQL", "CREATE UNIQUE INDEX x ON no_such_table(a)"):
            with self.assertLogs("db", level="WARNING") as logs:
                db.init_db()                                                         # OperationalError inside: caught
        self.assertIn("could not be created", "\n".join(logs.output))
        self.assertIsNone(index_definition())

    def test_the_real_application_import_survives_a_database_with_duplicates(self):
        """End to end: `import app` (which runs init_db at startup) against a
        database that already contains duplicates exits cleanly."""
        self.make_duplicates()
        env = dict(os.environ, FULL_PASSWORD="a", ADMISSIONS_PASSWORD="b", CONSULTANTS_PASSWORD="c", MARKETING_PASSWORD="d", FLASK_SECRET_KEY="k")
        code = (
            "import sys; sys.path.insert(0, %r); import db; from pathlib import Path; db.DB_PATH = Path(%r); "
            "import app; print('started')" % (str(ROOT), str(db.DB_PATH))
        )
        done = subprocess.run([sys.executable, "-c", code], env=env, capture_output=True, text=True, timeout=60)
        self.assertEqual(done.returncode, 0, done.stderr[-800:])
        self.assertIn("started", done.stdout)
        self.assertIn("NOT created", done.stderr)
        self.assertEqual(len(lookup_rows()), 5)
        self.assertIsNone(index_definition())

    def test_the_migration_code_can_never_modify_lookup_rows(self):
        import ast
        import inspect
        for func in (db.ensure_lookup_unique_index, db.find_duplicate_lookups):
            tree = ast.parse(inspect.getsource(func))
            function = tree.body[0]
            if ast.get_docstring(function) is not None:
                function.body = function.body[1:]                              # the docstring is prose, not SQL
            strings = [n.value.upper() for n in ast.walk(function) if isinstance(n, ast.Constant) and isinstance(n.value, str)]
            for word in ("DELETE", "UPDATE LOOKUP", "INSERT INTO"):
                self.assertFalse([s for s in strings if word in s], f"{func.__name__} contains {word}")


# =========================================================================
# 2. Normal behaviour is unchanged
# =========================================================================
class NormalBehaviourTests(TempDbTestCase):
    def test_a_unique_add_succeeds(self):
        self.assertEqual(self.add("Alpha"), "added")
        self.assertEqual(self.add("Beta"), "added")
        self.assertEqual([r[2] for r in lookup_rows()], ["Alpha", "Beta"])

    def test_an_ordinary_duplicate_add_keeps_the_same_message(self):
        self.add("Alpha")
        for variant in ("Alpha", "alpha", "ALPHA", "  Alpha  ", "\tAlpha\n", "Alpha "):
            with self.subTest(value=variant):
                self.assertEqual(self.add(variant), ADD_MSG.format(variant.strip()))
        self.assertEqual(len(lookup_rows()), 1)

    def test_an_ordinary_duplicate_edit_keeps_the_same_message(self):
        self.add("Alpha")
        self.add("Beta")
        self.assertEqual(self.edit(self.row_id("Beta"), "alpha"), EDIT_MSG.format("alpha"))
        self.assertEqual([r[2] for r in lookup_rows()], ["Alpha", "Beta"])

    def test_the_precheck_still_runs_first_so_ordinary_duplicates_never_reach_sqlite(self):
        self.add("Alpha")
        with mock.patch.object(lookups, "_violates_unique_index") as unused:
            self.assertEqual(self.add("Alpha"), ADD_MSG.format("Alpha"))
        unused.assert_not_called()

    def test_the_same_value_in_another_lookup_type_is_allowed(self):
        self.assertEqual(self.add("Same"), "added")
        self.assertEqual(self.add("Same", table="office"), "added")
        self.assertEqual(self.add("SAME", table="sales_office"), "added")
        self.assertEqual(self.add("same"), ADD_MSG.format("same"), "but not twice in the same type")

    def test_editing_a_row_to_its_own_current_value_works(self):
        self.add("Alpha")
        rid = self.row_id("Alpha")
        for value in ("Alpha", "ALPHA", "alpha", "  Alpha  "):
            with self.subTest(value=value):
                self.assertEqual(self.edit(rid, value), "updated")
        self.assertEqual(lookup_rows()[0][2], "Alpha")

    def test_editing_a_row_to_a_free_value_works(self):
        self.add("Alpha")
        self.assertEqual(self.edit(self.row_id("Alpha"), "Omega"), "updated")
        self.assertEqual(self.add("Alpha"), "added", "the old value is free again")

    def test_whitespace_is_still_trimmed_and_internal_spaces_still_matter(self):
        self.assertEqual(self.add("  Padded  "), "added")
        self.assertEqual(lookup_rows()[0][2], "Padded")
        self.assertEqual(self.add("Pad ded"), "added")

    def test_blank_values_still_give_the_required_message(self):
        for blank in ("", "   ", "\t\n"):
            self.assertEqual(self.add(blank), "invalid: Source / Lookup Value is required.")

    def test_an_exact_non_ascii_repeat_is_now_refused_safely(self):
        """The old check let an exact repeat of "E-acute-cole" through
        (SQLite's lower() leaves the capital E-acute alone, Python's does not)."""
        self.assertEqual(self.add("École"), "added")
        message = self.add("École")
        self.assertEqual(message, ADD_MSG.format("École"))
        for word in INTERNAL_WORDS:
            self.assertNotIn(word, message)
        self.assertEqual(len(lookup_rows()), 1)

    def test_a_non_ascii_edit_to_an_exact_repeat_is_refused_safely(self):
        self.add("École")
        self.add("Other")
        self.assertEqual(self.edit(self.row_id("Other"), "École"), EDIT_MSG.format("École"))
        self.assertEqual([r[2] for r in lookup_rows()], ["École", "Other"])

    def test_non_ascii_case_variants_keep_their_documented_behaviour(self):
        self.assertEqual(self.add("École"), "added")
        self.assertEqual(self.add("école"), "added", "not recognised as a duplicate - as before")
        self.assertEqual(self.add("ÉCOLE"), ADD_MSG.format("ÉCOLE"), "matches the stored lower-case row via the app's check - as before")
        self.assertEqual(self.add("ecole"), "added")
        self.assertEqual(self.add("ECOLE"), ADD_MSG.format("ECOLE"), "ASCII case-insensitivity unchanged")

    def test_intake_count_validation_is_unchanged(self):
        with db.db_connection() as conn:
            with self.assertRaises(LookupValidationError) as caught:
                add_lookup(conn, "sales_office", "X", "m", NOW, intake_01_count="abc")
            self.assertEqual(str(caught.exception), "Intake 01 must be a whole number.")
            with self.assertRaises(LookupValidationError) as caught:
                add_lookup(conn, "sales_office", "X", "m", NOW, intake_02_count=str(2**63))
            self.assertEqual(str(caught.exception), "Intake 02 is too large.")

    def test_lookup_seeding_never_hits_the_index(self):
        """Seeding de-duplicates with Python's lower(); whatever it accepts the
        index must accept too (SQLite-equal implies Python-equal)."""
        import processing
        from tests.test_upload_atomicity import book, row
        import openpyxl
        data = book([row(**{"Student Code": "P", "Student Name": "N"})], lookups={
            "status": [("Alpha", "1"), ("alpha", "2"), ("ALPHA", "3"), ("École", "4"), ("école", "5"), ("ÉCOLE", "6"), ("Beta", "7")],
            "office": [("Alpha", "8")],
        })
        path = self.tmp / "seed.xlsx"
        path.write_bytes(data)
        with db.db_connection() as conn:
            workbook = openpyxl.load_workbook(path, data_only=True)
            processing.seed_lookup_tables_if_empty(conn, workbook, NOW)       # must not raise IntegrityError
            conn.commit()
        self.assertEqual([r[2] for r in lookup_rows(table="status")], ["Alpha", "École", "Beta"])
        self.assertEqual([r[2] for r in lookup_rows(table="office")], ["Alpha"])


# =========================================================================
# 3. Translation of the race loser, and of nothing else
# =========================================================================
class TranslationTests(TempDbTestCase):
    def stale_check(self):
        """Make the application's pre-check say "no duplicate" (as it does for
        the loser of a race) so the write reaches the database."""
        return mock.patch.object(lookups, "_has_duplicate", return_value=False)

    def test_a_stale_precheck_add_is_refused_by_the_database_and_reported_as_the_ordinary_duplicate(self):
        self.add("Alpha")
        with self.stale_check():
            self.assertEqual(self.add("alpha"), ADD_MSG.format("alpha"))
        self.assertEqual(len(lookup_rows()), 1)

    def test_a_stale_precheck_edit_is_refused_by_the_database_and_reported_as_the_ordinary_duplicate(self):
        self.add("Alpha")
        self.add("Beta")
        with self.stale_check():
            self.assertEqual(self.edit(self.row_id("Beta"), "ALPHA"), EDIT_MSG.format("ALPHA"))
        self.assertEqual([r[2] for r in lookup_rows()], ["Alpha", "Beta"])

    def test_the_loser_is_rolled_back_explicitly_and_leaves_no_open_transaction(self):
        self.add("Alpha")
        self.tracker.reset()
        conn = db.get_connection()
        try:
            with self.stale_check():
                with self.assertRaises(DuplicateLookupError):
                    add_lookup(conn, "status", "ALPHA", "m", NOW)
            self.assertFalse(conn.in_transaction, "the failed write was rolled back before raising")
            self.assertGreaterEqual(conn.rollback_calls, 1)
        finally:
            conn.close()
        self.assertEqual(self.tracker.leaked(), [])

    def test_the_edit_loser_is_rolled_back_explicitly_too(self):
        self.add("Alpha")
        self.add("Beta")
        conn = db.get_connection()
        try:
            with self.stale_check():
                with self.assertRaises(DuplicateLookupError):
                    update_lookup(conn, self.row_id("Beta"), "status", "alpha", "m")
            self.assertFalse(conn.in_transaction)
            self.assertGreaterEqual(conn.rollback_calls, 1)
        finally:
            conn.close()

    def test_the_translated_error_carries_no_sqlite_wording_and_hides_its_cause(self):
        self.add("Alpha")
        with self.stale_check():
            with db.db_connection() as conn:
                with self.assertRaises(DuplicateLookupError) as caught:
                    add_lookup(conn, "status", "alpha", "m", NOW)
        for word in INTERNAL_WORDS:
            self.assertNotIn(word, str(caught.exception))
        self.assertIsNone(caught.exception.__cause__)
        self.assertTrue(caught.exception.__suppress_context__, "the SQLite error is not chained into the user-facing one")

    def test_an_unrelated_integrity_error_is_not_translated_on_add(self):
        self.raw("CREATE TRIGGER boom BEFORE INSERT ON lookup_tables WHEN NEW.source_value = 'Boom' BEGIN SELECT RAISE(ABORT, 'secret internal detail'); END")
        with db.db_connection() as conn:
            with self.assertRaises(sqlite3.IntegrityError) as caught:
                add_lookup(conn, "status", "Boom", "m", NOW)
        self.assertNotIsInstance(caught.exception, DuplicateLookupError)
        self.assertIn("secret internal detail", str(caught.exception), "the ORIGINAL error propagates untouched")
        self.assertEqual(lookup_rows(), [])

    def test_an_unrelated_integrity_error_is_not_translated_on_edit(self):
        self.add("Alpha")
        self.raw("CREATE TRIGGER boom BEFORE UPDATE ON lookup_tables WHEN NEW.source_value = 'Boom' BEGIN SELECT RAISE(ABORT, 'secret internal detail'); END")
        with db.db_connection() as conn:
            with self.assertRaises(sqlite3.IntegrityError) as caught:
                update_lookup(conn, self.row_id("Alpha"), "status", "Boom", "m")
        self.assertNotIsInstance(caught.exception, DuplicateLookupError)
        self.assertEqual([r[2] for r in lookup_rows()], ["Alpha"])

    def test_an_integrity_error_is_not_a_duplicate_just_because_a_duplicate_exists_elsewhere(self):
        """A different value fails for an unrelated reason while a row with
        another value exists: still not translated."""
        self.add("Alpha")
        self.raw("CREATE TRIGGER boom BEFORE INSERT ON lookup_tables WHEN NEW.source_value = 'Other' BEGIN SELECT RAISE(ABORT, 'x'); END")
        with db.db_connection() as conn:
            with self.assertRaises(sqlite3.IntegrityError):
                add_lookup(conn, "status", "Other", "m", NOW)


# =========================================================================
# 4. Races
# =========================================================================
class PreCheckGate:
    """Each racing thread's FIRST duplicate check waits at a barrier after it
    has run, so both threads pass the check before either one writes - the
    exact interleaving that used to create duplicates."""

    def __init__(self, parties=2, timeout=5):
        self.barrier = threading.Barrier(parties, timeout=timeout)
        self.real = lookups._has_duplicate
        self.seen = set()
        self.lock = threading.Lock()

    def __call__(self, *args, **kwargs):
        result = self.real(*args, **kwargs)
        with self.lock:
            first = threading.get_ident() not in self.seen
            self.seen.add(threading.get_ident())
        if first:
            self.barrier.wait()
        return result


def run_concurrently(fns):
    results = [None] * len(fns)

    def runner(i, fn):
        try:
            results[i] = fn()
        except BaseException as exc:                                    # a leaked exception is a test failure
            results[i] = f"EXC {type(exc).__name__}: {exc}"

    threads = [threading.Thread(target=runner, args=(i, fn)) for i, fn in enumerate(fns)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    return results


class RaceTests(TempDbTestCase):
    def test_two_concurrent_adds_of_the_same_mapping(self):
        with mock.patch.object(lookups, "_has_duplicate", PreCheckGate()):
            results = run_concurrently([lambda: self.add("Racer"), lambda: self.add("Racer")])
        self.assertIn("added", results)
        winner_rows = [(1, "status", "Racer", "m")]
        self.assertEqual(lookup_rows(), winner_rows)
        loser = [r for r in results if r != "added"]
        self.assertEqual(loser, [ADD_MSG.format("Racer")])
        self.assertEqual(self.tracker.leaked(), [])
        self.assert_database_is_writable_immediately()
        self.assertEqual(self.add("Subsequent"), "added")

    def test_two_concurrent_adds_differing_only_in_case(self):
        with mock.patch.object(lookups, "_has_duplicate", PreCheckGate()):
            results = run_concurrently([lambda: self.add("Racer"), lambda: self.add("RACER")])
        self.assertEqual(results.count("added"), 1)
        loser = [r for r in results if r != "added"]
        self.assertEqual(len(loser), 1)
        self.assertIn(loser[0], (ADD_MSG.format("Racer"), ADD_MSG.format("RACER")))
        self.assertEqual(len(lookup_rows()), 1)
        self.assertEqual(self.tracker.leaked(), [])

    def test_two_concurrent_edits_to_the_same_target_value(self):
        self.add("One")
        self.add("Two")
        ids = [r[0] for r in lookup_rows()]
        with mock.patch.object(lookups, "_has_duplicate", PreCheckGate()):
            results = run_concurrently([lambda: self.edit(ids[0], "Same"), lambda: self.edit(ids[1], "Same")])
        self.assertEqual(results.count("updated"), 1)
        self.assertEqual([r for r in results if r != "updated"], [EDIT_MSG.format("Same")])
        values = [r[2] for r in lookup_rows()]
        self.assertEqual(values.count("Same"), 1, f"exactly one row holds the target value: {values}")
        self.assertEqual(len(values), 2)
        self.assertEqual(self.tracker.leaked(), [])
        self.assert_database_is_writable_immediately()
        self.assertEqual(self.add("Subsequent"), "added")

    def test_a_concurrent_add_and_edit_to_the_same_target_value(self):
        self.add("Existing")
        existing = lookup_rows()[0][0]
        with mock.patch.object(lookups, "_has_duplicate", PreCheckGate()):
            results = run_concurrently([lambda: self.add("Clash"), lambda: self.edit(existing, "Clash")])
        values = [r[2] for r in lookup_rows()]
        self.assertEqual(values.count("Clash"), 1, f"exactly one row holds the target value: {values}")
        self.assertEqual(len([r for r in results if r in ("added", "updated")]), 1)
        loser = [r for r in results if r not in ("added", "updated")]
        self.assertEqual(len(loser), 1)
        self.assertIn(loser[0], (ADD_MSG.format("Clash"), EDIT_MSG.format("Clash")))
        for word in INTERNAL_WORDS:
            self.assertNotIn(word, loser[0])
        self.assertEqual(self.tracker.leaked(), [])
        self.assert_database_is_writable_immediately()

    def test_a_concurrent_non_ascii_exact_repeat(self):
        with mock.patch.object(lookups, "_has_duplicate", PreCheckGate()):
            results = run_concurrently([lambda: self.add("École"), lambda: self.add("École")])
        self.assertEqual(results.count("added"), 1)
        self.assertEqual([r for r in results if r != "added"], [ADD_MSG.format("École")])
        self.assertEqual(len(lookup_rows()), 1)

    def test_a_natural_eight_thread_race_over_many_rounds(self):
        rounds = 120
        for n in range(rounds):
            start = threading.Barrier(8)
            value = f"value-{n}"

            def go(value=value, start=start):
                start.wait()
                return self.add(value)

            results = run_concurrently([go] * 8)
            self.assertEqual(results.count("added"), 1, f"round {n}: {results}")
            self.assertEqual({r for r in results if r != "added"}, {ADD_MSG.format(value)}, f"round {n}: {results}")
        conn = sqlite3.connect(db.DB_PATH)
        duplicates = conn.execute("SELECT COUNT(*) FROM (SELECT 1 FROM lookup_tables GROUP BY table_name, lower(source_value) HAVING COUNT(*) > 1)").fetchone()[0]
        total = conn.execute("SELECT COUNT(*) FROM lookup_tables").fetchone()[0]
        conn.close()
        self.assertEqual(duplicates, 0)
        self.assertEqual(total, rounds, "exactly one row per round")
        self.assertEqual(self.tracker.leaked(), [])
        self.assert_database_is_writable_immediately()
        self.assertEqual(self.add("Subsequent"), "added")


# =========================================================================
# 5. Through the real routes (messages, redirects, no 500, no leaks)
# =========================================================================
class LookupRouteTests(IsolatedAppTestCase):
    def setUp(self):
        super().setUp()
        self.tracker = ConnectionTracker(db_module)
        self.tracker.install()
        self.addCleanup(self.tracker.uninstall)
        self.addCleanup(self.tracker.force_close_leaks)
        self.client = self._client_logged_in_as("full")
        self.token = extract_token(self.client.get("/login").get_data(as_text=True))
        self.tracker.reset()

    def post(self, path, **data):
        return self.client.post(path, data={"csrf_token": self.token, **data})

    def flashes(self, response):
        page = self.client.get(response.headers["Location"]).get_data(as_text=True)
        return [(k, html.unescape(v)) for k, v in re.findall(r'class="flash (\w+)">([^<]+)<', page)]

    def setup_add(self, value, mapped="x"):
        """An add whose result we do not care about - and whose pending flash
        message is consumed so it cannot pile up in the session."""
        response = self.post("/admin/lookups/status/add", source_value=value, mapped_value=mapped)
        self.flashes(response)
        return response

    def rows(self):
        return lookup_rows(db_module.DB_PATH)

    def production(self):
        patcher = mock.patch.dict(app_module.app.config, {"TESTING": False, "PROPAGATE_EXCEPTIONS": False})
        patcher.start()
        logging.disable(logging.CRITICAL)
        self.addCleanup(patcher.stop)
        self.addCleanup(logging.disable, logging.NOTSET)

    def assert_no_internal_wording(self, response):
        text = " ".join(t for _, t in self.flashes(response)) if response.status_code == 302 else response.get_data(as_text=True)
        for word in INTERNAL_WORDS:
            self.assertNotIn(word, text)

    def test_ordinary_duplicate_add_and_edit_keep_their_messages_and_redirects(self):
        first = self.post("/admin/lookups/status/add", source_value="Alpha", mapped_value="x")
        self.assertEqual(self.flashes(first), [("success", "Mapping added.")])
        response = self.post("/admin/lookups/status/add", source_value="ALPHA", mapped_value="x")
        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.headers["Location"].endswith("/admin?tab=status"))
        self.assertEqual(self.flashes(response), [("error", ADD_MSG.format("ALPHA"))])
        self.setup_add("Beta")
        beta = [r[0] for r in self.rows() if r[2] == "Beta"][0]
        response = self.post(f"/admin/lookups/status/{beta}/edit", source_value="alpha", mapped_value="x")
        self.assertEqual(self.flashes(response), [("error", EDIT_MSG.format("alpha"))])
        self.assertEqual([r[2] for r in self.rows()], ["Alpha", "Beta"])

    def test_the_race_loser_through_the_add_route_gets_the_friendly_message(self):
        self.setup_add("Alpha")
        self.tracker.reset()
        with mock.patch.object(lookups, "_has_duplicate", return_value=False):          # the loser's stale pre-check
            response = self.post("/admin/lookups/status/add", source_value="alpha", mapped_value="x")
        self.assertEqual(response.status_code, 302, "no 500")
        self.assertTrue(response.headers["Location"].endswith("/admin?tab=status"))
        self.assertEqual(self.flashes(response), [("error", ADD_MSG.format("alpha"))])
        self.assert_no_internal_wording(response)
        self.assertEqual([r[2] for r in self.rows()], ["Alpha"])
        self.assertEqual(self.tracker.leaked(), [])

    def test_the_race_loser_through_the_edit_route_gets_the_friendly_message(self):
        self.setup_add("Alpha")
        self.setup_add("Beta")
        beta = [r[0] for r in self.rows() if r[2] == "Beta"][0]
        self.tracker.reset()
        with mock.patch.object(lookups, "_has_duplicate", return_value=False):
            response = self.post(f"/admin/lookups/status/{beta}/edit", source_value="ALPHA", mapped_value="x")
        self.assertEqual(response.status_code, 302)
        self.assertEqual(self.flashes(response), [("error", EDIT_MSG.format("ALPHA"))])
        self.assert_no_internal_wording(response)
        self.assertEqual([r[2] for r in self.rows()], ["Alpha", "Beta"])
        self.assertEqual(self.tracker.leaked(), [])

    def test_an_exact_non_ascii_repeat_is_refused_with_the_friendly_message(self):
        self.setup_add("École")
        response = self.post("/admin/lookups/status/add", source_value="École", mapped_value="x")
        self.assertEqual(response.status_code, 302)
        self.assertEqual(self.flashes(response), [("error", ADD_MSG.format("École"))])
        self.assert_no_internal_wording(response)
        self.assertEqual(len(self.rows()), 1)

    def test_an_unrelated_integrity_error_follows_the_normal_safe_error_handling(self):
        self.production()
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute("CREATE TRIGGER boom BEFORE INSERT ON lookup_tables WHEN NEW.source_value = 'Boom' BEGIN SELECT RAISE(ABORT, 'secret internal detail'); END")
        conn.commit()
        conn.close()
        self.tracker.reset()
        response = self.post("/admin/lookups/status/add", source_value="Boom", mapped_value="x")
        self.assertEqual(response.status_code, 500, "an unexpected error stays an unexpected error")
        body = response.get_data(as_text=True)
        for leaked in ("secret internal detail", "IntegrityError", "already exists", "UNIQUE", "Traceback", "sqlite"):
            self.assertNotIn(leaked, body)
        self.assertEqual(self.rows(), [])
        self.assertEqual(self.tracker.leaked(), [])

    def test_authorization_and_csrf_are_unaffected(self):
        viewer = self._client_logged_in_as("consultants")
        token = extract_token(viewer.get("/login").get_data(as_text=True))
        self.assertEqual(viewer.post("/admin/lookups/status/add", data={"csrf_token": token, "source_value": "X"}).status_code, 403)
        self.assertEqual(self.client.post("/admin/lookups/status/add", data={"source_value": "X"}).status_code, 400)
        self.assertEqual(self.rows(), [])


if __name__ == "__main__":
    unittest.main()
