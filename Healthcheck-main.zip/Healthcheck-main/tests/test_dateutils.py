import unittest
from datetime import date, datetime, timezone
from unittest import mock

from dateutils import safe_date, today_uk


class SafeDateTests(unittest.TestCase):
    def test_valid_iso_string(self):
        self.assertEqual(safe_date("2026-08-13"), date(2026, 8, 13))

    def test_date_object_passthrough(self):
        self.assertEqual(safe_date(date(2026, 8, 13)), date(2026, 8, 13))

    def test_datetime_object_is_reduced_to_date(self):
        self.assertEqual(safe_date(datetime(2026, 8, 13, 14, 30, 0)), date(2026, 8, 13))

    def test_none_is_none(self):
        self.assertIsNone(safe_date(None))

    def test_blank_string_is_none(self):
        self.assertIsNone(safe_date(""))

    def test_whitespace_only_string_is_none(self):
        self.assertIsNone(safe_date("   "))

    def test_malformed_string_is_none(self):
        self.assertIsNone(safe_date("not-a-date"))

    def test_wrong_format_string_is_none(self):
        # dd/mm/yyyy is not ISO format and must not be silently misread.
        self.assertIsNone(safe_date("13/08/2026"))

    def test_impossible_calendar_date_is_none(self):
        self.assertIsNone(safe_date("2026-02-30"))

    def test_unsupported_type_is_none(self):
        # An int/float slipping through (e.g. a raw Excel serial number)
        # must never raise - it's simply not a recognised shape.
        self.assertIsNone(safe_date(20260813))

    def test_healthcheck_cutoff_boundary_date_parses(self):
        # healthcheck.DATE_COMPLETENESS_CUTOFF is date(2026, 7, 31) - the
        # exact boundary date several rules compare against must parse
        # cleanly as a stored ISO string.
        self.assertEqual(safe_date("2026-07-31"), date(2026, 7, 31))

    def test_leap_day_parses(self):
        self.assertEqual(safe_date("2024-02-29"), date(2024, 2, 29))


class TodayUkTests(unittest.TestCase):
    """today_uk() must be BST/GMT-aware, not just a UTC passthrough - the
    server runs in UTC (gunicorn), so a naive date.today() disagrees with
    the UK calendar day for up to an hour every day during BST."""

    def test_bst_summer_evening_utc_is_already_next_day_in_uk(self):
        # 23:30 UTC on 24 Aug 2026 is 00:30 BST (UTC+1) on 25 Aug - a
        # different calendar day than the UTC instant's own date.
        fixed_now = datetime(2026, 8, 24, 23, 30, tzinfo=timezone.utc)
        with mock.patch("dateutils.datetime") as mock_dt:
            mock_dt.now.return_value = fixed_now
            self.assertEqual(today_uk(), date(2026, 8, 25))

    def test_gmt_winter_matches_the_utc_date(self):
        # In GMT (UTC+0, winter), UK local time and UTC agree.
        fixed_now = datetime(2026, 1, 15, 10, 0, tzinfo=timezone.utc)
        with mock.patch("dateutils.datetime") as mock_dt:
            mock_dt.now.return_value = fixed_now
            self.assertEqual(today_uk(), date(2026, 1, 15))

    def test_returns_a_plain_date_not_a_datetime(self):
        fixed_now = datetime(2026, 6, 1, 12, 0, tzinfo=timezone.utc)
        with mock.patch("dateutils.datetime") as mock_dt:
            mock_dt.now.return_value = fixed_now
            result = today_uk()
            self.assertIs(type(result), date)


if __name__ == "__main__":
    unittest.main()
