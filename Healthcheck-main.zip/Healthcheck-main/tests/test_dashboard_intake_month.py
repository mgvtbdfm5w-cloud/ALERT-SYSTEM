"""Application Manager Pipeline page: a third tab row below the year and the Intake 01/02/03
tabs - the Intake month. Choosing one narrows everything on the page (cards, both charts, the
Offer Days, the pop-up windows and the download) to applications of that Intake month."""

import io
import unittest

import openpyxl

from tests.flask_test_support import IsolatedAppTestCase
from tests.test_bonus import PageBase, app, d, workbook_rows

ROWS = [
    app("M1", sub=d(5), Intake="March 2027"),
    app("M2", sub=None, Intake="March 2027"),
    app("M3", sub=d(60), accepted=d(20), status="09-Enrolled", Intake="March 2027"),
    app("A1", sub=d(25), Intake="May 2027"),
    app("S1", sub=d(5), Intake="September 2027"),
    app("S2", sub=d(70), accepted=d(30), status="09-Enrolled", Intake="September 2027"),
    app("Y1", sub=d(5), Intake="October 2026"),
]


class IntakeMonthBase(PageBase):
    ROWS = workbook_rows(ROWS)

    def health(self, context):
        return {seg["key"]: seg["count"] for g in context["pending_stage_chart_groups"] for row in g["rows"] for seg in row["segments"]}

    def codes(self, path, query, group="pending_assessment"):
        data = self.full.get(f"{path}?{query}&manager=Alice&group={group}").get_json()
        return sorted(r["code"] for r in data["records"])


class TabsTests(IntakeMonthBase):
    def tabs(self, query):
        html, context = self.dashboard_page(query)
        return html, context, [(o["value"], o["label"]) for o in context["intake_month_options"]]

    def test_a_year_lists_the_intake_months_it_has_in_calendar_order(self):
        html, context, options = self.tabs("year=2027")
        self.assertEqual(options, [(3, "March"), (5, "May"), (9, "September")])
        self.assertIsNone(context["selected_intake_month"])
        tabs = html[html.index("tabs-months"):]
        tabs = tabs[:tabs.index("</div>")]
        self.assertEqual([t.split(">")[1].split("<")[0] for t in tabs.split("<a ")[1:]], ["All months", "March", "May", "September"])
        self.assertIn('class="tab-link active">All months', tabs)

    def test_an_intake_tab_narrows_the_months_to_its_own(self):
        _, _, options = self.tabs("year=2027&intake=intake_01")
        self.assertEqual(options, [(3, "March")])
        _, _, options = self.tabs("year=2027&intake=intake_03")
        self.assertEqual(options, [(9, "September")])

    def test_2026_has_the_month_row_too_straight_under_the_year(self):
        html, context, options = self.tabs("year=2026")
        self.assertEqual(options, [(10, "October")])
        self.assertIn("tabs-months", html)

    def test_the_links_keep_the_year_and_intake_and_the_chosen_month_is_highlighted(self):
        html, context, _ = self.tabs("year=2027&intake=intake_03&intake_month=9")
        self.assertEqual(context["selected_intake_month"], 9)
        month_row = html[html.index("tabs-months"):]
        month_row = month_row[:month_row.index("</div>")]
        self.assertRegex(month_row, r'href="/dashboard\?year=2027&amp;intake_month=9&amp;intake=intake_03"\s+class="tab-link active">September')
        self.assertRegex(month_row, r'href="/dashboard\?year=2027&amp;intake=intake_03"\s+class="tab-link">All months')

    def test_the_year_and_intake_tabs_clear_the_month(self):
        html, _, _ = self.tabs("year=2027&intake_month=3")
        self.assertIn('<a href="/dashboard?year=2027&amp;intake=intake_01"', html)
        self.assertNotIn('year=2027&amp;intake=intake_01&amp;intake_month', html)
        self.assertNotIn('<a href="/dashboard?year=2026&amp;intake_month', html)

    def test_a_month_that_is_not_there_or_not_valid_is_ignored(self):
        for query in ("year=2027&intake_month=7", "year=2027&intake_month=x", "year=2027&intake_month=13", "year=2027&intake_month=",
                      "year=2027&intake=intake_02&intake_month=3"):
            _, context, _ = self.tabs(query)
            self.assertIsNone(context["selected_intake_month"], query)

    def test_the_tab_row_is_only_there_when_a_year_has_months_to_pick(self):
        html, _, options = self.tabs("year=2027")
        self.assertTrue(options)
        self.assertIn("tabs-months", html)


class NoMonthsTests(PageBase):
    ROWS = workbook_rows([app("Z1", sub=d(5), Intake="2027")])           # an Intake with a year but no month

    def test_no_month_row_when_no_intake_has_a_month(self):
        html, context = self.dashboard_page("year=2027")
        self.assertEqual(context["intake_month_options"], [])
        self.assertNotIn("tabs-months", html)


class FilterTests(IntakeMonthBase):
    def test_every_month_is_the_whole_year_as_before(self):
        _, context = self.dashboard_page("year=2027")
        self.assertEqual(self.health(context)["pending_assessment"], 4)
        self.assertEqual(self.codes("/dashboard/records", "year=2027"), ["A1", "M1", "M2", "S1"])

    def test_a_month_narrows_the_health_chart_the_cards_and_the_list(self):
        _, context = self.dashboard_page("year=2027&intake_month=3")
        self.assertEqual(self.codes("/dashboard/records", "year=2027&intake_month=3"), ["M1", "M2"])
        self.assertEqual(self.codes("/dashboard/records", "year=2027&intake_month=3", "enrolled_this_intake"), ["M3"])
        overall = next(c for c in context["am_summary_cards"] if c["label"] == "Overall")
        self.assertEqual(overall["total"], 3)
        self.assertEqual(self.health(context)["pending_assessment"], 2)

    def test_the_month_works_inside_an_intake_tab(self):
        self.assertEqual(self.codes("/dashboard/records", "year=2027&intake=intake_03&intake_month=9"), ["S1"])
        self.assertEqual(self.codes("/dashboard/records", "year=2027&intake=intake_03"), ["S1"])
        self.assertEqual(self.codes("/dashboard/records", "year=2027&intake=intake_02&intake_month=3"), ["A1"])      # not in that intake: ignored

    def test_the_offer_days_follow_the_month(self):
        def assessment_average(query):
            _, context = self.dashboard_page(query)
            return context["manager_average_offer_days"]["Alice"]["pending_assessment"]
        self.assertEqual(assessment_average("year=2027&intake_month=3"), 5)
        self.assertEqual(assessment_average("year=2027&intake_month=5"), 25)
        self.assertGreater(assessment_average("year=2027"), 5)

    def test_the_download_follows_the_month_and_says_so_in_its_name(self):
        html, _ = self.dashboard_page("year=2027&intake=intake_01&intake_month=3")
        self.assertIn("/dashboard/export?year=2027&amp;intake=intake_01&amp;intake_month=3", html)
        response = self.full.get("/dashboard/export?year=2027&intake=intake_01&intake_month=3")
        self.assertEqual(response.status_code, 200)
        self.assertIn("Application_Manager_Pipeline_2027_Intake01_March_", response.headers["Content-Disposition"])
        response = self.full.get("/dashboard/export?year=2027")
        self.assertNotIn("March", response.headers["Content-Disposition"])

    def test_the_other_pipeline_pages_ignore_an_intake_month(self):
        plain = self.full.get("/dashboard/just-jon?year=2027").get_data(as_text=True)
        with_month = self.full.get("/dashboard/just-jon?year=2027&intake_month=3").get_data(as_text=True)
        self.assertEqual(plain.count("chart-segment-clickable"), with_month.count("chart-segment-clickable"))
        self.assertNotIn("tabs-months", with_month)
        self.assertNotIn("tabs-months", self.full.get("/university-pipeline?year=2027").get_data(as_text=True))


class ExportContentTests(PageBase):
    ROWS = workbook_rows([app("M4", sub=d(45), Intake="March 2027"), app("S3", sub=d(45), Intake="September 2027")])    # both over 30 days old

    def codes_in_download(self, query):
        response = self.full.get("/dashboard/export?" + query)
        self.assertEqual(response.status_code, 200)
        workbook = openpyxl.load_workbook(io.BytesIO(response.data))
        return {c for ws in workbook for r in ws.iter_rows(values_only=True) for c in r if c in ("M4", "S3")}

    def test_the_download_holds_just_the_chosen_months_applications(self):
        self.assertEqual(self.codes_in_download("year=2027&intake_month=3"), {"M4"})
        self.assertEqual(self.codes_in_download("year=2027&intake_month=9"), {"S3"})
        self.assertEqual(self.codes_in_download("year=2027"), {"M4", "S3"})


class ExportFilenameTests(unittest.TestCase):
    def test_the_month_comes_after_the_intake(self):
        from datetime import date
        from application_manager_export import export_filename
        today = date(2026, 11, 1)
        self.assertEqual(export_filename(today, 2027, "Intake 01", "March"), "Application_Manager_Pipeline_2027_Intake01_March_01-11-2026.xlsx")
        self.assertEqual(export_filename(today, 2027, None, "March"), "Application_Manager_Pipeline_2027_March_01-11-2026.xlsx")
        self.assertEqual(export_filename(today, 2027, "Intake 01"), "Application_Manager_Pipeline_2027_Intake01_01-11-2026.xlsx")


if __name__ == "__main__":
    unittest.main()
