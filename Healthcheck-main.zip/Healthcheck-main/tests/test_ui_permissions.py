"""UI permission tests: the Admin page and navigation only RENDER the
controls the current role is allowed to use.

This is a presentation layer on top of the server-side policy in
authorization.py - it is NOT the security boundary. Hiding a control never
authorizes or denies anything; test_authorization.py still proves that the
server returns 403 for a denied URL or POST, and the DirectAccessStillDenied
class below re-checks that a role whose controls are hidden is still
refused (even with a valid CSRF token) if it crafts the request by hand.

Hidden means ABSENT from the rendered HTML (no disabled/greyed-out
control, no link that leads to a 403), so every assertion here is a
substring check against the response body.

Uses the shared isolated Flask test infrastructure (temp database/uploads,
disposable credentials, CSRFProtect never disabled). Nothing here touches
the real data/app.db or uploads/ folder.
"""

import json
import re
import sqlite3
import unittest

from authorization import ALLOW, ENDPOINT_ROLES, KNOWN_ROLES, authorize
from kpi import COMPANY_TARGET_TYPE, set_kpi_target
from pipeline import seed_forecast_settings_if_empty
from tests.flask_test_support import (
    IsolatedAppTestCase,
    app_module,
    db_module,
    extract_token,
)

# Controls each restricted capability renders on /admin, as unique
# substrings of the rendered HTML.
APPLICATIONS_UPLOAD = ['action="/upload"', "Application Data Upload"]
APPLICATIONS_DOWNLOAD = ['href="/download"']
LEADS_UPLOAD = ['action="/leads/upload"', "Leads Data Upload"]
LEADS_DOWNLOAD = ['href="/leads/download"']
REPROCESS = ['action="/admin/reprocess"', "Reprocess Current Data"]
LOOKUP_ADD = ["/admin/lookups/status/add", "Add New Mapping", "Add Mapping"]
LOOKUP_EDIT = ["/admin/lookups/status/{id}/edit", 'onclick="toggleEdit(', 'class="edit-cell"', "edit-form-"]
LOOKUP_DELETE = ["/admin/lookups/status/{id}/delete", "Delete"]
LOOKUP_ACTIONS_HEADER = ["<th>Actions</th>"]
FORECAST_CONTROLS = ["/admin/forecast-settings/", 'name="forecast_percent"']
KPI_CONTROLS = ["/admin/kpi-targets/", 'name="target_value"']

# Always rendered for every role: the allowed navigation/exports, and the
# READ-ONLY views of the configuration tables.
ALLOWED_FOR_ALL = [
    'href="/company-dashboard"',
    'href="/admin"',
    'href="/todo"',
    'action="/logout"',  # Logout is a POST form, not a link (see test_logout.py)
    'href="/interviews"',
    'href="/offer-days"',
    'href="/lost-reasons"',
    'href="/university-report"',
    'href="/university-pipeline"',
    'href="/dashboard/just-jon"',
    'href="/consultants"',
    'href="/enrolled/export/current-intake"',
    "Lookup Tables",
    "Pipeline Forecast Settings",
    "KPI Monthly Targets",
]

NON_EDITORS = ("admissions", "consultants", "marketing")
VIEWERS = ("consultants", "marketing")


class AdminUITestCase(IsolatedAppTestCase):
    """Seeds one Applications dataset (with a QA Passed date so the KPI
    target editor renders), one Leads dataset, one lookup row and the
    Forecast settings, so every restricted control would render if the
    role were allowed to see it."""

    def setUp(self):
        super().setUp()
        rows = [{"Student Code": "PES-UI-1", "QA Passed": "2026-08-10", "Sales Office": "Test Office"}]
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.row_factory = sqlite3.Row
        conn.execute(
            "INSERT INTO active_dataset (original_filename, stored_filename, uploaded_at, row_count, data_json) "
            "VALUES ('a.xlsx', '20260101000000_a.xlsx', '2026-01-01T00:00:00', 1, ?)",
            (json.dumps(rows),),
        )
        conn.execute(
            "INSERT INTO active_leads_dataset "
            "(original_filename, stored_filename, uploaded_at, row_count, columns_json, data_json) "
            "VALUES ('l.xlsx', 'leads_20260101000000_l.xlsx', '2026-01-01T00:00:00', 0, '[]', '[]')"
        )
        conn.execute(
            "INSERT INTO lookup_tables (table_name, source_value, mapped_value, created_at) "
            "VALUES ('status', 'A', 'B', '2026-01-01T00:00:00')"
        )
        seed_forecast_settings_if_empty(conn)
        set_kpi_target(conn, 2026, 8, COMPANY_TARGET_TYPE, "4321")
        conn.commit()
        conn.close()
        self.lookup_id = self._query("SELECT id FROM lookup_tables")[0]["id"]

    def _admin_html(self, role):
        resp = self._client_logged_in_as(role).get("/admin")
        self.assertEqual(resp.status_code, 200)
        return resp.get_data(as_text=True)

    def _fragments(self, fragments):
        return [f.replace("{id}", str(self.lookup_id)) for f in fragments]

    def assertPresent(self, html, fragments, role):
        for fragment in self._fragments(fragments):
            self.assertIn(fragment, html, f"{role} should see {fragment!r}")

    def assertAbsent(self, html, fragments, role):
        for fragment in self._fragments(fragments):
            self.assertNotIn(fragment, html, f"{role} must not see {fragment!r}")


class FullSeesEverythingTests(AdminUITestCase):
    def test_full_sees_every_restricted_control(self):
        html = self._admin_html("full")
        for group in (
            APPLICATIONS_UPLOAD, APPLICATIONS_DOWNLOAD, LEADS_UPLOAD, LEADS_DOWNLOAD, REPROCESS,
            LOOKUP_ADD, LOOKUP_EDIT, LOOKUP_DELETE, LOOKUP_ACTIONS_HEADER, FORECAST_CONTROLS, KPI_CONTROLS,
        ):
            self.assertPresent(html, group, "full")

    def test_full_sees_all_allowed_navigation(self):
        self.assertPresent(self._admin_html("full"), ALLOWED_FOR_ALL, "full")


class AdmissionsUITests(AdminUITestCase):
    def setUp(self):
        super().setUp()
        self.html = self._admin_html("admissions")

    def test_sees_uploads_full_downloads_and_reprocess(self):
        for group in (APPLICATIONS_UPLOAD, APPLICATIONS_DOWNLOAD, LEADS_UPLOAD, LEADS_DOWNLOAD, REPROCESS):
            self.assertPresent(self.html, group, "admissions")

    def test_does_not_see_lookup_controls(self):
        for group in (LOOKUP_ADD, LOOKUP_EDIT, LOOKUP_DELETE, LOOKUP_ACTIONS_HEADER):
            self.assertAbsent(self.html, group, "admissions")

    def test_does_not_see_forecast_or_kpi_controls(self):
        self.assertAbsent(self.html, FORECAST_CONTROLS + KPI_CONTROLS, "admissions")

    def test_still_sees_all_navigation_and_read_only_config_views(self):
        self.assertPresent(self.html, ALLOWED_FOR_ALL, "admissions")


class ViewerUITests(AdminUITestCase):
    """Consultants and Marketing: identical UI permissions."""

    def test_do_not_see_uploads_full_downloads_or_reprocess(self):
        for role in VIEWERS:
            html = self._admin_html(role)
            for group in (
                APPLICATIONS_UPLOAD, APPLICATIONS_DOWNLOAD, LEADS_UPLOAD, LEADS_DOWNLOAD, REPROCESS
            ):
                self.assertAbsent(html, group, role)

    def test_do_not_see_any_config_controls(self):
        for role in VIEWERS:
            html = self._admin_html(role)
            for group in (
                LOOKUP_ADD, LOOKUP_EDIT, LOOKUP_DELETE, LOOKUP_ACTIONS_HEADER, FORECAST_CONTROLS, KPI_CONTROLS,
            ):
                self.assertAbsent(html, group, role)

    def test_still_see_all_allowed_navigation_exports_and_read_only_views(self):
        for role in VIEWERS:
            self.assertPresent(self._admin_html(role), ALLOWED_FOR_ALL, role)

    def test_see_the_same_admin_page_as_each_other(self):
        def normalised(html):
            # The nav's Logout form carries a per-session CSRF token, which
            # legitimately differs between two sessions.
            return re.sub(r'name="csrf_token" value="[^"]+"', 'name="csrf_token" value="TOKEN"', html)

        self.assertEqual(
            normalised(self._admin_html("consultants")),
            normalised(self._admin_html("marketing")).replace("Marketing", "Consultants"),
        )

    def test_read_only_tables_still_show_their_values(self):
        cleanpct = app_module.app.jinja_env.filters["cleanpct"]
        forecast = self._query("SELECT stage, forecast_percent FROM forecast_settings")
        self.assertTrue(forecast)
        for role in VIEWERS:
            html = self._admin_html(role)
            self.assertIn(">A<", html, role)  # lookup source value
            self.assertIn(">B<", html, role)  # lookup mapped value
            for row in forecast:  # every Forecast stage AND its percentage
                self.assertIn(f"<td>{row['stage']}</td>", html, role)
                self.assertIn(f"{cleanpct(row['forecast_percent'])}%", html, role)
            self.assertIn("Company Total", html, role)  # KPI target row...
            self.assertRegex(html, r"<td>\s*4321\s*</td>", role)  # ...and its stored value

    def test_read_only_tables_are_the_same_data_and_structure_full_sees(self):
        """Hiding controls leaves the underlying values/rows identical:
        every value a Full user sees in those tables is also visible
        read-only (compared with all tags and controls stripped)."""
        def visible_text(html, heading_start, heading_end):
            chunk = html[html.index(heading_start):html.index(heading_end)]
            chunk = re.sub(r"<form.*?</form>", "", chunk, flags=re.S)
            chunk = re.sub(r"<script.*?</script>", "", chunk, flags=re.S)
            chunk = re.sub(r"<[^>]+>", " ", chunk)
            return re.sub(r"\s+", " ", chunk)

        full = self._admin_html("full")
        viewer = self._admin_html("consultants")
        for start, end in (("Pipeline Forecast Settings", "KPI Monthly Targets"), ("KPI Monthly Targets", "<script>")):
            full_text = visible_text(full, start, end)
            viewer_text = visible_text(viewer, start, end)
            for token in re.findall(r"\d+(?:\.\d+)?%|\b\d{3,}\b|\d\d-\w+", full_text):
                self.assertIn(token, viewer_text, token)


class NoWeeklyReportOnAdminTests(AdminUITestCase):
    """The Weekly Report panel and its download button are no longer on the Admin page."""

    def test_no_role_sees_a_weekly_report_panel_or_button(self):
        for role in ("full", "admissions", "consultants", "marketing"):
            html = self._admin_html(role)
            for text in ("Weekly Report", "Download Weekly Report", 'href="/admin/weekly-report"', "branded PDF"):
                self.assertNotIn(text, html, (role, text))

    def test_the_neighbouring_admin_panels_are_still_there(self):
        html = self._admin_html("full")
        for text in ("<h2>Pages</h2>", "Enrolled - Current Intake Export", "Reprocess Current Data", "Lookup Tables"):
            self.assertIn(text, html)


class EditGuidanceWordingTests(AdminUITestCase):
    """The "Controls the ... Changes apply immediately" guidance only
    appears for roles that can actually change those values."""

    EDIT_GUIDANCE = ["Changes apply immediately", "Controls the Forecast %", "Controls the Sales Office"]
    READ_ONLY_GUIDANCE = ["The Forecast % used by the Application Manager Pipeline dashboard for each stage.",
                          "The Sales Office, Consultant, and Company Total targets used by the KPI page"]

    def test_full_sees_the_edit_guidance_and_controls(self):
        html = self._admin_html("full")
        self.assertPresent(html, self.EDIT_GUIDANCE, "full")
        self.assertAbsent(html, self.READ_ONLY_GUIDANCE, "full")
        self.assertPresent(html, FORECAST_CONTROLS + KPI_CONTROLS, "full")

    def test_admissions_and_viewers_see_read_only_wording_not_edit_guidance(self):
        for role in NON_EDITORS:
            html = self._admin_html(role)
            self.assertAbsent(html, self.EDIT_GUIDANCE, role)
            self.assertPresent(html, self.READ_ONLY_GUIDANCE, role)
            for word in ("re-upload", "reprocessing required"):
                self.assertNotIn(word, html.lower(), (role, word))

    def test_admissions_keeps_upload_controls_but_no_config_edit_controls(self):
        html = self._admin_html("admissions")
        self.assertPresent(html, APPLICATIONS_UPLOAD + LEADS_UPLOAD + REPROCESS, "admissions")
        self.assertAbsent(html, LOOKUP_ADD + LOOKUP_EDIT + LOOKUP_DELETE + FORECAST_CONTROLS + KPI_CONTROLS, "admissions")


class UploadWordingTests(IsolatedAppTestCase):
    """With NO dataset loaded, only a role that can upload is told to
    upload; everyone else gets neutral wording (no instruction they cannot
    follow)."""

    UPLOAD_INSTRUCTION = re.compile(r"upload a workbook", re.I)
    PAGES = ["/company-dashboard", "/dashboard", "/kpi", "/todo", "/interviews", "/university-pipeline",
             "/dashboard/just-jon", "/consultants", "/enrolled", "/university-report", "/offer-days",
             "/lost-reasons", "/submissions", "/doc-check", "/leads-dashboard", "/admin"]

    def _html(self, role, path):
        resp = self._client_logged_in_as(role).get(path)
        self.assertEqual(resp.status_code, 200, (role, path))
        return resp.get_data(as_text=True)

    def test_uploaders_keep_the_existing_upload_wording(self):
        for role in ("full", "admissions"):
            admin = self._html(role, "/admin")
            self.assertEqual(admin.count("Upload a workbook first to generate a report."), 1, role)   # the Enrolled export panel
            self.assertIn("No QA Passed dates found in Current Data yet. Upload a workbook first.", admin)
            self.assertIn("No active dataset yet. Upload a workbook on the Admin page first.",
                          self._html(role, "/company-dashboard"))
            self.assertIn("No active Leads dataset yet. Upload a workbook on the Leads page first.",
                          self._html(role, "/leads-dashboard"))

    def test_viewers_are_never_told_to_upload_on_any_page(self):
        for role in VIEWERS:
            for path in self.PAGES:
                self.assertNotRegex(self._html(role, path), self.UPLOAD_INSTRUCTION, (role, path))

    def test_viewers_get_neutral_wording_instead(self):
        for role in VIEWERS:
            admin = self._html(role, "/admin")
            self.assertEqual(admin.count("No data is currently available."), 1, role)   # the Enrolled export panel
            self.assertIn("No QA Passed dates found in Current Data yet.</p>", admin)
            self.assertIn('class="placeholder">No active dataset yet.</p>', self._html(role, "/company-dashboard"))
            self.assertIn('class="placeholder">No active Leads dataset yet.</p>', self._html(role, "/leads-dashboard"))

    def test_with_a_dataset_loaded_no_role_sees_the_placeholders(self):
        # Sanity check that the wording above is genuinely the empty-state
        # message and not always-on text.
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute(
            "INSERT INTO active_dataset (original_filename, stored_filename, uploaded_at, row_count, data_json) "
            "VALUES ('a.xlsx', '20260101000000_a.xlsx', '2026-01-01T00:00:00', 0, '[]')"
        )
        conn.commit()
        conn.close()
        for role in KNOWN_ROLES:
            admin = self._html(role, "/admin")
            self.assertNotIn("No data is currently available.", admin, role)
            self.assertNotIn("Upload a workbook first to generate a report.", admin, role)


class HiddenMeansAbsentTests(AdminUITestCase):
    """No disabled/greyed-out stand-ins: a restricted role's page has no
    `disabled` attribute, and no empty heading left behind for a hidden
    section."""

    def test_no_disabled_controls_or_leftover_headings_for_viewers(self):
        for role in VIEWERS:
            html = self._admin_html(role)
            self.assertNotIn("disabled", html, role)
            self.assertNotIn("<h3>", html, role)  # "Add New Mapping" heading removed with its form
            for heading in ("Application Data Upload", "Leads Data Upload", "Reprocess Current Data"):
                self.assertNotIn(heading, html, f"{role}: empty section {heading!r} left behind")

    def test_no_empty_panel_blocks_for_any_role(self):
        for role in KNOWN_ROLES:
            html = self._admin_html(role)
            self.assertNotRegex(html, r'<section class="panel">\s*</section>', role)


class NavigationUITests(AdminUITestCase):
    def test_every_role_sees_the_main_navigation_on_other_pages_too(self):
        for role in KNOWN_ROLES:
            client = self._client_logged_in_as(role)
            for path in ("/company-dashboard", "/kpi", "/leads-dashboard"):
                html = client.get(path).get_data(as_text=True)
                for link in ("/company-dashboard", "/admin", "/todo"):
                    self.assertIn(f'href="{link}"', html, (role, path, link))
                self.assertIn('action="/logout"', html, (role, path))

    def test_no_nav_or_page_template_links_to_a_restricted_endpoint_for_viewers(self):
        """Across every page, a Consultant/Marketing session is never
        offered a link or form pointing at an endpoint it would be 403'd
        on."""
        denied_urls = ["/download", "/leads/download", "/upload", "/leads/upload", "/admin/reprocess",
                       "/admin/lookups/", "/admin/forecast-settings/", "/admin/kpi-targets/"]
        pages = ["/company-dashboard", "/admin", "/todo", "/interviews", "/dashboard", "/kpi", "/enrolled",
                 "/university-pipeline", "/university-report", "/offer-days", "/lost-reasons", "/submissions",
                 "/doc-check", "/leads-dashboard", "/dashboard/just-jon", "/consultants"]
        for role in VIEWERS:
            client = self._client_logged_in_as(role)
            for path in pages:
                html = client.get(path).get_data(as_text=True)
                for url in denied_urls:
                    self.assertNotIn(f'"{url}', html, (role, path, url))


class CanHelperTests(AdminUITestCase):
    """The Jinja helper is a thin view over authorization.authorize() - it
    adds no role lists of its own."""

    def _render(self, endpoint, **session_values):
        with app_module.app.test_request_context("/admin"):
            from flask import render_template_string, session

            session.update(session_values)
            return render_template_string("{{ 'yes' if can(endpoint) else 'no' }}", endpoint=endpoint) == "yes"

    def test_can_agrees_with_authorize_for_every_endpoint_and_role(self):
        for endpoint in ENDPOINT_ROLES:
            for role in KNOWN_ROLES:
                expected = authorize(endpoint, True, role) == ALLOW
                self.assertEqual(self._render(endpoint, logged_in=True, role=role), expected, (endpoint, role))

    def test_can_is_false_when_logged_out_for_unknown_roles_and_for_unlisted_endpoints(self):
        self.assertFalse(self._render("kpi"))
        self.assertFalse(self._render("kpi", logged_in=True, role="unknown-role"))
        self.assertFalse(self._render("kpi", logged_in=True))
        self.assertFalse(self._render("not_a_real_endpoint", logged_in=True, role="full"))


class DirectAccessStillDenied(AdminUITestCase):
    """Hiding is cosmetic: a role whose control is hidden still gets 403
    from the server if it requests the URL or POSTs by hand, even with a
    valid CSRF token."""

    def test_denied_urls_and_posts_still_return_403(self):
        for role in VIEWERS:
            client = self._client_logged_in_as(role)
            token = extract_token(client.get("/login").get_data(as_text=True))
            self.assertEqual(client.get("/download").status_code, 403, role)
            self.assertEqual(client.get("/leads/download").status_code, 403, role)
            self.assertEqual(client.post("/admin/reprocess", data={"csrf_token": token}).status_code, 403, role)
            self.assertEqual(
                client.post("/admin/lookups/status/add", data={"source_value": "x", "csrf_token": token}).status_code,
                403, role,
            )
            self.assertEqual(
                client.post(f"/admin/lookups/status/{self.lookup_id}/delete", data={"csrf_token": token}).status_code,
                403, role,
            )
        admissions = self._client_logged_in_as("admissions")
        token = extract_token(admissions.get("/login").get_data(as_text=True))
        self.assertEqual(
            admissions.post(
                "/admin/forecast-settings/02-PendingQA", data={"forecast_percent": "42", "csrf_token": token}
            ).status_code,
            403,
        )
        self.assertEqual(self._query("SELECT COUNT(*) AS n FROM lookup_tables")[0]["n"], 1)


if __name__ == "__main__":
    unittest.main()
