"""The Consultant filter on the Leads dashboard, next to the Month filter.

Leads are uploaded through the real route into the isolated temp database."""

import io
import re
import unittest
from contextlib import contextmanager

import openpyxl
from flask import template_rendered

from leads import REQUIRED_LEADS_SOURCE_COLUMNS
from tests.flask_test_support import IsolatedAppTestCase, app_module, extract_token


def leads_book(rows):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Leads"
    ws.append(REQUIRED_LEADS_SOURCE_COLUMNS)
    for r in rows:
        full = {c: "" for c in REQUIRED_LEADS_SOURCE_COLUMNS}
        full.update(r)
        ws.append([full[c] for c in REQUIRED_LEADS_SOURCE_COLUMNS])
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def lead(code, consultant, created, status="New Lead", source="Paid Ad/Google"):
    return {"Student Id": code, "Name": code, "Counsellor": consultant, "Creation Date": created,
            "Lead Status": status, "Lead Source": source}


LEADS = [
    # August: Mel 4 (1 applied, 1 enrolled), Hannah 2, Jon 1 (flagged Group as Other), blank 1
    lead("M1", "Mel Smith", "03/08/2026"), lead("M2", "Mel Smith", "04/08/2026", "Applied"),
    lead("M3", "mel Smith", "05/08/2026", "Enrolled Student", "Agent/X"), lead("M4", "Mel", "06/08/2026", source="Agent/Y"),
    lead("H1", "Hannah Lee", "03/08/2026"), lead("H2", "Hannah Lee", "04/08/2026", "Applied"),
    lead("J1", "Jon Daniels", "05/08/2026"),
    lead("B1", "", "06/08/2026"),
    # September: Mel 1, Hannah 3
    lead("M5", "Mel Smith", "02/09/2026"),
    lead("H3", "Hannah Lee", "02/09/2026"), lead("H4", "Hannah Lee", "03/09/2026"), lead("H5", "Hannah Lee", "04/09/2026"),
]


@contextmanager
def captured():
    rendered = []

    def record(sender, template, context, **extra):
        rendered.append((template.name, dict(context)))

    template_rendered.connect(record, app_module.app)
    try:
        yield rendered
    finally:
        template_rendered.disconnect(record, app_module.app)


class LeadsConsultantFilterTests(IsolatedAppTestCase):
    def setUp(self):
        super().setUp()
        self.full = self._client_logged_in_as("full")
        token = extract_token(self.full.get("/login").get_data(as_text=True))
        r = self.full.post("/leads/upload", data={"csrf_token": token, "excel_file": (io.BytesIO(leads_book(LEADS)), "l.xlsx")},
                           content_type="multipart/form-data")
        self.assertEqual(r.status_code, 302)

    def page(self, query="?month=2026-08", client=None):
        with captured() as rendered:
            r = (client or self.full).get("/leads-dashboard" + query)
        self.assertEqual(r.status_code, 200)
        context = next(c for name, c in rendered if name == "leads_dashboard.html")
        return r.get_data(as_text=True), context

    def flag_group_as_other(self, name):
        token = extract_token(self.full.get("/login").get_data(as_text=True))
        r = self.full.post("/admin/lookups/sales_office/add", data={
            "csrf_token": token, "source_value": name, "mapped_value": "OXF", "group_as_other": "on"})
        self.assertEqual(r.status_code, 302)

    # ------------------------------------------------------------- the control
    def test_the_consultant_filter_sits_next_to_the_month_filter_in_the_same_form(self):
        html, _ = self.page()
        start = html.index('<form method="GET" action="/leads-dashboard"')
        form = html[start:html.index("</form>", start)]
        self.assertLess(form.index('id="month"'), form.index('id="consultant"'))
        self.assertIn('<label for="consultant">Consultant</label>', form)
        self.assertIn('<select name="consultant" id="consultant"', form)
        self.assertIn('<label for="month">Month</label>', form)
        self.assertIn(">All consultants</option>", form)

    def test_the_options_are_the_consultants_in_the_leads_data_a_to_z_without_blanks(self):
        _, context = self.page()
        self.assertEqual(context["consultant_names"], ["Hannah", "Jon", "Mel"])

    def test_default_is_everyone(self):
        html, context = self.page()
        self.assertIsNone(context["selected_consultant"])
        self.assertEqual(context["month_summary"]["total"], 8)            # every August lead, blank consultant included
        self.assertRegex(html, r'<option value="" selected>All consultants</option>')

    # --------------------------------------------------------------- filtering
    def test_choosing_a_consultant_limits_everything_on_the_page_to_their_leads(self):
        html, context = self.page("?month=2026-08&consultant=Mel")
        s = context["month_summary"]
        self.assertEqual((s["total"], s["prospecting"], s["applications"], s["enrolled"]), (4, 2, 2, 1))
        text = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html))
        self.assertIn("Total Uploaded This Month Leads 4", text)
        self.assertRegex(html, r'<option value="Mel" selected>')
        self.assertRegex(re.sub(r"\s+", " ", html), r"August 2026 &mdash; Mel &mdash; data as of")

    def test_another_consultants_leads_never_leak_in(self):
        _, mel = self.page("?month=2026-08&consultant=Mel")
        _, hannah = self.page("?month=2026-08&consultant=Hannah")
        self.assertEqual(mel["month_summary"]["total"] + hannah["month_summary"]["total"] + 1 + 1, 8)   # + Jon + the blank one
        self.assertEqual((hannah["month_summary"]["total"], hannah["month_summary"]["applications"], hannah["month_summary"]["enrolled"]), (2, 1, 0))

    def test_the_source_chart_is_only_that_consultants(self):
        _, context = self.page("?month=2026-08&consultant=Mel")
        names = [g["source"] for g in context["report"]["source_groups"]]
        self.assertEqual(sorted(names), ["Agent", "Paid Ad"])
        _, hannah = self.page("?month=2026-08&consultant=Hannah")
        self.assertEqual([g["source"] for g in hannah["report"]["source_groups"]], ["Paid Ad"])

    def test_month_and_consultant_combine_and_each_can_change_without_losing_the_other(self):
        _, sep_mel = self.page("?month=2026-09&consultant=Mel")
        self.assertEqual(sep_mel["month_summary"]["total"], 1)
        _, sep_hannah = self.page("?month=2026-09&consultant=Hannah")
        self.assertEqual(sep_hannah["month_summary"]["total"], 3)
        html, _ = self.page("?month=2026-09&consultant=Hannah")
        self.assertIn('<option value="2026-09" selected>', html)
        self.assertRegex(html, r'<option value="Hannah" selected>')

    def test_the_consultant_name_is_matched_ignoring_case_and_spaces(self):
        for value in ("mel", "MEL", "%20Mel%20"):
            _, context = self.page(f"?month=2026-08&consultant={value}")
            self.assertEqual(context["selected_consultant"], "Mel", value)
            self.assertEqual(context["month_summary"]["total"], 4, value)

    def test_the_same_person_spelled_differently_is_one_consultant(self):
        # "Mel Smith", "mel Smith" and "Mel" are all Mel
        _, context = self.page("?month=2026-08&consultant=Mel")
        self.assertEqual(context["month_summary"]["total"], 4)

    def test_a_consultant_with_no_leads_that_month_gets_a_friendly_empty_state(self):
        html, context = self.page("?month=2026-09&consultant=Jon")      # Jon only has an August lead
        self.assertEqual(context["selected_consultant"], "Jon")
        self.assertIn("No Leads found for this month and consultant.", html)
        self.assertNotIn("Traceback", html)

    def test_without_a_consultant_the_empty_wording_is_unchanged(self):
        # a month that exists but has no leads cannot happen here, so check the unfiltered wording is not the filtered one
        html, _ = self.page("?month=2026-08")
        self.assertNotIn("and consultant", html)

    # ---------------------------------------------------- bad / hidden values
    def test_unknown_or_hostile_values_mean_everyone_and_are_never_echoed(self):
        for value in ("Nobody", "", "%3Cscript%3Ealert(1)%3C%2Fscript%3E", "%27%20OR%201%3D1", "Mel%00", "%E2%80%AE"):
            html, context = self.page(f"?month=2026-08&consultant={value}")
            self.assertIsNone(context["selected_consultant"], value)
            self.assertEqual(context["month_summary"]["total"], 8, value)
            self.assertNotIn("<script>alert(1)</script>", html)
            self.assertNotIn("OR 1=1", html)

    def test_a_consultant_set_to_group_as_other_is_not_offered_and_typing_them_means_everyone(self):
        self.flag_group_as_other("Jon")
        html, context = self.page("?month=2026-08&consultant=Jon")
        self.assertEqual(context["consultant_names"], ["Hannah", "Mel"])
        self.assertNotIn('<option value="Jon"', html)
        self.assertIsNone(context["selected_consultant"])
        self.assertEqual(context["month_summary"]["total"], 8, "their leads still count in 'All consultants'")

    def test_a_consultant_with_no_admin_row_is_still_offered(self):
        _, context = self.page()
        self.assertIn("Mel", context["consultant_names"])           # no Consultant lookup rows exist at all in this test database

    # ----------------------------------------------------- the rest of the page
    def test_the_enrolled_box_follows_the_filter(self):
        html, context = self.page("?month=2026-08&consultant=Mel")
        text = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html))
        self.assertIn("Leads enrolled 1", text)
        self.assertIn("% of Total 25.0%", text)                      # 1 of Mel's 4 leads

    def test_the_paid_ads_link_is_unaffected(self):
        html, _ = self.page("?month=2026-08&consultant=Mel")
        self.assertIn('href="/paid-ads"', html)

    def test_every_role_can_use_the_filter(self):
        for role in ("full", "admissions", "consultants", "marketing"):
            client = self._client_logged_in_as(role)
            _, context = self.page("?month=2026-08&consultant=Hannah", client)
            self.assertEqual(context["month_summary"]["total"], 2, role)

    def test_login_is_still_required(self):
        r = app_module.app.test_client().get("/leads-dashboard?consultant=Mel")
        self.assertEqual(r.status_code, 302)
        self.assertIn("/login", r.headers["Location"])


if __name__ == "__main__":
    unittest.main()
