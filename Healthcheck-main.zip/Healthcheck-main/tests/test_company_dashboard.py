import unittest
from datetime import date

from company_dashboard import (
    MONTH_TILE_TARGETS,
    PENDING_ASSESSMENT_STAGES,
    PENDING_ENROLMENT_STAGES,
    PENDING_OFFER_STAGES,
    PENDING_TILES_INTAKE_BUCKET,
    PENDING_TILES_INTAKE_YEAR,
    build_enrolled_by_office,
    build_month_scoped_tiles,
    build_pipeline_stage_tiles,
    classify_month_tile,
    count_enrolled_this_calendar_year,
    count_enrolled_this_intake,
    list_available_months,
    month_progress,
)

# A row whose Intake falls inside Intake 03 2026 (July-December 2026) -
# the fixed window build_pipeline_stage_tiles() scopes itself to (see
# PENDING_TILES_INTAKE_YEAR/PENDING_TILES_INTAKE_BUCKET).
IN_SCOPE_INTAKE = "September 2026"


class ListAvailableMonthsTests(unittest.TestCase):
    def test_union_across_all_four_date_fields(self):
        rows = [
            {"Docs Approved": "2026-08-01"},
            {"QA Passed": "2026-07-15"},
            {"Submitted To Uni": "2026-06-10"},
        ]
        leads_rows = [{"Creation Date": "2026-05-01"}]
        months = list_available_months(rows, leads_rows)
        self.assertEqual(set(months), {(2026, 8), (2026, 7), (2026, 6), (2026, 5)})

    def test_sorted_newest_first(self):
        rows = [{"QA Passed": "2026-06-01"}, {"QA Passed": "2026-08-01"}]
        months = list_available_months(rows, [])
        self.assertEqual(months, [(2026, 8), (2026, 6)])

    def test_a_month_shared_by_multiple_fields_is_not_duplicated(self):
        rows = [{"Docs Approved": "2026-08-01"}, {"QA Passed": "2026-08-15"}]
        months = list_available_months(rows, [])
        self.assertEqual(months, [(2026, 8)])

    def test_empty_input_gives_empty_list(self):
        self.assertEqual(list_available_months([], []), [])


class BuildMonthScopedTilesTests(unittest.TestCase):
    def test_leads_generated_counts_leads_created_that_month(self):
        leads_rows = [
            {"Creation Date": "2026-08-01"},
            {"Creation Date": "2026-08-15"},
            {"Creation Date": "2026-07-01"},  # different month
        ]
        tiles = build_month_scoped_tiles([], leads_rows, 2026, 8)
        self.assertEqual(tiles["leads_generated"], 2)

    def test_docs_approved_counts_rows_with_docs_approved_that_month(self):
        rows = [
            {"Docs Approved": "2026-08-01", "QA": "Raneen"},
            {"Docs Approved": "2026-08-15", "QA": "Mustapha"},
            {"Docs Approved": "2026-07-01", "QA": "Raneen"},
        ]
        tiles = build_month_scoped_tiles(rows, [], 2026, 8)
        self.assertEqual(tiles["docs_approved"], 2)

    def test_submitted_to_uni_counts_rows_with_submitted_date_that_month(self):
        rows = [
            {"Submitted To Uni": "2026-08-01", "Support": "Raneen"},
            {"Submitted To Uni": "2026-08-15", "Support": ""},
        ]
        tiles = build_month_scoped_tiles(rows, [], 2026, 8)
        self.assertEqual(tiles["submitted_to_uni"], 2)

    def test_qa_passed_counts_distinct_student_codes_that_month(self):
        rows = [
            {"Student Code": "PES1", "QA Passed": "2026-08-01", "Consultant": "Raneen", "Sales Office": "OXF"},
            {"Student Code": "PES1", "QA Passed": "2026-08-05", "Consultant": "Raneen", "Sales Office": "OXF"},
            {"Student Code": "PES2", "QA Passed": "2026-08-10", "Consultant": "Mo", "Sales Office": "CAR"},
        ]
        tiles = build_month_scoped_tiles(rows, [], 2026, 8)
        self.assertEqual(tiles["qa_passed"], 2)  # PES1 counted once despite 2 qualifying rows

    def test_tiles_are_independent_of_each_other(self):
        rows = [{"Docs Approved": "2026-08-01"}]
        leads_rows = [{"Creation Date": "2026-08-01"}]
        tiles = build_month_scoped_tiles(rows, leads_rows, 2026, 8)
        self.assertEqual(tiles["docs_approved"], 1)
        self.assertEqual(tiles["leads_generated"], 1)
        self.assertEqual(tiles["qa_passed"], 0)
        self.assertEqual(tiles["submitted_to_uni"], 0)


class BuildPipelineStageTilesTests(unittest.TestCase):
    """The 3 live pipeline-progress tiles - Pending Assessment/Offer/
    Enrolment - each a fixed group of Statuses, scoped to Intake 03 2026
    (July-December 2026) only."""

    def _row(self, status, intake=IN_SCOPE_INTAKE):
        return {"Status": status, "Intake": intake}

    def test_stage_groups_are_as_specified(self):
        self.assertEqual(PENDING_ASSESSMENT_STAGES, ("04-Onboarding", "05-Assessment"))
        self.assertEqual(PENDING_OFFER_STAGES, ("06-Decision",))
        self.assertEqual(PENDING_ENROLMENT_STAGES, ("07-Ready", "08-Pre-Enrolled"))

    def test_scope_is_intake_03_2026(self):
        self.assertEqual(PENDING_TILES_INTAKE_YEAR, 2026)
        self.assertEqual(PENDING_TILES_INTAKE_BUCKET, "intake_03")

    def test_pending_assessment_combines_onboarding_and_assessment(self):
        rows = [self._row("04-Onboarding"), self._row("05-Assessment"), self._row("05-Assessment")]
        tiles = build_pipeline_stage_tiles(rows)
        self.assertEqual(tiles["pending_assessment"], 3)
        self.assertEqual(tiles["pending_offer"], 0)
        self.assertEqual(tiles["pending_enrolment"], 0)

    def test_pending_offer_is_decision_only(self):
        rows = [self._row("06-Decision"), self._row("06-Decision")]
        tiles = build_pipeline_stage_tiles(rows)
        self.assertEqual(tiles["pending_offer"], 2)
        self.assertEqual(tiles["pending_assessment"], 0)
        self.assertEqual(tiles["pending_enrolment"], 0)

    def test_pending_enrolment_combines_ready_and_pre_enrolled(self):
        rows = [self._row("07-Ready"), self._row("08-Pre-Enrolled")]
        tiles = build_pipeline_stage_tiles(rows)
        self.assertEqual(tiles["pending_enrolment"], 2)
        self.assertEqual(tiles["pending_assessment"], 0)
        self.assertEqual(tiles["pending_offer"], 0)

    def test_stages_outside_the_3_groups_are_not_counted_anywhere(self):
        rows = [
            self._row("01-NewApp"),
            self._row("02-PendingQA"),
            self._row("03-PendingSubmission"),
            self._row("09-Enrolled"),
            self._row("10-Lost"),
            self._row("00-QARejected"),
            self._row("11-Deferred"),
        ]
        tiles = build_pipeline_stage_tiles(rows)
        self.assertEqual(tiles["pending_assessment"], 0)
        self.assertEqual(tiles["pending_offer"], 0)
        self.assertEqual(tiles["pending_enrolment"], 0)

    def test_a_mixed_pipeline(self):
        rows = (
            [self._row("04-Onboarding")] * 2
            + [self._row("05-Assessment")] * 3
            + [self._row("06-Decision")] * 1
            + [self._row("07-Ready")] * 4
            + [self._row("08-Pre-Enrolled")] * 2
        )
        tiles = build_pipeline_stage_tiles(rows)
        self.assertEqual(tiles["pending_assessment"], 5)
        self.assertEqual(tiles["pending_offer"], 1)
        self.assertEqual(tiles["pending_enrolment"], 6)

    def test_empty_input_gives_all_zero_counts(self):
        tiles = build_pipeline_stage_tiles([])
        self.assertEqual(tiles["pending_assessment"], 0)
        self.assertEqual(tiles["pending_offer"], 0)
        self.assertEqual(tiles["pending_enrolment"], 0)
        self.assertIsNone(tiles["pending_assessment_average_days"])
        self.assertIsNone(tiles["pending_offer_average_days"])

    def test_rows_outside_2026_are_excluded(self):
        rows = [self._row("04-Onboarding", intake="January 2027"), self._row("05-Assessment", intake="2025")]
        tiles = build_pipeline_stage_tiles(rows)
        self.assertEqual(tiles["pending_assessment"], 0)

    def test_rows_in_2026_but_before_july_are_excluded(self):
        # Intake 01/02 2026 (Jan-Jun) predates this app's own live data
        # (the CRM migration) - only Intake 03 2026 (Jul-Dec) counts.
        rows = [
            self._row("04-Onboarding", intake="January 2026"),
            self._row("05-Assessment", intake="March 2026"),
            self._row("06-Decision", intake="June 2026"),
        ]
        tiles = build_pipeline_stage_tiles(rows)
        self.assertEqual(tiles["pending_assessment"], 0)
        self.assertEqual(tiles["pending_offer"], 0)

    def test_every_month_of_intake_03_2026_is_included(self):
        rows = [
            self._row("06-Decision", intake=f"{month} 2026")
            for month in ("July", "August", "September", "October", "November", "December")
        ]
        tiles = build_pipeline_stage_tiles(rows)
        self.assertEqual(tiles["pending_offer"], 6)

    def test_blank_or_unparseable_intake_is_excluded(self):
        rows = [self._row("04-Onboarding", intake=""), self._row("05-Assessment", intake="not a real intake")]
        tiles = build_pipeline_stage_tiles(rows)
        self.assertEqual(tiles["pending_assessment"], 0)


class PendingTilesStudentDedupTests(unittest.TestCase):
    """The 3 Pending tiles count students, not raw rows - a student
    applying to several courses in this scope only counts once, and a
    live application always wins over a 10-Lost one for the same
    student (pipeline.resolve_pipeline_rows_by_student)."""

    def _row(self, code, status, created, intake=IN_SCOPE_INTAKE):
        return {"Student Code": code, "Status": status, "Created": created, "Intake": intake}

    def test_a_student_with_two_rows_in_the_same_pending_stage_counts_once(self):
        # Real case found in production data: same student, two
        # applications, both still at 05-Assessment.
        rows = [
            self._row("PES1", "05-Assessment", "2026-07-11"),
            self._row("PES1", "05-Assessment", "2026-09-15"),
        ]
        tiles = build_pipeline_stage_tiles(rows)
        self.assertEqual(tiles["pending_assessment"], 1)

    def test_a_live_application_wins_over_a_lost_one_for_the_same_student(self):
        rows = [
            self._row("PES1", "10-Lost", "2026-08-24"),
            self._row("PES1", "05-Assessment", "2026-09-15"),
        ]
        tiles = build_pipeline_stage_tiles(rows)
        self.assertEqual(tiles["pending_assessment"], 1)

    def test_order_in_the_input_does_not_matter(self):
        rows = [
            self._row("PES1", "05-Assessment", "2026-09-15"),
            self._row("PES1", "10-Lost", "2026-08-24"),
        ]
        tiles = build_pipeline_stage_tiles(rows)
        self.assertEqual(tiles["pending_assessment"], 1)

    def test_a_student_with_only_lost_rows_in_scope_counts_in_no_pending_tile(self):
        rows = [
            self._row("PES1", "10-Lost", "2026-08-01"),
            self._row("PES1", "10-Lost", "2026-09-01"),
        ]
        tiles = build_pipeline_stage_tiles(rows)
        self.assertEqual(tiles["pending_assessment"], 0)
        self.assertEqual(tiles["pending_offer"], 0)
        self.assertEqual(tiles["pending_enrolment"], 0)

    def test_a_student_with_rows_in_two_different_pending_stages_only_counts_in_one(self):
        # The most recently Created row wins - here that's the
        # 07-Ready one, so the student shows up in Pending Enrolment
        # only, not also in Pending Assessment.
        rows = [
            self._row("PES1", "05-Assessment", "2026-07-01"),
            self._row("PES1", "07-Ready", "2026-09-01"),
        ]
        tiles = build_pipeline_stage_tiles(rows)
        self.assertEqual(tiles["pending_assessment"], 0)
        self.assertEqual(tiles["pending_enrolment"], 1)

    def test_different_students_are_each_counted(self):
        rows = [
            self._row("PES1", "05-Assessment", "2026-07-01"),
            self._row("PES2", "05-Assessment", "2026-07-01"),
        ]
        tiles = build_pipeline_stage_tiles(rows)
        self.assertEqual(tiles["pending_assessment"], 2)

    def test_a_blank_student_code_row_is_never_collapsed_with_another(self):
        rows = [
            {"Status": "05-Assessment", "Created": "2026-07-01", "Intake": IN_SCOPE_INTAKE},
            {"Status": "05-Assessment", "Created": "2026-08-01", "Intake": IN_SCOPE_INTAKE},
        ]
        tiles = build_pipeline_stage_tiles(rows)
        self.assertEqual(tiles["pending_assessment"], 2)


class PendingAverageDaysTests(unittest.TestCase):
    """Pending Assessment and Pending Offer also carry an average Stage
    Length figure - Pending Enrolment doesn't (not asked for)."""

    def _row(self, status, stage_length, intake=IN_SCOPE_INTAKE):
        return {"Status": status, "Stage Length": stage_length, "Intake": intake}

    def test_average_days_for_pending_assessment(self):
        rows = [
            self._row("04-Onboarding", "5 Days ago"),
            self._row("05-Assessment", "15 Days ago"),
        ]
        tiles = build_pipeline_stage_tiles(rows)
        self.assertEqual(tiles["pending_assessment_average_days"], 10.0)

    def test_average_days_for_pending_offer(self):
        rows = [
            self._row("06-Decision", "4 Days ago"),
            self._row("06-Decision", "6 Days ago"),
            self._row("06-Decision", "5 Days ago"),
        ]
        tiles = build_pipeline_stage_tiles(rows)
        self.assertEqual(tiles["pending_offer_average_days"], 5.0)

    def test_pending_enrolment_has_no_average_days_key(self):
        rows = [self._row("07-Ready", "3 Days ago")]
        tiles = build_pipeline_stage_tiles(rows)
        self.assertNotIn("pending_enrolment_average_days", tiles)

    def test_rows_without_a_parseable_stage_length_are_skipped(self):
        rows = [
            self._row("04-Onboarding", "5 Days ago"),
            self._row("04-Onboarding", ""),
            self._row("04-Onboarding", None),
            self._row("04-Onboarding", "not a stage length"),
        ]
        tiles = build_pipeline_stage_tiles(rows)
        self.assertEqual(tiles["pending_assessment_average_days"], 5.0)

    def test_no_rows_at_all_gives_none_not_a_divide_by_zero(self):
        tiles = build_pipeline_stage_tiles([])
        self.assertIsNone(tiles["pending_assessment_average_days"])
        self.assertIsNone(tiles["pending_offer_average_days"])

    def test_result_is_rounded_to_one_decimal_place(self):
        rows = [
            self._row("06-Decision", "5 Days ago"),
            self._row("06-Decision", "6 Days ago"),
            self._row("06-Decision", "6 Days ago"),
        ]
        tiles = build_pipeline_stage_tiles(rows)
        self.assertEqual(tiles["pending_offer_average_days"], 5.7)  # (5 + 6 + 6) / 3 = 5.666...

    def test_a_row_out_of_scope_does_not_affect_the_average(self):
        rows = [
            self._row("04-Onboarding", "5 Days ago"),
            self._row("04-Onboarding", "999 Days ago", intake="January 2026"),  # out of scope
        ]
        tiles = build_pipeline_stage_tiles(rows)
        self.assertEqual(tiles["pending_assessment_average_days"], 5.0)


class CountEnrolledThisIntakeTests(unittest.TestCase):
    def test_counts_enrolled_rows_for_the_given_intake_year(self):
        rows = [
            {"Status": "09-Enrolled", "Intake": "September 2026"},
            {"Status": "09-Enrolled", "Intake": "January 2027"},
            {"Status": "10-Lost", "Intake": "September 2026"},
        ]
        self.assertEqual(count_enrolled_this_intake(rows, 2026), 1)
        self.assertEqual(count_enrolled_this_intake(rows, 2027), 1)

    def test_defaults_to_the_apps_default_intake_year(self):
        from pipeline import PIPELINE_INTAKE_YEAR

        rows = [{"Status": "09-Enrolled", "Intake": f"September {PIPELINE_INTAKE_YEAR}"}]
        self.assertEqual(count_enrolled_this_intake(rows), 1)

    def test_empty_input_gives_zero(self):
        self.assertEqual(count_enrolled_this_intake([], 2026), 0)


class BuildEnrolledByOfficeTests(unittest.TestCase):
    """Enrolled This Intake's own total, broken down by Sales Office."""

    def _row(self, status, office, intake="September 2026"):
        return {"Status": status, "Sales Office": office, "Intake": intake}

    def test_groups_by_office(self):
        rows = [
            self._row("09-Enrolled", "OXF"),
            self._row("09-Enrolled", "OXF"),
            self._row("09-Enrolled", "CAR"),
        ]
        breakdown = build_enrolled_by_office(rows, 2026)
        self.assertEqual(breakdown, [{"office": "CAR", "count": 1}, {"office": "OXF", "count": 2}])

    def test_sorted_alphabetically_case_insensitive(self):
        rows = [
            self._row("09-Enrolled", "oxf"),
            self._row("09-Enrolled", "CAR"),
            self._row("09-Enrolled", "Lon"),
        ]
        breakdown = build_enrolled_by_office(rows, 2026)
        self.assertEqual([e["office"] for e in breakdown], ["CAR", "Lon", "oxf"])

    def test_non_enrolled_rows_are_excluded(self):
        rows = [self._row("10-Lost", "OXF"), self._row("05-Assessment", "OXF")]
        self.assertEqual(build_enrolled_by_office(rows, 2026), [])

    def test_rows_outside_the_intake_year_are_excluded(self):
        rows = [self._row("09-Enrolled", "OXF", intake="January 2027")]
        self.assertEqual(build_enrolled_by_office(rows, 2026), [])

    def test_blank_sales_office_is_excluded_not_fabricated_as_unassigned(self):
        rows = [self._row("09-Enrolled", ""), self._row("09-Enrolled", "OXF")]
        breakdown = build_enrolled_by_office(rows, 2026)
        self.assertEqual(breakdown, [{"office": "OXF", "count": 1}])

    def test_office_totals_never_exceed_the_enrolled_this_intake_total(self):
        rows = [
            self._row("09-Enrolled", "OXF"),
            self._row("09-Enrolled", ""),  # excluded from breakdown, still counts in the overall total
        ]
        breakdown = build_enrolled_by_office(rows, 2026)
        self.assertLessEqual(sum(e["count"] for e in breakdown), count_enrolled_this_intake(rows, 2026))

    def test_defaults_to_the_apps_default_intake_year(self):
        from pipeline import PIPELINE_INTAKE_YEAR

        rows = [self._row("09-Enrolled", "OXF", intake=f"September {PIPELINE_INTAKE_YEAR}")]
        self.assertEqual(build_enrolled_by_office(rows), [{"office": "OXF", "count": 1}])

    def test_empty_input_gives_empty_list(self):
        self.assertEqual(build_enrolled_by_office([], 2026), [])


class CountEnrolledThisCalendarYearTests(unittest.TestCase):
    def test_counts_by_real_enrolled_date_not_intake_label(self):
        rows = [
            # Intake label says 2027, but actually enrolled in Dec 2026.
            {"Status": "09-Enrolled", "Intake": "January 2027", "Enrolled Date": "2026-12-15"},
            {"Status": "09-Enrolled", "Intake": "September 2026", "Enrolled Date": "2026-09-05"},
            {"Status": "09-Enrolled", "Intake": "September 2026", "Enrolled Date": "2027-01-10"},
        ]
        self.assertEqual(count_enrolled_this_calendar_year(rows, 2026), 2)
        self.assertEqual(count_enrolled_this_calendar_year(rows, 2027), 1)

    def test_non_enrolled_rows_are_excluded(self):
        rows = [{"Status": "10-Lost", "Enrolled Date": "2026-09-05"}]
        self.assertEqual(count_enrolled_this_calendar_year(rows, 2026), 0)

    def test_blank_enrolled_date_is_excluded_safely(self):
        rows = [{"Status": "09-Enrolled", "Enrolled Date": ""}, {"Status": "09-Enrolled", "Enrolled Date": None}]
        self.assertEqual(count_enrolled_this_calendar_year(rows, 2026), 0)

    def test_empty_input_gives_zero(self):
        self.assertEqual(count_enrolled_this_calendar_year([], 2026), 0)

    def test_manual_backfill_total_is_added_on_top(self):
        # The 2026 CRM-migration Intake 01/02 backfill (Consultant Lookup
        # table) has no Enrolled Date row to find in `rows` at all - it's
        # added on top of whatever real Enrolled Date rows do turn up.
        rows = [{"Status": "09-Enrolled", "Enrolled Date": "2026-09-05"}]
        self.assertEqual(count_enrolled_this_calendar_year(rows, 2026, manual_backfill_total=637), 638)

    def test_manual_backfill_total_defaults_to_zero(self):
        rows = [{"Status": "09-Enrolled", "Enrolled Date": "2026-09-05"}]
        self.assertEqual(count_enrolled_this_calendar_year(rows, 2026), 1)


class MonthProgressTests(unittest.TestCase):
    """The Month filter bar's "Day X of Y (Z% of month)" indicator."""

    def test_current_month_shows_todays_day_and_pct(self):
        result = month_progress(2026, 9, date(2026, 9, 21))
        self.assertEqual(result, {"day": 21, "days_in_month": 30, "pct": 70.0})

    def test_a_past_month_is_fully_elapsed(self):
        result = month_progress(2026, 8, date(2026, 9, 21))
        self.assertEqual(result, {"day": 31, "days_in_month": 31, "pct": 100.0})

    def test_a_future_month_has_not_started(self):
        result = month_progress(2026, 10, date(2026, 9, 21))
        self.assertEqual(result, {"day": 0, "days_in_month": 31, "pct": 0.0})

    def test_the_first_day_of_the_current_month(self):
        result = month_progress(2026, 9, date(2026, 9, 1))
        self.assertAlmostEqual(result["pct"], 3.3)

    def test_the_last_day_of_the_current_month(self):
        result = month_progress(2026, 9, date(2026, 9, 30))
        self.assertEqual(result["pct"], 100.0)


class ClassifyMonthTileTests(unittest.TestCase):
    """Red/yellow/green for the 4 month-scoped tiles against their fixed
    monthly targets - below 80% red, 80-99% yellow, 100%+ green (the
    same 3-tier ratio rule as kpi.classify_status())."""

    def test_targets_are_as_specified(self):
        self.assertEqual(
            MONTH_TILE_TARGETS,
            {"leads_generated": 6000, "docs_approved": 400, "qa_passed": 400, "submitted_to_uni": 400},
        )

    def test_below_80_pct_is_red(self):
        self.assertEqual(classify_month_tile("docs_approved", 319), "red")  # 79.75%

    def test_80_to_99_pct_is_yellow(self):
        self.assertEqual(classify_month_tile("docs_approved", 320), "yellow")  # 80.0%
        self.assertEqual(classify_month_tile("docs_approved", 399), "yellow")  # 99.75%

    def test_100_pct_and_above_is_green(self):
        self.assertEqual(classify_month_tile("docs_approved", 400), "green")
        self.assertEqual(classify_month_tile("docs_approved", 500), "green")

    def test_leads_generated_uses_its_own_6000_target(self):
        self.assertEqual(classify_month_tile("leads_generated", 4799), "red")  # 79.98%
        self.assertEqual(classify_month_tile("leads_generated", 4800), "yellow")  # 80.0%
        self.assertEqual(classify_month_tile("leads_generated", 6000), "green")

    def test_unknown_tile_key_has_no_target_to_classify(self):
        self.assertIsNone(classify_month_tile("not_a_real_tile", 1000))


if __name__ == "__main__":
    unittest.main()
