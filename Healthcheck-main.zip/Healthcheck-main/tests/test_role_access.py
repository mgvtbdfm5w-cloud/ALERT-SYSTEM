"""The Admin page's access grid: which logins can open Company Dashboard,
Consultants, Admin and To Do List, and whether the two kinds of download are
available. Rules and storage first, then the real routes."""

import io
import re
import sqlite3
import unittest
from unittest import mock

import authorization
import db
import role_access
from authorization import ALLOW, DENY, ENDPOINT_PERMISSION, ENDPOINT_ROLES, REQUIRE_LOGIN, authorize
from role_access import CONFIGURABLE_ROLES, PERMISSION_KEYS, default_allowed, field_name, load_access
from tests.flask_test_support import IsolatedAppTestCase, app_module, db_module, extract_token
from tests.test_upload_atomicity import book, row

ROLES = ("full", "admissions", "consultants", "marketing")
PAGES = {"company_dashboard": "/company-dashboard", "consultants": "/consultants", "admin": "/admin", "todo": "/todo"}
NAV_TEXT = {"company_dashboard": "Company Dashboard", "consultants": "Consultants", "admin": "Admin", "todo": "To Do List"}
EXPORT_PATHS = ["/dashboard/export", "/dashboard/just-jon/export", "/enrolled/export/intake-03",
                "/enrolled/export/current-intake", "/offer-days/export/total"]
FULL_DOWNLOADS = ["/download", "/leads/download"]


def everything(roles=CONFIGURABLE_ROLES):
    return {role: set(PERMISSION_KEYS) for role in roles}


# ------------------------------------------------------------------- rules
class DefaultsTests(unittest.TestCase):
    def test_defaults_reproduce_what_each_login_could_do_before_the_grid_existed(self):
        for role in CONFIGURABLE_ROLES:
            for key in ("company_dashboard", "consultants", "admin", "todo", "download_exports"):
                self.assertTrue(default_allowed(role, key), (role, key))
        self.assertTrue(default_allowed("admissions", "download_full"))
        self.assertFalse(default_allowed("consultants", "download_full"))
        self.assertFalse(default_allowed("marketing", "download_full"))

    def test_six_switches_for_three_configurable_logins(self):
        self.assertEqual(len(PERMISSION_KEYS), 6)
        self.assertEqual(len(role_access.default_rows()), 18)
        self.assertNotIn("full", CONFIGURABLE_ROLES)

    def test_every_switch_maps_to_endpoints_that_exist_in_the_policy(self):
        for endpoint, permission in ENDPOINT_PERMISSION.items():
            self.assertIn(endpoint, ENDPOINT_ROLES, endpoint)
            self.assertIn(permission, PERMISSION_KEYS, endpoint)
        self.assertEqual(set(ENDPOINT_PERMISSION.values()), set(PERMISSION_KEYS), "no switch without an endpoint")

    def test_the_default_grid_gives_every_endpoint_the_same_answer_as_the_fixed_table(self):
        """Seeding the grid must change nobody's access: grid answer == fixed-table answer."""
        access = {"full": set(PERMISSION_KEYS), **{r: {k for k in PERMISSION_KEYS if default_allowed(r, k)} for r in CONFIGURABLE_ROLES}}
        for endpoint in ENDPOINT_PERMISSION:
            for role in ROLES:
                self.assertEqual(authorize(endpoint, True, role, access), authorize(endpoint, True, role), (endpoint, role))


class AuthorizeWithGridTests(unittest.TestCase):
    def test_for_grid_endpoints_the_grid_decides_for_every_login_except_full(self):
        for endpoint, permission in ENDPOINT_PERMISSION.items():
            for role in CONFIGURABLE_ROLES:
                self.assertEqual(authorize(endpoint, True, role, {role: {permission}}), ALLOW, (endpoint, role, "granted"))
                self.assertEqual(authorize(endpoint, True, role, {role: set(PERMISSION_KEYS) - {permission}}), DENY, (endpoint, role, "removed"))

    def test_the_grid_can_grant_what_the_fixed_table_did_not(self):
        self.assertEqual(authorize("download", True, "consultants"), DENY)
        self.assertEqual(authorize("download", True, "consultants", {"consultants": {"download_full"}}), ALLOW)

    def test_full_access_is_never_narrowed(self):
        for endpoint in ENDPOINT_PERMISSION:
            for access in ({}, {"full": set()}, everything()):
                self.assertEqual(authorize(endpoint, True, "full", access), ALLOW, endpoint)

    def test_a_login_missing_from_the_grid_has_nothing_switched_on(self):
        for endpoint in ENDPOINT_PERMISSION:
            self.assertEqual(authorize(endpoint, True, "marketing", {"admissions": set(PERMISSION_KEYS)}), DENY, endpoint)

    def test_the_grid_never_touches_endpoints_it_does_not_cover(self):
        for endpoint, roles in ENDPOINT_ROLES.items():
            if endpoint in ENDPOINT_PERMISSION:
                continue
            for role in ROLES:
                expected = authorize(endpoint, True, role)
                self.assertEqual(authorize(endpoint, True, role, everything()), expected, (endpoint, role))
                self.assertEqual(authorize(endpoint, True, role, {}), expected, (endpoint, role))

    def test_login_state_unknown_roles_and_public_pages_are_unchanged(self):
        for endpoint in ENDPOINT_PERMISSION:
            self.assertEqual(authorize(endpoint, False, "marketing", everything()), REQUIRE_LOGIN)
            self.assertEqual(authorize(endpoint, True, "stranger", everything()), DENY)
            self.assertEqual(authorize(endpoint, True, None, everything()), DENY)
        for public in ("login", "logout", "index", "static"):
            self.assertEqual(authorize(public, False, None, {}), ALLOW)

    def test_without_a_grid_the_fixed_table_applies(self):
        self.assertEqual(authorize("admin", True, "marketing"), ALLOW)
        self.assertEqual(authorize("download", True, "marketing"), DENY)


# ----------------------------------------------------------------- storage
class StorageTests(unittest.TestCase):
    def setUp(self):
        self.conn = sqlite3.connect(":memory:")
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("CREATE TABLE role_access (role TEXT NOT NULL, permission TEXT NOT NULL, allowed INTEGER NOT NULL CHECK (allowed IN (0,1)), updated_at TEXT NOT NULL, PRIMARY KEY (role, permission))")
        self.addCleanup(self.conn.close)

    def test_an_empty_table_loads_as_the_defaults(self):
        access = load_access(self.conn)
        self.assertEqual(access["full"], set(PERMISSION_KEYS))
        self.assertIn("download_full", access["admissions"])
        self.assertNotIn("download_full", access["consultants"])
        self.assertEqual(access["marketing"], set(PERMISSION_KEYS) - {"download_full"})

    def test_saving_turns_exactly_the_submitted_boxes_on(self):
        role_access.save_access(self.conn, {field_name("marketing", "todo"), field_name("marketing", "admin")}, "t")
        access = load_access(self.conn)
        self.assertEqual(access["marketing"], {"todo", "admin"})
        self.assertEqual(access["consultants"], set(), "every box not submitted is off")

    def test_tampered_fields_are_ignored_and_full_cannot_be_changed(self):
        role_access.save_access(self.conn, {"full__admin", "stranger__todo", "marketing__nonsense", "csrf_token", field_name("marketing", "todo")}, "t")
        rows = self.conn.execute("SELECT role, permission FROM role_access").fetchall()
        self.assertEqual({r["role"] for r in rows}, set(CONFIGURABLE_ROLES))
        self.assertEqual({r["permission"] for r in rows}, set(PERMISSION_KEYS))
        self.assertEqual(load_access(self.conn)["full"], set(PERMISSION_KEYS))
        self.assertEqual(load_access(self.conn)["marketing"], {"todo"})

    def test_reset_restores_every_default(self):
        role_access.save_access(self.conn, set(), "t")
        self.assertEqual(load_access(self.conn)["admissions"], set())
        role_access.reset_access(self.conn, "t2")
        self.assertEqual(load_access(self.conn)["admissions"], set(PERMISSION_KEYS))
        self.assertEqual(load_access(self.conn)["consultants"], set(PERMISSION_KEYS) - {"download_full"})

    def test_the_grid_rows_lock_the_full_access_column(self):
        grid = role_access.build_grid(load_access(self.conn))
        self.assertEqual([r["key"] for r in grid], list(PERMISSION_KEYS))
        for r in grid:
            self.assertEqual([c["role"] for c in r["cells"]], ["full", "admissions", "consultants", "marketing"])
            self.assertTrue(r["cells"][0]["locked"] and r["cells"][0]["checked"])
            self.assertFalse(any(c["locked"] for c in r["cells"][1:]))


class DatabaseTests(unittest.TestCase):
    def setUp(self):
        import shutil, tempfile
        from pathlib import Path
        self.tmp = Path(tempfile.mkdtemp(prefix="gsp_access_db_"))
        self.addCleanup(shutil.rmtree, self.tmp, ignore_errors=True)
        patcher = mock.patch.object(db, "DB_PATH", self.tmp / "t.db")
        patcher.start()
        self.addCleanup(patcher.stop)

    def rows(self, sql="SELECT role, permission, allowed FROM role_access"):
        conn = sqlite3.connect(self.tmp / "t.db")
        try:
            return conn.execute(sql).fetchall()
        finally:
            conn.close()

    def test_a_fresh_database_gets_the_table_and_the_defaults(self):
        db.init_db()
        self.assertEqual(len(self.rows()), 18)
        self.assertEqual(sorted(r for r in self.rows() if r[1] == "download_full"),
                         [("admissions", "download_full", 1), ("consultants", "download_full", 0), ("marketing", "download_full", 0)])

    def test_restarting_never_overwrites_an_edited_grid_but_fills_in_a_missing_switch(self):
        db.init_db()
        conn = sqlite3.connect(self.tmp / "t.db")
        conn.execute("UPDATE role_access SET allowed = 0 WHERE role = 'marketing' AND permission = 'todo'")
        conn.execute("DELETE FROM role_access WHERE role = 'consultants' AND permission = 'admin'")
        conn.commit()
        conn.close()
        db.init_db()
        db.init_db()
        rows = {(r[0], r[1]): r[2] for r in self.rows()}
        self.assertEqual(rows[("marketing", "todo")], 0, "the edit survived")
        self.assertEqual(rows[("consultants", "admin")], 1, "the missing switch came back at its default")
        self.assertEqual(len(rows), 18)

    def test_the_database_refuses_a_value_that_is_not_on_or_off(self):
        db.init_db()
        conn = sqlite3.connect(self.tmp / "t.db")
        with self.assertRaises(sqlite3.IntegrityError):
            conn.execute("UPDATE role_access SET allowed = 2")
        conn.close()


# ------------------------------------------------------------------ routes
class AccessRouteTestCase(IsolatedAppTestCase):
    def setUp(self):
        super().setUp()
        self.full = self._client_logged_in_as("full")

    def token(self, client):
        return extract_token(client.get("/login").get_data(as_text=True))

    def save(self, on, client=None):
        """Submit the grid with exactly the boxes in `on` ({role: set(permission keys)}) ticked."""
        client = client or self.full
        fields = {field_name(role, key): "on" for role, keys in on.items() for key in keys}
        return client.post("/admin/access", data={"csrf_token": self.token(client), **fields})

    def defaults(self):
        return {role: {k for k in PERMISSION_KEYS if default_allowed(role, k)} for role in CONFIGURABLE_ROLES}

    def grid_with(self, **changes):
        """The default grid with `role=(keys to turn on, keys to turn off)` edits applied."""
        grid = self.defaults()
        for role, (on, off) in changes.items():
            grid[role] = (grid[role] | set(on)) - set(off)
        return grid

    def nav(self, client, path="/kpi"):
        html = client.get(path).get_data(as_text=True)
        nav = html[html.index('<nav class="nav">'):html.index("</nav>")]
        return {key: f'href="{PAGES[key]}"' in nav for key in PAGES}      # by link: the login's own label can say "Consultants" too

    def load_data(self):
        """Both datasets, so every download returns a real file."""
        from datetime import timedelta
        from dateutils import today_uk
        from tests.test_paid_ads import leads_book, lead_row
        submitted = (today_uk() - timedelta(days=10)).strftime("%d/%m/%Y")
        rows = [row(**{"Student Code": "P1", "Student Name": "A", "Application Status": "x"}),
                # in assessment and submitted 10 days ago: it belongs on the Offer Days page, so its cards are drawn
                row(**{"Student Code": "P2", "Student Name": "B", "Application Status": "Assessment", "Uni Submission Done": submitted, "Intake": "September 2026"})]
        workbook = book(rows, lookups={"status": [("Assessment", "05-Assessment")]})
        for path, data in (("/upload", workbook), ("/leads/upload", leads_book([lead_row("L1", "Paid Ad/G", "03/08/2026", "New Lead")]))):
            self.assertEqual(self.full.post(path, data={"csrf_token": self.token(self.full), "excel_file": (io.BytesIO(data), "f.xlsx")},
                                            content_type="multipart/form-data").status_code, 302)


class GridPageTests(AccessRouteTestCase):
    def test_full_access_sees_the_grid_with_every_login_and_every_switch(self):
        html = self.full.get("/admin").get_data(as_text=True)
        self.assertIn('id="access-settings"', html)
        for label in ("Company Dashboard", "Consultants", "To Do List", "Download page exports", "Download the full Applications and Leads spreadsheets"):
            self.assertIn(label, html)
        section = html[html.index('id="access-settings"'):]
        for header in ("Full Access", "Admissions", "Consultants", "Marketing"):
            self.assertIn(f"<th>{header}</th>", section)
        for role in CONFIGURABLE_ROLES:
            for key in PERMISSION_KEYS:
                self.assertIn(f'name="{field_name(role, key)}"', section)
        self.assertNotIn('name="full__', section, "Full Access cannot be edited")
        self.assertEqual(len(re.findall(r"<input type=\"checkbox\" checked disabled", section)), 6, "Full Access column is locked on")

    def test_the_default_ticks_match_todays_access(self):
        section = self.full.get("/admin").get_data(as_text=True)
        section = section[section.index('id="access-settings"'):]

        def ticked(role, key):
            m = re.search(rf'name="{field_name(role, key)}" (checked)?', section)
            return bool(m.group(1))
        for role in CONFIGURABLE_ROLES:
            for key in PERMISSION_KEYS:
                self.assertEqual(ticked(role, key), default_allowed(role, key), (role, key))

    def test_nobody_else_sees_the_grid(self):
        for role in ("admissions", "consultants", "marketing"):
            html = self._client_logged_in_as(role).get("/admin").get_data(as_text=True)
            self.assertNotIn("Access Settings", html, role)
            self.assertNotIn("access-settings", html, role)

    def test_only_full_access_can_save_or_reset(self):
        before = self.defaults()
        for role in ("admissions", "consultants", "marketing"):
            client = self._client_logged_in_as(role)
            for path in ("/admin/access", "/admin/access/reset"):
                r = client.post(path, data={"csrf_token": self.token(client), field_name("marketing", "todo"): "on"})
                self.assertEqual(r.status_code, 403, (role, path))
        conn = sqlite3.connect(db_module.DB_PATH)
        stored = {(r[0], r[1]): r[2] for r in conn.execute("SELECT role, permission, allowed FROM role_access")}
        conn.close()
        self.assertEqual({k for k, v in stored.items() if v}, {(r, k) for r, keys in before.items() for k in keys})

    def test_csrf_and_login_are_required(self):
        for path in ("/admin/access", "/admin/access/reset"):
            self.assertEqual(self.full.post(path, data={}).status_code, 400, path)
            anonymous = app_module.app.test_client()
            r = anonymous.post(path, data={"csrf_token": self.token(anonymous)})
            self.assertEqual(r.status_code, 302, path)
            self.assertIn("/login", r.headers["Location"])


class PageSwitchTests(AccessRouteTestCase):
    def test_university_pipeline_is_a_toolbar_link_for_every_login_and_no_longer_in_the_admin_pages_panel(self):
        for role in ("full",) + CONFIGURABLE_ROLES:
            client = self._client_logged_in_as(role)
            html = client.get("/kpi").get_data(as_text=True)
            nav = html[html.index('<nav class="nav">'):html.index("</nav>")]
            self.assertIn('href="/university-pipeline"', nav, role)
            self.assertLess(nav.index('href="/consultants"'), nav.index('href="/university-pipeline"'), "sits next to Consultants")
            self.assertEqual(client.get("/university-pipeline").status_code, 200, role)
            admin = client.get("/admin").get_data(as_text=True)
            panel = admin[admin.index("<h2>Pages</h2>"):]
            panel = panel[:panel.index("</section>")]
            self.assertNotIn("university-pipeline", panel, role)

    def test_every_defaults_login_can_open_all_four_pages_and_sees_all_four_links(self):
        for role in CONFIGURABLE_ROLES:
            client = self._client_logged_in_as(role)
            for key, path in PAGES.items():
                self.assertEqual(client.get(path).status_code, 200, (role, key))
            self.assertEqual(set(self.nav(client).values()), {True}, role)

    def test_unticking_a_page_blocks_it_and_hides_its_link_for_that_login_only(self):
        for key, path in PAGES.items():
            for role in CONFIGURABLE_ROLES:
                with self.subTest(page=key, role=role):
                    self.save(self.grid_with(**{role: ((), (key,))}))
                    client = self._client_logged_in_as(role)
                    self.assertEqual(client.get(path).status_code, 403)
                    expected = {k: k != key for k in PAGES}
                    self.assertEqual(self.nav(client), expected)
                    for other in CONFIGURABLE_ROLES:
                        if other != role:
                            self.assertEqual(self._client_logged_in_as(other).get(path).status_code, 200, other)
                    self.assertEqual(self.full.get(path).status_code, 200, "Full Access is never affected")
                    self.save(self.defaults())

    def test_ticking_a_page_back_on_restores_it_straight_away(self):
        self.save(self.grid_with(marketing=((), ("todo",))))
        marketing = self._client_logged_in_as("marketing")
        self.assertEqual(marketing.get("/todo").status_code, 403)
        self.save(self.defaults())
        self.assertEqual(marketing.get("/todo").status_code, 200)

    def test_the_old_faheem_bookmark_follows_the_consultants_switch(self):
        self.save(self.grid_with(consultants=((), ("consultants",))))
        client = self._client_logged_in_as("consultants")
        self.assertEqual(client.get("/dashboard/faheem").status_code, 403)
        self.assertEqual(client.get("/consultants?consultant=Mel").status_code, 403)

    def test_pages_the_grid_does_not_cover_stay_open(self):
        self.save({role: set() for role in CONFIGURABLE_ROLES})
        for role in CONFIGURABLE_ROLES:
            client = self._client_logged_in_as(role)
            for path in ("/kpi", "/leads-dashboard", "/allocation", "/interviews", "/enrolled", "/university-pipeline"):
                self.assertEqual(client.get(path).status_code, 200, (role, path))

    def test_the_admin_pages_list_hides_the_consultants_link_when_it_is_off(self):
        self.save(self.grid_with(admissions=((), ("consultants",))))
        html = self._client_logged_in_as("admissions").get("/admin").get_data(as_text=True)
        self.assertNotIn('class="page-link" href="/consultants"', html)
        self.assertIn('class="page-link" href="/interviews"', html)

    def test_other_restrictions_are_unchanged_even_with_everything_ticked(self):
        self.save(everything())
        for role in ("consultants", "marketing"):
            client = self._client_logged_in_as(role)
            for path in ("/paid-ads",):
                self.assertEqual(client.get(path).status_code, 403, (role, path))
            token = self.token(client)
            for path in ("/upload", "/leads/upload", "/admin/reprocess", "/admin/access", "/admin/paid-ads/settings"):
                self.assertEqual(client.post(path, data={"csrf_token": token}).status_code, 403, (role, path))
            html = client.get("/admin").get_data(as_text=True)
            self.assertNotIn("Access Settings", html)
            self.assertNotIn('action="/upload"', html)


class LandingTests(AccessRouteTestCase):
    def login(self, role):
        from tests.flask_test_support import ROLE_PASSWORDS
        client = app_module.app.test_client()
        r = client.post("/login", data={"csrf_token": self.token(client), "password": ROLE_PASSWORDS[role]})
        return client, r

    def test_login_lands_on_the_first_page_the_login_may_open(self):
        for off, expected in ((("company_dashboard",), "/consultants"), (("company_dashboard", "consultants"), "/todo"),
                              (("company_dashboard", "consultants", "todo"), "/admin")):
            self.save(self.grid_with(marketing=((), off)))
            client, r = self.login("marketing")
            self.assertEqual(r.status_code, 302)
            self.assertEqual(r.headers["Location"].split("?")[0].rsplit("/", 1)[-1], expected.strip("/"), off)
            self.assertEqual(client.get(r.headers["Location"]).status_code, 200)

    def test_the_root_address_goes_to_the_same_landing_page(self):
        self.save(self.grid_with(marketing=((), ("company_dashboard",))))
        client, _ = self.login("marketing")
        r = client.get("/")
        self.assertEqual(r.status_code, 302)
        self.assertTrue(r.headers["Location"].endswith("/consultants"))

    def test_a_login_with_nothing_ticked_can_sign_in_but_only_sees_access_denied_and_can_log_out(self):
        self.save({role: set() for role in CONFIGURABLE_ROLES})
        client, r = self.login("consultants")
        self.assertEqual(r.status_code, 302)
        denied = client.get(r.headers["Location"], follow_redirects=True)
        self.assertEqual(denied.status_code, 403)
        self.assertIn("Access Denied", denied.get_data(as_text=True))
        nav = denied.get_data(as_text=True)
        nav = nav[nav.index('<nav class="nav">'):nav.index("</nav>")]
        self.assertNotIn("Company Dashboard", nav)
        self.assertIn("Logout", nav)
        out = client.post("/logout", data={"csrf_token": self.token(client)})
        self.assertEqual(out.status_code, 302)
        self.assertIn("/login", out.headers["Location"])

    def test_full_access_can_never_be_locked_out_even_with_an_empty_grid(self):
        self.save({})
        client, r = self.login("full")
        self.assertEqual(r.status_code, 302)
        for path in PAGES.values():
            self.assertEqual(client.get(path).status_code, 200, path)
        self.assertIn("Access Settings", client.get("/admin").get_data(as_text=True))


class DownloadSwitchTests(AccessRouteTestCase):
    def setUp(self):
        super().setUp()
        self.load_data()

    def test_page_exports_off_blocks_all_five_export_files_and_hides_their_controls(self):
        self.save(self.grid_with(consultants=((), ("download_exports",))))
        client = self._client_logged_in_as("consultants")
        for path in EXPORT_PATHS:
            self.assertEqual(client.get(path).status_code, 403, path)
        self.assertNotIn("/dashboard/export", client.get("/dashboard").get_data(as_text=True))
        self.assertNotIn("/dashboard/just-jon/export", client.get("/dashboard/just-jon").get_data(as_text=True))
        self.assertNotIn("/enrolled/export/", client.get("/enrolled").get_data(as_text=True))
        self.assertNotIn("/offer-days/export/", client.get("/offer-days").get_data(as_text=True))
        self.assertNotIn("Download Enrolled - Current Intake", client.get("/admin").get_data(as_text=True))
        self.assertNotIn("Enrolled - Current Intake Export", client.get("/admin").get_data(as_text=True))

    def test_page_exports_stay_available_to_everyone_else(self):
        self.save(self.grid_with(consultants=((), ("download_exports",))))
        for role in ("admissions", "marketing", "full"):
            client = self._client_logged_in_as(role)
            for path in EXPORT_PATHS:
                self.assertEqual(client.get(path).status_code, 200, (role, path))
            self.assertIn("/dashboard/export", client.get("/dashboard").get_data(as_text=True), role)

    def test_the_offer_days_and_enrolled_cards_become_plain_cards_without_downloads(self):
        self.save(self.grid_with(marketing=((), ("download_exports",))))
        marketing = self._client_logged_in_as("marketing")
        full_offer_days = self.full.get("/offer-days").get_data(as_text=True)
        self.assertIn("offer-card-link", full_offer_days, "the cards are drawn on this data (so the check below is not vacuous)")
        self.assertIn('href="/offer-days/export/', full_offer_days)
        for path in ("/offer-days", "/enrolled"):
            html = marketing.get(path).get_data(as_text=True)
            self.assertNotIn("offer-card-link", html, path)
            self.assertNotIn("offer-card-download-icon", html, path)
            self.assertNotIn('href="/offer-days/export/', html, path)
            self.assertNotIn('href="/enrolled/export/', html, path)
        self.assertIn("summary-card", marketing.get("/offer-days").get_data(as_text=True), "the numbers are still shown")
        self.assertIn("offer-card-link", self.full.get("/enrolled").get_data(as_text=True))

    def test_full_spreadsheets_off_blocks_the_two_downloads_and_hides_the_buttons(self):
        self.save(self.grid_with(admissions=((), ("download_full",))))
        client = self._client_logged_in_as("admissions")
        for path in FULL_DOWNLOADS:
            self.assertEqual(client.get(path).status_code, 403, path)
        html = client.get("/admin").get_data(as_text=True)
        self.assertNotIn('href="/download"', html)
        self.assertNotIn('href="/leads/download"', html)
        self.assertIn('action="/upload"', html, "uploading is not a download")
        for path in EXPORT_PATHS:
            self.assertEqual(client.get(path).status_code, 200, "the page exports are a separate switch")

    def test_ticking_full_spreadsheets_for_consultants_grants_it(self):
        client = self._client_logged_in_as("consultants")
        for path in FULL_DOWNLOADS:
            self.assertEqual(client.get(path).status_code, 403, path)
        self.save(self.grid_with(consultants=(("download_full",), ())))
        for path in FULL_DOWNLOADS:
            r = client.get(path)
            self.assertEqual(r.status_code, 200, path)
            self.assertIn("attachment", r.headers.get("Content-Disposition", ""))
        html = client.get("/admin").get_data(as_text=True)
        self.assertIn('href="/download"', html)

    def test_the_two_download_switches_are_independent(self):
        self.save(self.grid_with(marketing=(("download_full",), ("download_exports",))))
        client = self._client_logged_in_as("marketing")
        self.assertEqual(client.get("/download").status_code, 200)
        self.assertEqual(client.get("/dashboard/export").status_code, 403)

    def test_full_access_keeps_every_download_whatever_the_grid_says(self):
        self.save({})
        for path in FULL_DOWNLOADS + EXPORT_PATHS:
            self.assertEqual(self.full.get(path).status_code, 200, path)


class SavingTests(AccessRouteTestCase):
    def test_a_save_stores_the_grid_and_confirms_it(self):
        r = self.save(self.grid_with(marketing=((), ("todo",))))
        self.assertEqual(r.status_code, 302)
        self.assertTrue(r.headers["Location"].endswith("/admin#access-settings"))
        self.assertIn("Access settings saved.", self.full.get("/admin").get_data(as_text=True))
        conn = sqlite3.connect(db_module.DB_PATH)
        self.assertEqual(conn.execute("SELECT allowed FROM role_access WHERE role='marketing' AND permission='todo'").fetchone()[0], 0)
        conn.close()

    def test_the_grid_shows_what_was_saved(self):
        self.save(self.grid_with(consultants=(("download_full",), ("admin",))))
        section = self.full.get("/admin").get_data(as_text=True)
        section = section[section.index('id="access-settings"'):]
        self.assertRegex(section, rf'name="{field_name("consultants", "download_full")}" checked')
        self.assertNotRegex(section, rf'name="{field_name("consultants", "admin")}" checked')

    def test_tampered_extra_fields_change_nothing_and_full_stays_on(self):
        r = self.full.post("/admin/access", data={"csrf_token": self.token(self.full), "full__admin": "", "stranger__todo": "on",
                                                   "marketing__bogus": "on", field_name("marketing", "todo"): "on"})
        self.assertEqual(r.status_code, 302)
        self.assertEqual(self.full.get("/admin").status_code, 200)
        self.assertEqual(self._client_logged_in_as("marketing").get("/todo").status_code, 200)
        self.assertEqual(self._client_logged_in_as("marketing").get("/company-dashboard").status_code, 403)

    def test_reset_puts_everything_back(self):
        self.load_data()
        self.save({role: set() for role in CONFIGURABLE_ROLES})
        self.assertEqual(self._client_logged_in_as("marketing").get("/todo").status_code, 403)
        r = self.full.post("/admin/access/reset", data={"csrf_token": self.token(self.full)})
        self.assertEqual(r.status_code, 302)
        self.assertEqual(self._client_logged_in_as("marketing").get("/todo").status_code, 200)
        self.assertEqual(self._client_logged_in_as("consultants").get("/download").status_code, 403)
        self.assertEqual(self._client_logged_in_as("admissions").get("/download").status_code, 200)

    def test_changes_survive_a_restart(self):
        self.save(self.grid_with(marketing=((), ("todo",))))
        db_module.init_db()
        app_module.reload_role_access()
        self.assertEqual(self._client_logged_in_as("marketing").get("/todo").status_code, 403)


class CacheTests(AccessRouteTestCase):
    def test_a_change_made_behind_the_apps_back_is_picked_up_after_the_refresh_interval(self):
        marketing = self._client_logged_in_as("marketing")
        self.assertEqual(marketing.get("/todo").status_code, 200)
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute("UPDATE role_access SET allowed = 0 WHERE role='marketing' AND permission='todo'")
        conn.commit()
        conn.close()
        self.assertEqual(marketing.get("/todo").status_code, 200, "cached until the interval passes")
        app_module._access_cache["loaded_at"] -= app_module.ACCESS_REFRESH_SECONDS + 1
        self.assertEqual(marketing.get("/todo").status_code, 403, "re-read after the interval")

    def test_if_the_refresh_fails_the_last_known_grid_stays_in_force(self):
        self.save(self.grid_with(marketing=((), ("todo",))))
        marketing = self._client_logged_in_as("marketing")
        app_module._access_cache["loaded_at"] -= app_module.ACCESS_REFRESH_SECONDS + 1
        with mock.patch.object(app_module, "load_access", side_effect=sqlite3.OperationalError("locked")):
            self.assertEqual(marketing.get("/todo").status_code, 403, "still blocked, not suddenly open")
            self.assertEqual(marketing.get("/consultants").status_code, 200)

    def test_pages_do_not_open_an_extra_database_connection_for_authorization(self):
        from tests.connection_tracking import ConnectionTracker
        tracker = ConnectionTracker(db_module)
        tracker.install()
        self.addCleanup(tracker.uninstall)
        tracker.reset()
        self._client_logged_in_as("marketing").get("/todo")
        self.assertEqual(tracker.opened, 1, "only the page's own connection")


if __name__ == "__main__":
    unittest.main()
