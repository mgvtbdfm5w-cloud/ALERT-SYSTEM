import unittest

from colors import UNASSIGNED_COLOR, assign_categorical_colors


class AssignCategoricalColorsTests(unittest.TestCase):
    def test_unassigned_always_gets_the_neutral_grey(self):
        colors = assign_categorical_colors(["Alex", "Unassigned", "John"])
        self.assertEqual(colors[1], UNASSIGNED_COLOR)

    def test_real_values_get_distinct_palette_colors_in_order(self):
        colors = assign_categorical_colors(["Alex", "John"])
        self.assertNotEqual(colors[0], colors[1])
        self.assertNotIn(UNASSIGNED_COLOR, colors)

    def test_same_input_order_always_produces_the_same_colors(self):
        names = ["Alex", "John", "Unassigned", "Zoe"]
        self.assertEqual(assign_categorical_colors(names), assign_categorical_colors(names))

    def test_cycles_when_more_names_than_palette_entries(self):
        from colors import CATEGORICAL_PALETTE

        names = [f"Person{i}" for i in range(len(CATEGORICAL_PALETTE) + 2)]
        colors = assign_categorical_colors(names)
        self.assertEqual(colors[0], colors[len(CATEGORICAL_PALETTE)])

    def test_empty_list_returns_empty_list(self):
        self.assertEqual(assign_categorical_colors([]), [])


if __name__ == "__main__":
    unittest.main()
