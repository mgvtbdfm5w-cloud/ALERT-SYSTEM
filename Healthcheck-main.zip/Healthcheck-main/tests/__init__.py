import os
import sys

# Make the project root importable regardless of the working directory the
# test runner was invoked from (e.g. `python -m unittest discover -s tests`
# run from a different cwd), so `import dateutils`, `import healthcheck`,
# etc. always resolve to the top-level modules rather than needing a
# separately installed package.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
