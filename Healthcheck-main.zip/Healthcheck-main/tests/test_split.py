"""The Split page: Paid Leads vs Non Paid by Office and Consultant - leads
allocated, then applications, then enrolled, each as Paid / Non Paid / Total.

Pure builder tests, then route tests through the real upload/lookups routes."""

import io
import re
import unittest

from flask import template_rendered

from leads_dashboard import build_month_summary, build_split_report, is_paid_ad_lead
from tests.flask_test_support import IsolatedAppTestCase, app_module, extract_token
from tests.test_allocation import captured, lead, leads_book
from tests.test_upload_atomicity import book, row as app_row

OFFICES = {"mel": "OXF", "hannah": "OXF", "kian": "MAN", "raymond": "LON"}
MEASURES = ("leads", "applications", "enrolled")


def lead_row(consultant, stage="01 - New Lead", source="Paid Ad", code=""):
    return {"Consultant": consultant, "Stage": stage, "Lead Source": source, "PES Code": code}


def triple(figures):
    """{"leads": (paid, non paid, total), ...}"""
    return {m: (figures[m]["paid"], figures[m]["non_paid"], figures[m]["total"]) for m in MEASURES}


def by_office(report):
    return {g["office"]: {r["name"]: triple(r["figures"]) for r in g["rows"]} for g in report["groups"]}


class BuilderTests(unittest.TestCase):
    def test_paid_ad_is_paid_and_every_other_lead_source_is_non_paid(self):
        rows = [lead_row("Mel", source="Paid Ad"), lead_row("Mel", source=" paid ad "), lead_row("Mel", source="Agent"),
                lead_row("Mel", source="Inbound Call"), lead_row("Mel", source=""), lead_row("Mel", source=None), lead_row("Mel", source="Paid Ads")]
        figures = build_split_report(rows, OFFICES)["groups"][0]["rows"][0]["figures"]
        self.assertEqual(triple(figures)["leads"], (2, 5, 7))

    def test_applications_are_applied_enrolled_and_applied_lost_only(self):
        stages = ["01 - New Lead", "02 - Qualified", "03 - Documents", "04 - Applied", "05 - Enrolled", "06 - Applied Lost",
                  "07 - Future Intake", "10 - Disqualified", "", "weird"]
        rows = [lead_row("Mel", stage) for stage in stages] + [lead_row("Mel", stage, source="Agent") for stage in stages]
        figures = triple(build_split_report(rows, OFFICES)["figures"])
        self.assertEqual(figures["leads"], (10, 10, 20))
        self.assertEqual(figures["applications"], (3, 3, 6))

    def test_enrolled_is_the_stage_or_an_enrolled_student_code(self):
        rows = [lead_row("Mel", "05 - Enrolled", code="A1"),                        # by stage
                lead_row("Mel", "01 - New Lead", code="B2"),                        # by code, stage never moved
                lead_row("Mel", "01 - New Lead", code="C3"),                        # not enrolled
                lead_row("Mel", "01 - New Lead", source="Agent", code="B2"),
                lead_row("Mel", "01 - New Lead", code="")]                          # blank code never matches
        figures = triple(build_split_report(rows, OFFICES, enrolled_student_codes={"B2", ""})["figures"])
        self.assertEqual(figures["enrolled"], (2, 1, 3))
        self.assertEqual(figures["applications"], (1, 0, 1), "an enrolled-by-code lead is not an application unless its stage says so")

    def test_every_total_is_paid_plus_non_paid_and_every_group_is_the_sum_of_its_rows(self):
        rows = [lead_row(c, s, src, code) for c in ("Mel", "Hannah", "Kian", "Raymond", "Newbie", "")
                for s in ("01 - New Lead", "04 - Applied", "05 - Enrolled", "06 - Applied Lost") for src in ("Paid Ad", "Agent") for code in ("", "E9")]
        report = build_split_report(rows, OFFICES, {"raymond"}, {"E9"})
        everything = [report["figures"]] + [g["figures"] for g in report["groups"]] + [r["figures"] for g in report["groups"] for r in g["rows"]]
        for figures in everything:
            for m in MEASURES:
                self.assertEqual(figures[m]["paid"] + figures[m]["non_paid"], figures[m]["total"])
        for m in MEASURES:
            for kind in ("paid", "non_paid", "total"):
                self.assertEqual(sum(g["figures"][m][kind] for g in report["groups"]), report["figures"][m][kind])
                for g in report["groups"]:
                    self.assertEqual(sum(r["figures"][m][kind] for r in g["rows"]), g["figures"][m][kind])
        self.assertEqual(report["figures"]["leads"]["total"], len(rows))

    def test_it_agrees_with_the_leads_dashboard_summary(self):
        rows = [lead_row("Mel", "04 - Applied"), lead_row("Hannah", "05 - Enrolled", "Agent"), lead_row("Kian", "01 - New Lead", code="E1"),
                lead_row("", "06 - Applied Lost"), lead_row("Newbie", "02 - Qualified", "Agent")]
        summary = build_month_summary(rows, {"E1"})
        figures = build_split_report(rows, OFFICES, enrolled_student_codes={"E1"})["figures"]
        self.assertEqual((figures["leads"]["total"], figures["applications"]["total"], figures["enrolled"]["total"]),
                         (summary["total"], summary["applications"], summary["enrolled"]))

    def test_offices_and_consultants_come_from_the_lookup_like_the_allocation_page(self):
        rows = [lead_row("Mel"), lead_row("mel"), lead_row("Hannah"), lead_row("Kian"), lead_row("Newbie"), lead_row(""), lead_row(None),
                lead_row("Raymond"), lead_row("Jon")]
        report = build_split_report(rows, {**OFFICES, "jon": "LON"}, {"raymond", "jon"})
        self.assertEqual({o: {n: t["leads"][2] for n, t in r.items()} for o, r in by_office(report).items()},
                         {"OXF": {"Mel": 2, "Hannah": 1}, "LON": {"Other": 2}, "MAN": {"Kian": 1}, "Other": {"Newbie": 1}, "Unassigned": {"Unassigned": 2}})

    def test_ranked_by_leads_allocated_with_name_as_the_tie_break(self):
        rows = [lead_row("Kian")] + [lead_row("Mel")] * 2 + [lead_row("Hannah")] * 2 + [lead_row("Raymond")]
        report = build_split_report(rows, OFFICES)
        self.assertEqual([g["office"] for g in report["groups"]], ["OXF", "LON", "MAN"])          # 4, then 1 and 1 alphabetically
        self.assertEqual([r["name"] for r in report["groups"][0]["rows"]], ["Hannah", "Mel"])

    def test_percent_paid_is_paid_over_total_rounded_half_up_and_none_when_there_is_nothing(self):
        def pct(paid, non_paid, measure="leads"):
            rows = [lead_row("Mel", source="Paid Ad")] * paid + [lead_row("Mel", source="Agent")] * non_paid
            return build_split_report(rows, OFFICES)["figures"][measure]["paid_pct"]
        self.assertEqual([pct(1, 2), pct(2, 1), pct(1, 7), pct(3, 0), pct(0, 3), pct(0, 0)], [33, 67, 13, 100, 0, None])
        report = build_split_report([lead_row("Mel", "04 - Applied"), lead_row("Mel", "01 - New Lead", "Agent")], OFFICES)
        self.assertEqual([report["figures"][m]["paid_pct"] for m in MEASURES], [50, 100, None])
        for figures in [report["groups"][0]["figures"], report["groups"][0]["rows"][0]["figures"]]:
            self.assertEqual([figures[m]["paid_pct"] for m in MEASURES], [50, 100, None])

    def test_empty_input(self):
        report = build_split_report([], OFFICES)
        self.assertEqual(report["groups"], [])
        self.assertEqual(triple(report["figures"]), {m: (0, 0, 0) for m in MEASURES})

    def test_the_input_is_not_modified(self):
        rows = [lead_row("Mel", "04 - Applied")]
        build_split_report(rows, OFFICES, {"mel"}, {"X"})
        self.assertEqual(rows, [lead_row("Mel", "04 - Applied")])

    def test_is_paid_ad_lead(self):
        self.assertTrue(is_paid_ad_lead({"Lead Source": " PAID AD "}))
        self.assertFalse(is_paid_ad_lead({"Lead Source": "Paid"}))
        self.assertFalse(is_paid_ad_lead({}))


LEADS = [
    lead("M1", "Mel X", "03/08/2026"),                                                  # paid, new
    lead("M2", "Mel X", "04/08/2026", "Applied"),                                       # paid, application
    lead("M3", "Mel X", "05/08/2026", "Applied", "Agent/Z"),                            # non paid, application
    lead("M4", "Mel X", "06/08/2026", source="Website/Organic"),                        # non paid, new
    lead("H1", "Hannah Y", "03/08/2026", "Enrolled Student"),                           # paid, enrolled by stage
    lead("H2", "Hannah Y", "04/08/2026", "Applied Lost", "Inbound Call/Phone"),         # non paid, application
    lead("K1", "Kian Q", "03/08/2026"),                                                 # paid, new
    lead("K2", "Kian Q", "04/08/2026", source="Agent/Z"),                               # non paid, enrolled by code
    lead("R1", "Raymond P", "03/08/2026", "Applied"),                                   # paid, application (Group as Other)
    lead("U1", "", "04/08/2026"),                                                       # paid, nobody allocated
    lead("S1", "Mel X", "02/09/2026"),                                                  # September
]
EXPECTED_AUGUST = {
    "OXF": {"Mel": {"leads": (2, 2, 4), "applications": (1, 1, 2), "enrolled": (0, 0, 0)},
            "Hannah": {"leads": (1, 1, 2), "applications": (1, 1, 2), "enrolled": (1, 0, 1)}},
    "MAN": {"Kian": {"leads": (1, 1, 2), "applications": (0, 0, 0), "enrolled": (0, 1, 1)}},
    "LON": {"Other": {"leads": (1, 0, 1), "applications": (1, 0, 1), "enrolled": (0, 0, 0)}},
    "Unassigned": {"Unassigned": {"leads": (1, 0, 1), "applications": (0, 0, 0), "enrolled": (0, 0, 0)}},
}
EXPECTED_AUGUST_TOTAL = {"leads": (6, 4, 10), "applications": (3, 2, 5), "enrolled": (1, 1, 2)}


class SplitRouteTests(IsolatedAppTestCase):
    def setUp(self):
        super().setUp()
        self.full = self._client_logged_in_as("full")
        self.upload("/leads/upload", leads_book(LEADS))
        apps = book([app_row(**{"Student Code": "K2", "Student Name": "Kian's lead", "Application Status": "Enrolled"})],
                    lookups={"status": [("Enrolled", "09-Enrolled")]})
        self.upload("/upload", apps)
        for consultant, office, other in (("Mel", "OXF", False), ("Hannah", "OXF", False), ("Kian", "MAN", False), ("Raymond", "LON", True)):
            data = {"csrf_token": self.token(), "source_value": consultant, "mapped_value": office}
            if other:
                data["group_as_other"] = "on"
            self.assertEqual(self.full.post("/admin/lookups/sales_office/add", data=data).status_code, 302)

    def token(self):
        return extract_token(self.full.get("/login").get_data(as_text=True))

    def upload(self, path, data):
        r = self.full.post(path, data={"csrf_token": self.token(), "excel_file": (io.BytesIO(data), "f.xlsx")}, content_type="multipart/form-data")
        self.assertEqual(r.status_code, 302)

    def page(self, query="?month=2026-08", client=None):
        with captured() as rendered:
            r = (client or self.full).get("/split" + query)
        self.assertEqual(r.status_code, 200)
        context = next(c for name, c in rendered if name == "split.html")
        return r.get_data(as_text=True), context

    def drawn(self, html):
        """{section title: [(label, [paid, not paid, total, "% Paid" as printed])]} for the table as printed:
        each row's twelve figure cells split into its Leads, Apps and Enrolled groups of four."""
        table = html[html.index('<table class="split-table">'):]
        body = table[table.index("<tbody>"):table.index("</tbody>")]
        sections = {"Leads": [], "Apps": [], "Enrolled": []}
        for tr in re.findall(r'<tr class="split-(?:office|consultant)-row">.*?</tr>|<tr class="grand-total-row">.*?</tr>', body, re.S):
            label = re.search(r'split-name[^>]*>(?:<span[^>]*>)?([^<]+)<', tr).group(1)
            cells = re.findall(r'<td class="split-(?!name)[^>]*>([^<]+)</td>', tr)
            self.assertEqual(len(cells), 12, label)
            for i, title in enumerate(sections):
                group = cells[i * 4:i * 4 + 4]
                sections[title].append((label, [int(n.replace(",", "")) for n in group[:3]] + [group[3]]))
        return sections

    def test_the_figures_are_right_for_the_month(self):
        _, context = self.page()
        self.assertEqual(by_office(context["report"]), {o: {n: {m: t[m] for m in MEASURES} for n, t in rows.items()} for o, rows in EXPECTED_AUGUST.items()})
        self.assertEqual(triple(context["report"]["figures"]), EXPECTED_AUGUST_TOTAL)

    def test_the_table_prints_exactly_those_figures_in_three_sections(self):
        html, context = self.page()
        report = context["report"]

        def printed(counts):
            return [counts["paid"], counts["non_paid"], counts["total"], "-" if counts["paid_pct"] is None else f"{counts['paid_pct']}%"]

        expected = {}
        for measure, title in (("leads", "Leads"), ("applications", "Apps"), ("enrolled", "Enrolled")):
            rows = []
            for g in report["groups"]:
                rows.append((g["office"], printed(g["figures"][measure])))
                rows.extend((r["name"], printed(r["figures"][measure])) for r in g["rows"])
            rows.append(("Total", printed(report["figures"][measure])))
            expected[title] = rows
        drawn = self.drawn(html)
        self.assertEqual(drawn, expected)
        self.assertEqual(list(drawn), ["Leads", "Apps", "Enrolled"], "in this order")
        self.assertEqual([label for label, _ in drawn["Leads"]][:3], ["OXF", "Mel", "Hannah"])

    def test_the_percent_paid_column_is_right_for_the_month(self):
        html, _ = self.page()
        drawn = {title: dict(rows) for title, rows in self.drawn(html).items()}
        pct = lambda title, label: drawn[title][label][3]
        self.assertEqual([pct("Leads", l) for l in ("OXF", "Mel", "Hannah", "MAN", "Other", "Unassigned", "Total")],
                         ["50%", "50%", "50%", "50%", "100%", "100%", "60%"])
        self.assertEqual([pct("Apps", l) for l in ("OXF", "Kian", "Other", "Total")], ["50%", "-", "100%", "60%"])
        self.assertEqual([pct("Enrolled", l) for l in ("OXF", "Mel", "Hannah", "Kian", "Total")], ["100%", "-", "100%", "0%", "50%"])

    def test_leads_apps_and_enrolled_sit_side_by_side_each_with_paid_not_paid_total_percent_paid(self):
        html, _ = self.page()
        head = html[html.index("<thead>"):html.index("</thead>")]
        text = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", head)).strip()
        self.assertEqual(text, "Consultant Leads Apps Enrolled" + " Paid Not Paid Total % Paid" * 3)
        self.assertEqual(re.findall(r'<th colspan="4"[^>]*>(\w+)</th>', head), ["Leads", "Apps", "Enrolled"])
        self.assertEqual(html.count("<tbody"), 1, "one body: the groups are columns, not stacked sections")
        self.assertEqual(html.count('class="split-office-row"'), 4, "each Office is listed once")
        for old in ("Leads Allocated", "Applications</th>", "Non Paid", ">Paid Leads</th>", "split-section"):
            self.assertNotIn(old, html, old)

    def test_there_is_no_explanatory_note_under_the_table(self):
        html, _ = self.page()
        for text in ("Paid is leads with the Lead Source", "Not Paid is every other Lead Source", "% Paid is Paid as a share", "as on the Leads Dashboard", 'class="hint'):
            self.assertNotIn(text, html, text)

    def test_the_table_uses_its_own_plain_styling_not_the_spreadsheet_grid(self):
        html, _ = self.page()
        self.assertNotIn("pipeline-table", html)
        self.assertEqual(html.count('class="split-office-chip"'), 4, "each Office is a chip like the charts' Office labels")

    def test_it_ties_to_the_leads_dashboard_cards_for_the_same_month(self):
        _, context = self.page()
        with captured() as rendered:
            self.assertEqual(self.full.get("/leads-dashboard?month=2026-08").status_code, 200)
        summary = next(c for name, c in rendered if name == "leads_dashboard.html")["month_summary"]
        figures = context["report"]["figures"]
        self.assertEqual((figures["leads"]["total"], figures["applications"]["total"], figures["enrolled"]["total"]),
                         (summary["total"], summary["applications"], summary["enrolled"]))

    def test_the_month_filter(self):
        html, context = self.page("?month=2026-09")
        self.assertEqual(by_office(context["report"]), {"OXF": {"Mel": {"leads": (1, 0, 1), "applications": (0, 0, 0), "enrolled": (0, 0, 0)}}})
        self.assertIn('<option value="2026-09" selected>', html)

    def test_defaults_to_the_latest_month_and_ignores_a_bad_month(self):
        for query in ("", "?month=garbage", "?month=2026-13", "?month=%3Cscript%3E"):
            html, context = self.page(query)
            self.assertEqual(context["selected_key"], "2026-09", query)
            self.assertNotIn("<script>", html.split("<main")[1].split("</main>")[0].replace("<script src", ""))

    def test_a_month_with_a_single_lead_is_one_office_one_consultant_and_a_total(self):
        self.upload("/leads/upload", leads_book([lead("A1", "Mel X", "05/10/2026")]))
        html, context = self.page("?month=2026-10")
        self.assertEqual(by_office(context["report"]), {"OXF": {"Mel": {"leads": (1, 0, 1), "applications": (0, 0, 0), "enrolled": (0, 0, 0)}}})
        self.assertEqual([[label for label, _ in rows] for rows in self.drawn(html).values()], [["OXF", "Mel", "Total"]] * 3)

    def test_with_no_leads_file_there_is_a_friendly_message(self):
        import sqlite3
        from tests.flask_test_support import db_module
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute("DELETE FROM active_leads_dataset")
        conn.commit()
        conn.close()
        r = self.full.get("/split")
        self.assertEqual(r.status_code, 200)
        self.assertIn("No active Leads dataset yet.", r.get_data(as_text=True))

    def test_without_an_applications_file_the_page_still_works_and_nothing_is_enrolled_by_code(self):
        import sqlite3
        from tests.flask_test_support import db_module
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute("DELETE FROM active_dataset")
        conn.commit()
        conn.close()
        _, context = self.page()
        self.assertEqual(context["report"]["figures"]["enrolled"]["total"], 1, "only H1, enrolled by its stage")

    def test_the_button_sits_next_to_allocation_on_the_leads_dashboard(self):
        html = self.full.get("/leads-dashboard?month=2026-08").get_data(as_text=True)
        alloc, split = html.index('href="/allocation"'), html.index('href="/split"')
        self.assertLess(alloc, split)
        self.assertLess(split - alloc, 200, "the two buttons are adjacent")
        self.assertIn(">Split</a>", html)

    def test_every_role_sees_the_button_and_can_open_the_page(self):
        for role in ("full", "admissions", "consultants", "marketing"):
            client = self._client_logged_in_as(role)
            self.assertIn('href="/split"', client.get("/leads-dashboard?month=2026-08").get_data(as_text=True), role)
            self.assertEqual(client.get("/split").status_code, 200, role)

    def test_login_is_required(self):
        r = app_module.app.test_client().get("/split")
        self.assertEqual(r.status_code, 302)
        self.assertIn("/login", r.headers["Location"])

    def test_no_money_on_the_page(self):
        html, _ = self.page()
        for text in ("£", "Revenue", "Ad Spend", "spend"):
            self.assertNotIn(text, html, text)


if __name__ == "__main__":
    unittest.main()
