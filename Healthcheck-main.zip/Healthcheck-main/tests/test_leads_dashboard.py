import unittest

from leads_dashboard import (
    build_lead_source_report,
    build_lead_source_summary,
    build_month_summary,
    filter_by_creation_month,
)


def _row(source=None, sub_source=None, stage="01 - New Lead", **extra):
    row = {"Lead Source": source, "Sub Source": sub_source, "Stage": stage}
    row.update(extra)
    return row


def _segment_map(row):
    """{stage: count} for a chart row's segments, for easy assertions."""
    return {seg["stage"]: seg["count"] for seg in row["segments"]}


class FilterByCreationMonthTests(unittest.TestCase):
    def test_matches_year_and_month(self):
        rows = [_row(**{"Creation Date": "2026-09-11"})]
        self.assertEqual(filter_by_creation_month(rows, 2026, 9), rows)

    def test_excludes_other_months(self):
        rows = [_row(**{"Creation Date": "2026-08-11"})]
        self.assertEqual(filter_by_creation_month(rows, 2026, 9), [])

    def test_excludes_other_years(self):
        rows = [_row(**{"Creation Date": "2025-09-11"})]
        self.assertEqual(filter_by_creation_month(rows, 2026, 9), [])

    def test_blank_or_unparseable_creation_date_is_excluded(self):
        rows = [_row(**{"Creation Date": None}), _row(**{"Creation Date": ""})]
        self.assertEqual(filter_by_creation_month(rows, 2026, 9), [])


class EmptyReportTests(unittest.TestCase):
    def test_empty_rows_produces_an_empty_report_not_a_crash(self):
        report = build_lead_source_report([])
        self.assertEqual(report["total"], 0)
        self.assertEqual(report["source_groups"], [])


class GroupingTests(unittest.TestCase):
    def setUp(self):
        self.rows = [
            _row(source="Paid Ad", sub_source="Facebook"),
            _row(source="Paid Ad", sub_source="Facebook"),
            _row(source="Paid Ad", sub_source="Instagram"),
            _row(source="Staff Referral", sub_source="Kesh Boodhoo"),
        ]
        self.report = build_lead_source_report(self.rows)

    def test_total_counts_every_row(self):
        self.assertEqual(self.report["total"], 4)

    def test_source_group_totals(self):
        totals = {g["source"]: g["total"] for g in self.report["source_groups"]}
        self.assertEqual(totals, {"Paid Ad": 3, "Staff Referral": 1})

    def test_source_total_equals_sum_of_its_sub_source_rows(self):
        for group in self.report["source_groups"]:
            self.assertEqual(group["total"], sum(r["count"] for r in group["rows"]))

    def test_source_groups_ranked_by_total_descending(self):
        names = [g["source"] for g in self.report["source_groups"]]
        self.assertEqual(names, ["Paid Ad", "Staff Referral"])

    def test_sub_source_rows_within_a_group_ranked_by_count_descending(self):
        paid_ad = next(g for g in self.report["source_groups"] if g["source"] == "Paid Ad")
        sub_sources = [r["name"] for r in paid_ad["rows"]]
        self.assertEqual(sub_sources, ["Facebook", "Instagram"])


class TieBreakTests(unittest.TestCase):
    def test_source_tie_breaks_alphabetically(self):
        rows = [_row(source="Zed Source", sub_source="X"), _row(source="Amy Source", sub_source="Y")]
        report = build_lead_source_report(rows)
        names = [g["source"] for g in report["source_groups"]]
        self.assertEqual(names, ["Amy Source", "Zed Source"])

    def test_sub_source_tie_breaks_alphabetically(self):
        rows = [_row(source="Source", sub_source="Zed Sub"), _row(source="Source", sub_source="Amy Sub")]
        report = build_lead_source_report(rows)
        sub_sources = [r["name"] for r in report["source_groups"][0]["rows"]]
        self.assertEqual(sub_sources, ["Amy Sub", "Zed Sub"])


class BlankSourceAndSubSourceTests(unittest.TestCase):
    def test_blank_source_folds_into_unassigned(self):
        rows = [_row(source="", sub_source="whatever"), _row(source=None, sub_source="whatever")]
        report = build_lead_source_report(rows)
        names = [g["source"] for g in report["source_groups"]]
        self.assertEqual(names, ["Unassigned"])
        self.assertEqual(report["source_groups"][0]["total"], 2)

    def test_blank_sub_source_folds_into_unassigned(self):
        rows = [_row(source="Paid Ad", sub_source=""), _row(source="Paid Ad", sub_source=None)]
        report = build_lead_source_report(rows)
        sub_sources = [r["name"] for r in report["source_groups"][0]["rows"]]
        self.assertEqual(sub_sources, ["Unassigned"])
        self.assertEqual(report["source_groups"][0]["rows"][0]["count"], 2)


class StageSegmentTests(unittest.TestCase):
    """Each chart row is a segmented bar broken down by Stage
    (leads.LEAD_STAGE_COLORS), scaled against the busiest Sub Source
    total across the whole report."""

    def test_a_row_with_one_stage_has_one_segment(self):
        rows = [_row(source="Paid Ad", sub_source="Facebook", stage="01 - New Lead")] * 3
        report = build_lead_source_report(rows)
        row = report["source_groups"][0]["rows"][0]
        self.assertEqual(_segment_map(row), {"01 - New Lead": 3})

    def test_a_row_split_across_stages_has_one_segment_per_stage(self):
        rows = (
            [_row(source="Paid Ad", sub_source="Facebook", stage="01 - New Lead")] * 2
            + [_row(source="Paid Ad", sub_source="Facebook", stage="02 - Qualified")]
        )
        report = build_lead_source_report(rows)
        row = report["source_groups"][0]["rows"][0]
        self.assertEqual(_segment_map(row), {"01 - New Lead": 2, "02 - Qualified": 1})

    def test_segment_widths_sum_to_the_rows_own_share_of_the_page_max(self):
        rows = (
            [_row(source="Big", sub_source="X", stage="01 - New Lead")] * 8
            + [_row(source="Big", sub_source="X", stage="02 - Qualified")] * 2
        )
        report = build_lead_source_report(rows)
        row = report["source_groups"][0]["rows"][0]
        total_width = sum(seg["width_pct"] for seg in row["segments"])
        self.assertAlmostEqual(total_width, 100.0)  # this is the page's only/busiest row

    def test_each_segment_carries_its_stage_colour(self):
        rows = [_row(source="Paid Ad", sub_source="Facebook", stage="02 - Qualified")]
        report = build_lead_source_report(rows)
        segment = report["source_groups"][0]["rows"][0]["segments"][0]
        self.assertEqual(segment["color"], "#2563eb")

    def test_blank_or_unrecognised_stage_becomes_one_grey_unassigned_segment(self):
        rows = [
            _row(source="Paid Ad", sub_source="Facebook", stage=""),
            _row(source="Paid Ad", sub_source="Facebook", stage="Not A Real Stage"),
        ]
        report = build_lead_source_report(rows)
        row = report["source_groups"][0]["rows"][0]
        self.assertEqual(_segment_map(row), {"Unassigned": 2})
        self.assertEqual(row["segments"][0]["color"], "#9aa4b2")


class BarWidthTests(unittest.TestCase):
    def test_row_width_scales_against_the_busiest_row_on_the_whole_page_not_just_its_group(self):
        rows = (
            [_row(source="Big", sub_source="A")] * 10
            + [_row(source="Small", sub_source="B")] * 2
        )
        report = build_lead_source_report(rows)
        by_source = {g["source"]: g for g in report["source_groups"]}

        big_row = by_source["Big"]["rows"][0]
        self.assertAlmostEqual(sum(s["width_pct"] for s in big_row["segments"]), 100.0)

        small_row = by_source["Small"]["rows"][0]
        self.assertAlmostEqual(sum(s["width_pct"] for s in small_row["segments"]), 20.0)  # 2/10 * 100

    def test_zero_rows_does_not_divide_by_zero(self):
        report = build_lead_source_report([])
        self.assertEqual(report["source_groups"], [])


class BuildLeadSourceSummaryTests(unittest.TestCase):
    """The high-level, no-Sub-Source-breakdown chart shown above the
    detailed Lead Source/Sub Source chart - also segmented by Stage."""

    def test_one_row_per_lead_source_with_its_group_total(self):
        rows = (
            [_row(source="Paid Ad", sub_source="Facebook")] * 3
            + [_row(source="Paid Ad", sub_source="Instagram")] * 2
            + [_row(source="Staff Referral", sub_source="Kesh Boodhoo")]
        )
        report = build_lead_source_report(rows)
        summary = build_lead_source_summary(report)
        by_name = {r["name"]: r["count"] for r in summary}
        self.assertEqual(by_name, {"Paid Ad": 5, "Staff Referral": 1})

    def test_same_order_as_the_detailed_report(self):
        rows = [_row(source="Small", sub_source="X")] + [_row(source="Big", sub_source="Y")] * 5
        report = build_lead_source_report(rows)
        summary = build_lead_source_summary(report)
        self.assertEqual([r["name"] for r in summary], ["Big", "Small"])

    def test_stage_counts_are_aggregated_across_sub_sources(self):
        rows = (
            [_row(source="Paid Ad", sub_source="Facebook", stage="01 - New Lead")] * 2
            + [_row(source="Paid Ad", sub_source="Instagram", stage="01 - New Lead")]
            + [_row(source="Paid Ad", sub_source="Instagram", stage="02 - Qualified")]
        )
        report = build_lead_source_report(rows)
        summary = build_lead_source_summary(report)
        paid_ad = next(r for r in summary if r["name"] == "Paid Ad")
        self.assertEqual(_segment_map(paid_ad), {"01 - New Lead": 3, "02 - Qualified": 1})

    def test_width_scales_against_the_busiest_lead_source_not_any_sub_source(self):
        # "Big" Lead Source has one Sub Source of count 10 (the busiest
        # single Sub Source anywhere). "Medium" has two Sub Sources
        # totalling 8 (5 + 3) - no single Sub Source of Medium's own beats
        # 5, but its GROUP total (8) should still be what this summary
        # chart's width is based on, not any one Sub Source's count.
        rows = (
            [_row(source="Big", sub_source="A")] * 10
            + [_row(source="Medium", sub_source="B")] * 5
            + [_row(source="Medium", sub_source="C")] * 3
        )
        report = build_lead_source_report(rows)
        summary = build_lead_source_summary(report)
        by_name = {r["name"]: sum(s["width_pct"] for s in r["segments"]) for r in summary}
        self.assertAlmostEqual(by_name["Big"], 100.0)
        self.assertAlmostEqual(by_name["Medium"], 80.0)  # 8/10 * 100, not 5/10=50

    def test_zero_rows_does_not_divide_by_zero(self):
        report = build_lead_source_report([])
        self.assertEqual(build_lead_source_summary(report), [])


class RowApplicationsPctTests(unittest.TestCase):
    """Applications as a % of Total, shown next to each row on both
    Leads Dashboard charts - build_lead_source_report()'s own Sub Source
    rows, and build_lead_source_summary()'s Lead Source rows built from
    them."""

    def test_sub_source_row_applications_pct(self):
        rows = (
            [_row(source="Paid Ad", sub_source="Facebook", stage="04 - Applied")] * 3
            + [_row(source="Paid Ad", sub_source="Facebook", stage="01 - New Lead")] * 7
        )
        report = build_lead_source_report(rows)
        row = report["source_groups"][0]["rows"][0]
        self.assertEqual(row["applications"], 3)
        self.assertEqual(row["applications_pct"], 30)  # 3/10 * 100

    def test_lead_source_summary_row_applications_pct(self):
        rows = (
            [_row(source="Paid Ad", sub_source="Facebook", stage="04 - Applied")] * 1
            + [_row(source="Paid Ad", sub_source="Instagram", stage="01 - New Lead")] * 3
        )
        report = build_lead_source_report(rows)
        summary = build_lead_source_summary(report)
        paid_ad = next(r for r in summary if r["name"] == "Paid Ad")
        self.assertEqual(paid_ad["applications_pct"], 25)  # 1/4 * 100


class BuildMonthSummaryTests(unittest.TestCase):
    """The Leads Dashboard's top summary cards - Total Uploaded This
    Month, Prospecting (01-03), Applications (04-06)."""

    def _row(self, stage):
        return {"Stage": stage}

    def test_total_counts_every_row_regardless_of_stage(self):
        rows = [self._row("01 - New Lead"), self._row("10 - Disqualified"), self._row("")]
        self.assertEqual(build_month_summary(rows)["total"], 3)

    def test_prospecting_is_new_lead_plus_qualified_plus_documents(self):
        rows = (
            [self._row("01 - New Lead")] * 3
            + [self._row("02 - Qualified")] * 2
            + [self._row("03 - Documents")]
            + [self._row("04 - Applied")]
        )
        summary = build_month_summary(rows)
        self.assertEqual(summary["prospecting"], 6)

    def test_applications_is_applied_plus_enrolled_plus_applied_lost(self):
        rows = (
            [self._row("04 - Applied")] * 2
            + [self._row("05 - Enrolled")]
            + [self._row("06 - Applied Lost")] * 3
            + [self._row("01 - New Lead")]
        )
        summary = build_month_summary(rows)
        self.assertEqual(summary["applications"], 6)

    def test_stages_outside_both_buckets_count_in_total_only(self):
        rows = [self._row("07 - Future Intake"), self._row("10 - Disqualified"), self._row("Not A Stage")]
        summary = build_month_summary(rows)
        self.assertEqual(summary["total"], 3)
        self.assertEqual(summary["prospecting"], 0)
        self.assertEqual(summary["applications"], 0)

    def test_empty_rows_is_all_zero(self):
        summary = build_month_summary([])
        self.assertEqual(
            summary,
            {"total": 0, "prospecting": 0, "applications": 0, "applications_pct": None,
             "enrolled": 0, "enrolled_pct": None},
        )

    def test_applications_pct_is_applications_over_total(self):
        rows = (
            [self._row("04 - Applied")] * 2
            + [self._row("05 - Enrolled")]
            + [self._row("01 - New Lead")] * 7
        )
        summary = build_month_summary(rows)
        self.assertEqual(summary["applications_pct"], 30)  # 3/10 * 100

    def test_applications_pct_is_none_when_total_is_zero(self):
        self.assertIsNone(build_month_summary([])["applications_pct"])


if __name__ == "__main__":
    unittest.main()
