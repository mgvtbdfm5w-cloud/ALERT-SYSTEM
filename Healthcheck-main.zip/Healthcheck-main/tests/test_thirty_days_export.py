"""The 30 Day Offers Accepted page's Download Data button: an Excel sheet of the Eligible
applications only (it is used to check commission), sorted by Application Manager, for the
"Submitted to uni in" month chosen on the page."""

import io
import unittest
from datetime import date

import openpyxl

from bonus import build_bonus_chart
from tests.flask_test_support import app_module
from tests.test_bonus import PageBase, TODAY, d, in_2027, sample
from thirty_days_export import EXPORT_COLUMNS, SHEET_TITLE, build_thirty_days_export, eligible_rows, export_filename

HEADER = ["Application Manager", "Office", "PES Code", "Student Name", "University", "Course", "Intake", "Consultant", "Application Status",
          "Date Submitted to University", "Offer Accepted Date", "Days to Offer"]


def load(buffer):
    return openpyxl.load_workbook(buffer).active


class BuilderTests(unittest.TestCase):
    def sheet(self, rows=None, month_label=None):
        chart = build_bonus_chart(sample() if rows is None else rows, TODAY)
        return load(build_thirty_days_export(chart, TODAY, month_label))

    def data_rows(self, ws):
        return list(ws.iter_rows(min_row=3, values_only=True))

    def test_the_columns(self):
        self.assertEqual(EXPORT_COLUMNS, HEADER)
        ws = self.sheet()
        self.assertEqual([c.value for c in ws[2]], HEADER)
        self.assertEqual(ws.title, "30 Day Offers Accepted")
        self.assertEqual(ws.freeze_panes, "A3")

    def test_only_eligible_applications_are_in_it(self):
        codes = [r[2] for r in self.data_rows(self.sheet())]
        self.assertEqual(sorted(codes), ["A1", "A6", "B3"], "not the Open (A3, B1, C1) or Missed (A2, A4, A5, B2) ones")

    def test_sorted_by_application_manager_then_submitted_date(self):
        rows = self.data_rows(self.sheet())
        self.assertEqual([(r[0], r[2]) for r in rows], [("Alice", "A6"), ("Alice", "A1"), ("Bob", "B3")], "Alice's A6 was submitted before her A1")

    def test_managers_run_a_to_z_ignoring_case_with_unassigned_last(self):
        rows = [in_2027("1", sub=d(40), accepted=d(30), manager="zed"), in_2027("2", sub=d(40), accepted=d(30), manager="Bea"), in_2027("3", sub=d(40), accepted=d(30), manager=""),
                in_2027("4", sub=d(40), accepted=d(30), manager="Al"), in_2027("5", sub=d(40), accepted=d(30), manager="bea"), in_2027("6", sub=d(40), accepted=d(30), manager="alan")]
        managers = [r[0] for r in self.data_rows(self.sheet(rows))]
        self.assertEqual(managers, ["Al", "alan", "Bea", "bea", "zed", "Unassigned"])

    def test_the_figures_dates_and_days_to_offer(self):
        row = {r[2]: r for r in self.data_rows(self.sheet())}["A1"]
        self.assertEqual(row[:9], ("Alice", "EG", "A1", "Student A1", "Uni A", None, "September 2027", "Gina", "05-Assessment"))
        self.assertEqual((row[9].date(), row[10].date(), row[11]), (date.fromisoformat(d(17)), date.fromisoformat(d(2)), 15))
        ws = self.sheet()
        self.assertEqual(ws["J3"].number_format, "DD/MM/YYYY")
        self.assertEqual(ws["K3"].number_format, "DD/MM/YYYY")
        self.assertEqual({r[2]: r[11] for r in self.data_rows(ws)}, {"A1": 15, "A6": 30, "B3": 15}, "exactly 30 days counts")

    def test_the_title_row_names_the_sheet_the_month_and_the_date(self):
        self.assertEqual(self.sheet()["A1"].value, "30 Day Offers Accepted - Eligible applications - 15/01/2027")
        self.assertEqual(self.sheet(month_label="December 2026")["A1"].value, "30 Day Offers Accepted - Eligible applications - submitted in December 2026 - 15/01/2027")

    def test_nothing_eligible_is_still_a_valid_sheet_with_just_the_headings(self):
        ws = self.sheet([in_2027("1", sub=d(5))])
        self.assertEqual([c.value for c in ws[2]], HEADER)
        self.assertEqual(self.data_rows(ws), [])
        self.assertEqual(self.data_rows(self.sheet([])), [])

    def test_text_that_looks_like_a_formula_is_stored_as_text(self):
        rows = [dict(in_2027("1", sub=d(40), accepted=d(30)), **{"Student Name": "=1+1"})]
        cell = self.sheet(rows)["D3"]
        self.assertEqual((cell.value, cell.data_type), ("=1+1", "s"))

    def test_the_input_is_not_modified(self):
        rows = sample()
        before = [dict(r) for r in rows]
        chart = build_bonus_chart(rows, TODAY)
        eligible_rows(chart)
        self.assertEqual(rows, before)

    def test_the_file_name(self):
        self.assertEqual(export_filename(date(2027, 1, 15)), "30_Day_Offers_Accepted_15-01-2027.xlsx")
        self.assertEqual(export_filename(date(2027, 1, 15), "October 2026"), "30_Day_Offers_Accepted_October2026_15-01-2027.xlsx")


class DownloadRouteTests(PageBase):
    def download(self, query="", client=None):
        return (client or self.full).get("/thirty-days/export" + ("?" + query if query else ""))

    def codes(self, query=""):
        response = self.download(query)
        self.assertEqual(response.status_code, 200, query)
        ws = load(io.BytesIO(response.data))
        return [r[2] for r in ws.iter_rows(min_row=3, values_only=True)]

    def test_the_button_is_on_the_page_and_follows_the_chosen_month(self):
        html, _ = self.page()
        self.assertRegex(html, r'<a class="download-link"\s+href="/thirty-days/export">Download Data</a>')
        html, _ = self.page("sub_month=2026-12")
        self.assertRegex(html, r'href="/thirty-days/export\?sub_month=2026-12">Download Data</a>')
        html, _ = self.page("sub_month=bogus")
        self.assertIn('href="/thirty-days/export">Download Data</a>', html)

    def test_the_download_is_an_excel_file_with_the_eligible_applications(self):
        response = self.download()
        self.assertEqual(response.mimetype, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        self.assertIn('attachment; filename=30_Day_Offers_Accepted_15-01-2027.xlsx', response.headers["Content-Disposition"])
        self.assertEqual(sorted(self.codes()), ["A1", "A6", "B3"])

    def test_it_holds_exactly_the_applications_the_chart_counts_as_eligible(self):
        for query in ("", "sub_month=2026-10", "sub_month=2026-11", "sub_month=2026-12", "sub_month=2027-01"):
            _, context = self.page(query)
            counted = sorted(r["Student Code"] for per in context["bonus_chart"]["managers"].values() for r in per["Eligible"])
            self.assertEqual(sorted(self.codes(query)), counted, query)

    def test_the_month_narrows_it_and_is_in_the_file_name(self):
        self.assertEqual(self.codes("sub_month=2026-12"), ["A1"])
        self.assertEqual(self.codes("sub_month=2026-11"), ["A6"])
        self.assertEqual(self.codes("sub_month=2026-10"), ["B3"])
        self.assertEqual(self.codes("sub_month=2027-01"), [])
        self.assertIn("30_Day_Offers_Accepted_December2026_15-01-2027.xlsx", self.download("sub_month=2026-12").headers["Content-Disposition"])
        self.assertNotIn("2026_15", self.download("sub_month=garbage").headers["Content-Disposition"])
        self.assertEqual(sorted(self.codes("sub_month=garbage")), ["A1", "A6", "B3"], "an unknown month means every month")

    def test_a_year_or_intake_in_the_address_makes_no_difference(self):
        self.assertEqual(sorted(self.codes("year=2026&intake=intake_01&intake_month=3")), ["A1", "A6", "B3"])

    def test_login_and_roles(self):
        anon = self.download(client=app_module.app.test_client())
        self.assertEqual(anon.status_code, 302)
        for role in ("admissions", "consultants", "marketing"):
            self.assertEqual(self.download(client=self._client_logged_in_as(role)).status_code, 200, role)

    def test_the_access_grid_download_switch_controls_the_button_and_the_file(self):
        from role_access import CONFIGURABLE_ROLES, PERMISSION_KEYS, default_allowed, field_name
        from tests.flask_test_support import extract_token
        keep = {(role, key) for role in CONFIGURABLE_ROLES for key in PERMISSION_KEYS if default_allowed(role, key)} - {("marketing", "download_exports")}
        token = extract_token(self.full.get("/login").get_data(as_text=True))
        self.full.post("/admin/access", data={"csrf_token": token, **{field_name(role, key): "on" for role, key in keep}})
        marketing = self._client_logged_in_as("marketing")
        self.assertEqual(self.download(client=marketing).status_code, 403)
        self.assertNotIn("/thirty-days/export", marketing.get("/thirty-days").get_data(as_text=True))
        self.assertEqual(marketing.get("/thirty-days").status_code, 200)
        self.assertEqual(self.download(client=self._client_logged_in_as("admissions")).status_code, 200)
        self.assertEqual(self.download().status_code, 200)

    def test_with_no_dataset_it_goes_back_to_the_page_with_a_message(self):
        import sqlite3
        from tests.flask_test_support import db_module
        conn = sqlite3.connect(db_module.DB_PATH)
        conn.execute("DELETE FROM active_dataset")
        conn.commit()
        conn.close()
        response = self.download()
        self.assertEqual((response.status_code, response.headers["Location"]), (302, "/thirty-days"))


if __name__ == "__main__":
    unittest.main()
