"""Healthcheck rule engine.

Each rule inspects one processed row (which also carries the original raw
source fields under row["_raw"]) and returns a plain-English message if it
finds a problem, or None if the row is fine. The To Do List is always the
live result of running every rule against the current active dataset - no
results are ever persisted, so there is nothing to go stale or need clearing.
"""

import logging
from datetime import date, timedelta

from dateutils import safe_date as _safe_date, today_uk as _today_uk
from offer_days import QUALIFYING_STATUSES as _OFFER_DAYS_QUALIFYING_STATUSES
from pipeline import STAGES as _PIPELINE_STAGES
from processing import parse_stage_length_days as _parse_stage_length_days

logger = logging.getLogger(__name__)


class HealthcheckRule:
    id = None
    name = None

    def evaluate(self, row):
        """Return a violation message string, or None if the row is fine."""
        raise NotImplementedError


class HealthcheckDatasetRule:
    """A rule that needs to see the whole active dataset at once, rather
    than one row in isolation - e.g. anything that compares records to each
    other (duplicates, cross-record consistency). Runs once per Healthcheck
    pass rather than once per row, and can raise zero, one, or several
    issues from that single pass.

    Kept as a separate interface from HealthcheckRule rather than forcing
    dataset-wide logic into the one-row-at-a-time shape - that would either
    require re-scanning the whole dataset on every single row (wasteful) or
    produce one issue per matching row instead of one issue per real-world
    problem (which is exactly what this shape exists to avoid).
    """

    id = None
    name = None

    def evaluate(self, rows):
        """Return an iterable of (student_code, message) tuples - zero or
        more issues found across the whole dataset."""
        raise NotImplementedError


class InvalidConsultantMappingRule(HealthcheckRule):
    id = "invalid_consultant_mapping"
    name = "Invalid Consultant Mapping"

    def evaluate(self, row):
        consultant = (row.get("Consultant") or "").strip()
        sales_office = (row.get("Sales Office") or "").strip()
        if consultant and not sales_office:
            return f'Consultant "{consultant}" has no valid Sales Office mapping'
        return None


class ApplicationManagerStillAdmissionsRule(HealthcheckRule):
    id = "application_manager_still_admissions"
    name = "Application Manager still set to Admissions"

    # "Admissions" is a holding/placeholder value for the Application field
    # (see pipeline.py's EXCLUDED_MANAGERS). Once a record reaches QA or any
    # later active stage it should have a real Application Manager, not
    # still be sitting under that placeholder. Derived from pipeline.STAGES
    # (the single source of truth for stage names) rather than a hardcoded
    # copy, so a future stage addition is picked up automatically instead
    # of silently passing this rule unflagged. "10-Lost" is the only stage
    # excluded - a lost application no longer needs a manager assigned.
    _FLAGGED_STATUSES = set(_PIPELINE_STAGES) - {"10-Lost"}

    def evaluate(self, row):
        application = (row.get("Application") or "").strip().lower()
        if application != "admissions":
            return None

        status = (row.get("Status") or "").strip()
        if status not in self._FLAGGED_STATUSES:
            return None

        return "Application Manager is still set to Admissions at this stage and needs to be assigned."


class MultipleAdmissionOfficersRule(HealthcheckRule):
    id = "multiple_admission_officers"
    name = "Multiple Admission Officers"

    _DELIMITERS = (",", ";", "&")

    def evaluate(self, row):
        raw = row.get("_raw") or {}
        admission_officer = raw.get("Admission Officer")
        if not admission_officer:
            return None
        value = str(admission_officer).strip()
        if not value:
            return None
        if any(d in value for d in self._DELIMITERS) or " and " in value.lower():
            return "Admission Officer contains multiple names. Only one Admission Officer is allowed."
        return None


# Records created on or before this date were migrated into the CRM and may
# legitimately have incomplete process dates, so date-completeness rules
# below only apply to records created after it.
DATE_COMPLETENESS_CUTOFF = date(2026, 7, 31)


class ApprovedMissingSubmittedToUniRule(HealthcheckRule):
    id = "approved_missing_submitted_to_uni"
    name = "Approved but no Submitted To Uni date"

    # Deliberately no Created-date cutoff (unlike QAPassedMissingDocsApprovedRule
    # below) - this is a legacy rule and must also catch records migrated into
    # the CRM before August 2026.
    def evaluate(self, row):
        sub_status = (row.get("Sub Status") or "").strip().lower()
        if sub_status != "approved":
            return None

        if _safe_date(row.get("Submitted To Uni")):
            return None

        return "Sub Status is Approved but no Submitted To Uni date is recorded."


class SubmittedToUniNotApprovedRule(HealthcheckRule):
    id = "submitted_to_uni_not_approved"
    name = "Submitted To Uni but not Approved"

    def evaluate(self, row):
        if not _safe_date(row.get("Submitted To Uni")):
            return None

        sub_status = (row.get("Sub Status") or "").strip().lower()
        if sub_status == "approved":
            return None

        return "Submitted To Uni date is recorded but Sub Status is not Approved."


class UnassignedApplicationManagerPreOfferRule(HealthcheckRule):
    id = "unassigned_application_manager_pre_offer"
    name = "Unassigned Application Manager (submitted, pre-offer)"

    # Same qualifying stages as the Offer Days dashboard's "Unassigned" group
    # (offer_days.QUALIFYING_STATUSES) - reused rather than duplicated so
    # this rule can never disagree with what that dashboard shows.
    def evaluate(self, row):
        status = row.get("Status") or ""
        if status not in _OFFER_DAYS_QUALIFYING_STATUSES:
            return None

        if not _safe_date(row.get("Submitted To Uni")):
            return None

        application = (row.get("Application") or "").strip()
        if application:
            return None

        return "Submitted To Uni date is recorded but no Application Manager is assigned yet."


class QAPassedMissingDocsApprovedRule(HealthcheckRule):
    id = "qa_passed_missing_docs_approved"
    name = "QA Passed but Docs Approved missing"

    def evaluate(self, row):
        created = _safe_date(row.get("Created"))
        if not created or created <= DATE_COMPLETENESS_CUTOFF:
            return None

        if not _safe_date(row.get("QA Passed")):
            return None

        if _safe_date(row.get("Docs Approved")):
            return None

        return "QA Passed date is recorded but Docs Approved date is missing."


class ApprovedButPendingSubmissionRule(HealthcheckRule):
    id = "approved_but_pending_submission"
    name = "Approved but still Pending Submission"

    # A current-state contradiction, independent of Submitted To Uni - that
    # date-based case is already covered by ApprovedMissingSubmittedToUniRule
    # and SubmittedToUniNotApprovedRule above and deliberately stays separate.
    # No Created-date cutoff either: this is about the current values, not
    # migration-era data completeness.
    def evaluate(self, row):
        sub_status = (row.get("Sub Status") or "").strip().lower()
        if sub_status != "approved":
            return None

        status = (row.get("Status") or "").strip().lower()
        if status != "03-pendingsubmission":
            return None

        return "Sub Status is Approved but application is still at 03-PendingSubmission."


def _business_days_since(calendar_days_ago, reference_date=None):
    """Convert a "N calendar days ago" count into the number of Monday-
    Friday business days between then and `reference_date` (defaults to
    today, UK time) - weekends within that span don't count toward the
    total, so a stretch that includes a weekend takes longer to reach a
    given business-day threshold than one that doesn't."""
    if reference_date is None:
        reference_date = _today_uk()
    start = reference_date - timedelta(days=calendar_days_ago)
    business_days = 0
    current = start
    while current < reference_date:
        current += timedelta(days=1)
        if current.weekday() < 5:  # Monday=0 ... Friday=4
            business_days += 1
    return business_days


class _StageStuckRule(HealthcheckRule):
    """Shared base for "been on <stage> for N+ business days, excluding
    weekends" rules - both New App and QA read the same Stage Length
    column and use the same business-day counting, just against a
    different Status and threshold. Silent (no issue) whenever Stage
    Length is missing or unparseable, rather than guessing."""

    status_value = None
    stage_name = None
    threshold_business_days = 4

    def evaluate(self, row):
        status = (row.get("Status") or "").strip()
        if status != self.status_value:
            return None

        calendar_days = _parse_stage_length_days(row.get("Stage Length"))
        if calendar_days is None:
            return None

        business_days = _business_days_since(calendar_days)
        if business_days < self.threshold_business_days:
            return None

        return (
            f"Been on {self.stage_name} for {business_days} business day(s) "
            f"({calendar_days} calendar day(s)), excluding weekends."
        )


class NewAppStuckRule(_StageStuckRule):
    id = "new_app_stuck"
    name = "Stuck on New App"
    status_value = "01-NewApp"
    stage_name = "New App"


class QAStuckRule(_StageStuckRule):
    id = "qa_stuck"
    name = "Stuck on QA"
    status_value = "02-PendingQA"
    stage_name = "QA"


class DuplicateStudentCodeOpenApplicationsRule(HealthcheckDatasetRule):
    id = "duplicate_student_code_open_applications"
    name = "Duplicate Student Code - Open Applications"

    # Statuses that mean an application is no longer live - none of these
    # count toward "open" for this rule. 10-Lost was the only one handled
    # originally; 00-QARejected (rejected at QA) and 11-Deferred (paused,
    # not progressing) are just as closed and were being miscounted as
    # open, which produced false "Two Open Applications" flags for every
    # student who simply had one live application plus one rejected/
    # deferred attempt.
    _CLOSED_STATUSES = {"10-lost", "00-qarejected", "11-deferred"}

    def evaluate(self, rows):
        open_counts = {}
        for row in rows:
            status = (row.get("Status") or "").strip().lower()
            if status in self._CLOSED_STATUSES:
                continue

            student_code = (row.get("Student Code") or "").strip()
            if not student_code:
                # Student Code is system-generated and should always be
                # present; an unexpected blank must never be grouped into a
                # fake "duplicate" with other blanks.
                continue

            open_counts[student_code] = open_counts.get(student_code, 0) + 1

        return [
            (student_code, "Two Open Applications")
            for student_code, count in open_counts.items()
            if count >= 2
        ]


class UnassignedSupportSubmittedRule(HealthcheckDatasetRule):
    id = "unassigned_support_submitted"
    name = "Unassigned Support (this month's submissions)"

    # Mirrors the Submissions page's "Unassigned" chart bucket for its
    # default (most recent) month - the "most recent month with data" logic
    # below matches submissions.list_available_months()[0] exactly (same
    # "highest year, then highest month" ordering), computed independently
    # here rather than imported so this rule doesn't depend on a
    # page-specific feature module, and so the dataset only needs one pass
    # instead of one pass to find the month plus a second pass to filter it.
    # A dataset rule rather than a per-row one because determining "the
    # most recent month with data" needs to see every row at once, not just
    # the one being evaluated.
    def evaluate(self, rows):
        by_month = {}
        for row in rows:
            submitted = _safe_date(row.get("Submitted To Uni"))
            if not submitted:
                continue
            by_month.setdefault((submitted.year, submitted.month), []).append(row)

        if not by_month:
            return []

        latest_month_rows = by_month[max(by_month)]

        issues = []
        for row in latest_month_rows:
            support = (row.get("Support") or "").strip()
            if support:
                continue

            student_code = (row.get("Student Code") or "").strip()
            issues.append(
                (student_code, "Submitted To Uni date is recorded but no Support person is assigned.")
            )
        return issues


RULES = [
    InvalidConsultantMappingRule(),
    ApplicationManagerStillAdmissionsRule(),
    MultipleAdmissionOfficersRule(),
    ApprovedMissingSubmittedToUniRule(),
    SubmittedToUniNotApprovedRule(),
    UnassignedApplicationManagerPreOfferRule(),
    QAPassedMissingDocsApprovedRule(),
    ApprovedButPendingSubmissionRule(),
    NewAppStuckRule(),
    QAStuckRule(),
]

DATASET_RULES = [
    DuplicateStudentCodeOpenApplicationsRule(),
    UnassignedSupportSubmittedRule(),
]


def run_healthcheck(rows):
    issues = []
    for row in rows:
        student_code = row.get("Student Code", "")
        for rule in RULES:
            try:
                message = rule.evaluate(row)
            except Exception:
                # A single rule/row failure must never take down the whole
                # To Do List - treat it as "no issue found" for this row, but
                # it must not disappear silently either: log it (with enough
                # detail to diagnose) so a broken rule gets noticed. Logging
                # itself must never be allowed to crash the engine either.
                try:
                    logger.exception(
                        "Healthcheck rule '%s' (id=%s) raised an unexpected exception "
                        "while evaluating Student Code '%s' - skipping this rule for "
                        "this record.",
                        rule.name,
                        rule.id,
                        student_code,
                    )
                except Exception:
                    pass
                continue
            if message:
                issues.append(
                    {
                        "student_code": student_code,
                        "rule_id": rule.id,
                        "rule_name": rule.name,
                        "message": message,
                    }
                )

    for rule in DATASET_RULES:
        try:
            rule_issues = rule.evaluate(rows)
        except Exception:
            # Same isolation/logging guarantee as a single row-rule failure:
            # a broken dataset-level rule must not take down the rest of the
            # engine, and must not fail silently either.
            try:
                logger.exception(
                    "Dataset-level Healthcheck rule '%s' (id=%s) raised an unexpected "
                    "exception while evaluating the active dataset - skipping this rule.",
                    rule.name,
                    rule.id,
                )
            except Exception:
                pass
            continue

        for student_code, message in rule_issues:
            issues.append(
                {
                    "student_code": student_code,
                    "rule_id": rule.id,
                    "rule_name": rule.name,
                    "message": message,
                }
            )

    return issues
