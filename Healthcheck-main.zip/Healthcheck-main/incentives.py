"""Incentives: campaigns that reward Consultants for enrolments.

Each incentive is a fixed set of rules (see INCENTIVES): which University's
applications (or which group of Universities), which Intake, the earliest QA Passed
date (if it has one), the lead Source they must come from (if it has one), and how
many enrolments trigger it (some have several levels, e.g. 5, 10 and 20; some cover a
whole year's intakes, or several months of one, rather than one month's; some have no
trigger at all and are just a list of the enrolled applications; one pays a higher
rate once everyone together has reached a team total). The Incentives page shows, for each, the pipeline of the
qualifying applications by Consultant, in the University Pipeline's chart style,
with how close each Consultant is to the trigger.

Everything is read live from the current active Applications data - nothing is
stored - so a new upload or reprocess is reflected the next time the page loads.
"""

from collections import Counter
from dataclasses import dataclass
from datetime import date
from typing import Optional, Tuple

from dateutils import safe_date
from pipeline import (
    PIPELINE_HEALTH_STAGE_GROUPS,
    _fold_unassigned,
    _intake_year,
    application_records,
    build_pipeline_report,
    build_stage_group_chart_groups,
    intake_month_number,
    report_group_rows,
)

ENROLLED_STATUS = "09-Enrolled"

# The Incentives page's tabs: (key in the address, as ?tab=, and the label). The first is the
# page's own - what /incentives shows without a ?tab= - and each Incentive says which tab it is on.
INCENTIVE_TABS = (("2026", "2026"), ("2027-intake-01", "2027 Intake 01"))


# The enrolled-applications list's columns: key in enrolled_applications() -> heading.
LIST_COLUMN_LABELS = {
    "consultant": "Consultant",
    "manager": "Application Manager",
    "code": "PES Code",
    "student": "Student Name",
    "university": "University",
    "course": "Course",
}


@dataclass(frozen=True)
class Incentive:
    key: str                    # in the page's links, e.g. "incentive_1"
    title: str                  # "Incentive 1"
    university: str             # University Name, matched whole, ignoring case/spacing
    intake_month: Optional[int]  # 11 = November (None: any month of intake_year)
    intake_year: int
    qa_approved_from: Optional[date]    # QA Passed on or after this day (None: any QA Passed date)
    triggers: Tuple[int, ...]   # enrolments that trigger the incentive, lowest first (several = levels); () = no chart, just the list
    show_enrolled_list: bool = False    # list the enrolled applications (under the chart, if it has one)
    list_columns: Tuple[str, ...] = ("consultant", "course", "code", "student")     # the list's columns, keys of LIST_COLUMN_LABELS
    list_min_enrolled: int = 0  # list only Consultants with at least this many enrolled applications (0: everyone)
    tab: str = INCENTIVE_TABS[0][0]     # the page tab it is shown on, a key of INCENTIVE_TABS (the 2026 incentives are on the first)
    universities: Tuple[str, ...] = ()  # a group of Universities, each matched whole; `university` then names the group (empty: just `university`)
    intake_months: Tuple[int, ...] = ()     # several months of intake_year, e.g. (1, 2, 3) (empty: intake_month, or any month)
    source: Optional[str] = None    # only applications from this lead Source (e.g. "Paid Ad") count towards a Consultant (None: any Source)
    team_target: int = 0            # enrolments of everyone together (any Source) that raise the rate (0: no such rule)
    rate: int = 0                   # £ paid per enrolled student (0: the incentive does not state one)
    raised_rate: int = 0            # the rate once team_target is reached
    rule_text: str = ""             # the rule line exactly as it should read on the page, instead of the one worked out from the rules

    @property
    def has_chart(self):
        return bool(self.triggers)

    @property
    def covered_universities(self):
        return self.universities or (self.university,)

    @property
    def months(self):
        """The months of the intake year it covers, in order - () for any month."""
        if self.intake_months:
            return tuple(sorted(self.intake_months))
        return (self.intake_month,) if self.intake_month is not None else ()

    @property
    def intake_label(self):
        months = self.months
        if not months:
            return str(self.intake_year)
        name = lambda m: f"{date(self.intake_year, m, 1):%B}"
        if len(months) == 1:
            return f"{name(months[0])} {self.intake_year}"
        if months[-1] - months[0] == len(months) - 1:
            return f"{name(months[0])} to {name(months[-1])} {self.intake_year}"
        return f"{', '.join(name(m) for m in months[:-1])} and {name(months[-1])} {self.intake_year}"

    @property
    def subject(self):
        """Who the applications are for: "LSC", or "Callum and Matthews (UCLAN, ARU and UOGM)"."""
        if not self.universities:
            return self.university
        names = f"{', '.join(self.universities[:-1])} and {self.universities[-1]}" if len(self.universities) > 1 else self.universities[0]
        return f"{self.university} ({names})"

    @property
    def description(self):
        if self.rule_text:
            return self.rule_text
        if self.qa_approved_from is None:
            qa = "whose QA has been approved"
        else:
            qa = f"whose QA was approved on or after {self.qa_approved_from.day} {self.qa_approved_from:%B %Y}"
        what = f"{self.source} applications" if self.source else "applications"
        if not self.triggers:
            text = f"{self.subject} {self.intake_label} intake {what} {qa} and are enrolled."
            if self.list_min_enrolled:
                text += f" Only Consultants with {self.list_min_enrolled} or more enrolled are listed."
            return text
        return f"{self.subject} {self.intake_label} intake {what} {qa}. {self.triggers_text}."

    @property
    def triggers_text(self):
        """"Triggered at 5 enrolments" or "Triggers at 5, 10 and 20 enrolments"."""
        if len(self.triggers) == 1:
            return f"Triggered at {self.triggers[0]} enrolments"
        return f"Triggers at {', '.join(str(t) for t in self.triggers[:-1])} and {self.triggers[-1]} enrolments"


INCENTIVES = (
    Incentive(
        key="incentive_1",
        title="Incentive 1",
        university="LSC",
        intake_month=11,
        intake_year=2026,
        qa_approved_from=date(2026, 10, 9),
        triggers=(5,),
    ),
    Incentive(
        key="incentive_2",
        title="Incentive 2",
        university="QA Limited",
        intake_month=11,
        intake_year=2026,
        qa_approved_from=None,
        triggers=(5, 10, 20),
    ),
    Incentive(
        key="incentive_3",
        title="Incentive 3",
        university="ULAW",
        intake_month=None,
        intake_year=2026,
        qa_approved_from=None,
        triggers=(2, 5),
        show_enrolled_list=True,
    ),
    Incentive(
        key="incentive_4",
        title="Incentive 4",
        university="TSD",
        intake_month=None,
        intake_year=2026,
        qa_approved_from=date(2026, 7, 24),
        triggers=(),
        show_enrolled_list=True,
        list_columns=("consultant", "manager", "code", "student", "university", "course"),
        list_min_enrolled=10,
    ),
    Incentive(
        key="incentive_2027_1",
        title="Incentive 1",
        university="Callum and Matthews",       # the name of the group of Universities below
        universities=("UCLAN", "ARU", "UOGM"),
        intake_month=None,
        intake_months=(1, 2, 3),
        intake_year=2027,
        qa_approved_from=None,
        triggers=(4,),
        source="Paid Ad",
        team_target=50,
        rate=250,
        raised_rate=500,
        rule_text=(
            "For ARU, UCLAN and UOGM, 4 Enrolled from Paid Ad lead sources only = \u00a3250 per student bonus. "
            "If 50 are enrolled into all 3 universities as a team from any source, the Paid Ad qualifying enrolments doubles to \u00a3500 per student."
        ),
        tab="2027-intake-01",
    ),
)
INCENTIVES_BY_KEY = {incentive.key: incentive for incentive in INCENTIVES}


def qualifying_rows(rows, incentive, any_source=False):
    """The applications that count towards `incentive`: its University (or any of its
    group of Universities), its Intake (the month and year, any of its months of the year,
    or any month of the year if it has none), and a QA Passed date on or after its start
    day (any date, if it has no start day). An application with no usable QA Passed date
    does not qualify. If the incentive has a lead Source, only applications from it
    qualify - unless `any_source`, for a count of everyone's whatever their Source."""
    wanted_universities = {name.strip().lower() for name in incentive.covered_universities}
    wanted_months = incentive.months
    wanted_source = incentive.source.strip().lower() if incentive.source and not any_source else None
    result = []
    for row in rows:
        if (row.get("University Name") or "").strip().lower() not in wanted_universities:
            continue
        intake = row.get("Intake")
        if _intake_year(intake) != incentive.intake_year:
            continue
        if wanted_months and intake_month_number(intake) not in wanted_months:
            continue
        passed = safe_date(row.get("QA Passed"))
        if passed is None or (incentive.qa_approved_from is not None and passed < incentive.qa_approved_from):
            continue
        if wanted_source is not None and (row.get("Source") or "").strip().lower() != wanted_source:
            continue
        result.append(row)
    return result


def build_incentive(rows, incentive, forecast_percentages):
    """Everything the Incentives page shows for one incentive:

    An incentive with no triggers has no chart: "report" is None, "chart_groups" and
    "consultants" are empty and "summary" has just the total and enrolled counts.

    - "report": the pipeline of the qualifying applications by Consultant (a
      blank Consultant is "Unassigned"), most applications first, built with
      keep_rows=True so a piece of the chart can list its applications.
    - "chart_groups": the University Pipeline's stage-group chart for that report.
    - "consultants": one entry per Consultant in the chart's order -
      {"name", "enrolled", "triggered", "level", "next", "target", "remaining"} -
      where enrolled is their 09-Enrolled applications, triggered is enrolled >=
      the lowest trigger, level is how many triggers they have reached, next is
      the next trigger up (None once they have reached them all), remaining is
      how many more enrolments that takes (0 if none) and target is what the
      Enrolled pill shows them against: the next trigger, or the highest one.
    - "enrolled_list": for an incentive with show_enrolled_list, its 09-Enrolled
      applications as [{"consultant", "course", "code", "student"}] (see
      enrolled_applications); otherwise [].
    - "unassigned_list": for an incentive with a Consultant minimum, the qualifying
      enrolled applications that have no Consultant (the same fields) - which the
      minimum can never list - so they can be checked; otherwise [].
    - "summary": the Overall card's figures plus enrolled, how many Consultants
      have triggered it and, per trigger, how many have reached it ("tiers"), and
      "team": for an incentive with a team target, the enrolments of everyone together
      whatever their Source - {"enrolled", "target", "reached", "rate"} (rate being the
      raised one once reached) - otherwise None."""
    qualifying = qualifying_rows(rows, incentive)
    team = team_total(rows, incentive)
    enrolled_list = enrolled_applications(qualifying, incentive.list_min_enrolled) if incentive.show_enrolled_list else []
    # What the Consultant minimum leaves out for want of a Consultant, so it can be checked by hand.
    unassigned_list = [r for r in enrolled_applications(qualifying) if r["consultant"] == "Unassigned"] if incentive.list_min_enrolled else []
    if not incentive.has_chart:
        summary = {"total": len(qualifying), "enrolled": sum(1 for r in qualifying if (r.get("Status") or "").strip() == ENROLLED_STATUS), "team": team}
        return {"incentive": incentive, "report": None, "chart_groups": [], "consultants": [], "enrolled_list": enrolled_list, "unassigned_list": unassigned_list, "summary": summary}

    report = build_pipeline_report(
        qualifying,
        forecast_percentages,
        person_field="Consultant",
        group_field=None,
        excluded_persons=None,
        hidden_persons=None,
        group_priority=None,
        blank_person_label="Unassigned",
        rank_by_total=True,
        keep_rows=True,
    )
    chart_groups = build_stage_group_chart_groups(report, PIPELINE_HEALTH_STAGE_GROUPS, forecast_percentages)

    people = [person for group in report["office_groups"] for person in group["managers"]]
    consultants = []
    by_name = {person["name"]: person for person in people}
    for group in chart_groups:
        for row in group["rows"]:
            enrolled = by_name[row["name"]]["counts"][ENROLLED_STATUS]
            upcoming = next((t for t in incentive.triggers if enrolled < t), None)
            consultants.append(
                {
                    "name": row["name"],
                    "enrolled": enrolled,
                    "triggered": enrolled >= incentive.triggers[0],
                    "level": sum(1 for t in incentive.triggers if enrolled >= t),
                    "next": upcoming,
                    "target": upcoming if upcoming is not None else incentive.triggers[-1],
                    "remaining": upcoming - enrolled if upcoming is not None else 0,
                }
            )
    summary = {
        "total": report["grand_total_records"],
        "enrolled": report["grand_total_counts"][ENROLLED_STATUS],
        "forecast": report["grand_total_forecast"],
        "conversion": report["grand_total_conversion"],
        "triggered": sum(1 for c in consultants if c["triggered"]),
        "tiers": [{"enrolments": t, "consultants": sum(1 for c in consultants if c["enrolled"] >= t)} for t in incentive.triggers],
        "consultants": len(consultants),
        "team": team,
    }
    return {"incentive": incentive, "report": report, "chart_groups": chart_groups, "consultants": consultants, "enrolled_list": enrolled_list, "unassigned_list": unassigned_list, "summary": summary}


def team_total(rows, incentive):
    """The incentive's team target: the 09-Enrolled applications of everyone together that
    meet its University, Intake and QA rules from any lead Source, against its target -
    {"enrolled", "target", "reached", "rate"}; None if it has no team target."""
    if not incentive.team_target:
        return None
    enrolled = sum(1 for r in qualifying_rows(rows, incentive, any_source=True) if (r.get("Status") or "").strip() == ENROLLED_STATUS)
    reached = enrolled >= incentive.team_target
    return {"enrolled": enrolled, "target": incentive.team_target, "reached": reached, "rate": incentive.raised_rate if reached else incentive.rate}


def enrolled_applications(rows, min_per_consultant=0):
    """The 09-Enrolled applications among `rows` as plain dicts - the Consultant and
    Application Manager (a blank one is "Unassigned"), the Course, University, PES
    Code and Student Name (see LIST_COLUMN_LABELS) - sorted by Consultant (A to Z,
    Unassigned last), then Student Name and PES Code.

    With `min_per_consultant`, only Consultants who have at least that many
    enrolled applications in `rows` are listed (all of theirs). "Unassigned" is not
    a Consultant, so it is never listed then."""
    listed = [
        {
            "consultant": _fold_unassigned(row.get("Consultant")),
            "manager": _fold_unassigned(row.get("Application")),
            "university": (row.get("University Name") or "").strip(),
            "course": (row.get("Course Name") or "").strip(),
            "code": (row.get("Student Code") or "").strip(),
            "student": (row.get("Student Name") or "").strip(),
        }
        for row in rows
        if (row.get("Status") or "").strip() == ENROLLED_STATUS
    ]
    if min_per_consultant:
        counts = Counter(r["consultant"] for r in listed)
        listed = [r for r in listed if r["consultant"] != "Unassigned" and counts[r["consultant"]] >= min_per_consultant]
    return sorted(listed, key=lambda r: (r["consultant"] == "Unassigned", r["consultant"].lower(), r["consultant"], r["student"].lower(), r["code"]))


def incentive_records(report, consultant, group_key):
    """The applications behind one piece of an incentive's chart: `consultant`'s
    applications in the stage group called `group_key`, as the click-through
    window's records (see pipeline.application_records). None if there is no such group."""
    group = next((g for g in PIPELINE_HEALTH_STAGE_GROUPS if g["key"] == group_key), None)
    if group is None:
        return None
    return application_records(report_group_rows(report, consultant, group["stages"]))
